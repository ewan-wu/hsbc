#!/bin/sh
SHELL=/bin/sh
echo `date` >> $APPL/log/action_time.log
at -f $APPL/sbin/clear_action.sh now + 4 hours
#at -f $APPL/sbin/clear_action.sh now + 1 minute
#at -f $APPL/sbin/clear_action.sh now
