cd $APPL/tongji
mv *.txt bak
rm -f tmp.data
tt=`date '+%C%y%m%d%T'`
echo $tt
orafile="oracle"$tt.txt
sysfile="sys"$tt.txt
touch $orafile
while [ 1 ]; do
    echo "------------------------begin-------------------------" >>$orafile 
    echo "At time: " `date '+%C%y%m%d%T'` >>$orafile
	sqlplus -s ${DBUSER}/${DBPWD} <<EOF > /dev/null
    spool tmp.data
    select count(count) "���ʱ���" from bepsbtmng where drct='1';
    select count(count) "���ʱ���" from bepsbtmng where drct='2';
    spool off;
    exit
EOF
    cat tmp.data >> $orafile
	echo "----------------------end------------------------" >> $orafile
    echo "---------------------begin-----------------------------------" >>$sysfile
    echo "At time: " `date '+%C%y%m%d%T'`  >> $sysfile
     sar 1 5 >> $sysfile
     iostat 1 5 >> $sysfile
     vmstat 1 5 >> $sysfile
    echo "---------------------end----------------------------------- " >> $sysfile
	 sleep 5 
done


