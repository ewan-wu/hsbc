#!/usr/bin/sh

if [ $# != 3 ]
then
	echo "Usage: ConvRpt2Win.sh [RPTFILE] [TLRNO] [BRNO]"
	exit 1
fi

echo "DAT,OL_HOR" > /tmp/ONLINE.txt.$2.$3
cat $1 | sed "s///g" | tr "" "\n" >> /tmp/ONLINE.txt.$2.$3
