#!/usr/bin/perl
my ($sec,$min,$hour,$mday,$mon,$year)=localtime(time());
my $date=sprintf "%4d%02d%02d", (1900+$year),($mon+1),$mday;
my $FileName="/archivelog/h2h_dump/h2h$date.dmp";
my $DbUser=$ENV{DBUSER};
my $DbPwd=$ENV{DBPWD};
my $DbSvr=$ENV{ORACLE_SID};
system("exp $DbUser/$DbPwd\@$DbSvr file=$FileName");

