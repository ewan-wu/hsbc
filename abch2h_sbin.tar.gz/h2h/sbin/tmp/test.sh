#!/usr/bin/sh
FILEHOME="/tstapp/tstbeps/beps/sbin/tmp"
cd $FILEHOME
rm -f date.tmp
rm -f username.tmp
echo `date`
sqlplus -s ${DBUSER}/${DBPWD} <<EOF > /dev/null
	set term off;
	set echo off;
	set timing off;
	set heading off;
	set feedback off;
	set pagesize 0;
	set linesize 1000;
	set trimspool on;
	set trimout on;
	set colsep ":";
	set newp none;
	set WRAP off;

	spool date.tmp;
	select work_date,to_char(to_date(work_date,'YYYYMMDD')-30,'YYYYMMDD') from bsysctl;
	spool off;
	exit
EOF

DUMPDATE=`cat date.tmp|cut -d':' -f1|cut -c1-8`
DELEDATE=`cat date.tmp|cut -d':' -f2|cut -c1-8`
FILENAME=$FILEHOME"/"'DATA_DUMP_'$DUMPDATE".dmp"
LOGNAME=$FILEHOME"/DATA_DUMP_"$DUMPDATE".log"
echo $FILENAME
echo $DELEDATE

delstr1=`echo $DELEDATE|cut -c5-8`
delstr2=$DELEDATE
delstr3=`echo $DELEDATE|cut -c3-8`
FILETYPE=BH$delstr1*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=FE$delstr1*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=BH$delstr3*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE="RCV[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"$delstr2*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE="RCV[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"$delstr2*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=RCV$delstr2*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=$delstr2"ERR*"
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=CBCB$delstr1.LCL*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=BKCBCB$delstr1.LCL*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=HB$delstr1*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;

FILETYPE=BKHB$delstr1*
#echo $FILETYPE
find . -name "$FILETYPE" -exec rm -f {} \;
echo `date`