#!/bin/sh

FILES=`ls ${MKHOME}/db/createsql/*/*.sql`

cd ${MKHOME}/tmp
#rm -f dbsvr_*.ec
rm -f dbsvr_*.pc
rm -f *_HVAR.h
rm -f *.wd
rm -f *_wd.h
rm -f liblpsdbsvr.exp
rm -f lpsdbsvr.mak

cat /dev/null > dbsvr.obj
cat /dev/null > liblpsdbsvr.exp
cp ${MKHOME}/src/tools/gendbs/tmp.mak ${MKHOME}/tmp
#cp ${MKHOME}/src/tools/gendbs/dbsvr_stub.ec ${MKHOME}/tmp
cp ${MKHOME}/src/tools/gendbs/dbsvr_stub.pc ${MKHOME}/tmp

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	dir=`dirname ${file}`
	module=`basename ${dir}`
	echo ${module} ${table}
	gendbs ${module} ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
	echo "\t\$(SRCHOME)/dbsvr_${table}.o \\" >> dbsvr.obj
	upcase=`echo $table | awk '{print toupper($1)}'`
	echo "Dbs${upcase}" >> liblpsdbsvr.exp
done

MODULES=`ls -1 *.wd | cut -f1 -d "_" | sort | uniq`
for module in ${MODULES}
do
	echo ${module}
	upcase=`echo ${module} | awk '{print toupper($1)}'`
	echo "#ifndef ${upcase}_WD_H" > ${module}_wd.h
	echo "#define ${upcase}_WD_H" >> ${module}_wd.h
	cat ${module}_*.wd >> ${module}_wd.h
	echo "" >> ${module}_wd.h
	echo "#endif" >> ${module}_wd.h
done

sed "/^PRGOBJS/r dbsvr.obj" tmp.mak > lpsdbsvr.mak

#mv -f dbsvr_*.ec ${MKHOME}/src/dbsvr
mv -f dbsvr_*.pc ${MKHOME}/src/dbsvr
mv -f lpsdbsvr.mak ${MKHOME}/src/dbsvr
mv -f liblpsdbsvr.exp ${MKHOME}/mak/exp
mv -f *_HVAR.h ${MKHOME}/incl/dbincl
mv -f *_wd.h ${MKHOME}/incl
rm -f *.wd
