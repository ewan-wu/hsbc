#!/bin/sh

FILES=`ls ${APPL}/db/sql/*.sql`

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	genctl_b ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
done

FILES=`ls ${APPL}/db/createsql/be/*.sql`

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	genctl be ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
done

FILES=`ls ${APPL}/db/createsql/sys/*.sql`

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	genctl sys ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
done

exit 0

