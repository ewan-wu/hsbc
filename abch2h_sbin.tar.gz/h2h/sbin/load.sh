table=$1
sed s/\$/\|/ ${table}.txt > ${table}.txt2
#cp ${table}.unl ${table}.bak
#mv -f ${table}.txt2 ${table}.unl
loadsql.sh ${table} > /dev/null
if [ $? -ne 0 ]
then
	echo "error"
	exit 1
fi
rm -f ${table}.txt2

