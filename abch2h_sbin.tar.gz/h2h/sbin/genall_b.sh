#!/bin/sh

FILES=`ls ${APPL}/db/sql/*.sql`

cd ${APPL}/tmp
/usr/bin/rm -f libdbsvr_b.exp
/usr/bin/rm -f dbsvr_b.mak
/usr/bin/rm -f wd_incl.h

cat /dev/null > dbsvr_b.obj
cat /dev/null > libdbsvr_b.exp
/usr/bin/cp ${APPL}/src/tools/gendbs_b/tmp.mak ${APPL}/tmp
/usr/bin/cp ${APPL}/src/tools/gendbs_b/dbsvr_stub.pc ${APPL}/src/dbsvr_b

echo "#ifndef _WD_INCL_H" > wd_incl.h
echo "#define _WD_INCL_H" >> wd_incl.h

for file in ${FILES}
do
	table=`basename ${file} | cut -f1 -d "."`
	echo ${table}
	gendbs_b ${table} > /dev/null
	if [ $? -ne 0 ]
	then
		echo "error"
		exit 1
	fi
	echo "\t\$(SRCHOME)/dbsvr_${table}.o \\" >> dbsvr_b.obj
	echo "\t\$(SRCHOME)/init_${table}_hvar.o \\" >> dbsvr_b.obj
	upcase=`echo $table | /usr/bin/awk '{print toupper($1)}'`
	#echo "Dbs${upcase}" >> libdbsvr_b.exp
	cat ${APPL}/incl/dbincl/${table}.wd >> wd_incl.h
done

echo "#endif" >> wd_incl.h

sed "/^PRGOBJS/r dbsvr_b.obj" tmp.mak > dbsvr_b.mak

/usr/bin/mv -f dbsvr_b.mak ${APPL}/src/dbsvr_b
#/usr/bin/mv -f libdbsvr_b.exp ${APPL}/mak/exp
/usr/bin/mv -f wd_incl.h ${APPL}/incl/dbincl
/usr/bin/rm -f ${APPL}/incl/dbincl/*.wd

