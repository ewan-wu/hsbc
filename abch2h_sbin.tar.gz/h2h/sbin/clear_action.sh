#!/bin/sh
echo `date` >> $APPL/log/action_time.log
FILEHOME="$IODATA/dbback"
cd $FILEHOME
rm -f date.tmp
rm -f username.tmp

sqlplus -s ${DBUSER}/${DBPWD} <<EOF > /dev/null
	set term off;
	set echo off;
	set timing off;
	set heading off;
	set feedback off;
	set pagesize 0;
	set linesize 1000;
	set trimspool on;
	set trimout on;
	set colsep ":";
	set newp none;
	set WRAP off;

	spool date.tmp;
	select work_date,to_char(to_date(work_date,'YYYYMMDD')-30,'YYYYMMDD') from bsysctl;
	spool off;
	#spool username.tmp;
	#select username from dba_users where default_tablespace='USERS';
	#spool off;
	exit
EOF

echo $DBUSER > username.tmp 
DUMPDATE=`cat date.tmp|cut -d':' -f1|cut -c1-8`
DELEDATE=`cat date.tmp|cut -d':' -f2|cut -c1-8`
FILENAME=$FILEHOME"/"'DATA_DUMP_'$DUMPDATE".dmp"
LOGNAME=$FILEHOME"/DATA_DUMP_"$DUMPDATE".log"
DBNAME=$FILEHOME"/dbdata/DATA_DUMP.dmp.gz"
echo $FILENAME
echo $DELEDATE
NLS_LANG=american_america.ZHS16GBK;export NLS_LANG
USERS=""
for one in `cat username.tmp`
do
    if [ "A"$USERS = "A" ] 
	then
	   USERS=$one
    else
	   USERS=$USERS","$one
    fi 
done
echo $USERS

if [ -p /tmp/tmp_pipe ]
then
   if [ -r /tmp/tmp_pipe -a -w /tmp/tmp_pipe ]
   then
	  echo "Begin to export database user("$USERS")'s tables"
	  gzip < /tmp/tmp_pipe > $FILENAME.gz &
      exp userid=${DBUSER}/${DBPWD} owner=$USERS file=/tmp/tmp_pipe grants=Y log=$LOGNAME
   else
	  chmod a+rw /tmp/tmp_pipe
   fi
   cp $FILENAME.gz $DBNAME
else
   mknod /tmp/tmp_pipe p
fi

echo "Begin to delete the history data"

echo "use "$APPL"/sbin/del_info.txt to delete records before 30 days"

TMPSQLFILE=$FILEHOME/tmpsql.txt
DELLOGFILE=$FILEHOME/del.log
cp /dev/null $DELLOGFILE
cp /dev/null $TMPSQLFILE

echo "Do delete at "`date '+%Y%m%d-%T'` >> $DELLOGFILE
for field in `cat $APPL/sbin/del_info.txt`
do
   tablename=`echo $field|cut -d',' -f1`
   fieldname=`echo $field|cut -d',' -f2`
   datelen=`echo $field|cut -d',' -f3`
   if [ "A"$datelen = "A"$tablename -a "A"$fieldname = "A"$tablename ]
   then
	  fieldname="txdate"
	  echo "delete from "$tablename " where "$fieldname"<'"$DELEDATE"';" > $TMPSQLFILE
   else
	  if [ "A"$datelen = "A8" ]
	  then
		 echo "delete from "$tablename " where substr("$fieldname",1,8)<'"$DELEDATE"';" > $TMPSQLFILE
      else if [ "A"$datelen = "A10" ]
		   then
			  DELEDATE1=`echo $DELEDATE|cut -c1-4`"/"`echo $DELEDATE|cut -c5-6`"/"`echo $DELEDATE|cut -c7-8`
              echo "delete from "$tablename " where substr("$fieldname",1,10)<'"$DELEDATE1"';" > $TMPSQLFILE
           else
			  echo "delete from "$tablename " where "$fieldname"<'$DELEDATE';" > $TMPSQLFILE
           fi
      fi
   fi
   cat $TMPSQLFILE >> $DELLOGFILE
   sqlplus -s $DBUSER/$DBPWD < $TMPSQLFILE >> $DELLOGFILE
   if [ $? != 0 ]
   then
	  echo "delete failed! please check the sql" >> $DELLOGFILE
   else
	  echo "delete successfully" >> $DELLOGFILE
   fi
done

echo "Begin to delete data file"


echo "find -L $IODATA -type f -mtime +31 -exec rm -f {} \;"
find -L $IODATA -type f -mtime +31 -exec rm -f {} \;
echo "End of delete data file"

echo "Begin to delete log&report file"
LOGFILE=$APPL"/log/"$DELEDATE
echo "rm -fr "$LOGFILE
rm -fr $LOGFILE
