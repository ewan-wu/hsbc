sqlldr userid=$DBUSER/$DBPWD control=$APPL/db/ctl/$1.ctl

