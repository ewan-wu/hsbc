FILE=${APPL}/sbin/netstat.data
IP=172.26.188.82
COUNT=0
COUNT=`netstat -na | grep $IP | grep ESTABLISHED | wc -l`
if [ $COUNT -lt 2 ]
then
	exit 1
else
	exit 0
fi
