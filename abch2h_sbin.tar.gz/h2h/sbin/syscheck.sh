FILE=${APPL}/sbin/sysstat.data
chkproc()
{
PROCESS=$1
COUNT=0
COUNT=`ps -fu $LOGNAME | grep $PROCESS | grep bin | grep -v grep | grep -v runprocess | wc -l`
if [ $COUNT -eq 0 ]
then
    echo "[$LOGNAME:$PROCESS]" >> $FILE
fi

}

chkmsgque()
{
COUNT=0
COUNT=`ipcs -q | grep $LOGNAME | awk '{if($6!=0) print $2}'| wc -l`
if [ $COUNT -ne 0 ]
then
echo "��Ϣ�����쳣���쳣��Ϣ����ID��" >> $FILE
ipcs -q | grep $LOGNAME | awk '{if($6!=0) print $2}' >> $FILE
fi
}
rm -f $FILE
chkproc errsvr
chkproc toctl_seq
chkproc tlrbdg
chkproc manager
chkproc mngtxn
chkproc HBFileScan
chkproc tlrcomm
chkproc BAcmdsnd
chkmsgque
exit 0

