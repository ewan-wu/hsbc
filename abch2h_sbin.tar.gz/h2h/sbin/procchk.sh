chkproc()
{
PROCESS=$1
COUNT=0
COUNT=`ps -fu $LOGNAME | grep $PROCESS | grep bin | grep -v grep | grep -v runprocess | wc -l`
if [ $COUNT -eq 0 ]
then
    echo "!!!!! WARNING !!!!! No process [$PROCESS]!!!!! CHECK!!!!!"
else
    echo "Process [$PROCESS] OK!"
fi
}

echo "[BEGIN]"

echo "=========================== <ERRSVR>  ============================"
chkproc errsvr

echo "=========================== <TOCTL>   ============================"
chkproc toctl_seq

echo "=========================== <BRIDGE>  ============================"
chkproc tlrbdg

echo "=========================== <MNGSVR>  ============================"
chkproc manager

echo "=========================== <SWTSVR>  ============================"
chkproc mngtxn
chkproc baswt
chkproc HBFileScan

#echo "=========================== <TIMER>   ============================"

echo "=========================== <COMM>    ============================"
chkproc tlrcomm
chkproc bacomm

echo "=========================== <CMDSND>  ============================"
chkproc	BAcmdsnd 
chkproc	BAcmdrcv 
echo "=========================<MSGQUE STATUS>=========================="
ipcs -q | grep h2h
echo "=========================<COMM STATUS>============================"
netstat -na | grep 172.26.187.9:9001
netstat -na | grep 172.26.188.82:8001
echo "[END]"
exit 0
