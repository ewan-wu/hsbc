sqlplus -s $DBUSER/$DBPWD <<EOF >/dev/null
set heading off;
set term off;
set echo off;
set pagesize 0;
set linesize 2500;
set trimspool on;
set trimout on;
set feedback off;
set colsep |;
set num 18;
spool output.txt;
select * from $1;
spool off;
exit
EOF
tr -d ' ' <output.txt >$1.txt
rm output.txt

