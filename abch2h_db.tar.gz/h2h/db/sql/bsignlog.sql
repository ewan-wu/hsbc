create table bsignlog
(
brno	            char(3)     not null,
dept_id             char(1)     not null,
tlr_id              char(8)     not null,
act_time            char(19)    not null,
act_type            char(1)     not null,
act_data            varchar(255),
rec_updt_time       char(19)
);
create unique index bsignlog_idx on bsignlog(brno, dept_id, tlr_id, act_time, act_type);

