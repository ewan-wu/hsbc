create table btlrpswderr
(
retryseq			char(8)     not null,
brno				char(3)     not null,
dept_id             char(1)     not null,
tlr_id              char(8)     not null,
local_time			char(14)	not null,
work_date			char(8)		not null,
retry				char(1)		not null,
memo				varchar(255),
rec_updt_time       char(19)
);
create unique index btlrpswderr_idx on btlrpswderr(retryseq);

