create table bsyslog
(
sys_log_time        char(19)    not null,
msg_src             number(6),
msg_code            number(6),
msg_subcode         number(6),
msg_level           number(6),
msg_desc            varchar(60) not null,
rec_updt_time       char(19)
);

