create table bsrvmsq
(
src_srv_id          number(8),
txn_no              number(8),
txn_step            number(1),
usage_key           number(8),
src_srv_desc        varchar(60),
srv_id              number(8),
srv_name            varchar(60),
srv_pri             number(4),
use_flag            char(1),
rsv1                varchar(30),
rsv2                varchar(30),
rec_updt_time       char(19)
);
create unique index bsrvmsq_idx on bsrvmsq(src_srv_id, txn_no, txn_step, usage_key);

