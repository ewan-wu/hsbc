create table bseqctl
(
rcd_id              char(8)     not null,
sn_len              number(2),
sn_min              number(8),
sn_max              number(8),
sn_next_apply       number(8),
rec_updt_time       char(19)
);
create unique index bseqctl_idx on bseqctl(rcd_id);

