create table bscmlog
(
brno				char(3)     not null,
dept_id             char(1)     not null,
act_time            char(19)    not null,
act_type            char(1)     not null,
act_subtype         char(1)     not null,
act_data            varchar(255),
rec_updt_time       char(19)
);
create unique index bscmlog_idx on bscmlog(dept_id, act_time, act_type, act_subtype);

