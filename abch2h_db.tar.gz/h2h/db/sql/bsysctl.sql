create table bsysctl
(
rcd_id              char(8),
sys_status          char(1),
eft_status          char(1),
cnaps_status        char(2),
cnaps_sign          char(1),
work_date           char(8),
last_work_date      char(8),
work_date_1         char(8),
work_date_2         char(8),
online_days         number(4),
history_max_days    number(4),
tlr_p_exp_days		number(4),
tlr_s_exp_days		number(4),
rec_updt_time       char(19),
namount CHAR(30),
namount1 CHAR(30),
nadate1 CHAR(8),
remarks CHAR(60)
);
create unique index bsysctl_idx on bsysctl(rcd_id);

