create table bdeptctl
(
dept_id             char(1)     not null,
dept_name           varchar(60),
work_flag           char(1)     not null,
work_type           char(1)     not null,
rec_updt_time       char(19)
);
create unique index bdeptctl_idx on bdeptctl(dept_id);

