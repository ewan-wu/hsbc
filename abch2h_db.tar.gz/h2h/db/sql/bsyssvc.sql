create table bsyssvc
(
svc_id              number(8),
svc_name            varchar(60),
msq_in_key          number(8),
msq_in_type         number(8),
msq_in_id           number(10),
msq_out_key         number(8),
msq_out_type        number(8),
msq_out_id          number(10),
svc_cfg_data        varchar(255),
rec_updt_time       char(19)
);
create unique index bsyssvc_idx on bsyssvc(svc_id);

