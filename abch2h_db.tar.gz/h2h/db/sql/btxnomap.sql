create table btxnomap
(
txn_no              number(8),
infc_id             number(8),
infc_desc           varchar(60),
out_no              char(8),
txn_desc            varchar(60),
file_flg            number(1),
fill_map            varchar(60),
fill_val            varchar(60),
sfd_flg             number(1),
rsv1                varchar(30),
rec_updt_time       char(19)
);
create unique index btxnomap_idx on btxnomap(txn_no, infc_id, out_no)

