create table btlrctl_tmp
(
opcode				char(1)     not null,
brno 	            char(3)     not null,
dept_id             char(1),
tlr_id              char(8)     not null,
tlr_name            varchar(40),
init_flag           char(1),
work_flag           char(1),
work_level          char(1),
password            char(12),
last_pswd_chg       char(8),
pswd_retry_cnt		number(2),
status              char(1),
last_status_chg     char(8),
add_by_dept_id		char(1),
add_by_tlr_id		char(8),
auth_by_dept_id		char(1),
auth_by_tlr_id		char(8),
recent_pswd_str		char(144),
rec_updt_time       char(19)
) ;
create unique index btlrctl_tmp_idx on btlrctl_tmp(opcode, brno, tlr_id);

