create table expnsdtl
(
	txdate		char(8),
	tlrno		char(8),
	tlsrno		char(7),
	brno		char(3),
	vdate		char(8),
	accode		char(5),
	extno		char(17),
	actno		char(32),
	amount		number(14),
	status		char(1),		/* δ��ȡ/����ȡ */
	type		char(1),
	txno		char(4),
	rsv1        varchar(60),
	rsv2        varchar(60),
	rsv3        varchar(60),
	rsv4        varchar(60),
	rsv5        varchar(60),
	primary key (txdate, tlrno, tlsrno)
) ;

create index expnsdtl_chk_idx on expnsdtl(vdate, brno, status);
