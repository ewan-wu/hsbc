/* �������ſ��Ʊ� */
create table remitctl
(
	txdate		char(8),
	brno		char(3),
	type		char(1),		/* 1-CNAPS 2-��ضԽ� */
	seqno		number(8),
	rsv1        varchar(60),
	rsv2        varchar(60),
	rsv3        varchar(60),
	rsv4        varchar(60),
	rsv5        varchar(60),
	primary key (txdate, type)
);
