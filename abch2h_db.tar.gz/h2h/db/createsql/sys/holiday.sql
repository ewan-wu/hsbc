CREATE TABLE holiday (
hdate   char(8),
weekdy  char(1),
work    char(1),
xend    char(1),
mend    char(1),
qend    char(1),
hend    char(1),
yend    char(1),
intday  char(1),
cxintday    char(1),
rsv1        varchar(60),
rsv2        varchar(60),
rsv3        varchar(60),
rsv4        varchar(60),
rsv5        varchar(60),
PRIMARY KEY (hdate)
) /* lock mode row */
;
