create table freefmtfile
(
	TrnDate        char (8),
	ReqSeqNo       char (30),
	Direction      char (1),
	ReqTime        char (6),
	resptime       char (6),
	RespSeqNo      char (12),
	RespCode       char(7),
	RespInfo       char(256),
	FileType       char (4),
	Postscript     char (70),
	FileName       char (80),
	TellerNo       char (8),
	rsv1           varchar(60),
	rsv2           varchar(60),
	rsv3           varchar(60),
	primary key (ReqSeqNo,Direction)
);
