create table account
(
	Acct           char (35),
	AcctName       char (70),
	OpenBankName   char (70),
	LastTranDt     char (8),
	LastTimeslice  char (26),
	LastJrnNo      char (9),
	TellerNo       char (8),
	ChckNo         char (8),
	CmdStat        char (1),
	RejReason      char (30),
	AcctStat       char (1),
	Balance        number (22),
	rsv1           varchar(60),
	rsv2           varchar(60),
	rsv3           varchar(60),
	primary key (Acct)
);