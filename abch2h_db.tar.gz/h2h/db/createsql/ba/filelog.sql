create table filelog
(
	BRNO       char(3),
	FILE_NAME  char(100),
	TRSC_TIME  char(14),
	FILE_SRC   char(2),
	InOutFlag  char(1),
	COUNT      number(8),
	AMOUNT     number(22),
	STATUS     char(1),
	ERR_CODE   char(2),
	REMARKS    char(256),
	RSV1       varchar(60),
	RSV2       varchar(60),
	RSV3       varchar(60),
	primary key (FILE_NAME,TRSC_TIME,FILE_SRC)
);
