create table payrolldetail
(
	btno              char(8),
	seqno             char(8),    
	TrnDate           char(8),
	refno             char(30),
	payeeacc          char(35),
	payeeName         char(60),
	Amt               number(22),
	payeeBankCode     char(2),
	payeeBankName     char(60),
	Remark            varchar(40),
	rsv1           		varchar(60),
	rsv2           		varchar(60),
	rsv3           		varchar(60),
	primary key (btno,seqno,TrnDate)
);         
