cat /dev/null > createall.sql

for file in `ls $APPL/db/createsql/*/*.sql`
do
	echo [$file]
	cat $file >> $APPL/db/bat/createall.sql
done

for file in `ls $APPL/db/sql/*.sql`
do
	echo [$file]
	cat $file >> $APPL/db/bat/createall.sql
done

echo "exit;" >> $APPL/db/bat/createall.sql

