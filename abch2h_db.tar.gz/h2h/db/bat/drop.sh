cat /dev/null > dropall.sql
for file in `ls $APPL/db/createsql/*/*.sql`
do
	echo [$file]
	table=`basename $file | sed -e "s/\.sql//"`
	echo "drop table $table;" >> $APPL/db/bat/dropall.sql
done
for file in `ls $APPL/db/sql/*.sql`
do
	echo [$file]
	table=`basename $file | sed -e "s/\.sql//"`
	echo "drop table $table;" >> $APPL/db/bat/dropall.sql
done

echo "exit;" >> $APPL/db/bat/dropall.sql
