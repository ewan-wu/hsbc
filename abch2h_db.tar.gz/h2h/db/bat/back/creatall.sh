cat /dev/null > creatall.sql

for file in `ls ../sql/*.sql`
do
	echo [$file]
	cat $file >> creatall.sql
	echo " " >> creatall.sql
done

for file in `ls ../createsql/*/*.sql`
do
	echo [$file]
	cat $file >> creatall.sql
	echo " " >> creatall.sql
done

echo "exit;" >> creatall.sql

