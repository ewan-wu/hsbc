cat /dev/null > dropall.sql

for file in `ls ../sql/*.sql`
do
    echo [$file]
    table=`basename $file | sed -e "s/\.sql//"`
    echo "drop table $table;" >> dropall.sql
done

for file in `ls ../createsql/*/*.sql`
do
    echo [$file]
    table=`basename $file | sed -e "s/\.sql//"`
    echo "drop table $table;" >> dropall.sql
done

echo "exit;" >> dropall.sql


