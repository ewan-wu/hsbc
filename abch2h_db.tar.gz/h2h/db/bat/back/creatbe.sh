cat /dev/null > creatbe.sql

for file in `ls ../createsql/*/*.sql`
do
	echo [$file]
	cat $file >> creatbe.sql
	echo " " >> creatbe.sql
done

echo "exit;" >> creatbe.sql

