cat /dev/null > dropbe.sql

for file in `ls ../createsql/*/*.sql`
do
    echo [$file]
    table=`basename $file | sed -e "s/\.sql//"`
    echo "drop table $table;" >> dropbe.sql
done

echo "exit;" >> dropbe.sql


