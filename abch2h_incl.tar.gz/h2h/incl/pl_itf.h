#ifndef __PL_ITF_H__
#define __PL_ITF_H__

#define MAX_ACDTL		4

typedef struct
{
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
	double	dAmount;
} ACDTL;

typedef struct
{
	char	sOpcode[DLEN_OPCODE+1];
	char	sTlsrno[DLEN_TLSRNO+1];
	char	sVdate[DLEN_DATE+1];
	char	sType[DLEN_TYPE+1];
	char	sRound[DLEN_TYPE+1];
	char	sBatchno[DLEN_BATCHNO+1];
	char	sOppName[DLEN_DESC+1];
	char	sOppActno[DLEN_LACTNO+1];
	char	sOppBank[DLEN_DESC+1];
	char	sOppBrno[DLEN_LBRNO+1];
	char	sVoctype[DLEN_VOCTYPE+1];
	char	sVocno[DLEN_VOCNO+1];
	char	sRemarks[DLEN_DESC+1];
	char	sComment[DLEN_DESC+1];
	char	sStatus[DLEN_STATUS+1];
	char	sCustRef[DLEN_CUSTREF+1];
	char	sBankRef[DLEN_BANKREF+1];
	char	sPaytype[DLEN_TYPE+1];
	ACDTL	dbdtl[MAX_ACDTL];
	ACDTL	crdtl[MAX_ACDTL];
} pTisAccount;

typedef struct
{
	struct
	{
		char	sAccode[DLEN_ACCODE+1];
		char	sActno[DLEN_ACTNO+1];
	} dbdtl[MAX_ACDTL];

	struct
	{
		char	sAccode[DLEN_ACCODE+1];
		char	sActno[DLEN_ACTNO+1];
	} crdtl[MAX_ACDTL];
} pTosAccount;

#endif
