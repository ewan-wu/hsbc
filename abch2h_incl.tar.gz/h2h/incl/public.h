#include "wd_incl.h"

#define MAX_SRVMSQ_TXN_NUM          5000
#define MAX_TXNNOMAP_TXN_NUM        3000
#define MAX_TSKSVCMAP_TXN_NUM       50
#define TXNNO_MAP_INFC_LEN          4
#define TXNNO_MAP_OUTNO_LEN         8
#define TXNNO_MAP_FILLMAP_LEN       50
#define TXNNO_MAP_FILLVAL_LEN       50
#define TSK_ID_LEN                  2
#define SVC_NAME_LEN                12

#define FREEFMT_BATCH				"1"
#define FREEFMT_REPORT				"2"
#define FREEFMT_OTHERS				"3"

struct wd_bsrvmsq_area gSrvMsq[MAX_SRVMSQ_TXN_NUM];
struct wd_btxnomap_area gTxnnoMap[MAX_TXNNOMAP_TXN_NUM];


