#ifndef __GLOBAL_VAR
#define __GLOBAL_VAR

#include "sys_wd.h"

T_TITA_RECD		it_tita, *get_array;
T_TOTW_RECD		it_tota[TOTA_LIMIT], it_totw;
T_TXCOM_AREA	it_txcom;

T_BCTL		gwdBctl;
T_TLRCTL	gwdTlrctl;
T_XDTL		gwdXdtl;

char		gsTlsrno[DLEN_TLSRNO+1];
char		gsErrDesc[DLEN_LDESC+1];
char		gsErrPrefix[DLEN_SDESC+1];
int			giActidStatusChanged;

#endif


