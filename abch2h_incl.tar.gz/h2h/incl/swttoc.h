#ifndef _SWTTOC_H
#define _SWTTOC_H

/* definition nTransCode */

/* Definition of IPC Structure between SWITCH and TOCTL */
typedef struct
{
    long    MsgType;
    long    nMsgCode;
	long	nSwitchPID;
	short	nReplyCode;

	char	cDeptId;
	char	cPayType;
	char	sSysSeqNum[4];
} SwtToSSNReqDef;

#define SEQCTL_RCD_ID_SWIFTMSG	"SWIFTMSG"
#define SEQCTL_RCD_ID_REVAPPLY	"REVAPPLY"
#define SEQCTL_RCD_ID_CLSWTSSN	"CLSSN"
#define SEQCTL_RCD_ID_CNPKTLEN	"CNPKTLEN"
#define SEQCTL_RCD_ID_EISSEQNO	"EISSEQNO"
#define SEQCTL_RCD_ID_RETRYSEQ	"RETRYSEQ"
#define SEQCTL_RCD_ID_GIROPSEQ	"GIROPSEQ"

#define SEQCTL_RCD_ID_ABC	"HSBC2ABC"
#define SEQCTL_RCD_ID_SYS	"SYSSEQNO"


typedef struct
{
    long    MsgType;
    long    nMsgCode;
	long	nSwitchPID;
	short	nReplyCode;

	char	sSeqType[8];  /* type of sequence number (rcd_id in SEQCTL) */
	short	nSeqLen;
	char	sSeqStr[12];
} SwtToSEQReqDef;

/* function in libcom.a */
short SwtSnd2ToSSN (SwtToSSNReqDef *);
short SwtSnd2ToSEQ (SwtToSEQReqDef *);

#define NORMAL_FIRST       1
#define NORMAL_SECOND      2
#define REVERSAL_FIRST     3

#define BANKCODE_LEN	6

typedef long    MsgTypeDef;

typedef struct
{
    MsgTypeDef    MsgType;
    long          nMsgCode;
    char          cSsnCode;
    long          lSrvId;
    short         nTransCode;
    short         nReplyCode;
    long          nSwitchPID;
    char          sOBCode[BANKCODE_LEN];
    char          sCBCode[BANKCODE_LEN];
    char          sTerminalCode[8];
    char          sSysSeqNum[6];
} SwtToReqDef;

#endif
