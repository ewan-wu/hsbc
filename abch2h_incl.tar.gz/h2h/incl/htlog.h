#ifndef		_HTLOG_H_
#define		_HTLOG_H_

#include  	<stdio.h>
#include  	<stdlib.h>
#include  	<string.h>
#include  	<stdarg.h>
#include  	<fcntl.h>
#include  	<time.h>
#include  	<sys/types.h>
#include  	<sys/stat.h>

#define    	SINGLE_LINE   				"-------------------------\n"

#define    	DOUBLE_LINE   				"=========================\n"

#define    	SIZE_UNIT   				( 1024*1024 )

#define    	CorporationTitle			"Shanghai Huateng Co. Ltd"

#define     HT_LOG_MODE_OFF         	0
#define     HT_LOG_MODE_SIMPLE      	1
#define     HT_LOG_MODE_COMPLEX     	2

#define     HT_DEBUG_STRING_MODE_OFF	0
#define     HT_DEBUG_STRING_MODE_ON		1

#define     MAX_FILE_LEN          		128

#endif
