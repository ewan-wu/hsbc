#ifndef GLB_EXT_H
#define GLB_EXT_H

#include "sys_wd.h"

extern  T_TITA_RECD       it_tita, *get_array;
extern  T_TOTW_RECD       it_tota[TOTA_LIMIT], it_totw;
extern  T_TXCOM_AREA      it_txcom;

extern T_BCTL gwdBctl;
extern T_TLRCTL gwdTlrctl;
extern T_XDTL gwdXdtl;

extern char gsTlsrno[DLEN_TLSRNO+1];
extern char	gsErrDesc[DLEN_LDESC+1];
extern char	gsErrPrefix[DLEN_SDESC+1];
extern int  giActidStatusChanged;     /* Add by Valley, 20030410 */

extern char *cmgetdate(void);
extern char *cmgettime(void);
extern char *cmGetDttm(void);

#endif
