#ifndef	__BE_ITF_H__
#define	__BE_ITF_H__

typedef T_ACCOUNT aTisBaAccountInq;
typedef T_ACCOUNT aTosBaAccountInq;

typedef T_ACCOUNT aTisBaAccountUpd;
typedef T_ACCOUNT aTosBaAccountUpd;

typedef T_ACCOUNT aTisBaAccountNew;
typedef T_ACCOUNT aTosBaAccountNew;

typedef T_COMMON aTisBaCommonInq;
typedef T_COMMON aTosBaCommonInq;

typedef T_COMMON aTisBaCommonUpd;
typedef T_COMMON aTosBaCommonUpd;

typedef T_COMMON aTisBaCommonNew;
typedef T_COMMON aTosBaCommonNew;

typedef T_FILELOG aTisBaFilelogInq;
typedef T_FILELOG aTosBaFilelogInq;

typedef T_FILELOG aTisBaFilelogUpd;
typedef T_FILELOG aTosBaFilelogUpd;

typedef T_FILELOG aTisBaFilelogNew;
typedef T_FILELOG aTosBaFilelogNew;

typedef T_REMIT aTisBaRemitInq;
typedef T_REMIT aTosBaRemitInq;

typedef T_REMIT aTisBaRemitUpd;
typedef T_REMIT aTosBaRemitUpd;

typedef T_REMIT aTisBaRemitNew;
typedef T_REMIT aTosBaRemitNew;

typedef T_FREEFMTFILE aTisBaFreefmtfileInq;
typedef T_FREEFMTFILE aTosBaFreefmtfileInq;

typedef T_FREEFMTFILE aTisBaFreefmtfileUpd;
typedef T_FREEFMTFILE aTosBaFreefmtfileUpd;

typedef T_FREEFMTFILE aTisBaFreefmtfileNew;
typedef T_FREEFMTFILE aTosBaFreefmtfileNew;

typedef T_TRANSDETAIL aTisBaTransdetailInq;
typedef T_TRANSDETAIL aTosBaTransdetailInq;

typedef T_TRANSDETAIL aTisBaTransdetailUpd;
typedef T_TRANSDETAIL aTosBaTransdetailUpd;

typedef T_TRANSDETAIL aTisBaTransdetailNew;
typedef T_TRANSDETAIL aTosBaTransdetailNew;

typedef T_PAYROLLDETAIL aTisBaPayrolldetailInq;
typedef T_PAYROLLDETAIL aTosBaPayrolldetailInq;

typedef T_PAYROLLDETAIL aTisBaPayrolldetailUpd;
typedef T_PAYROLLDETAIL aTosBaPayrolldetailUpd;

typedef T_PAYROLLDETAIL aTisBaPayrolldetailNew;
typedef T_PAYROLLDETAIL aTosBaPayrolldetailNew;

typedef T_PAYROLLMAIN aTisBaPayrollmainInq;
typedef T_PAYROLLMAIN aTosBaPayrollmainInq;

typedef T_PAYROLLMAIN aTisBaPayrollmainUpd;
typedef T_PAYROLLMAIN aTosBaPayrollmainUpd;

typedef T_PAYROLLMAIN aTisBaPayrollmainNew;
typedef T_PAYROLLMAIN aTosBaPayrollmainNew;

#endif
