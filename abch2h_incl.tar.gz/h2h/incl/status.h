#ifndef _STATUS_H
#define _STATUS_H

#define CHK_STATUS               0
#define CHK_CNAPS_STATUS         1
#define CHK_CNAPS_SIGN           2
#define CHK_HST_STATUS           3

#define SET_STATUS               0
#define SET_CNAPS_STATUS         1
#define SET_CNAPS_SIGN           2
#define SET_HST_STATUS           3

#define CHK_STATUS_ON            1
#define CHK_STATUS_OFF           0
#define SET_STATUS_ON            1
#define SET_STATUS_OFF           0

#define LINE_CODE_EFT            1000
#define LINE_CODE_MBFE           1001


/* department work flag */
#define BDEPTCTL_WORK_FLAG_OFF   '0'
#define BDEPTCTL_WORK_FLAG_ON    '1'

/* teller work flag */
#define BTLRCTL_WORK_FLAG_OFF    '0'
#define BTLRCTL_WORK_FLAG_ON     '1'

/* teller status */
#define BTLRCTL_STATUS_LOG_OFF   '0'
#define BTLRCTL_STATUS_LOG_ON    '1'
#define BTLRCTL_STATUS_LOCK      '2'

/* teller init flag */
#define BTLRCTL_INIT_FLAG_OFF    '0'
#define BTLRCTL_INIT_FLAG_ON     '1'

/* teller sign log action type */
#define BSIGNLOG_ACTION_TYPE_SIGNON   '0'  /* ��¼��ǩ�� */
#define BSIGNLOG_ACTION_TYPE_SIGNOFF  '1'  /* ǩ�� */
#define BSIGNLOG_ACTION_TYPE_CHGPSWD  '2'  /* ������ */
#define BSIGNLOG_ACTION_TYPE_RSTPSWD  '3'  /* �������á�����ǿ�Ʊ�� */
#define BSIGNLOG_ACTION_TYPE_RCVPSWD  '4'  /* ʧЧ����ָ� */
#define BSIGNLOG_ACTION_TYPE_RCVAUTH  '5'  /* ����Ȩ�޻ָ� */
#define BSIGNLOG_ACTION_TYPE_UNLOCK1  '6'  /* ������ǿ��ǩ�ˣ� */
#define BSIGNLOG_ACTION_TYPE_OTHERS   '9'

/* teller password length (max) */
#define BTLRCTL_PASSWORD_MAX_LENGTH		12
#define BTLRCTL_PASSWORD_MAX_HIS		12

/* dept/tlr maintenance log action type */
#define BSCMLOG_ACTION_TYPE_DEPT      '0'
#define BSCMLOG_ACTION_TYPE_TLR       '1'
#define BSCMLOG_ACTION_TYPE_TRM       '2'
#define BSCMLOG_ACTION_TYPE_CAP		 'C'
#define BSCMLOG_ACTION_TYPE_APR       'A'
#define BSCMLOG_ACTION_TYPE_OTHERS    '9'

/* dept/tlr maintenance log action subtype */
#define BSCMLOG_ACTION_SUBTYPE_ADD    '0'
#define BSCMLOG_ACTION_SUBTYPE_DEL    '1'
#define BSCMLOG_ACTION_SUBTYPE_UPD    '2'
#define BSCMLOG_ACTION_SUBTYPE_OTHERS '9'

/* function in libcom.a */
short ChkSysStatus(short, short *);
short SetSysStatus(short, short);

short GetCurHstStlmDate(char *);
short GetLstHstStlmDate(char *);
short SetHstStlmDate(char *);

short ChkLineStatus(long, short *);
short SetLineStatus(long, short);

#endif


