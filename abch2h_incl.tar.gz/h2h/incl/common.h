#ifndef _COMMON_H
#define _COMMON_H

#define TO_HOST        0
#define TO_CNAPS       1

#define CMT_FROM_CNAPS         '1'
#define CMT_FROM_HOST          '0'

#define TIMES_OUT_SECS         300

/***************************************/
/* Index for all kinds of KEY in HSM   */
/***************************************/
#define NTL_BMK_INDEX  2
#define NTL_MK_INDEX   99 
#define NTL_PK_INDEX   115
#define SC_BMK_INDEX   1
#define SC_MK_INDEX    114 
#define SC_PK_INDEX    98

void AddString(char * d, int dlen, char * s, int slen);
char MinString(char * d, int dlen, char * s, int slen);

short DebugString(char *psBuf, int iLength, int iLine);
void DebugMemory(char *psDesc);

void CommonGetCurrentTime(char *sCurrentTime);  /* YYYYMMDDhhmmss */
void CommonGetCurrentDate(char *sCurrentDate);  /* YYYYMMDD */
void CommonGetCurrentTimeDB(char *sCurrentTime);  /* YYYY/MM/DD hh:mm:ss */
char *GetSystemTime(void);
int CommonInterval(const char *date1, const char *date2);

short ErrReport(long lMsgSource, long lErrorCode, long lErrorSubCode,
                long lSeverity, char *sDescription);

void Transfer8To16(char *, char *);
void Transfer16To8(char *, char *);

void GetGlobalTxtime();
void GetGlobalTxdate();

/****************************************************************/
/* 				Online 		Txn 		types 					*/
/****************************************************************/

/* CNAPS���ʽ��״���Ķ��� */
#define N_CMT100					10002
#define N_CMT101					10004
#define N_CMT102					10006
#define N_CMT103					10008
#define N_CMT105					10014
#define N_CMT108					10016
#define N_CMT109					10018
#define N_CMT122					10024
#define N_CMT123					10026
#define N_CMT124					10028
#define N_CMT232					10030
#define N_CMT233					10094
#define N_CMT234					10096
#define N_CMT253					10032
#define N_CMT310					10092
#define N_CMT312					10046
#define N_CMT407					10034
#define N_CMT408					10036
#define N_CMT681					10064
#define N_CMT683					10088
#define N_CMT689					10066
#define N_CMT725					10072
#define N_CMT841					10078
#define N_CMT910					10082

#define N_CMT104					10010
#define N_CMT114					10020
#define N_CMT119					10012

#define N_CMT660					10062

#define N_CMT121					10022
#define N_CMT301					10038
#define N_CMT302					10040
#define N_CMT303					10042
#define N_CMT311					10044
#define N_CMT313					10048
#define N_CMT314					10050
#define N_CMT315					10052
#define N_CMT417					10054
#define N_CMT418					10056
#define N_CMT633					10084
#define N_CMT651					10058
#define N_CMT653					10086
#define N_CMT721					10068
#define N_CMT724					10070
#define N_CMT802					10076
#define N_CMT803					10074


/* FE���ʽ��״��붨��*/
#define O_CMT100					4982
#define O_CMT101					4984
#define O_CMT102					4978
#define O_CMT103					4886
#define O_CMT109					4986
#define O_CMT311					4968
#define O_CMT651					4946
#define O_CMT653					4942
#define O_CMT724					4912
#define O_CMT652					4944
#define O_CMT656					4940
#define O_CMT313					4966
#define O_CMT303					4948
#define O_CMT301					4954
#define O_CMT302					4950

#define O_CMT314					4896
#define O_CMT105					4884
#define O_CMT121					4882

#define O_CMT633					4890
#define O_CMT659					4894
#define O_CMT721					4892
#define O_CMT605					4888

#define O_CMT104					10002
#define O_CMT108					10004
#define O_CMT114					10005
#define O_CMT119					10006
#define O_CMT122					10007
#define O_CMT123					10008
#define O_CMT124					10009
#define O_CMT232					10010
#define O_CMT253					10011
#define O_CMT407					10012
#define O_CMT408					10013
#define O_CMT310					10014
#define O_CMT312					10015
#define O_CMT681					10016
#define O_CMT683					10017
#define O_CMT689					10018
#define O_CMT725					10019
#define O_CMT841					10020
#define O_CMT910					10021
#define O_CMT233					20022
#define O_CMT234					20023
#define O_CMT315					20026
#define O_CMT417					20027
#define O_CMT418					20028
#define O_CMT660					20032
#define O_CMT802					20034
#define O_CMT803					20035


#define O_MT103					        5002
#define O_MT202					        5004
#define O_MT192					        5006



/*  SmartTeller �����ڲ����״��붨�� 
#define O_CMT101		4984*/	/*ί���տ�(����)¼��4216*/



/*�����кźͷ�������2003-11-09*/
#define  CURRENT_BANK_NO           "712290000012"    /*CNAPS�к�*/
#define  CURRENT_EBANK_NO          "002731"          /*���������к�*/
#define  CURRENT_LEVEL_NO          "712290000012"    /*�ϼ��������к�*/
#define  CURRENT_CENTRA_NO         "2900"            /*�����ڵ�*/
#define  CURRENT_SUPER_CENTRA_NO   "9988"            /*���Ľڵ�*/

#define  CURRENT_EIS_CENTER_CODE   "000998800006"    /*EIS Switch Center*/
#define  CURRENCY_CODE_RMB         "RMB"
#define  MBFE_FRONT_END_NO         "946"

#endif
