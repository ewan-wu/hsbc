EXEC SQL BEGIN DECLARE SECTION;
	extern char  		H_BSEQCTL_RCD_ID	[  9];
	extern int   		H_BSEQCTL_SN_LEN;
	extern int   		H_BSEQCTL_SN_MIN;
	extern int   		H_BSEQCTL_SN_MAX;
	extern int   		H_BSEQCTL_SN_NEXT_APPLY;
	extern char  		H_BSEQCTL_REC_UPDT_TIME	[ 20];
EXEC SQL END DECLARE SECTION;
