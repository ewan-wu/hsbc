EXEC SQL BEGIN DECLARE SECTION;
	extern char  		H_BSCMLOG_BRNO	[  4];
	extern char  		H_BSCMLOG_DEPT_ID	[  2];
	extern char  		H_BSCMLOG_ACT_TIME	[ 20];
	extern char  		H_BSCMLOG_ACT_TYPE	[  2];
	extern char  		H_BSCMLOG_ACT_SUBTYPE	[  2];
	extern varchar  	H_BSCMLOG_ACT_DATA	[256];
	extern char  		H_BSCMLOG_REC_UPDT_TIME	[ 20];
EXEC SQL END DECLARE SECTION;
