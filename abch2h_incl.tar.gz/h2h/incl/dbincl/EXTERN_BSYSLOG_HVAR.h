EXEC SQL BEGIN DECLARE SECTION;
	extern char  		H_BSYSLOG_SYS_LOG_TIME	[ 20];
	extern int   		H_BSYSLOG_MSG_SRC;
	extern int   		H_BSYSLOG_MSG_CODE;
	extern int   		H_BSYSLOG_MSG_SUBCODE;
	extern int   		H_BSYSLOG_MSG_LEVEL;
	extern varchar  	H_BSYSLOG_MSG_DESC	[ 61];
	extern char  		H_BSYSLOG_REC_UPDT_TIME	[ 20];
EXEC SQL END DECLARE SECTION;
