EXEC SQL BEGIN DECLARE SECTION;
	extern char  		H_BDEPTCTL_DEPT_ID	[  2];
	extern varchar  	H_BDEPTCTL_DEPT_NAME	[ 61];
	extern char  		H_BDEPTCTL_WORK_FLAG	[  2];
	extern char  		H_BDEPTCTL_WORK_TYPE	[  2];
	extern char  		H_BDEPTCTL_REC_UPDT_TIME	[ 20];
EXEC SQL END DECLARE SECTION;
