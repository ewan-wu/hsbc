#ifndef _WD_INCL_H
#define _WD_INCL_H
struct wd_bdeptctl_area {
	char  		dept_id	[  2];
	char  		dept_name	[ 61];
	char  		work_flag	[  2];
	char  		work_type	[  2];
	char  		rec_updt_time	[ 20];
};
struct wd_berrcode_area {
	char  		ecode	[  6];
	char  		emsg	[ 61];
};
struct wd_bscmlog_area {
	char  		brno	[  4];
	char  		dept_id	[  2];
	char  		act_time	[ 20];
	char  		act_type	[  2];
	char  		act_subtype	[  2];
	char  		act_data	[256];
	char  		rec_updt_time	[ 20];
};
struct wd_bseqctl_area {
	char  		rcd_id	[  9];
	short		sn_len;
	long		sn_min;
	long		sn_max;
	long		sn_next_apply;
	char  		rec_updt_time	[ 20];
};
struct wd_bsignlog_area {
	char  		brno	[  4];
	char  		dept_id	[  2];
	char  		tlr_id	[  9];
	char  		act_time	[ 20];
	char  		act_type	[  2];
	char  		act_data	[256];
	char  		rec_updt_time	[ 20];
};
struct wd_bsrvmsq_area {
	long		src_srv_id;
	long		txn_no;
	short		txn_step;
	long		usage_key;
	char  		src_srv_desc	[ 61];
	long		srv_id;
	char  		srv_name	[ 61];
	short		srv_pri;
	char  		use_flag	[  2];
	char  		rsv1	[ 31];
	char  		rsv2	[ 31];
	char  		rec_updt_time	[ 20];
};
struct wd_bsysctl_area {
	char  		rcd_id	[  9];
	char  		sys_status	[  2];
	char  		eft_status	[  2];
	char  		cnaps_status	[  3];
	char  		cnaps_sign	[  2];
	char  		work_date	[  9];
	char  		last_work_date	[  9];
	char  		work_date_1	[  9];
	char  		work_date_2	[  9];
	short		online_days;
	short		history_max_days;
	short		tlr_p_exp_days;
	short		tlr_s_exp_days;
	char  		rec_updt_time	[ 20];
	char  		namount	[ 31];
	char  		namount1	[ 31];
	char  		nadate1	[  9];
	char  		remarks	[ 61];
};
struct wd_bsyslog_area {
	char  		sys_log_time	[ 20];
	long		msg_src;
	long		msg_code;
	long		msg_subcode;
	long		msg_level;
	char  		msg_desc	[ 61];
	char  		rec_updt_time	[ 20];
};
struct wd_bsyssvc_area {
	long		svc_id;
	char  		svc_name	[ 61];
	long		msq_in_key;
	long		msq_in_type;
	double		msq_in_id;
	long		msq_out_key;
	long		msq_out_type;
	double		msq_out_id;
	char  		svc_cfg_data	[256];
	char  		rec_updt_time	[ 20];
};
struct wd_btlrctl_area {
	char  		brno	[  4];
	char  		dept_id	[  2];
	char  		tlr_id	[  9];
	char  		tlr_name	[ 41];
	char  		init_flag	[  2];
	char  		work_flag	[  2];
	char  		work_level	[  2];
	char  		password	[ 13];
	char  		last_pswd_chg	[  9];
	short		pswd_retry_cnt;
	char  		status	[  2];
	char  		last_status_chg	[  9];
	char  		add_by_dept_id	[  2];
	char  		add_by_tlr_id	[  9];
	char  		auth_by_dept_id	[  2];
	char  		auth_by_tlr_id	[  9];
	char  		recent_pswd_str	[145];
	char  		rec_updt_time	[ 20];
};
struct wd_btlrctl_tmp_area {
	char  		opcode	[  2];
	char  		brno	[  4];
	char  		dept_id	[  2];
	char  		tlr_id	[  9];
	char  		tlr_name	[ 41];
	char  		init_flag	[  2];
	char  		work_flag	[  2];
	char  		work_level	[  2];
	char  		password	[ 13];
	char  		last_pswd_chg	[  9];
	short		pswd_retry_cnt;
	char  		status	[  2];
	char  		last_status_chg	[  9];
	char  		add_by_dept_id	[  2];
	char  		add_by_tlr_id	[  9];
	char  		auth_by_dept_id	[  2];
	char  		auth_by_tlr_id	[  9];
	char  		recent_pswd_str	[145];
	char  		rec_updt_time	[ 20];
};
struct wd_btlrpswderr_area {
	char  		retryseq	[  9];
	char  		brno	[  4];
	char  		dept_id	[  2];
	char  		tlr_id	[  9];
	char  		local_time	[ 15];
	char  		work_date	[  9];
	char  		retry	[  2];
	char  		memo	[256];
	char  		rec_updt_time	[ 20];
};
struct wd_btxnomap_area {
    long        txn_no;
    long        infc_id;
    char        infc_desc   [ 61];
    char        out_no  [  9];
    char        txn_desc    [ 61];
    short       file_flg;
    char        fill_map    [ 61];
    char        fill_val    [ 61];
    short       sfd_flg;
    char        rsv1    [ 31];
    char        rec_updt_time   [ 20];
};
#endif
