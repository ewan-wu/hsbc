#ifndef _BASIC_IPC_H
#define _BASIC_IPC_H

#include "glb_dic.h"

#define CR_CLSTXNNO_LEN         8
#define CR_TXNSTEP_LEN          4
#define CR_CLRRLTNO_LEN         8
#define CR_CLSSSN_LEN           6
#define CR_AMT_LEN              16
#define CR_TERMNO_LEN           2
#define CR_TERMSSN_LEN          8
#define CR_SRVID_LEN            8
#define CR_TERMID_LEN           8
#define CR_SRVNAME_LEN          10
#define CR_REFNO_LEN            14
#define CR_CLSTXNSTEP_LEN       1

#define TLR_TXNO_MIN_MNG           1
#define TLR_TXNO_MAX_MNG        2500

#define TLR_TXNO_MIN_SWT        2501
#define TLR_TXNO_MAX_SWT        5000

#define HST_TXNO_MIN_SWT        5001
#define HST_TXNO_MAX_SWT       10000

#define CNAPS_TXNO_MIN_SWT     10001
#define CNAPS_TXNO_MAX_SWT     15000

#define IPC_RSV_LEN		14*1024
#define GEN_FLD_LEN 	385
#define TEXT_FLD_LEN	IPC_RSV_LEN+GEN_FLD_LEN
#define	TSK_ID_LEN					2
#define	SVC_NAME_LEN				12
#define	DELTA_TITA_TOTA  9 /*sizeof(T_TitaLabel)-sizeof(T_TotaLabel)*/
#define	TXNO_QUERY_RSP_MAX		9997
#define	TXNO_QUERY_RSP_MIN		5001

#define CR_TLRSSN_LEN		4
#define OUT_TXNNO_LEN		2
#define CR_OUTTXNNO_LEN		4
#define CR_CNAPS_PKT_LEN	8
#define CNS_MAX_PKT_LEN		9000
#define CMT_BIT                 3


/* Define For Mt Packet */
#define MAX_TAG_NUM            64
#define MAX_BLOCK_NUM          16

#define MT_NAME_LEN            8
#define MT_BIT                 3
#define FLD_NAME_LEN           6
#define FLD_NAME_BIT           1
#define FLD_TYPE_LEN           1
#define FLD_ATTR_LEN           3
#define FLD_DESC_LEN           64
#define FLD_OPT_LEN            1
#define FLD_FLG_LEN            1
#define LEN_FLG_LEN            1
#define FLD_TEAM_LEN           1
#define MAX_TAG_LEN            600
#define MAX_PACKET_TAG_NUM     300  /*or (MAX_TAG_NUM +1) * MAX_BLOCK_NUM*/
#define MAX_PACKET_TAG_ALL     MAX_PACKET_TAG_NUM * MAX_NAME_LEN

#define PACKET_LEN_BIT         8
#define PACKET_MSG_ACK         8
#define MAX_PACKET_LEN         IPC_RSV_LEN+2048


#define  MAX_TAGCNT_LEN  9001
#define  CNS_PKTHEAD_LEN 69
#define  CNS_PKTHEAD_LEN2 93


#define ULONG                  unsigned long
#define UINT                   unsigned int
#define USHORT                 unsigned short


typedef struct
{
    char 	  sClsTxnNo[CR_CLSTXNNO_LEN];
    char	  sClsSsn[CR_CLSSSN_LEN];
    char      sSrcSrvId[CR_SRVID_LEN];
    char	  sTxnStep[CR_TXNSTEP_LEN];
    /*char 	  sClsTxnNo[8];
    char	  sClsSsn[6];
    char      sSrcSrvId[8];
    char	  sTxnStep[4];*/
} T_IPCHeader;  /*len 26*/

typedef struct
{
    char 	sOutTxnNo[8]; 	/*�ⲿ���״���*/
    char	sOutRltNo[8]; 	/*�ⲿ��ؽ��״���*/
    char	sBankNo[12];	/*�к�*/
    char	sTermNo[8];		/*�ն˺�*/
    char	sTermSsn[14];	/*�ն���ˮ��*/
    char	sTermTime[14];	/*�ն�ʼ��ʱ��*/
    char	sTlrNo[4];		/*��Ա��*/ 
    char	sTlrSsn[4];		/*��Ա��ˮ��*/
    char	sTxnType[2];	/*��������*/
    char	sOprType[2];	/*ҵ������*/
    char	sGbaseDate[8];	/*ָ�������*/
    
    char	sRefSsn[14];    /* ������ˮ��*/
    char	sRltSsn[14];    /*���������ˮ��*/
    char	sRspNo[4];      /* ����Ӧ����*/

    char	sPayAcc[18];	/*�������˺�*/
    char	sPayBnk[12];	/*�������к�*/
    char	sPayName[60];	/*����������*/
    char	sCurCode[3];	/*���ҷ���*/
    char	sTxnAmt[16];	/*���*/
    char	sRcvAcc[32];	/*�տ����˺�*/
    char	sRcvBnk[12];	/*�տ����к�*/
    char	sRcvName[60];	/*�տ�������*/
} T_FEGenFldDef;  /*len 329 */

typedef struct
{
    char	sPayAcc[32];	/*�������˺�*/
    char	sPayBnk[12];	/*�������к�*/
    char	sPayName[60];	/*����������*/
    char	sCurCode[3];	/*���ҷ���*/
    char	sTxnAmt[15];	/*���*/
    char	sRcvAcc[32];	/*�տ����˺�*/
    char	sRcvBnk[12];	/*�տ����к�*/
    char	sRcvName[60];	/*�տ�������*/
	
	char	sCmtNo[CMT_BIT];        /*CNAPS���״���*/
	char	sPktID[8];		/*���ı�ʶ��*/
	char	sPktNo[20];		/*���Ĳο���*/
	char	sWrkdate[8];  	/*��������*/
	char	sCmtDate[8];	/*ί������*/	               
	char	sSndBank[12];	/*����������/�������к�*/
	char	sPaySeq[8];		/*֧��������� */
	char	sRcvCtrNo[4];	/*�ձ����Ĵ���*/
	char	sSndCtrNo[4];	/*�������Ĵ���*/
	char	sSndStlBnk[12];	/*�����������к�*/	           
	char	sRcvStlBnk[12];	/*�����������к�*/		           
	char	sTktNo[8];		/*Ʊ�ݺ���*/	
	char	sTktDate[8];	/*Ʊ������*/		           
	char	sTktSec[10];	/*��Ʊ��Ѻ*/		                
	char	sTktAmt[15];	/*��Ʊ���*/	
	char    sTrnType[1];	/*ҵ������*/
	char	sTrnStat[3];	/*ҵ��״̬*/
} T_GenFldDef;  /* GEN_FLD_LEN = 385(??) */

typedef struct
{
	/*block 1 information*/
	char        cAppIdr;         /*Application Identifier*/
	char        sSvcIdr[2];      /*Service Identifier*/
	char        sLTIdr[12];      /*LT Identifier*/
	char        sSessionSSN[4];  /*Session Number*/
	char        sSeqSSN[6];      /*Sequence Number(ISN or OSN)*/

	/*block 2 information*/
	char        cIOIdr;          /*Input/Output Identifier*/
	char        sMsgType[MT_BIT];/*Message Type*/
	char		sTime[10];
	char        sRcvAddr[12];    /*Receiver Address*/
	char		sSerial[10];
	char		sTime2[10];
	char        cMsgPrty;        /*Message Priority*/
	/*
	char        cDeyMon;         *Delivery Monitoring*
	char        sObsPeriod[3];   *Obsolescence Period*

	char        sBlank1[16];        *Unused Blank*
	*/

	/*block 3 information*/
	char        sBkingPrty[4];   /*Banking Priority*/
	char        MUR[16];         /*Message User Reference*/

	/*block 4 information*/
	char        sRefSSN[16];     /*tag 20  Transaction Reference Number*/
	char        sTimeIcn[19];    /*tag 13C Time Indication*/
	char        sBankCode[4];    /*tag 23B Bank Operation Code*/
	char        sTranCode[3];    /*tag 26T Transaction Type Code*/

	char        sValueDate[6];   /*tag 32A Value Date*/
	char        sStlCur[3];      /*tag 32A Currency*/
	char        sStlAmt[15];     /*tag 32A Interbank Settled Amount*/

	char        sInsrtCur[3];    /*tag 33B Currency*/
	char        sInsrtAmt[15];   /*tag 33B Instructed Amount*/
	char        sExgRate[15];    /*tag 36  Exchange Rate*/
	char        sDtlCharge[3];   /*tag 71A Details of Charges*/
	char        sSndCharge[18];  /*tag 71F Sender��s Charges*/
	char        sRcvCharge[18];  /*tag 71G Receiver��s Charges*/
	char        sRlaRefSSN[16];  /*tag 21  Related Reference Number(Sender��s Reference)*/

	char        sOrgMsgType[3];  /*tag 11S Messsage Type of the Original Message*/
	char        sOrgMsgDate[6];  /*tag 11S Messsage Date of the Original Message*/
	char        sOrgSesSSN[4];   /*tag 11S Session Number of the Original Message*/
	char        sOrgSeqSSN[6];   /*tag 11S Sequence Number(ISN) of the Original Message*/

	/*block 5 information*/
	char        sMAC[8];
	char        sCHK[12];

	/*block DATE information*/
	char        sDateBlk[10];

	/* added by Laura */
	char		s23E[35];
	char		s50K[175];
	char		s51A[48];
	char		s52A[177];
	char		s53A[177];
	char		s54A[177];
	char		s55A[177];
	char		s56A[177];
	char		s57A[177];
	char		s59[175];
	char		s70[140];
	char		s72[210];
	char		s77B[105];
	char		s77T[256];
} T_HostInGenFldDef;  /* Input Structure GEN_FLD_LEN = 295(2501) */

typedef struct
{
	/*block 1 information*/
	char        cAppIdr;         /*Application Identifier*/
	char        sSvcIdr[2];      /*Service Identifier*/
	char        sLTIdr[12];      /*LT Identifier*/
	char        sSessionSSN[4];  /*Session Number*/
	char        sSeqSSN[6];      /*Sequence Number(ISN or OSN)*/

	/*block 2 information*/
	char        cIOIdr;          /*Input/Output Identifier*/
	char        sMsgType[MT_BIT];/*Message Type*/
	char        sInTime[4];      /*Input Time*/
	char        sMIR[28];        /*MIR*/
	char        sOutDate2[6];    /*Output Date*/
	char        sOutTime[4];     /*Output Time*/
	char        cMsgPrty;        /*Message Priority*/

	/*block 3 information*/
	char        sBkingPrty[4];   /*Banking Priority*/
	char        MUR[16];         /*Message User Reference*/

	/*block 4 information*/
	char        sRefSSN[16];     /*tag 20  Transaction Reference Number*/
	char        sTimeIcn[19];    /*tag 13C Time Indication*/
	char        sBankCode[4];    /*tag 23B Bank Operation Code*/
	char        sTranCode[3];    /*tag 26T Transaction Type Code*/

	char        sValueDate[6];   /*tag 32A Value Date*/
	char        sStlCur[3];      /*tag 32A Currency*/
	char        sStlAmt[15];     /*tag 32A Interbank Settled Amount*/

	char        sInsrtCur[3];    /*tag 33B Currency*/
	char        sInsrtAmt[15];   /*tag 33B Instructed Amount*/
	char        sExgRate[15];    /*tag 36  Exchange Rate*/
	char        sDtlCharge[3];   /*tag 71A Details of Charges*/
	char        sSndCharge[18];  /*tag 71F Sender��s Charges*/
	char        sRcvCharge[18];  /*tag 71G Receiver��s Charges*/
	char        sRlaRefSSN[16];  /*tag 21  Related Reference Number(Sender��s Reference)*/

	char        sOrgMsgType[3];  /*tag 11S Messsage Type of the Original Message*/
	char        sOrgMsgDate[6];  /*tag 11S Messsage Date of the Original Message*/
	char        sOrgSesSSN[4];   /*tag 11S Session Number of the Original Message*/
	char        sOrgSeqSSN[6];   /*tag 11S Sequence Number(ISN) of the Original Message*/

	/*block 5 information*/
	char        sMAC[8];
	char        sCHK[12];

	/*block DATE information*/
	char        sDateBlk[10];

	/* added by Laura */
	/*
	char		s23E[35];
	char		s50K[175];
	char		s51A[48];
	char		s52A[177];
	char		s53A[177];
	char		s54A[177];
	char		s55A[177];
	char		s56A[177];
	char		s57A[177];
	char		s59[175];
	char		s70[140];
	char		s72[210];
	char		s77B[105];
	char		s77T[256];
	*/
} T_HostOutGenFldDef;  /* Output Structure GEN_FLD_LEN = 295(2501) */

typedef struct  HOST_LABEL
{
	char header[8];
} T_HostLabel;

typedef struct  TITA_LABEL
{
	char header[8];
	char clsno[6];   			   /*  CLS ssn */
	char termid[8];   			   /*  termid */
    char htrmseq[DLEN_TRMSEQ];     /* correction old trmseq 2*/
    char hejfno[DLEN_EJFNO];       /*  correction old ejfno 7*/
    char opnbr[DLEN_BRNO];         /*  open account branch 3*/
    char kinbr[DLEN_BRNO];         /*  �кţ�3λ��       */
    char trmseq[DLEN_TRMSEQ];      /*  terminal sequence 2 */
    char ejfno[DLEN_EJFNO];        /*  EJF no   7           */
    char taskid[DLEN_TASKID];      /*  �������ࣨ2λ��             */
    char tmtype;                   /*  terminal type       */
    char txno[DLEN_TXNCD];         /*  �ⲿ���״��루4λ��*/
    char hcode;                    /*  cancel transaction  */
    char supinit[2];               /*  supervisor code     */
    char tlrno[DLEN_TLRNO];        /*  ��Ա�ţ�8λ��          */
    char sptlrno[DLEN_TLRNO];      /*  supervisor's tlrno  */
    char otxtlrno[DLEN_TLRNO];     /*  verified tx tlrno   */
    char otxtlsrno[DLEN_TLSRNO];   /*  verified tx tlsrno  7*/
    char passwd[DLEN_TLR_PASSWD];  /*  shuffled password  8 */
    char nbcd;                     /*  nobook code         */
    char multtx;                   /*  multiple txn        */
    char multno[DLEN_MULTNO];      /*  multiple txn set no 6*/
} T_TitaLabel;   /*len 95+8 */

typedef struct TITA_LABEL T_TITA_LABEL;

#define   TITA_TEXT_LENGTH    4018
#define   TITA                it_tita.labtex.label
#define   TITA_LABEL_LENGTH   (sizeof (T_TITA_LABEL))

struct  TITA_LABTEX
{
	T_TITA_LABEL label;
	char text[TITA_TEXT_LENGTH];
};
typedef struct TITA_LABTEX T_TITA_LABTEX;

struct  TITA_RECD
{
	T_TITA_LABTEX labtex;
	char dummy;
};
typedef struct TITA_RECD T_TITA_RECD;

typedef struct TOTW_LABEL
{
	char 	header[8];
	char 	clsno[6];
	char 	termid[8];   			   /*  termid */
	char 	refssn[14];
    char    kinbr[DLEN_BRNO];      /*  �к�     3  */
    char    trmseq[DLEN_TRMSEQ];   /*  terminal sequence 2  */
    char    ejfno[DLEN_EJFNO];     /*  EJF no            7  */
    char    taskid[DLEN_TASKID];   /*  task id           2  */
	char 	txno[DLEN_TXNCD];		/*�ⲿ���״���  4*/
	char 	tlrno[DLEN_TLRNO];     /*  ��Ա�ţ�8λ��*/
	char    tlsrno[DLEN_TLSRNO];   /*  tlsrno7 */ 
	char    tmtype;                /*  terminal type       */
    char    txdate[DLEN_DATE];     /*  transaction date  8  */
    char    txtime[DLEN_TIME];     /*  transaction time  6 */
    char    msgend;                /*  message end         */
    char    msgtype;               /*  message type        */
    char    msgno[4];              /*  message no          */
    char    msglng[4];             /*  message length      */

} T_TotaLabel;   /*len 86 + 8*/

typedef    struct    TOTW_LABEL     T_TOTW_LABEL;

#define   TOTA_TEXT_LENGTH    4096
#define   TOTW                it_totw.labtex.label
#define   TOTA_LABEL_LENGTH   (sizeof (T_TOTW_LABEL))
#define   TOTA_LIMIT          24

struct    TOTW_LABTEX
{
	T_TOTW_LABEL label;
	char text[TOTA_TEXT_LENGTH];
};
typedef    struct    TOTW_LABTEX    T_TOTW_LABTEX;

struct    TOTW_RECD
{
	T_TOTW_LABTEX   labtex;
};
typedef    struct    TOTW_RECD      T_TOTW_RECD;


typedef struct
{
	T_TitaLabel tTitaLabel;
	T_GenFldDef tGenFld;
	char	    sRsv[IPC_RSV_LEN];
} T_MsgText;

typedef struct
{
	T_IPCHeader   tIPCHeader;
	T_MsgText	  tMsgText;
} T_SwtInBufDef;

typedef struct
{
	T_TotaLabel tTotaLabel;
	char        sRsv[TEXT_FLD_LEN]; /*�ı���*/
} T_MsgOutText;

typedef struct
{
	T_IPCHeader   tIPCHeader;
	T_MsgOutText  tMsgText;
} T_SwtOutBufDef;

/*used in cnapsswt,cnapsbdg */
typedef struct
{	
	T_TitaLabel  	tTitaLabel;
	T_GenFldDef		tCnapsGen;
	char			sRsv[IPC_RSV_LEN];	/*�Զ�����*/
}T_TitaPktDef;

typedef struct
{	
    T_IPCHeader    	tIPCHeader;
	T_TitaPktDef    tTitaPkt;
}T_CnsSwtTitaDef;

typedef struct
{	
	T_TotaLabel		tTotaLabel;
	T_GenFldDef		tCnapsGen;	
	char			sRsv[IPC_RSV_LEN];	/*�Զ�����*/
}T_CnsTotaPktDef;

typedef struct
{	
    T_IPCHeader    	tIPCHeader;
	T_CnsTotaPktDef tTotaPkt;
}T_CnsSwtTotaDef;
/*used in cnapsswt,cnapsbdg */

/*used in HostBdg*/
typedef struct
{	
	T_TotaLabel		tTotaLabel;
	char			sRsv[TEXT_FLD_LEN];	/*�ı���*/
}T_TotaPktDef;

typedef struct
{	
    T_IPCHeader    	tIPCHeader;
	T_TotaPktDef    tTotaPkt;
}T_SwtTotaDef;


typedef struct
{	
	T_IPCHeader    	        tIPCHeader;
	T_HostLabel             tHostLabel;
	char                    sMsgAck[PACKET_MSG_ACK];
	T_HostOutGenFldDef         tHostGen;
	char                    sRsv[IPC_RSV_LEN];	/*�Զ�����*/
}T_HostSwtOutDef;

typedef struct
{	
	T_IPCHeader    	        tIPCHeader;
	T_HostLabel             tHostLabel;
	char                    sMsgAck[PACKET_MSG_ACK];
	T_HostInGenFldDef         tHostGen;
	char                    sRsv[IPC_RSV_LEN];	/*�Զ�����*/
}T_HostSwtInDef;

typedef struct
{
	ULONG              packet_len;
	char               sMsgAck[PACKET_MSG_ACK];
	char               sPacketLen[PACKET_LEN_BIT];
	char               sPacket[MAX_PACKET_LEN];
}MT_PACKET;


#define BPAYTXNLOG_IO_FLAG_INCOMING			'I'
#define BPAYTXNLOG_IO_FLAG_OUTGOING			'O'

#define BPAYTXNLOG_MT_IO_IN_FROM_EFT		'I'
#define BPAYTXNLOG_MT_IO_OUT_TO_EFT			'O'

#define BPAYTXNLOG_CMT_IO_IN_FROM_CNAPS		'I'
#define BPAYTXNLOG_CMT_IO_OUT_TO_CNAPS		'O'

#define BPAYTXNLOG_CR_FLAG_NORMAL			'0'
#define BPAYTXNLOG_CR_FLAG_REVERSAL			'1'

#define BPAYTXNLOG_CR_STATUS_NORMAL			'0'
#define BPAYTXNLOG_CR_STATUS_REVERSAL		'1'

#define BPAYTXNLOG_STATUS_UNSETTLE			'0' /* δ���� */
#define BPAYTXNLOG_STATUS_SETTLE			'1'
#define BPAYTXNLOG_STATUS_REVERSAL			'2'
#define BPAYTXNLOG_STATUS_QUEUE				'3' /* �Ŷ� */
#define BPAYTXNLOG_STATUS_DECLINE			'4' /* ���� */
#define BPAYTXNLOG_STATUS_QUEUECAN			'5' /* �Ŷӳ��� */
#define BPAYTXNLOG_STATUS_ERROR				'6' /* MBFE�ܾ� */
#define BPAYTXNLOG_STATUS_REPEAT			'7' /* �ظ����� */

#define BCMTLOG_STATUS_PENDING 			'P' /* Pending */
#define BCMTLOG_STATUS_APPROVE 			'A' /* Approve */
#define BCMTLOG_STATUS_REJECT 			'R' /* Reject */


typedef struct
{
	char		s23E[35];
	char		s50K[175];
	char		s51A[48];
	char		s52A[177];
	char		s53A[177];
	char		s54A[177];
	char		s55A[177];
	char		s56A[177];
	char		s57A[177];
	char		s59[175];
	char		s70[140];
	char		s72[210];
	char		s77B[105];
	char		s77T[256];
} T_HostRsv;

typedef struct
{
	char		s177[10];
	char		s451;
	char		s108[88];
} T_HostRsvAck;

typedef struct
{
	char		s50B[60];
	char		s58A[12];
	char		s59B[60];
	char		sCEF[2];
	char		s72A[60];
} T_CnapsRsv100;

typedef struct
{
	char		s58A[12];
	char		s051[8];
	char		s02B[3];
	char		s005[8];
	char		sCQ1[32];
	char		sCR1[60];
	char		sCQ2[32];
	char		sCR2[60];
	char		s72A[60];
} T_CnapsRsv108;

typedef struct
{
	char		sCG1[6];
	char		sCG2[26];
	char		sCG3[36];
	char		sCG4[6];
	char		sCG5[26];
	char		sCG6[36];
	char		sCG7[28];
} T_CnapsRsv109;

typedef struct
{
	char		sC42[8];
} T_CnapsRsv253;

typedef struct
{
	char		sC47[3];
	char		s051[8];
	char		sCC1[12];
	char		sCE2;
	char		s046[8];
	char		s72A[60];
} T_CnapsRsv311;

typedef struct
{
	char		sCCD[12];
	char		sCP2[3];
	char		s046[8];
	char		s04C;
	char		s72A[60];
} T_CnapsRsv312;

typedef struct
{
	char		s051[8];
	char		s005[8];
	char		s58A[12];
	char		s72A[60];
	char		sCE2;
	char		sCND[18];
	char		sC47[3];
} T_CnapsRsv313;

typedef struct
{
	char		s051[8];
	char		s005[8];
	char		s58A[12];
	char		s72A[60];
	char		sCE2;
	char		sCND[18];
	char		sCP2[3];
	char		sCCE[12];
	char		sCJB[8];
	char		s018;
} T_CnapsRsv314;

typedef struct
{
	char		sCJ9[8];
	char		s01C[12];
	char		s051[8];
	char		s056[8];
	char		s005[8];
	char		s01D[12];
	char		sCC1[12];
	char		sCC2[12];
	char		sCE2;
	char		sCND[18];
	char		s053[255];
} T_CnapsRsv301;

typedef struct
{
	char		s051[8];
	char		s005[8];
	char		s01D[12];
	char		sCC1[12];
	char		sCC2[12];
	char		sCE2;
	char		sCND[18];
	char		s053[255];
	char		sCJ1[8];
	char		s043[8];
	char		sCCB[12];
	char		sCCC[12];
	char		sCJA[8];
	char		sCP1[8];
} T_CnapsRsv302;

char	gsDBTxdate[9];
char	gsDBTxtime[7];

/*************************************************************************/
/*                    BALAP  INTERFACE  AREA  TXCOM                      */
/*************************************************************************/
struct TXCOM_AREA
{
	char      apruntype;        /* application run type 1-online 2-batch  */
	char      txrsut;           /* txrsut , APCTL initial '0'             */
	char      tbsdy[DLEN_DATE]; /* today business date */
	char      nbsdy[DLEN_DATE]; /* next business date */
	char      lbsdy[DLEN_DATE]; /* last business date */
	char      nextdy[DLEN_DATE];/* next calendar date */
	char      lastdy[DLEN_DATE];/* last calendar date */
	char      batchdate[DLEN_DATE];/* batch date */
	char      actdate[DLEN_DATE];/* accounting date */
	char      auditdate[DLEN_DATE];/* post audit date */
	char      olstat;           /* online status */
	char      txtime[DLEN_TIME];/* Transaction time                       */
	short int totbox;           /* TOTA BOX count , APCTL initial 0       */
    long      rtncd;            /* return code    , APCTL initial 0       */
    char      prgnm[61];        /* program name , APCTL initial '    '    */
    char      msgid[5];         /* message id   , APCTL initial '    '    */
    long      response_id;      /* response destination , APCTL update    */
	int       srvid;            /* server id                              */
	char	  datasource;		/* data source */
};
typedef  struct  TXCOM_AREA  T_TXCOM_AREA;

#endif
