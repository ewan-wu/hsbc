#ifndef GLB_DEF_H
#define GLB_DEF_H

#if !defined(KBS_TRUE) || ((KBS_TRUE) != 1)
#define KBS_TRUE    (1)
#endif

#if !defined(KBS_FALSE) || ((KBS_FALSE) != 0)
#define KBS_FALSE   (0)
#endif

/* global region */
/* Modi by XuShenGen begin 20041021 */
#define	LPSYS_REGION	"MZH_"
/* Modi by XuShenGen end 20041021 */

/* DBS routine operation define */

#define DBS_FIND       1
#define DBS_LOCK       2
#define DBS_UPDATE     3
#define DBS_INSERT     4
#define DBS_DELETE     5
#define DBS_CLOSE      6
#define CUR_OPEN       7
#define CUR_FETCH      8
#define CUR_DELETE     9
#define CUR_CLOSE      10
#define CUR_UPDATE     11

#define  DBS_INI        12
#define  DBS_IUPD       13
#define  DBS_IDEL       14
#define  DBS_LOCK_NOCURSOR  15

/* TX hcode */
#define TX_HCODE_NORMAL			'0'
#define TX_HCODE_CANCEL			'1'
#define TX_HCODE_CHECK			'2'

/* transaction result */
# define  TX_SUCCESS            '0'
# define  TX_REJECT             '1'
# define  TX_DEADLOCK           '2'
# define  TX_MASTER_ERROR       '3'
# define  TX_LOGICAL_ERROR      '4'
# define  TX_RESERVE            '5'
# define  TX_RECURSIVE_LOOP     '9'
# define  TX_RETURN_RECEIPT     'A'				/*��ִ�ļ�*/

/* debit credit flag */
#define CRDB_DB					'1'
#define CRDB_CR					'2'

/* tx type */
#define TXTYPE_CASH			"01"
#define TXTYPE_TSFR			"02"
#define TXTYPE_RED_CASH		"03"
#define TXTYPE_RED_TSFR		"04"

/* clear type */
#define CLR_TYPE_OUT            '1'
#define CLR_TYPE_IN             '2'

/* RMB curcd */
#define CURCD_RMB			"RMB"
#define CURCD_USD			"157"  /* should be 840, laura */

/* pre-defined curno */
#define CURNO_RMB			"35"
#define CURNO_USD			"14"

/* accode tctd */
#define ACCODE_TCTD			"4070202"

/* MACRO */
#define chr2var(C,V)	{memcpy(V,C,sizeof(C));\
						V[sizeof(C)]='\0';}
#define var2chr(V,C)	memcpy(C,V,sizeof(C))
#define str2var(S,V)	strcpy(V,S)
#define var2str(V,S)	strcpy(S,V)

/* MACRO for VARCHAR */
#define str2var_V(S,V)	{ \
						strcpy((char*)V.arr,S); \
						V.len=strlen((char*)V.arr); \
						}
#define var2str_V(V,S)	{ \
						memcpy(S,(char*)V.arr,V.len); \
						S[V.len]='\0'; \
						}


/* application call return */
#define	SYS_OK			0
#define SYS_FAIL		-1

/* database sqlcode */
#define DB_OK			0
#define DB_NOTFOUND		1403
#define DB_NULL			-1405
#define DB_ISNULL	  	-1405 
#define DB_NOTINTRANS  -255
#define DB_DUPLICATE   -1
#define DB_INDEXDUP    -239

/* trace err.log */
#define ERRTRACE	cmErrorInfo(__FILE__, __LINE__);cmErrorHandle
#define ERRDESC	cmErrorDesc

/* true & false */
#define GLB_TRUE		'1'
#define GLB_FALSE		'0'

/* system expire date */
#define GLB_EXPIRE_DATE        "39991231"

/* for it_txcom apruntype */
#define		TXCOM_APRUNTYPE_ONLINE		'1'
#define		TXCOM_APRUNTYPE_BATCH		'2'

#define		TXCOM_DATASOURCE_ONLINE		'1'
#define		TXCOM_DATASOURCE_INQ		'2'

#define		FLAG_OFF			'0'
#define		FLAG_ON				'1'
#define		FLAG_UNHAPPENED		'2'

#define		SVTYPE_CASH			'0'
#define		SVTYPE_TRANSFER		'1'
#define		SVTYPE_INTER_BANK	'2'
#define		SVTYPE_ELEC_TRANS	'3'

#define		TXCODE_CANCEL		"9004"

/* inttype */
#define INTTYPE_CLOSE		'0'		/* ������Ϣ */
#define INTTYPE_ANULMID		'1'		/* ��Ƚ�Ϣ6/30 */
#define INTTYPE_ANULEND		'2'		/* ��Ƚ�Ϣ12/20 */
#define INTTYPE_QUARTER		'3'		/* ���Ƚ�Ϣ3/20,6/20,9/20,12/20 */
#define INTTYPE_MONTHLY		'4'		/* �¶Ƚ�Ϣÿ��20�� */
#define INTTYPE_DAILY		'5'		/* ÿ�ս�Ϣ */
#define INTTYPE_NONE		'6'		/* ����Ϣ */

#define COMMIT_CNT		500

#define BRNO_MIZUHO			"772"

/* for batch txt */
#define TXT_CREAT           0
#define TXT_APPEND          1
#define BULD_BUF_NOT_WRT    1
#define NOT_BULD_WRT_BUF    2
#define BULD_BUF_WRT_BUF    3

/* add by sunfei */
#define REMIT_SEQNO         "00000001"
#define FREEFMTFILE_SEQNO         "00000002"
#define	DAILY_SEQNO			"00000003"
#define PAYROLLMAIN_SEQNO         "00000004"

#endif
