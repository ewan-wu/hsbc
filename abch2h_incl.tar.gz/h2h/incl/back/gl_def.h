#ifndef __GL_DEF_H__
#define __GL_DEF_H__

#define OFFMR_STATUS_NORMAL			'1'
#define OFFMR_STATUS_CLOSED			'2'

#define ACGEN_FLG_NULL				'1'
#define ACGEN_FLG_INPUT				'2'
#define ACGEN_FLG_CONFIG			'3'
#define ACGEN_FLG_OFFMR				'4'

#define ACTMR_STATUS_CLOSED			'C'

/*add by pan beps begin*/
/*ACTFEECTL TYPE*/
#define ACT_SUM_TYPE1           "1"             /*С��������*/
/*add by pan beps end*/

#endif
