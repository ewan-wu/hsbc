#ifndef __GL_ITF_H__
#define __GL_ITF_H__

/* �����ʻ����ļ���¼ */
/* modi by pan 20050613
typedef struct
{
	char	sExtno[DLEN_EXTNO+1];
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
	char	sBrno[DLEN_BRNO+1];
	char	sCustno[DLEN_CUSTNO+1];
	char	sCurno[DLEN_CURCD+1];
	char	sActype[DLEN_TYPE2+1];
	char	sLicNo[DLEN_SDESC+1];
	char	sOverdraft[DLEN_TYPE+1];
	double	dSpread;
	char	sOpdate[DLEN_DATE+1];
	char	sClsdate[DLEN_DATE+1];
	char	sRatecd[DLEN_RATECD+1];
	char	sCalCode[DLEN_TYPE+1];
	char	sStatus[DLEN_TYPE+1];
} aTisGlActmrNew;
*/

/* add by Steven Liu 2005-07-29 begin */
typedef T_SPCACT aTisGlSpcactNew;
typedef T_SPCACT aTosGlSpcactNew;
/* add by Steven Liu 2005-07-29 end */

/* add by Jokey Sun 2005-07-29 begin */
typedef T_SPCACT aTisGlSpcactInq;
typedef T_SPCACT aTosGlSpcactInq;
typedef T_SPCACT aTisGlSpcactUpd;
typedef T_SPCACT aTosGlSpcactUpd;

/* add by Jokey Sun 2005-07-29 end */

typedef T_ACTMR aTisGlActmrNew;
 
typedef struct
{
	char	sStatus[DLEN_STATUS+1];
} aTosGlActmrNew;

/* �ʻ����ļ�������Ϣ */
/*modi by pan 20050613
typedef struct
{
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
	char	sExtno[DLEN_EXTNO+1];
	char	sActype[DLEN_TYPE2+1];
	char	sLicNo[DLEN_SDESC+1];
} aTisGlActmrUpd;
*/
typedef T_ACTMR aTisGlActmrUpd;

typedef struct
{
	char	sStatus[DLEN_STATUS+1];
} aTosGlActmrUpd;

/* �ʻ����ļ���ѯ */
typedef struct
{
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
} aTisGlActmrInq;

typedef T_ACTMR	aTosGlActmrInq;

/* �����ⲿ�ʺţ�17λ������ѯ�ڲ��ʺ�/��Ŀ */
typedef struct
{
	char	sExtno[DLEN_EXTNO+1];
	char	sBrno[DLEN_BRNO+1];
} aTisGlActnoInq;

typedef struct
{
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
} aTosGlActnoInq;

/* �����ͻ����ļ���¼ */
/* Modi by ZengShuFeng 20040803 begin */
/* 
typedef struct
{
	char	sCustno[DLEN_CUSTNO+1];
	char	sBrno[DLEN_BRNO+1];
	char	sCustCd[DLEN_CUSTCD+1];
	char	sName[DLEN_DESC+1];
	char	sCname[DLEN_DESC+1];
	char	sAddr[DLEN_DESC+1];
	char	sCaddr[DLEN_DESC+1];
	char	sZipcode[DLEN_ZIPCODE+1];
	char	sTel[DLEN_SDESC+1];
	char	sTelex[DLEN_SDESC+1];
	char	sOffcier[DLEN_TLRNO+1];
	char	sAttrCd[DLEN_TYPE+1];
	char	sJpFlg[DLEN_TYPE+1];
	char	sMailCont[DLEN_CONTCD+1];
	char	sLocCont[DLEN_CONTCD+1];
	char	sNation[DLEN_CONTCD+1];
	char	sEntpsCd[DLEN_SDESC+1];
	char	sEcoAttr[DLEN_TYPE2+1];
	char	sLicNo[DLEN_SDESC+1];
	char	sLawman[DLEN_PNAME+1];
	char	sLicPeriod[DLEN_SDESC+1];
	char	sRegAmt[DLEN_SDESC+1];
	char	sOpnbr[DLEN_BRNO+1];
} aTisGlCustmrNew;

typedef struct
{
	char	sStatus[DLEN_STATUS];
} aTosGlCustmrNew;
*/
typedef T_CUSTMR aTisGlCustmrNew;
typedef struct 
{
 	char null;
}aTosGlCustmrNew;
/* Modi by ZengShuFeng 20040803 end */

/* �ͻ����ļ�������Ϣ */
/* Modi by ZengShuFeng 20040803 begin */
/*
typedef struct
{
	char	sCustno[DLEN_CUSTNO+1];
	char	sBrno[DLEN_BRNO+1];
	char	sCname[DLEN_DESC+1];
	char	sCaddr[DLEN_DESC+1];
	char	sZipcode[DLEN_ZIPCODE+1];
} aTisGlCustmrUpd;

typedef struct
{
	char	sStatus[DLEN_STATUS+1];
} aTosGlCustmrUpd;
*/
typedef T_CUSTMR aTisGlCustmrUpd;
typedef struct 
{
 	char null;
}aTosGlCustmrUpd;
/* Modi by ZengShuFeng 20040803 end */

/* ��ѯ�ͻ����ļ� */
typedef struct
{
	char	sCustno[DLEN_CUSTNO+1];
	char	sBrno[DLEN_BRNO+1];
} aTisGlCustmrInq;

typedef T_CUSTMR	aTosGlCustmrInq;

/* �����ʻ����� */
typedef struct
{
	char	sActno[DLEN_ACTNO+1];
	char	sBrno[DLEN_BRNO+1];
	char	sName[DLEN_DESC+1];
	char	sVoctype[DLEN_VOCTYPE+1];
} aTisGlOffmrNew;

typedef struct
{
	char	sStatus[DLEN_STATUS+1];
} aTosGlOffmrNew;

/* �����ʻ��޸� */
typedef struct
{
	char	sActno[DLEN_ACTNO+1];
	char	sName[DLEN_DESC+1];
	char	sVoctype[DLEN_VOCTYPE+1];
} aTisGlOffmrUpd;

typedef T_OFFMR		aTosGlOffmrUpd;

/* �����ʻ���ѯ */
typedef struct
{
	char	sActno[DLEN_ACTNO+1];
} aTisGlOffmrInq;

typedef T_OFFMR		aTosGlOffmrInq;

/* �����ʻ����� */
typedef struct
{
	char	sTxdate[DLEN_DATE+1];
	char	sTlrno[DLEN_TLRNO+1];
	char	sTlsrno[DLEN_TLSRNO+1];
	char	sActno[DLEN_ACTNO+1];
	char	sCrdb[DLEN_TYPE+1];			/* 1���� 2���� */
	double	dAmount;
	char	sRemarks[DLEN_DESC+1];
} aTisGlOffmrAct;

typedef T_OFFMR		aTosGlOffmrAct;

/* ������Ʒ�¼���� */
typedef struct
{
    char    sOpcode[DLEN_OPCODE];
    char    sOpdesc[DLEN_DESC];
	struct
	{
    	char    sFlg[DLEN_TYPE+1];
    	char    sAccode[DLEN_ACCODE+1];
    	char    sActno[DLEN_ACTNO+1];
	} dbdtl[4];
	struct
	{
    	char    sFlg[DLEN_TYPE+1];
    	char    sAccode[DLEN_ACCODE+1];
    	char    sActno[DLEN_ACTNO+1];
	} crdtl[4];
} aTisGlAcgenNew;

typedef struct
{
	char	null;
} aTosGlAcgenNew;

/* ��ѯ�Ƿ�ΪGCMS�ʻ� */
typedef struct
{
	char	sAccode[DLEN_ACCODE+1];
	char	sActno[DLEN_ACTNO+1];
} aTisGlGcmsCtl;
typedef struct
{
	char	sStatus[DLEN_STATUS+1];
} aTosGlGcmsCtl;
/*2004-02-05 wenjian add begin*/
typedef T_PRNDTL aTisGlPrndtlNew;
typedef struct 
{
 	char null;
}aTosGlPrndtlNew;
/*2004-02-05 wenjian add end */
/* Add by ZengShuFeng begin 2004-08-02 */

typedef T_POBENDTL aTisGlPobendtlNew;

typedef struct 
{
	int	iBenseq;
}aTosGlPobendtlNew;

typedef struct
{
	char	sOptype[1];
	char	sBrno[4];
	int		iBenseq;
	char	sCustno[13];
	char	sBenactno[36];
	char	sType[2];
	char	sUsage[2];
	char	sBenname[61];
	char	sBenbkno[13];
	char	sBenbkname[61];
	char	sSwftccy[4];
	double	dAmount;
	char	sRemarks[61];
	char	sRsv1[31];
	char	sRsv2[31];
	char	sRsv3[31];
}aTisGlPobendtlUpd;

typedef struct 
{
 	char null;
}aTosGlPobendtlUpd;

typedef T_POFPRNDTL aTisGlPofprndtlUpd;

typedef struct 
{
 	char null;
}aTosGlPofprndtlUpd;

typedef T_MTSERACT aTisGlMtseractNew;

typedef struct 
{
 	char null;
}aTosGlMtseractNew;

typedef T_MTSERACT aTisGlMtseractUpd;

typedef struct 
{
 	char null;
}aTosGlMtseractUpd;
/* Add by ZengShuFeng end 2004-08-02 */

typedef T_POFPRNDTL aTisGlPofprndtlNew;
typedef T_POFPRNDTL aTosGlPofprndtlNew;

typedef T_POBENDTL aTisGlPobendtlInq;
typedef T_POBENDTL aTosGlPobendtlInq;

typedef T_PORPRNDTL aTisGlPorprndtlNew;
typedef T_PORPRNDTL aTosGlPorprndtlNew;

typedef T_PORPRNDTL aTisGlPorprndtlUpd;
typedef T_PORPRNDTL aTosGlPorprndtlUpd;

#endif
