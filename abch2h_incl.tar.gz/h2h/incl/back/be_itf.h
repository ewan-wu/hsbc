#ifndef	__BE_ITF_H__
#define	__BE_ITF_H__

typedef	T_BEPSUNVBT	aTisBeBepsunvbtNew;
typedef	T_BEPSUNVBT	aTosBeBepsunvbtNew;

typedef	T_BEPSUNVBT	aTisBeBepsunvbtInq;
typedef	T_BEPSUNVBT	aTosBeBepsunvbtInq;

typedef	T_BEPSUNVBT	aTisBeBepsunvbtUpd;
typedef	T_BEPSUNVBT	aTosBeBepsunvbtUpd;

typedef	T_BEPSUNV	aTisBeBepsunvNew;
typedef	T_BEPSUNV	aTosBeBepsunvNew;

typedef	T_BEPSUNV	aTisBeBepsunvInq;
typedef	T_BEPSUNV	aTosBeBepsunvInq;

typedef	T_BEPSUNV	aTisBeBepsunvUpd;
typedef	T_BEPSUNV	aTosBeBepsunvUpd;

typedef	T_BEPSLMTMNG	aTisBeBepslmtmngNew;
typedef	T_BEPSLMTMNG	aTosBeBepslmtmngNew;

typedef	T_BEPSLMTMNG	aTisBeBepslmtmngInq;
typedef	T_BEPSLMTMNG	aTosBeBepslmtmngInq;

typedef	T_BEPSLMTMNG	aTisBeBepslmtmngUpd;
typedef	T_BEPSLMTMNG	aTosBeBepslmtmngUpd;

typedef T_BEPSQUEMNG    aTisBeBepsquemngUpd;
typedef T_BEPSQUEMNG    aTosBeBepsquemngUpd;

typedef T_BEPSQUEMNG    aTisBeBepsquemngNew;
typedef T_BEPSQUEMNG    aTosBeBepsquemngNew;

typedef T_BEPSQUEMNG    aTisBeBepsquemngInq;
typedef T_BEPSQUEMNG    aTosBeBepsquemngInq;

typedef T_BEPSQUEDTL    aTisBeBepsquedtlNew;
typedef T_BEPSQUEDTL    aTosBeBepsquedtlNew;


typedef	T_BEPSALRMMNG	aTisBeBepsalrmmngNew;
typedef	T_BEPSALRMMNG	aTosBeBepsalrmmngNew;

typedef	T_BEPSALRMMNG	aTisBeBepsalrmmngUpd;
typedef	T_BEPSALRMMNG	aTosBeBepsalrmmngUpd;

typedef T_BEPSALRMMNG   aTisBeBepsalrmmngInq;
typedef T_BEPSALRMMNG   aTosBeBepsalrmmngInq;

typedef T_BEPSALRMLST   aTisBeBepsalrmlstNew;
typedef T_BEPSALRMLST   aTosBeBepsalrmlstNew;

typedef T_BEPSCMNCHG   aTisBeBepscmnchgNew;
typedef T_BEPSCMNCHG   aTosBeBepscmnchgNew;

typedef T_BEPSCMNCHG   aTisBeBepscmnchgInq;
typedef T_BEPSCMNCHG   aTosBeBepscmnchgInq;

typedef T_BEPSPRVLG   aTisBeBepsprvlgNew;
typedef T_BEPSPRVLG   aTosBeBepsprvlgNew;

typedef T_BEPSLWND   aTisBeBepslwndNew;
typedef T_BEPSLWND   aTosBeBepslwndNew;


typedef	T_BEPSCNCL	aTisBeBepscnclNew;
typedef	T_BEPSCNCL	aTosBeBepscnclNew;

typedef	T_BEPSCNCL	aTisBeBepscnclUpd;
typedef	T_BEPSCNCL	aTosBeBepscnclUpd;

typedef	T_BEPSCNCL	aTisBeBepscnclInq;
typedef	T_BEPSCNCL	aTosBeBepscnclInq;


typedef	T_BEPSCRT	aTisBeBepscrtNew;
typedef	T_BEPSCRT	aTosBeBepscrtNew;

typedef	T_BEPSUNPAY	aTisBeBepsunpayNew;
typedef	T_BEPSUNPAY	aTosBeBepsunpayNew;

typedef	T_BEPSUNPAY	aTisBeBepsunpayUpd;
typedef	T_BEPSUNPAY	aTosBeBepsunpayUpd;

typedef	T_BEPSUNPAY	aTisBeBepsunpayInq;
typedef	T_BEPSUNPAY	aTosBeBepsunpayInq;


typedef	T_BEPSRTN	aTisBeBepsrtnNew;
typedef	T_BEPSRTN	aTosBeBepsrtnNew;

typedef	T_BEPSRTN	aTisBeBepsrtnUpd;
typedef	T_BEPSRTN	aTosBeBepsrtnUpd;

typedef	T_BEPSRTN	aTisBeBepsrtnInq;
typedef	T_BEPSRTN	aTosBeBepsrtnInq;

typedef	T_BEPSST	aTisBeBepsstNew;
typedef	T_BEPSST	aTosBeBepsstNew;

typedef	T_BEPSOPRSTA	aTisBeBepsoprstaNew;
typedef	T_BEPSOPRSTA	aTosBeBepsoprstaNew;

typedef	T_BEPSOPRSTA	aTisBeBepsoprstaInq;
typedef	T_BEPSOPRSTA	aTosBeBepsoprstaInq;

typedef	T_BEPSOPRSTA	aTisBeBepsoprstaUpd;
typedef	T_BEPSOPRSTA	aTosBeBepsoprstaUpd;

typedef	T_BEPSMSGSTA	aTisBeBepsmsgstaNew;
typedef	T_BEPSMSGSTA	aTosBeBepsmsgstaNew;

typedef	T_BEPSMSGSTA	aTisBeBepsmsgstaInq;
typedef	T_BEPSMSGSTA	aTosBeBepsmsgstaInq;

typedef	T_BEPSMSGSTA	aTisBeBepsmsgstaUpd;
typedef	T_BEPSMSGSTA	aTosBeBepsmsgstaUpd;

typedef	T_BEPSFEE	aTisBeBepsfeeNew;
typedef	T_BEPSFEE	aTosBeBepsfeeNew;

typedef	T_BEPSOUTRTN	aTisBeBepsoutrtnNew;
typedef	T_BEPSOUTRTN	aTosBeBepsoutrtnNew;

typedef	T_BEPSRTNLST	aTisBeBepsrtnlstNew;
typedef	T_BEPSRTNLST	aTosBeBepsrtnlstNew;

typedef	T_BEPSFEELST	aTisBeBepsfeelstNew;
typedef	T_BEPSFEELST	aTosBeBepsfeelstNew;

typedef	T_BEPSCRQT	aTisBeBepscrqtNew;
typedef	T_BEPSCRQT	aTosBeBepscrqtNew;

typedef T_BEPSRQST  aTisBeBepsrqstNew;
typedef T_BEPSRQST  aTosBeBepsrqstNew;

typedef T_BEPSRQST  aTisBeBepsrqstInq;
typedef T_BEPSRQST  aTosBeBepsrqstInq;

typedef T_BEPSRQST  aTisBeBepsrqstUpd;
typedef T_BEPSRQST  aTosBeBepsrqstUpd;

typedef T_BEPSFREE  aTisBeBepsfreeNew;
typedef T_BEPSFREE  aTosBeBepsfreeNew;

typedef T_BEPSSTACHG aTisBeBepsstachgNew;
typedef T_BEPSSTACHG aTosBeBepsstachgNew;

typedef T_BEPSSTP aTisBeBepsstpNew;
typedef T_BEPSSTP aTosBeBepsstpNew;

typedef T_BEPSGTHCHKLST aTisBeBepsgthchklstNew;
typedef T_BEPSGTHCHKLST aTosBeBepsgthchklstNew;

typedef T_BEPSSETLST aTisBeBepssetlstNew;
typedef T_BEPSSETLST aTosBeBepssetlstNew;

typedef T_EXCHGPROXYNO aTisBeExchgproxynoUpd;
typedef T_EXCHGPROXYNO aTosBeExchgproxynoUpd;

typedef T_EXCHGPROXYNO aTisBeExchgproxynoNew;
typedef T_EXCHGPROXYNO aTosBeExchgproxynoNew;

typedef T_EXCHGPROXYNO aTisBeExchgproxynoInq;
typedef T_EXCHGPROXYNO aTosBeExchgproxynoInq;

typedef T_EXCHGPROXYCHG aTisBeExchgproxychgUpd;
typedef T_EXCHGPROXYCHG aTosBeExchgproxychgUpd;

typedef T_EXCHGPROXYCHG aTisBeExchgproxychgNew;
typedef T_EXCHGPROXYCHG aTosBeExchgproxychgNew;

typedef T_EXCHGPROXYCHG aTisBeExchgproxychgInq;
typedef T_EXCHGPROXYCHG aTosBeExchgproxychgInq;

typedef T_BEPSPRONOCHG aTisBeBepspronochgUpd;
typedef T_BEPSPRONOCHG aTosBeBepspronochgUpd;

typedef T_BEPSPRONOCHG aTisBeBepspronochgNew;
typedef T_BEPSPRONOCHG aTosBeBepspronochgNew;

typedef T_BEPSPRONOCHG aTisBeBepspronochgInq;
typedef T_BEPSPRONOCHG aTosBeBepspronochgInq;

typedef T_BEPSPARAMNG aTisBeBepsparamngNew;
typedef T_BEPSPARAMNG aTosBeBepsparamngNew;

typedef T_BEPSPARA aTisBeBepsparaUpd;
typedef T_BEPSPARA aTosBeBepsparaUpd;

typedef T_BEPSCMN aTisBeBepscmnUpd;
typedef T_BEPSCMN aTosBeBepscmnUpd;

typedef T_BEPSCMN aTisBeBepscmnInq;
typedef T_BEPSCMN aTosBeBepscmnInq;

/* ��ѯ������Ϣ */
typedef struct 
{
	char    sBrno[DLEN_HVPS_BRNO+1];
	char	sDate[DLEN_DATE+1];
}aTisBeBanknoInq;

typedef struct 
{
	char    sBankname[DLEN_DESC+1];
	char    sStbrno[DLEN_HVPS_BRNO+1];
	char	sNodecode[DLEN_HVPS_SNDCODE+1];
}aTosBeBanknoInq;

/*С��֧������*/
typedef T_BEPSSND aTisBeBepssndNew;
typedef struct
{
	char	null;
}aTosBeBepssndNew;

typedef struct
{
   char    sTxdate[DLEN_DATE+1];
   char    sTlrno[DLEN_TLRNO+1];
   char    sTlsrno[DLEN_TLSRNO+1];
}aTisBeBepssndInq;
typedef T_BEPSSND aTosBeBepssndInq;

typedef T_BEPSSND aTisBeBepssndUpd;
typedef struct
{
	char	null;
}aTosBeBepssndUpd;

/*���ι�����*/
typedef T_BEPSBTMNG aTisBeBepsbtmngNew;
typedef struct
{
	char	null;
}aTosBeBepsbtmngNew;

typedef struct
{
   char    sBedate[DLEN_DATE+1];
   char    sBtno[DLEN_BEPS_BTNO+1];
   char    sSndStBrno[DLEN_HVPS_BRNO+1];
   char    sBrno[DLEN_BRNO+1];
}aTisBeBepsbtmngInq;
typedef T_BEPSBTMNG aTosBeBepsbtmngInq;

typedef struct
{
   char    sRtBedate[DLEN_DATE+1];
   char    sRtBtno[DLEN_BEPS_BTNO+1];
   char    sRtStBrno[DLEN_HVPS_BRNO+1];
   char    sBrno[DLEN_BRNO+1];
}aTisBeBepsbtmngRtInq;
typedef T_BEPSBTMNG aTosBeBepsbtmngRtInq;

typedef T_BEPSBTMNG aTisBeBepsbtmngUpd;
typedef struct
{
	char	null;
}aTosBeBepsbtmngUpd;

/*С��֧������*/
typedef T_BEPSRCV aTisBeBepsrcvNew;
typedef struct
{
	char	null;
}aTosBeBepsrcvNew;

typedef struct
{
   char    sTxdate[DLEN_DATE+1];
   char    sTlrno[DLEN_TLRNO+1];
   char    sTlsrno[DLEN_TLSRNO+1];
}aTisBeBepsrcvInq;
typedef T_BEPSRCV aTosBeBepsrcvInq;

typedef T_BEPSRCV aTisBeBepsrcvUpd;
typedef struct
{
	char	null;
}aTosBeBepsrcvUpd;

typedef T_BEPSAPIMSG aTisBeBepsapimsgNew;
typedef struct
{
	char	null;
}aTosBeBepsapimsgNew;

typedef struct
{
   char    sTxdate[DLEN_DATE+1];
   char    sTlrno[DLEN_TLRNO+1];
   char    sTlsrno[DLEN_TLSRNO+1];
}aTisBeBepsrcvRej;
typedef T_BEPSRCV aTosBeBepsrcvRej;

/*��ʷ������Ϣ*/
typedef T_PAYINFO aTisBePayinfoUpd;
typedef struct
{
	char	null;
}aTosBePayinfoUpd;

typedef T_PAYINFO aTisBePayinfoNew;
typedef struct
{
	char	null;
}aTosBePayinfoNew;
#endif
