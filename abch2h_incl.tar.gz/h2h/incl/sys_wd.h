#ifndef SYS_WD_H
#define SYS_WD_H
typedef struct TABLE_CDATE
{
	char	sCdateHolidy[2];
	char	sCdateWeekdy[2];
	char	sCdateTbsdy[9];
	char	sCdateNbsdy[9];
	char	sCdateNnbsdy[9];
	char	sCdateLbsdy[9];
	char	sCdateLmndy[9];
	char	sCdateTmndy[9];
	char	sCdateFnbsdy[9];
	int		iCdateNdycnt;
	int		iCdateNndycnt;
	int		iCdateLdycnt;
	int		iCdateJday;
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_CDATE;
typedef struct TABLE_CURRDEF
{
	char	sCurno[3];
	char	sCurcd[4];
	char	sCurname[21];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_CURRDEF;
typedef struct TABLE_ERRCODE
{
	char	sEcode[6];
	char	sEmsg[81];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_ERRCODE;
typedef struct TABLE_EXCHGCTL
{
	char	sExchgno[7];
	char	sBrno[4];
	char	sName[61];
	char	sType[2];
	char	sAddr[61];
	char	sTel[21];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_EXCHGCTL;
typedef struct TABLE_FEEFRG
{
	char	sBrno[4];
	char	sFratecd[4];
	double	dLowTxnAmt;
	double	dHighTxnAmt;
	char	sType[2];
	double	dFeeAmt;
	double	dFeeRate;
	double	dDiscRate;
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_FEEFRG;
typedef struct TABLE_FEERATE
{
	char	sBrno[4];
	char	sFratecd[4];
	char	sVdate[9];
	char	sName[21];
	double	dFeeRate;
	double	dFixAmt;
	double	dDiscRate;
	char	sType[2];
	char	sFrgmtFlg[2];
	double	dOpbrRate;
	double	dTxbrRate;
	char	sFcode[3];
	char	sFtype[2];
	char	sActno[21];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_FEERATE;
typedef struct TABLE_FILEREC
{
	char	sBrno[4];
	char	sFiltype[2];
	char	sRcvdate[9];
	char	sRcvtime[7];
	char	sFilname[41];
	char	sSeqno[4];
	char	sStatus[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_FILEREC;
typedef struct TABLE_GLOBAL
{
	int		iGlobalidx;
	char	sRegion[8];
	char	sOnlinestat[2];
	char	sDatasource[2];
	char	sTbsdy[9];
	char	sActdate[9];
	char	sBatchdate[9];
	char	sNbsdy[9];
	char	sLbsdy[9];
	char	sNextdy[9];
	char	sLastdy[9];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_GLOBAL;
typedef struct TABLE_HOLIDAY
{
	char	sHdate[9];
	char	sWeekdy[2];
	char	sWork[2];
	char	sXend[2];
	char	sMend[2];
	char	sQend[2];
	char	sHend[2];
	char	sYend[2];
	char	sIntday[2];
	char	sCxintday[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_HOLIDAY;
typedef struct TABLE_HSXDTL
{
	char	sTxday[9];
	char	sKinbr[4];
	char	sTlrno[9];
	char	sTlsrno[8];
	char	sTxtime[15];
	char	sAfcls[2];
	char	sHtrmseq[3];
	char	sHejfno[8];
	char	sOpnbr[4];
	char	sTrmseq[3];
	char	sEjfno[8];
	char	sTaskid[3];
	char	sTmtype[2];
	char	sTxno[5];
	char	sHcode[2];
	char	sAppno[11];
	char	sNbcd[2];
	char	sMulttx[2];
	char	sMultno[7];
	char	sVflag[2];
	char	sVtlrno[9];
	char	sText[1001];
}T_HSXDTL;
typedef struct TABLE_INTRATE
{
	char	sCurcd[4];
	char	sRatecd[4];
	char	sVdate[9];
	char	sName[21];
	char	sType[3];
	char	sCrdb[2];
	double	dRate;
	double	dRateup;
	double	dRatedown;
	int		iTerm;
	int		iTermup;
	int		iTermdown;
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_INTRATE;
typedef struct TABLE_SCTL
{
	char	sBrno[4];
	char	sTermno[3];
	char	sType[2];
	char	sIp[21];
	char	sTty[21];
	char	sStatus[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_SCTL;
typedef struct TABLE_SWFTDTL
{
	char	sSwftno[13];
	char	sSwftccy[4];
	char	sSwftname[61];
	char	sSwftact[31];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_SWFTDTL;
typedef struct TABLE_SYSPARA
{
	char	sParano[5];
	char	sBrno[4];
	char	sParaval[61];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_SYSPARA;
typedef struct TABLE_SYSSTAT
{
	char	sRegion[8];
	char	sWflflg[31];
	char	sWflstep[61];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_SYSSTAT;
typedef struct TABLE_TLRCTL
{
	char	sTlrno[9];
	char	sBrno[4];
	char	sName[21];
	char	sPassword[9];
	char	sStatus[2];
	char	sGender[2];
	char	sBorndate[9];
	char	sRights[61];
	char	sLogtrmseq[3];
	char	sLogbrno[4];
	int		iMsrno;
	char	sFirst[2];
	char	sExpiration[9];
	char	sOldPswd[97];
	char	sFrozen[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_TLRCTL;
typedef struct TABLE_XDTL
{
	char	sTxday[9];
	char	sKinbr[4];
	char	sTlrno[9];
	char	sTlsrno[8];
	char	sTxtime[15];
	char	sAfcls[2];
	char	sHtrmseq[3];
	char	sHejfno[8];
	char	sOpnbr[4];
	char	sTrmseq[3];
	char	sEjfno[8];
	char	sTaskid[3];
	char	sTmtype[2];
	char	sTxno[5];
	char	sHcode[2];
	char	sAppno[11];
	char	sNbcd[2];
	char	sMulttx[2];
	char	sMultno[7];
	char	sVflag[2];
	char	sVtlrno[9];
	char	sText[1000];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_XDTL;
typedef struct TABLE_CNSPKTINF
{
	int		iCmtIndex;
	int		iTagIndex;
	char	sCmt[7];
	char	sTag[4];
	char	sTagType[2];
	char	sTagDesc[51];
	int		iTagOpt;
	int		iTagFlg;
	int		iLenFlg;
	int		iTagFlgPos;
	int		iDataLen;
	char	sRecUpdtTime[15];
	char	sRsv1[31];
	char	sRsv2[31];
}T_CNSPKTINF;

typedef struct TABLE_BCTL
{
	char	sBrno[4];
	char	sName[61];
	char	sBriefName[11];
	char	sStatus[2];
	char	sUnionno[13];
	char	sExchgno[7];
	char	sWorkstat[2];
	char	sModdate[9];
	char	sRound[3];
	char	sEbktag[4];
	char	sBatch[2];
	char	sActseq[3];
	char	sUsr[21];
	char	sPswd[21];
	char	sIp[21];
	char	sBeLck[9];
	char	sBeDate[9];
	char	sBeStatus[2];
	char	sBeChkstat[3];
	char	sRsvFlg1[2];
	char	sRsvFlg2[2];
	char	sRsvFlg3[2];
	char	sRsvFlg4[2];
	char	sRsvFlg5[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
	char	sRsv6[61];
	char	sRsv7[61];
	char	sRsv8[61];
	char	sRsv9[61];
	char	sRsv10[61];
}T_BCTL;

typedef struct TABLE_HVBANKNO
{
	char	sBrno[13];
	char	sStbrno[13];
	char	sRcvbrno[13];
	char	sBankname[61];
	char	sBanktype[2];
	char	sBrcode[5];
	char	sAcctstatus[2];
	char	sAddr[61];
	char	sAltdate[20];
	char	sAltissno[9];
	char	sAlttype[2];
	char	sAsaltdt[9];
	char	sAsalttm[15];
	char	sCategory[3];
	char	sClscode[4];
	char	sDreccode[13];
	char	sEffdate[9];
	char	sEmail[61];
	char	sInvdate[9];
	char	sNodecode[5];
	char	sPbccode[13];
	char	sPostcode[7];
	char	sRemark[61];
	char	sSname[61];
	char	sStatus[2];
	char	sSuprlist[25];
	char	sTel[61];
	char	sCbnkcode[13];
	char	sCnapsflag[2];
	char	sEissitecode[5];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_HVBANKNO;
typedef struct TABLE_REMITCTL
{
	char	sTxdate[9];
	char	sBrno[4];
	char	sType[2];
	int		iSeqno;
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_REMITCTL;
typedef struct TABLE_TXDTL
{
	char	sTxdate[9];
	char	sTlrno[9];
	char	sTlsrno[8];
	char	sBrno[4];
	char	sStatus[2];
	char	sVdate[9];
	char	sRefno[15];
	char	sType[2];
	char	sRound[2];
	char	sBatchno[17];
	char	sTxno[5];
	char	sTxtime[15];
	char	sChkTlrno[9];
	char	sChkTime[15];
	char	sApvTlrno[9];
	char	sApvTime[15];
	char	sCfmTlrno[9];
	char	sCfmTime[15];
	char	sDelTlrno[9];
	char	sDelTime[15];
	char	sDbCustno1[13];
	char	sDbAccode1[6];
	char	sDbActno1[13];
	char	sDbCurcd1[5];
	double	dDbAmount1;
	char	sDbDivcode1[3];
	char	sDbEncode1[4];
	char	sDbCustno2[13];
	char	sDbAccode2[6];
	char	sDbActno2[13];
	char	sDbCurcd2[5];
	double	dDbAmount2;
	char	sDbDivcode2[3];
	char	sDbEncode2[4];
	char	sDbCustno3[13];
	char	sDbAccode3[6];
	char	sDbActno3[13];
	char	sDbCurcd3[5];
	double	dDbAmount3;
	char	sDbDivcode3[3];
	char	sDbEncode3[4];
	char	sDbCustno4[13];
	char	sDbAccode4[6];
	char	sDbActno4[13];
	char	sDbCurcd4[5];
	double	dDbAmount4;
	char	sDbDivcode4[3];
	char	sDbEncode4[4];
	char	sCrCustno1[13];
	char	sCrAccode1[6];
	char	sCrActno1[13];
	char	sCrCurcd1[5];
	double	dCrAmount1;
	char	sCrDivcode1[3];
	char	sCrEncode1[4];
	char	sCrCustno2[13];
	char	sCrAccode2[6];
	char	sCrActno2[13];
	char	sCrCurcd2[5];
	double	dCrAmount2;
	char	sCrDivcode2[3];
	char	sCrEncode2[4];
	char	sCrCustno3[13];
	char	sCrAccode3[6];
	char	sCrActno3[13];
	char	sCrCurcd3[5];
	double	dCrAmount3;
	char	sCrDivcode3[3];
	char	sCrEncode3[4];
	char	sCrCustno4[13];
	char	sCrAccode4[6];
	char	sCrActno4[13];
	char	sCrCurcd4[5];
	double	dCrAmount4;
	char	sCrDivcode4[3];
	char	sCrEncode4[4];
	char	sOppName[61];
	char	sOppActno[33];
	char	sOppBank[61];
	char	sOppBrno[13];
	char	sVoctype[3];
	char	sVocno[21];
	char	sRemarks[61];
	char	sCustRef[17];
	char	sBankRef[17];
	char	sPaytype[2];
	char	sRsv1[61];
	char	sRsv2[61];
	char	sRsv3[61];
	char	sRsv4[61];
	char	sRsv5[61];
}T_TXDTL;

typedef struct TABLE_HSEXCHGDTL
{
	char	sTxdate[9];
	char	sTlrno[9];
	char	sTlsrno[8];
	char	sBrno[4];
	char	sVdate[9];
	char	sRound[2];
	char	sType[2];
	char	sReject[2];
	char	sAccode[6];
	char	sActno[13];
	char	sExtno[18];
	char	sDueAccode[6];
	char	sDueActno[13];
	char	sDueExtno[18];
	double	dAmount;
	char	sVoctype[3];
	char	sVocno[21];
	char	sOppName[61];
	char	sOppActno[33];
	char	sOppBank[61];
	char	sOppBrno[7];
	char	sRemarks[61];
	char	sSource[2];
	char	sCustRef[17];
	char	sBankRef[17];
}T_HSEXCHGDTL;
#endif
