#ifndef _FORWARD_H
#define _FORWARD_H

#define FWD_TARGET_HOST        'E'
#define FWD_TARGET_CNAPS       'C'

#define DEFAULT_FWD_TIMES      5000

#define MAX_FWD_MSG_LEN        2048-256         /* ?? */

typedef struct
{
	char        sSysWorkDate[8];
	char		sSysClsSsn[6];
    char        sRefno[8];
	char		sSender[12];
	char		sMsgType[6];
    char        cFwdTarget;
    long        nTxnNumber;
    short       nFwdTimes;
    short       nTxnMsgLen;
    char        sTxnMsg[MAX_FWD_MSG_LEN];
	char		sMemo[255];
} FwdMsgInfDef;

/* function in libcom.a */
short SvFwdInst(FwdMsgInfDef *);
short SvFwdUpdt(char *sSysWorkDate, char *sSysClsSsn, short nFwdTimes, short nTxnMsgLen, char *sTxnMsg);
short SvFwdReset(char *sSysWorkDate, char *sSysClsSsn, short nFwdTimes);

#endif
