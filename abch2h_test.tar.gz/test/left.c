#include <stdio.h>

int main()
{
	char str1[]="1 3 rtt.12yu";
	char *pstr = NULL;
	pstr=Left(str1);
	
	printf("%s\n", *pstr);

	return 0;
}
	
char * Left( char *str )
{
    	char    *s = str;

   		 while ( *s )
        	if ( (*s==' ') || (*s=='\t') || (*s=='\r') || (*s=='\n') || (*s=='.') )
            	++s;
        	else
            	break;

    	if ( s > str )
        	strcpy ( (char *)str, (char *)s );

    	return str;
}


