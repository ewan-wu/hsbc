/******************************************************************************/
/*  Kernel Banking System                                                     */
/*  Copyright (c) 2002                                                        */
/*  Shanghai Huateng Software System Co., Ltd.                                */
/*  All Rights Reserved                                                       */
/******************************************************************************/

#include <stdio.h>
#include <time.h>
#include <glb_dic.h>

#include "txatom_cm.h"

char *cmgetdate()
{
	time_t wdt;
	struct tm	*wdtm;
	char fmt[9];

	time(&wdt);
	wdtm=localtime(&wdt);

	strftime(fmt,9,"%Y%m%d",wdtm);
	return fmt;
}

char *cmgettime()
{
	time_t wdt;
	struct tm	*wdtm;
	char fmt[7];

	time(&wdt);
	wdtm=localtime(&wdt);

	strftime(fmt,7,"%H%M%S",wdtm);
	return fmt;
}

char *cmGetDttm(void)
{
	time_t wdt;
	struct tm	*wdtm;
	char fmt[DLEN_DATETIME+1];

	time(&wdt);
	wdtm=localtime(&wdt);

	strftime(fmt,sizeof(fmt),"%Y%m%d%H%M%S",wdtm);
	return fmt;
}
/** 20040406 WenJian DEL 
ͬ������cmGetNnbsdy��cmGetNnbsdy��cmTool.pc��ʵ�֡�
char* cmGetNnbsdy(char *tbsdy)
{
	T_CDATE		wdCdate;

	memset(&wdCdate, 0, sizeof(wdCdate));

	memcpy(wdCdate.sCdateTbsdy, tbsdy, DLEN_DATE);

	if((it_txcom.rtncd = DbsCDATE(DBS_FIND, &wdCdate)) != DB_OK)
	{
		ERRTRACE(E_DB_CDATE_RERR, "TBSDY[%s]", tbsdy);
		return NULL;
	}

	return wdCdate.sCdateNnbsdy;
}

char* cmGetNbsdy(char *tbsdy)
{
	T_CDATE		wdCdate;

	memset(&wdCdate, 0, sizeof(wdCdate));

	memcpy(wdCdate.sCdateTbsdy, tbsdy, DLEN_DATE);

	if((it_txcom.rtncd = DbsCDATE(DBS_FIND, &wdCdate)) != DB_OK)
	{
		ERRTRACE(E_DB_CDATE_RERR, "TBSDY[%s]", tbsdy);
		return NULL;
	}

	return wdCdate.sCdateNbsdy;
}
**/
