/******************************************************************************/
/*  Kernel Banking System                                                     */
/*  Copyright (c) 2002                                                        */
/*  Shanghai Huateng Software System Co., Ltd.                                */
/*  All Rights Reserved                                                       */
/******************************************************************************/
#include <time.h>
#include "txatom_cm.h"

/*static T_TXDTL	wdTxdtl;

int cmTxdtl(char *txdate, char *tlrno, char *tlsrno)
{
	memset(&wdTxdtl, 0, sizeof(wdTxdtl));

	memcpy(wdTxdtl.sTxdate, txdate, DLEN_DATE);
	memcpy(wdTxdtl.sTlrno, tlrno, DLEN_TLRNO);
	memcpy(wdTxdtl.sTlsrno, tlsrno, DLEN_TLSRNO);

	if((it_txcom.rtncd = DbsTXDTL(DBS_FIND, &wdTxdtl)) != DB_OK)
	{
		ERRTRACE(E_DB_TXDTL_RERR, "%s-%s-%s", txdate, tlrno, tlsrno);
		return;
	}

	switch(wdTxdtl.sStatus[0])
	{
		case TXDTL_STATUS_MADE:
			ERRTRACE(E_SE_TXDTL_UNCHECKED, NULL);
			return -1;
		case TXDTL_STATUS_CHECKED:
			ERRTRACE(E_SE_TXDTL_UNAPPROVED, NULL);
			return -1;
		case TXDTL_STATUS_APPROVED:
			ERRTRACE(E_SE_TXDTL_UNSUCCESS, NULL);
			return -1;
		case TXDTL_STATUS_SUCCESS:
			return 0;
		case TXDTL_STATUS_FAILED:
			ERRTRACE(E_SE_TXDTL_FAILED, NULL);
			return -1;
		case TXDTL_STATUS_DELETED:
			ERRTRACE(E_SE_TXDTL_DELETED, NULL);
			return -1;
		case TXDTL_STATUS_KICKBACK:
			ERRTRACE(E_SE_TXDTL_KICKBACK, NULL);
			return -1;
		default:
			ERRTRACE(E_SE_TXDTL_STATUS, "STATUS[%s]", wdTxdtl.sStatus);
			return -1;
	}
}*/

/* ȥ��str��β���Ŀ��ַ� */
char * cmRightTrim ( char *str )
{
    char    *s = str;

    while ( *s )
        ++s;

    --s;
    while ( s >= str )
	{
		/***
        if ( (*s==' ') || (*s=='\t') || (*s=='\r') || (*s=='\n') )
		***/
        if ( (*s==' ') || (*s=='\t') )
		{
    		*s = 0;
            --s;
		}
        else
            break;
	}

    return str;
}

