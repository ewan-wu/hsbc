/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   PreTX                                                              */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���׳�ʼ����                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20021216       Calvin Wei           Reinit                         */
/************************************************************************/

#include "txatom_cm.h"

int aSysBasicCheck(void);
int aSysStopCheck(void);
int aSysBranchCheck(void);

/******************************************************************************/
/*  Function     : aSysBasicCheck()                                           */
/*  Description  : check system tables before TX                              */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                -1 - fail                                                   */
/******************************************************************************/
int aSysBasicCheck()
{
	/* ��黻�ձ�־ */
	/*
	if ( aSysStopCheck() != SYS_OK )
		return SYS_FAIL;
	*/

	/* ��齻���� */
	if ( aSysBranchCheck() != SYS_OK )
		return SYS_FAIL;

	/* ���ڸ����ཻ�ף��õ�������ˮ�� 
	if(TITA.taskid[0] == 'U' )
		if(aSysGetTlsrno() != 0)
			return SYS_FAIL;*/

	/* ���ڸ����ཻ�ף����ɽ�����ˮ��¼ */
	if(aSysPrepareXdtl() != 0)
		return SYS_FAIL;

	return SYS_OK;
}

/******************************************************************************/
/*  Function     : aSysStopCheck()                                            */
/*  Description  : check online status                                        */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/

/******************************************************************************/
/*  Function     : aSysStopCheck()                                            */
/*  Description  : check online status                                        */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/
int aSysStopCheck()
{
	/* add by ZengShuFeng 2003-11-18 ����״̬�¿����޸����� */
	if (memcmp(TITA.taskid, "Ue", 2) == 0 && memcmp(TITA.txno, "7318", 4) == 0)
	{
		return SYS_OK;
	}

	if (memcmp(TITA.taskid, "U9", 2) != 0 && memcmp(TITA.taskid, "U7", 2) != 0)
	{
		if(it_txcom.olstat == TX_STATUS_BATCH)
		{
			ERRTRACE(E_SYS_SILENT_MODE, NULL);
			return SYS_FAIL;
		}
	}

	return SYS_OK;
}

/******************************************************************************/
/*  Function     : aSysBranchCheck()                                          */
/*  Description  : check branch status                                        */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/
int aSysBranchCheck()
{
	/* ����кſ��Ʊ� */
	memset(&gwdBctl, 0, sizeof(gwdBctl));
	memcpy(gwdBctl.sBrno, it_tita.labtex.label.kinbr, DLEN_BRNO);

	if((it_txcom.rtncd = DbsBCTL(DBS_FIND, &gwdBctl)) != DB_OK)
	{
		ERRTRACE(E_DB_BCTL_RERR, "brno[%s]", gwdBctl.sBrno);
		return SYS_FAIL;
	}

	/* ��齻���й���״̬ */
	if ( it_txcom.datasource == TXCOM_DATASOURCE_ONLINE )
	{
		if(gwdBctl.sStatus[0] != BCTL_STATUS_ONLINE)
		{
			ERRTRACE(E_SYS_BRANCH_LOGOFF, "branch status[%s]", gwdBctl.sStatus);
			return SYS_FAIL;
		}
	}

	return SYS_OK;
}

/******************************************************************************/
/*  Function     : aSysPrepareXdtl()                                          */
/*  Description  : evaluate basic fields in XDTL if TITA.hcode is '0'         */
/*                 DBS_LOCK XDTL if TITA.hcode is '1'                         */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/
int aSysPrepareXdtl()
{
	char	sDate[DLEN_DATE+1];
	char	sTime[DLEN_TIME+1];
	char	sCurcd[DLEN_CURCD+1];

	memset(&gwdXdtl, 0, sizeof(gwdXdtl));
	memcpy(gwdXdtl.sTxday, it_txcom.tbsdy, DLEN_DATE);
	memcpy(gwdXdtl.sKinbr, gwdBctl.sBrno, DLEN_BRNO);
	memcpy(gwdXdtl.sTlrno, TITA.tlrno, DLEN_TLRNO);
	memcpy(gwdXdtl.sTlsrno, gsTlsrno, DLEN_TLSRNO);

	strcpy(sDate, (char*)cmgetdate());
	strcpy(sTime, (char*)cmgettime());
	sprintf(gwdXdtl.sTxtime, "%8.8s%6.6s", sDate, sTime);

	if(TITA.hcode == TX_HCODE_NORMAL)
	{
		gwdXdtl.sAfcls[0] = '0';
		memcpy(gwdXdtl.sHtrmseq, TITA.htrmseq, DLEN_TRMSEQ);
		memcpy(gwdXdtl.sHejfno, TITA.hejfno, DLEN_TLSRNO);
		memcpy(gwdXdtl.sTrmseq, TITA.trmseq, DLEN_TRMSEQ);
		memcpy(gwdXdtl.sEjfno, TITA.ejfno, DLEN_TLSRNO);
		memcpy(gwdXdtl.sTaskid, TITA.taskid, DLEN_TASKID);
		gwdXdtl.sTmtype[0] = TITA.tmtype;
		memcpy(gwdXdtl.sTxno, TITA.txno, DLEN_TXNCD);
		gwdXdtl.sHcode[0] = TITA.hcode;
		gwdXdtl.sNbcd[0] = TITA.nbcd;
		gwdXdtl.sMulttx[0] = TITA.multtx;
		memcpy(gwdXdtl.sMultno, TITA.multno, DLEN_MULTNO);
		gwdXdtl.sVflag[0] = FLAG_OFF;
		memcpy(gwdXdtl.sText, it_tita.labtex.text, sizeof(gwdXdtl.sText));
		gwdXdtl.sText[sizeof(gwdXdtl.sText)-1] = 0;
	}
	else if(TITA.hcode == TX_HCODE_CANCEL)
	{
		if(TITA.taskid[0] == 'U' )
		{
			memcpy(gwdXdtl.sTlrno, TITA.otxtlrno, DLEN_TLRNO);
			if((it_txcom.rtncd = DbsXDTL(DBS_LOCK, &gwdXdtl)) != DB_OK)
			{
				ERRTRACE(E_DB_XDTL_RERR, NULL);
				return SYS_FAIL;
			}

			if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
			{
				ERRTRACE(E_SYS_TX_CANCELED, NULL);
				return SYS_FAIL;
			}

			if(memcmp(gwdXdtl.sTaskid, TITA.taskid, DLEN_TASKID) != 0)
			{
				ERRTRACE(E_SYS_TX_NOTFOUND, "taskid[%s]", gwdXdtl.sTaskid);
				return SYS_FAIL;
			}

			if(memcmp(gwdXdtl.sTxno, TITA.txno, DLEN_TXNCD) != 0)
			{
				ERRTRACE(E_SYS_TX_NOTFOUND, "txno[%s]", gwdXdtl.sTxno);
				return SYS_FAIL;
			}

			/* Modi by XuShenGen begin 20041111 */
			if(TITA.tmtype == AP_TRMTYPE_TERM || TITA.tmtype == AP_TRMTYPE_GRAPH)
			{
				if(gwdXdtl.sTmtype[0] != TITA.tmtype)
				{
					ERRTRACE(E_SYS_TX_NOTFOUND, "tmtype[%s] tmtype[%s]", gwdXdtl.sTmtype, TITA.tmtype);
					return SYS_FAIL;
				}
			}
			/* Modi by XuShenGen end 20041111 */

			gwdXdtl.sHcode[0] = TX_HCODE_CANCEL;
		}
	}
	else /* TX_HCODE_CHECK */
	{
		memcpy(gwdXdtl.sTlrno, TITA.otxtlrno, DLEN_TLRNO);
		memcpy(gwdXdtl.sTlsrno, gsTlsrno, DLEN_TLSRNO);

		if((it_txcom.rtncd = DbsXDTL(DBS_LOCK, &gwdXdtl)) != DB_OK)
		{
			ERRTRACE(E_DB_XDTL_RERR, "TLSRNO[%s]", gwdXdtl.sTlsrno);
			return;
		}

		if(gwdXdtl.sVflag[0] != XDTL_VFLAG_NORMAL)
		{
			ERRTRACE(E_SYS_XDTL_CHECKED, "TLSRNO[%s]", gwdXdtl.sTlsrno);
			return;
		}

		if(gwdXdtl.sHcode[0] != TX_HCODE_NORMAL)
		{
			ERRTRACE(E_SYS_TX_CANCELED, NULL);
			return;
		}

		if(memcmp(gwdXdtl.sTaskid, TITA.taskid, DLEN_TASKID) != 0)
		{
			ERRTRACE(E_SYS_TX_NOTFOUND, "taskid[%s]", gwdXdtl.sTaskid);
			return SYS_FAIL;
		}

		if(gwdXdtl.sTmtype[0] != TITA.tmtype)
		{
			ERRTRACE(E_SYS_TX_NOTFOUND, "tmtype[%s]", gwdXdtl.sTmtype);
			return SYS_FAIL;
		}

		if(memcmp(gwdXdtl.sTlrno, TITA.tlrno, DLEN_TLRNO) == 0)
		{
			ERRTRACE(E_SYS_VTLRNO_SAME, NULL);
			return SYS_FAIL;
		}

		gwdXdtl.sVflag[0] = XDTL_VFLAG_CHECKED;
		memcpy(gwdXdtl.sVtlrno, TITA.tlrno, DLEN_TLRNO);
	}

	return SYS_OK;
}

int aSysBasicCheckEnd()
{
	it_txcom.rtncd = DbsBCTL(DBS_CLOSE, &gwdBctl);
	it_txcom.rtncd = DbsXDTL(DBS_CLOSE, &gwdXdtl);
	return SYS_OK;
}
