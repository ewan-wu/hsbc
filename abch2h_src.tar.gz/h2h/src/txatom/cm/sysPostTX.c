/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/* transaction atom module                                              */
/*   PostTX                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���׽�������                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date       Author           Description                          */
/*   --------   ------------      ----------------                      */
/*   20021216   Calvin Wei        Reinit                                */
/************************************************************************/

#include "txatom_cm.h"

int aSysBasicUpdate(void);
int aSysXdtlUpdate(void);

/******************************************************************************/
/*  Function     : aSysBasicUpdate()                                          */
/*  Description  : update system tables after TX                              */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/
int aSysBasicUpdate()
{
	if(gwdXdtl.sTaskid[0] == 'U' )
		if(aSysXdtlUpdate() != 0)
			return(1);

	return(0);
}

/******************************************************************************/
/*  Function     : aSysXdtlUpdate()                                           */
/*  Description  : Insert/Update XDTL according to TITA.hcode                 */
/*  Arguments    : None                                                       */
/*  Return Value : 0 - success                                                */
/*                 1 - fail                                                   */
/******************************************************************************/
int aSysXdtlUpdate()
{
	if(TITA.hcode == TX_HCODE_NORMAL)
	{
		if((it_txcom.rtncd = DbsXDTL(DBS_INSERT, &gwdXdtl)) != DB_OK)
		{
			ERRTRACE(E_DB_XDTL_IERR, "Kinbr[%s] Tlrno[%s] Tlsrno[%s]", gwdXdtl.sKinbr, gwdXdtl.sTlrno, gwdXdtl.sTlsrno);
			return(1);
		}
	}
	else /* TX_HCODE_CANCEL || TX_HCODE_CHECK */
	{
		if((it_txcom.rtncd = DbsXDTL(DBS_UPDATE, &gwdXdtl)) != DB_OK)
		{
			ERRTRACE(E_DB_XDTL_WERR, "Kinbr[%s] Tlrno[%s] Tlsrno[%s]", gwdXdtl.sKinbr, gwdXdtl.sTlrno, gwdXdtl.sTlsrno);
			return(1);
		}
	}
	DbCommitTxn();
	return(0);
}
