/******************************************************************************/
/*                                                                            */
/* Product: Top Kernel Banking System                                         */
/*          transaction atom module                                           */
/*   aSeRemitctlInq                                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Description: �����Ų�ѯ                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Modification log:                                                          */
/*                                                                            */
/*     Date            Author              Description                        */
/*   --------       -----------          -----------------                    */
/*   20030715       Yang Louis           Initial                              */
/******************************************************************************/
#include "txatom_cm.h"

static T_REMITCTL			wdRemitctl;

void aSeRemitctlInqProcess(aTisSeRemitctlInq*, aTosSeRemitctlInq*);
void aSeRemitctlInqCheck(aTisSeRemitctlInq*, aTosSeRemitctlInq*);
void aSeRemitctlInqUpdate(aTisSeRemitctlInq*, aTosSeRemitctlInq*);
void aSeRemitctlInqEnd(void);

void aSeRemitctlInqProcess(staTisSeRemitctlInq, staTosSeRemitctlInq)
aTisSeRemitctlInq *staTisSeRemitctlInq;
aTosSeRemitctlInq *staTosSeRemitctlInq;
{
	aSeRemitctlInqCheck(staTisSeRemitctlInq, staTosSeRemitctlInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aSeRemitctlInqUpdate(staTisSeRemitctlInq, staTosSeRemitctlInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aSeRemitctlInqCheck(staTisSeRemitctlInq, staTosSeRemitctlInq)
aTisSeRemitctlInq *staTisSeRemitctlInq;
aTosSeRemitctlInq *staTosSeRemitctlInq;
{
	/* find REMITCTL */
	memset(&wdRemitctl, 0, sizeof(wdRemitctl));

	memcpy(wdRemitctl.sTxdate, staTisSeRemitctlInq->sDate, DLEN_DATE);
	/*memcpy(wdRemitctl.sBrno, staTisSeRemitctlInq->sBrno, DLEN_BRNO);*/
	memcpy(wdRemitctl.sType, staTisSeRemitctlInq->sType, DLEN_TYPE);

	it_txcom.rtncd = DbsREMITCTL(DBS_FIND, &wdRemitctl);

	if(it_txcom.rtncd == DB_NOTFOUND)
	{
		if((it_txcom.rtncd = DbsREMITCTL(DBS_INSERT, &wdRemitctl)) != DB_OK)
		{
			ERRTRACE(E_DB_REMITCTL_IERR, "TYPE[%s]", wdRemitctl.sType);
			return;
		}
	}
	else if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_REMITCTL_RERR, NULL);
		return;
	}

	staTosSeRemitctlInq->iSeqno = wdRemitctl.iSeqno+1;
}

void aSeRemitctlInqUpdate(staTisSeRemitctlInq, staTosSeRemitctlInq)
aTisSeRemitctlInq *staTisSeRemitctlInq;
aTosSeRemitctlInq *staTosSeRemitctlInq;
{
}

void aSeRemitctlInqEnd(void)
{
}
