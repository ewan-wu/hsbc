/******************************************************************************/
/*                                                                            */
/* Product: Top Kernel Banking System                                         */
/*          transaction atom module                                           */
/*   aSeRemitctlUpd                                                           */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Description: �������޸�                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Modification log:                                                          */
/*                                                                            */
/*     Date            Author              Description                        */
/*   --------       -----------          -----------------                    */
/*   20030715       Yang Louis           Initial                              */
/******************************************************************************/
#include "txatom_cm.h"

static T_REMITCTL			wdRemitctl;

void aSeRemitctlUpdProcess(aTisSeRemitctlUpd*, aTosSeRemitctlUpd*);
void aSeRemitctlUpdCheck(aTisSeRemitctlUpd*, aTosSeRemitctlUpd*);
void aSeRemitctlUpdUpdate(aTisSeRemitctlUpd*, aTosSeRemitctlUpd*);
void aSeRemitctlUpdEnd(void);

void aSeRemitctlUpdProcess(staTisSeRemitctlUpd, staTosSeRemitctlUpd)
aTisSeRemitctlUpd *staTisSeRemitctlUpd;
aTosSeRemitctlUpd *staTosSeRemitctlUpd;
{
	aSeRemitctlUpdCheck(staTisSeRemitctlUpd, staTosSeRemitctlUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aSeRemitctlUpdUpdate(staTisSeRemitctlUpd, staTosSeRemitctlUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aSeRemitctlUpdCheck(staTisSeRemitctlUpd, staTosSeRemitctlUpd)
aTisSeRemitctlUpd *staTisSeRemitctlUpd;
aTosSeRemitctlUpd *staTosSeRemitctlUpd;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		/* find REMITCTL */
		memset(&wdRemitctl, 0, sizeof(wdRemitctl));

		memcpy(wdRemitctl.sTxdate, staTisSeRemitctlUpd->sDate, DLEN_DATE);
		/*memcpy(wdRemitctl.sBrno, staTisSeRemitctlUpd->sBrno, DLEN_BRNO);*/
		memcpy(wdRemitctl.sType, staTisSeRemitctlUpd->sType, DLEN_TYPE);

		it_txcom.rtncd = DbsREMITCTL(DBS_LOCK, &wdRemitctl);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_REMITCTL_RERR, NULL);
			return;
		}
	}
}

void aSeRemitctlUpdUpdate(staTisSeRemitctlUpd, staTosSeRemitctlUpd)
aTisSeRemitctlUpd *staTisSeRemitctlUpd;
aTosSeRemitctlUpd *staTosSeRemitctlUpd;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		wdRemitctl.iSeqno ++;

		it_txcom.rtncd = DbsREMITCTL(DBS_UPDATE, &wdRemitctl);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_REMITCTL_WERR, NULL);
			return;
		}
		it_txcom.rtncd = DbsREMITCTL(DBS_CLOSE, &wdRemitctl);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_REMITCTL_WERR, NULL);
			return;
		}
	}
}

void aSeRemitctlUpdEnd(void)
{
}
