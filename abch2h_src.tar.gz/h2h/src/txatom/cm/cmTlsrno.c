/******************************************************************************/
/*  Kernel Banking System                                                     */
/*  Copyright (c) 2002                                                        */
/*  Shanghai Huateng Software System Co., Ltd.                                */
/*  All Rights Reserved                                                       */
/******************************************************************************/
#include <time.h>
#include "txatom_cm.h"
/*
static int	miMsrno;
static int	miSubno;*/

/*void cmInitTlsrno(char *);
void cmGetTlsrno(int,char *);*/
int nNewClsSsn(char *);
int nNewSysClsSsn(char *);

/******************************************************************************/
/*  Function     : cmInitTlsrno()                                             */
/*  Description  : Initialize msTlsrno                                        */
/*  Arguments    : sTlsrno - input                                            */
/*  Return Value : void                                                       */
/******************************************************************************/
/*void cmInitTlsrno(char *sTlsrno)
{
	char	sMsrno[5], sSubno[4];

	sprintf(sMsrno, "%.4s", sTlsrno);
	miMsrno = atoi(sMsrno);

	sprintf(sSubno, "%.3s", sTlsrno+4);
	miSubno = atoi(sSubno);
}*/

/******************************************************************************/
/*  Function     : cmGetTlsrno()                                              */
/*  Description  : Get current msTlsrno                                       */
/*  Arguments    : none                                                       */
/*  Return Value : teller's sequence number                                   */
/******************************************************************************/
/*void cmGetTlsrno(int flg,char *sTlsrno)
{
	if(flg == 1)
	{
		miSubno ++;
		if(miSubno >= 1000)
		{
			miSubno %= 1000;
			if(it_txcom.apruntype == TXCOM_APRUNTYPE_BATCH)
				miMsrno ++;
			if (miMsrno >= 10000)
			{
				miMsrno %= 10000;
			}
		}
	}

	sprintf(sTlsrno, "%04d%03d", miMsrno, miSubno);
	if(it_txcom.apruntype == TXCOM_APRUNTYPE_BATCH)
		memcpy(gwdXdtl.sTlsrno, sTlsrno, 7);

	return;
}*/

int nNewClsSsn(char *sClsSsn)
{
	long	lPid;
	short	nRet;
	SwtToSEQReqDef		tSwtTocSeq;

	lPid = getpid();

	memset(&tSwtTocSeq, 0, sizeof(tSwtTocSeq));

	tSwtTocSeq.MsgType=CI_TOCTL_SEQ;
	tSwtTocSeq.nMsgCode=lPid;
	tSwtTocSeq.nSwitchPID=lPid;
	tSwtTocSeq.nReplyCode=0;
	tSwtTocSeq.nSeqLen=0;
	memset(tSwtTocSeq.sSeqStr, '0', sizeof(tSwtTocSeq.sSeqStr));
	/*memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_CLSWTSSN, 5);
	memcpy(tSwtTocSeq.sSeqType+5, it_tita.labtex.label.kinbr, DLEN_BRNO);*/
	memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_ABC, 8);
	printf("SeqType=[%s]\n", tSwtTocSeq.sSeqType);

	nRet=SwtSnd2ToSEQ(&tSwtTocSeq);
	printf("nReturnCode SwtSnd2ToSEQ=[%d],nReplyCode=[%d]\n", nRet, tSwtTocSeq.nReplyCode);
	if (nRet!=0)
	{
		ErrReport(  CI_BDGMNG,
				EI_PROCESS,
				nRet,
				CI_SEVERITY_SYSERROR,
				EI_NORMAL_REGISTER_FROM_TOCTL);
		return -1;
	}

	if (tSwtTocSeq.nReplyCode!=0)
	{
		ErrReport(  CI_BDGMNG,
				EI_PROCESS,
				tSwtTocSeq.nReplyCode,
				CI_SEVERITY_SYSERROR,
				EI_NORMAL_REGISTER_FROM_TOCTL);
		return -2;
	}
	memcpy ( sClsSsn, tSwtTocSeq.sSeqStr, tSwtTocSeq.nSeqLen);
	sClsSsn[tSwtTocSeq.nSeqLen] = 0;
	printf("SwtSnd2ToSEQ sClsSsn[%s]\n",sClsSsn);
	
	return 0;
}

int nNewSysClsSsn(char *sClsSsn)
{
	long	lPid;
	short	nRet;
	SwtToSEQReqDef		tSwtTocSeq;

	lPid = getpid();

	memset(&tSwtTocSeq, 0, sizeof(tSwtTocSeq));

	tSwtTocSeq.MsgType=CI_TOCTL_SEQ;
	tSwtTocSeq.nMsgCode=lPid;
	tSwtTocSeq.nSwitchPID=lPid;
	tSwtTocSeq.nReplyCode=0;
	tSwtTocSeq.nSeqLen=0;
	memset(tSwtTocSeq.sSeqStr, '0', sizeof(tSwtTocSeq.sSeqStr));
	/*memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_CLSWTSSN, 5);
	memcpy(tSwtTocSeq.sSeqType+5, it_tita.labtex.label.kinbr, DLEN_BRNO);*/
	memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_SYS, 8);
	printf("SeqType=[%s]\n", tSwtTocSeq.sSeqType);

	nRet=SwtSnd2ToSEQ(&tSwtTocSeq);
	printf("nReturnCode SwtSnd2ToSEQ=[%d],nReplyCode=[%d]\n", nRet, tSwtTocSeq.nReplyCode);
	if (nRet!=0)
	{
		ErrReport(  CI_BDGMNG,
				EI_PROCESS,
				nRet,
				CI_SEVERITY_SYSERROR,
				EI_NORMAL_REGISTER_FROM_TOCTL);
		return -1;
	}

	if (tSwtTocSeq.nReplyCode!=0)
	{
		ErrReport(  CI_BDGMNG,
				EI_PROCESS,
				tSwtTocSeq.nReplyCode,
				CI_SEVERITY_SYSERROR,
				EI_NORMAL_REGISTER_FROM_TOCTL);
		return -2;
	}
	memcpy ( sClsSsn, tSwtTocSeq.sSeqStr, tSwtTocSeq.nSeqLen);
	sClsSsn[tSwtTocSeq.nSeqLen] = 0;
	printf("SwtSnd2ToSEQ sClsSsn[%s]\n",sClsSsn);
	
	return 0;
}