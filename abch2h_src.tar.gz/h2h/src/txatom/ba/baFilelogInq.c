/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaFilelogInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ���ι�����                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	bingliang.wu   			 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_FILELOG    wdFilelog;

void aBaFilelogInqProcess(aTisBaFilelogInq *, aTosBaFilelogInq *);
void aBaFilelogInqCheck(aTisBaFilelogInq *, aTosBaFilelogInq *);
void aBaFilelogInqUpdate(aTisBaFilelogInq *, aTosBaFilelogInq *);
void aBaFilelogInqEnd(void);

void aBaFilelogInqProcess(staTisBaFilelogInq, staTosBaFilelogInq)
aTisBaFilelogInq	*staTisBaFilelogInq;
aTosBaFilelogInq	*staTosBaFilelogInq;
{
	aBaFilelogInqCheck(staTisBaFilelogInq, staTosBaFilelogInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFilelogInqUpdate(staTisBaFilelogInq, staTosBaFilelogInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFilelogInqCheck(staTisBaFilelogInq, staTosBaFilelogInq)
aTisBaFilelogInq	*staTisBaFilelogInq;
aTosBaFilelogInq	*staTosBaFilelogInq;
{
	memset(&wdFilelog, 0, sizeof(wdFilelog));
	memcpy(wdFilelog.sFileName, staTisBaFilelogInq->sFileName, DLEN_FILENAME);
  memcpy(wdFilelog.sTrscTime, staTisBaFilelogInq->sTrscTime, DLEN_TRSCTIME);
  memcpy(wdFilelog.sFileSrc, staTisBaFilelogInq->sFileSrc, DLEN_FILESRC);

	it_txcom.rtncd = DbsFILELOG(DBS_FIND, &wdFilelog);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FILELOG_RERR, NULL);
		return;
	}

	memcpy(staTosBaFilelogInq, &wdFilelog, sizeof(wdFilelog));

}

void aBaFilelogInqUpdate(staTisBaFilelogInq, staTosBaFilelogInq)
aTisBaFilelogInq	*staTisBaFilelogInq;
aTosBaFilelogInq	*staTosBaFilelogInq;
{
}

void aBaFilelogInqEnd()
{
}
