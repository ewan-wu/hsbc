/******************************************************************************/
/*                                                                            */
/* Product: Top Kernel Banking System                                         */
/*          transaction atom module                                           */
/*   aBaCommonNew                                                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Description: ������Ϣ������                                                  */
/*                                                                            */
/*----------------------------------------------------------------------------*/
/* Modification log:                                                          */
/*                                                                            */
/*     Date            Author              Description                        */
/*   --------       -----------          -----------------                    */
/*   200711           sunfei                Initial                           */
/******************************************************************************/
#include "txatom_ba.h"

static T_COMMON			wdCommon;

void aBaCommonNewProcess(aTisBaCommonNew*, aTosBaCommonNew*);
void aBaCommonNewCheck(aTisBaCommonNew*, aTosBaCommonNew*);
void aBaCommonNewUpdate(aTisBaCommonNew*, aTosBaCommonNew*);
void aBaCommonNewEnd(void);

void aBaCommonNewProcess(staTisBaCommonNew, staTosBaCommonNew)
aTisBaCommonNew *staTisBaCommonNew;
aTosBaCommonNew *staTosBaCommonNew;
{
	aBaCommonNewCheck(staTisBaCommonNew, staTosBaCommonNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaCommonNewUpdate(staTisBaCommonNew, staTosBaCommonNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaCommonNewCheck(staTisBaCommonNew, staTosBaCommonNew)
aTisBaCommonNew *staTisBaCommonNew;
aTosBaCommonNew *staTosBaCommonNew;
{
}

void aBaCommonNewUpdate(staTisBaCommonNew, staTosBaCommonNew)
aTisBaCommonNew *staTisBaCommonNew;
aTosBaCommonNew *staTosBaCommonNew;
{
	/* insert COMMON */
	memset(&wdCommon, 0, sizeof(wdCommon));

	memcpy(&wdCommon,staTisBaCommonNew, sizeof(wdCommon));

	it_txcom.rtncd = DbsCOMMON(DBS_INSERT, &wdCommon);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_COMMON_IERR, NULL);
		return;
	}
}

void aBaCommonNewEnd(void)
{
	DbsCOMMON(DBS_CLOSE, &wdCommon);
}

