/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����ļ���־��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*       Date            Author              Description                */
/*   --------       -----------          -----------------              */
/*       200711         	bingliang.wu     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_FILELOG	wdFilelog;

void aBaFilelogNewProcess(aTisBaFilelogNew*, aTosBaFilelogNew*);
void aBaFilelogNewCheck(aTisBaFilelogNew*, aTosBaFilelogNew*);
void aBaFilelogNewUpdate(aTisBaFilelogNew*, aTosBaFilelogNew*);
void aBaFilelogNewEnd(void);

void aBaFilelogNewProcess
(aTisBaFilelogNew *staTisBaFilelogNew,aTosBaFilelogNew *staTosBaFilelogNew)
{
	aBaFilelogNewCheck(staTisBaFilelogNew, staTosBaFilelogNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFilelogNewUpdate(staTisBaFilelogNew, staTosBaFilelogNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFilelogNewCheck(staTisBaFilelogNew, staTosBaFilelogNew)
aTisBaFilelogNew	*staTisBaFilelogNew;
aTosBaFilelogNew	*staTosBaFilelogNew;
{	
}

void aBaFilelogNewUpdate(staTisBaFilelogNew, staTosBaFilelogNew)
aTisBaFilelogNew	*staTisBaFilelogNew;
aTosBaFilelogNew	*staTosBaFilelogNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdFilelog, 0, sizeof(wdFilelog));

		memcpy(&wdFilelog,staTisBaFilelogNew,sizeof(T_FILELOG));

		it_txcom.rtncd = DbsFILELOG(DBS_INSERT, &wdFilelog);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_FILELOG_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsFILELOG(DBS_DELETE, &wdFilelog);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_FILELOG_DERR, NULL);
			return;
		}
	}
}

void aBaFilelogNewEnd()
{
	DbsFILELOG(DBS_CLOSE, &wdFilelog);
}
