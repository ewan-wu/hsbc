/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaPayrolldetailUpd                                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �޸��ļ���־��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711          bingliang.wu         Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLDETAIL	wdPayrolldetail;

void aBaPayrolldetailUpdProcess(aTisBaPayrolldetailUpd *, aTosBaPayrolldetailUpd *);
void aBaPayrolldetailUpdCheck(aTisBaPayrolldetailUpd *, aTosBaPayrolldetailUpd *);
void aBaPayrolldetailUpdUpdate(aTisBaPayrolldetailUpd *, aTosBaPayrolldetailUpd *);
void aBaPayrolldetailUpdEnd(void);

void aBaPayrolldetailUpdProcess(staTisBaPayrolldetailUpd, staTosBaPayrolldetailUpd)
aTisBaPayrolldetailUpd	*staTisBaPayrolldetailUpd;
aTosBaPayrolldetailUpd	*staTosBaPayrolldetailUpd;
{
	aBaPayrolldetailUpdCheck(staTisBaPayrolldetailUpd, staTosBaPayrolldetailUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrolldetailUpdUpdate(staTisBaPayrolldetailUpd, staTosBaPayrolldetailUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrolldetailUpdCheck(staTisBaPayrolldetailUpd, staTosBaPayrolldetailUpd)
aTisBaPayrolldetailUpd	*staTisBaPayrolldetailUpd;
aTosBaPayrolldetailUpd	*staTosBaPayrolldetailUpd;
{
	memset(&wdPayrolldetail, 0, sizeof(wdPayrolldetail));
	memcpy(wdPayrolldetail.sBtno, staTisBaPayrolldetailUpd->sBtno, DLEN_BTNO);
  memcpy(wdPayrolldetail.sSeqno, staTisBaPayrolldetailUpd->sSeqno, DLEN_SEQNO);
  memcpy(wdPayrolldetail.sTrndate, staTisBaPayrolldetailUpd->sTrndate, DLEN_TRNDATE);

	it_txcom.rtncd = DbsPAYROLLDETAIL(DBS_LOCK, &wdPayrolldetail);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLDETAIL_RERR, "Btno[%s],Seqno[%s],Trndate[%s]", 
				 wdPayrolldetail.sBtno, wdPayrolldetail.sSeqno, wdPayrolldetail.sTrndate);
		return;
	}

	return;
}

void aBaPayrolldetailUpdUpdate(staTisBaPayrolldetailUpd, staTosBaPayrolldetailUpd)
aTisBaPayrolldetailUpd	*staTisBaPayrolldetailUpd;
aTosBaPayrolldetailUpd	*staTosBaPayrolldetailUpd;
{
	memcpy(&wdPayrolldetail,staTisBaPayrolldetailUpd,sizeof(T_PAYROLLDETAIL));

	it_txcom.rtncd = DbsPAYROLLDETAIL(DBS_UPDATE, &wdPayrolldetail);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLDETAIL_WERR, NULL);
		return;
	}
}

void aBaPayrolldetailUpdEnd()
{
	DbsPAYROLLDETAIL(DBS_CLOSE, &wdPayrolldetail);
}
