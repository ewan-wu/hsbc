/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaAccountNew                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����ʻ���Ϣ                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	kenshin     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_ACCOUNT	wdAccount;

void aBaAccountNewProcess(aTisBaAccountNew*, aTosBaAccountNew*);
void aBaAccountNewCheck(aTisBaAccountNew*, aTosBaAccountNew*);
void aBaAccountNewUpdate(aTisBaAccountNew*, aTosBaAccountNew*);
void aBaAccountNewEnd(void);

void aBaAccountNewProcess
(aTisBaAccountNew *staTisBaAccountNew,aTosBaAccountNew *staTosBaAccountNew)
{
	aBaAccountNewCheck(staTisBaAccountNew, staTosBaAccountNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaAccountNewUpdate(staTisBaAccountNew, staTosBaAccountNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaAccountNewCheck(staTisBaAccountNew, staTosBaAccountNew)
aTisBaAccountNew	*staTisBaAccountNew;
aTosBaAccountNew	*staTosBaAccountNew;
{
}

void aBaAccountNewUpdate(staTisBaAccountNew, staTosBaAccountNew)
aTisBaAccountNew	*staTisBaAccountNew;
aTosBaAccountNew	*staTosBaAccountNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdAccount, 0, sizeof(wdAccount));

		memcpy(&wdAccount,staTisBaAccountNew,sizeof(T_ACCOUNT));

		it_txcom.rtncd = DbsACCOUNT(DBS_INSERT, &wdAccount);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_ACCOUNT_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsACCOUNT(DBS_DELETE, &wdAccount);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_ACCOUNT_DERR, NULL);
			return;
		}
	}
}

void aBaAccountNewEnd()
{
	DbsACCOUNT(DBS_CLOSE, &wdAccount);
}
