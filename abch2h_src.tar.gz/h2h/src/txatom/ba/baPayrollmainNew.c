/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaPayrollmainNew                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����������ʻ��ܱ�                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	sunfei     							 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLMAIN	wdPayrollmain;

void aBaPayrollmainNewProcess(aTisBaPayrollmainNew*, aTosBaPayrollmainNew*);
void aBaPayrollmainNewCheck(aTisBaPayrollmainNew*, aTosBaPayrollmainNew*);
void aBaPayrollmainNewUpdate(aTisBaPayrollmainNew*, aTosBaPayrollmainNew*);
void aBaPayrollmainNewEnd(void);

void aBaPayrollmainNewProcess
(aTisBaPayrollmainNew *staTisBaPayrollmainNew,aTosBaPayrollmainNew *staTosBaPayrollmainNew)
{
	aBaPayrollmainNewCheck(staTisBaPayrollmainNew, staTosBaPayrollmainNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrollmainNewUpdate(staTisBaPayrollmainNew, staTosBaPayrollmainNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrollmainNewCheck(staTisBaPayrollmainNew, staTosBaPayrollmainNew)
aTisBaPayrollmainNew	*staTisBaPayrollmainNew;
aTosBaPayrollmainNew	*staTosBaPayrollmainNew;
{
}

void aBaPayrollmainNewUpdate(staTisBaPayrollmainNew, staTosBaPayrollmainNew)
aTisBaPayrollmainNew	*staTisBaPayrollmainNew;
aTosBaPayrollmainNew	*staTosBaPayrollmainNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdPayrollmain, 0, sizeof(wdPayrollmain));

		memcpy(&wdPayrollmain,staTisBaPayrollmainNew,sizeof(T_PAYROLLMAIN));

		it_txcom.rtncd = DbsPAYROLLMAIN(DBS_INSERT, &wdPayrollmain);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_PAYROLLMAIN_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsPAYROLLMAIN(DBS_DELETE, &wdPayrollmain);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_PAYROLLMAIN_DERR, NULL);
			return;
		}
	}
}

void aBaPayrollmainNewEnd()
{
	DbsPAYROLLMAIN(DBS_CLOSE, &wdPayrollmain);
}
