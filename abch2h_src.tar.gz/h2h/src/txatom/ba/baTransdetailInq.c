/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaTransdetailInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ������ϸ��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	bingliang.wu   			 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_TRANSDETAIL    wdTransdetail;

void aBaTransdetailInqProcess(aTisBaTransdetailInq *, aTosBaTransdetailInq *);
void aBaTransdetailInqCheck(aTisBaTransdetailInq *, aTosBaTransdetailInq *);
void aBaTransdetailInqUpdate(aTisBaTransdetailInq *, aTosBaTransdetailInq *);
void aBaTransdetailInqEnd(void);

void aBaTransdetailInqProcess(staTisBaTransdetailInq, staTosBaTransdetailInq)
aTisBaTransdetailInq	*staTisBaTransdetailInq;
aTosBaTransdetailInq	*staTosBaTransdetailInq;
{
	aBaTransdetailInqCheck(staTisBaTransdetailInq, staTosBaTransdetailInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaTransdetailInqUpdate(staTisBaTransdetailInq, staTosBaTransdetailInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaTransdetailInqCheck(staTisBaTransdetailInq, staTosBaTransdetailInq)
aTisBaTransdetailInq	*staTisBaTransdetailInq;
aTosBaTransdetailInq	*staTosBaTransdetailInq;
{
	memset(&wdTransdetail, 0, sizeof(wdTransdetail));
	memcpy(wdTransdetail.sTrndate, staTisBaTransdetailInq->sTrndate, DLEN_TRNDATE);
  memcpy(wdTransdetail.sTimestamp, staTisBaTransdetailInq->sTimestamp, DLEN_TIMESLICE);
  memcpy(wdTransdetail.sJrnno, staTisBaTransdetailInq->sJrnno, DLEN_JRNNO);

	it_txcom.rtncd = DbsTRANSDETAIL(DBS_FIND, &wdTransdetail);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_TRANSDETAIL_RERR, NULL);
		return;
	}

	memcpy(staTosBaTransdetailInq, &wdTransdetail, sizeof(wdTransdetail));

}

void aBaTransdetailInqUpdate(staTisBaTransdetailInq, staTosBaTransdetailInq)
aTisBaTransdetailInq	*staTisBaTransdetailInq;
aTosBaTransdetailInq	*staTosBaTransdetailInq;
{
}

void aBaTransdetailInqEnd()
{
}
