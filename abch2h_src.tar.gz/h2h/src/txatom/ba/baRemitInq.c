/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaRemitInq                                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ��ұ�                                              */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	bingliang.wu   			 	Initial             */
/************************************************************************/
#include "txatom_ba.h"

static T_REMIT    wdRemit;

void aBaRemitInqProcess(aTisBaRemitInq *, aTosBaRemitInq *);
void aBaRemitInqCheck(aTisBaRemitInq *, aTosBaRemitInq *);
void aBaRemitInqUpdate(aTisBaRemitInq *, aTosBaRemitInq *);
void aBaRemitInqEnd(void);

void aBaRemitInqProcess(staTisBaRemitInq, staTosBaRemitInq)
aTisBaRemitInq	*staTisBaRemitInq;
aTosBaRemitInq	*staTosBaRemitInq;
{
	aBaRemitInqCheck(staTisBaRemitInq, staTosBaRemitInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaRemitInqUpdate(staTisBaRemitInq, staTosBaRemitInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaRemitInqCheck(staTisBaRemitInq, staTosBaRemitInq)
aTisBaRemitInq	*staTisBaRemitInq;
aTosBaRemitInq	*staTosBaRemitInq;
{
	memset(&wdRemit, 0, sizeof(wdRemit));
	memcpy(wdRemit.sReqseqno, staTisBaRemitInq->sReqseqno, DLEN_REQSEQNO);
  
	it_txcom.rtncd = DbsREMIT(DBS_FIND, &wdRemit);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_REMIT_RERR, NULL);
		return;
	}

	memcpy(staTosBaRemitInq, &wdRemit, sizeof(wdRemit));

}

void aBaRemitInqUpdate(staTisBaRemitInq, staTosBaRemitInq)
aTisBaRemitInq	*staTisBaRemitInq;
aTosBaRemitInq	*staTosBaRemitInq;
{
}

void aBaRemitInqEnd()
{
}
