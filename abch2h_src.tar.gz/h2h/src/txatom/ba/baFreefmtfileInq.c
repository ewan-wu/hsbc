/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaFreefmtfileInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ���ɸ�ʽ�ļ���                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711        	sunfei  			 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_FREEFMTFILE    wdFreefmtfile;

void aBaFreefmtfileInqProcess(aTisBaFreefmtfileInq *, aTosBaFreefmtfileInq *);
void aBaFreefmtfileInqCheck(aTisBaFreefmtfileInq *, aTosBaFreefmtfileInq *);
void aBaFreefmtfileInqUpdate(aTisBaFreefmtfileInq *, aTosBaFreefmtfileInq *);
void aBaFreefmtfileInqEnd(void);

void aBaFreefmtfileInqProcess(staTisBaFreefmtfileInq, staTosBaFreefmtfileInq)
aTisBaFreefmtfileInq	*staTisBaFreefmtfileInq;
aTosBaFreefmtfileInq	*staTosBaFreefmtfileInq;
{
	aBaFreefmtfileInqCheck(staTisBaFreefmtfileInq, staTosBaFreefmtfileInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFreefmtfileInqUpdate(staTisBaFreefmtfileInq, staTosBaFreefmtfileInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFreefmtfileInqCheck(staTisBaFreefmtfileInq, staTosBaFreefmtfileInq)
aTisBaFreefmtfileInq	*staTisBaFreefmtfileInq;
aTosBaFreefmtfileInq	*staTosBaFreefmtfileInq;
{
	memset(&wdFreefmtfile, 0, sizeof(wdFreefmtfile));
	memcpy(wdFreefmtfile.sReqseqno, staTisBaFreefmtfileInq->sReqseqno, DLEN_REQSEQNO);
	memcpy(wdFreefmtfile.sDirection, staTisBaFreefmtfileInq->sDirection, DLEN_DIRECTION);


	it_txcom.rtncd = DbsFREEFMTFILE(DBS_FIND, &wdFreefmtfile);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FREEFMTFILE_RERR, NULL);
		return;
	}

	memcpy(staTosBaFreefmtfileInq, &wdFreefmtfile, sizeof(wdFreefmtfile));

}

void aBaFreefmtfileInqUpdate(staTisBaFreefmtfileInq, staTosBaFreefmtfileInq)
aTisBaFreefmtfileInq	*staTisBaFreefmtfileInq;
aTosBaFreefmtfileInq	*staTosBaFreefmtfileInq;
{
}

void aBaFreefmtfileInqEnd()
{
}
