#ifndef _TXATOM_BE_H
#define _TXATOM_BE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ipc.h"
#include "glb_def.h"
#include "glb_dic.h"
#include "glb_err.h"
#include "glb_ext.h"
#include "ba_def.h"
#include "ba_wd.h"
#include "ba_itf.h"
#include "sys_def.h"
#include "sys_wd.h"
#include "sys_itf.h"
#include "pl_itf.h"







/*
#include "sys_wd.h"
#include "sys_def.h"
#include "sys_itf.h"
#include "glb_err.h"
#include "glb_def.h"
#include "glb_ext.h"
#include "gl_wd.h"
#include "gl_def.h"
#include "gl_itf.h"
#include "be_wd.h"
#include "be_def.h"
#include "be_itf.h"
#include "beps_ipc.h"
#include "sysdef.h"
#include "msglog.h"
#include "wd_incl.h"
#include "status.h"
#include "swttoc.h"
#include "pl_itf.h"
#include "be_wd.h"
#include "be_def.h"
#include "be_itf.h"
#include "beps_ipc.h"*/


#define MAX_CNTRSTLM_COUNT        1

#define BUF_MAX_SIZE 8192
#define TITA_TEXT_MAX 5*1024
#define TOTA_TEXT_MAX 5*1024

#define ShowError(string) printf("%s", string)

typedef struct
{
	long MsgType;
	long nMsgCode;
	char sText[BUF_MAX_SIZE];
} CmdMsgDef;

typedef struct
{
	T_IPCHeader   tIPCHeader;
	T_TitaLabel   tTitaLabel;
	char          sTitaText[TITA_TEXT_MAX];
} T_MngBufFromTlrDef;

typedef struct
{
	T_TotaLabel   tTotaLabel;
	char          sTotaText[TOTA_TEXT_MAX];
} T_MngBufToTlrDef;

typedef struct
{
	 char  sTxnId[6];
	 char  sApFunLen[2];
	 char  sApFun[16];
	 char  sApTimeOut[2];
	 char  sUserDef[12];
	 char  sSessionHeader[8];
	 char  sDataBuf[BUF_MAX_SIZE];
} MsgToHostDef;

void HandleExit();

#endif /* _MANAGE_H */
