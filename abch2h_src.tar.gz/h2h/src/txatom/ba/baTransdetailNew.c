/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ����������ϸ��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*       Date            Author              Description                */
/*   --------       -----------          -----------------              */
/*       200711         	bingliang.wu     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_TRANSDETAIL	wdTransdetail;

void aBaTransdetailNewProcess(aTisBaTransdetailNew*, aTosBaTransdetailNew*);
void aBaTransdetailNewCheck(aTisBaTransdetailNew*, aTosBaTransdetailNew*);
void aBaTransdetailNewUpdate(aTisBaTransdetailNew*, aTosBaTransdetailNew*);
void aBaTransdetailNewEnd(void);

void aBaTransdetailNewProcess
(aTisBaTransdetailNew *staTisBaTransdetailNew,aTosBaTransdetailNew *staTosBaTransdetailNew)
{
	aBaTransdetailNewCheck(staTisBaTransdetailNew, staTosBaTransdetailNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaTransdetailNewUpdate(staTisBaTransdetailNew, staTosBaTransdetailNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaTransdetailNewCheck(staTisBaTransdetailNew, staTosBaTransdetailNew)
aTisBaTransdetailNew	*staTisBaTransdetailNew;
aTosBaTransdetailNew	*staTosBaTransdetailNew;
{	
}

void aBaTransdetailNewUpdate(staTisBaTransdetailNew, staTosBaTransdetailNew)
aTisBaTransdetailNew	*staTisBaTransdetailNew;
aTosBaTransdetailNew	*staTosBaTransdetailNew;
{
	
		memset(&wdTransdetail, 0, sizeof(wdTransdetail));

		memcpy(&wdTransdetail,staTisBaTransdetailNew,sizeof(T_TRANSDETAIL));

		it_txcom.rtncd = DbsTRANSDETAIL(DBS_INSERT, &wdTransdetail);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_TRANSDETAIL_IERR, NULL);
			return;
		}
	
}

void aBaTransdetailNewEnd()
{
	DbsTRANSDETAIL(DBS_CLOSE, &wdTransdetail);
}
