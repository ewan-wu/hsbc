/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaFreefmtfileUpd                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �������ɸ�ʽ�ļ���                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            SUNFEI  			 Initial                        */
/************************************************************************/
#include "txatom_ba.h"

static T_FREEFMTFILE	wdFreefmtfile;

void aBaFreefmtfileUpdProcess(aTisBaFreefmtfileUpd *, aTosBaFreefmtfileUpd *);
void aBaFreefmtfileUpdCheck(aTisBaFreefmtfileUpd *, aTosBaFreefmtfileUpd *);
void aBaFreefmtfileUpdUpdate(aTisBaFreefmtfileUpd *, aTosBaFreefmtfileUpd *);
void aBaFreefmtfileUpdEnd(void);

void aBaFreefmtfileUpdProcess(staTisBaFreefmtfileUpd, staTosBaFreefmtfileUpd)
aTisBaFreefmtfileUpd	*staTisBaFreefmtfileUpd;
aTosBaFreefmtfileUpd	*staTosBaFreefmtfileUpd;
{
	aBaFreefmtfileUpdCheck(staTisBaFreefmtfileUpd, staTosBaFreefmtfileUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFreefmtfileUpdUpdate(staTisBaFreefmtfileUpd, staTosBaFreefmtfileUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFreefmtfileUpdCheck(staTisBaFreefmtfileUpd, staTosBaFreefmtfileUpd)
aTisBaFreefmtfileUpd	*staTisBaFreefmtfileUpd;
aTosBaFreefmtfileUpd	*staTosBaFreefmtfileUpd;
{
	memset(&wdFreefmtfile, 0, sizeof(wdFreefmtfile));
	memcpy(wdFreefmtfile.sReqseqno, staTisBaFreefmtfileUpd->sReqseqno, DLEN_REQSEQNO);
	memcpy(wdFreefmtfile.sDirection, staTisBaFreefmtfileUpd->sDirection, DLEN_DIRECTION);


	it_txcom.rtncd = DbsFREEFMTFILE(DBS_LOCK, &wdFreefmtfile);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FREEFMTFILE_RERR, "Reqseqno[%s],Direction[%s]", 
				 wdFreefmtfile.sReqseqno, wdFreefmtfile.sDirection);
		return;
	}
	return;
}

void aBaFreefmtfileUpdUpdate(staTisBaFreefmtfileUpd, staTosBaFreefmtfileUpd)
aTisBaFreefmtfileUpd	*staTisBaFreefmtfileUpd;
aTosBaFreefmtfileUpd	*staTosBaFreefmtfileUpd;
{
	memcpy(&wdFreefmtfile,staTisBaFreefmtfileUpd,sizeof(T_FREEFMTFILE));

	it_txcom.rtncd = DbsFREEFMTFILE(DBS_UPDATE, &wdFreefmtfile);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FREEFMTFILE_WERR, NULL);
		return;
	}
}

void aBaFreefmtfileUpdEnd()
{
	DbsFREEFMTFILE(DBS_CLOSE, &wdFreefmtfile);
}
