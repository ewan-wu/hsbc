/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaCommonUpd                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���¹�����Ϣ��		                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            sunfei			  			 Initial                        */
/************************************************************************/
#include "txatom_ba.h"

static T_COMMON	wdCommon;

void aBaCommonUpdProcess(aTisBaCommonUpd *, aTosBaCommonUpd *);
void aBaCommonUpdCheck(aTisBaCommonUpd *, aTosBaCommonUpd *);
void aBaCommonUpdUpdate(aTisBaCommonUpd *, aTosBaCommonUpd *);
void aBaCommonUpdEnd(void);

void aBaCommonUpdProcess(staTisBaCommonUpd, staTosBaCommonUpd)
aTisBaCommonUpd	*staTisBaCommonUpd;
aTosBaCommonUpd	*staTosBaCommonUpd;
{
	aBaCommonUpdCheck(staTisBaCommonUpd, staTosBaCommonUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaCommonUpdUpdate(staTisBaCommonUpd, staTosBaCommonUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaCommonUpdCheck(staTisBaCommonUpd, staTosBaCommonUpd)
aTisBaCommonUpd	*staTisBaCommonUpd;
aTosBaCommonUpd	*staTosBaCommonUpd;
{
	memset(&wdCommon, 0, sizeof(wdCommon));
	memcpy(wdCommon.sReqseqno, staTisBaCommonUpd->sReqseqno, DLEN_REQSEQNO);

	it_txcom.rtncd = DbsCOMMON(DBS_LOCK, &wdCommon);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_COMMON_RERR, "Reqseqno[%s]", 
				 wdCommon.sReqseqno);
		return;
	}
	return;
}

void aBaCommonUpdUpdate(staTisBaCommonUpd, staTosBaCommonUpd)
aTisBaCommonUpd	*staTisBaCommonUpd;
aTosBaCommonUpd	*staTosBaCommonUpd;
{
	memcpy(&wdCommon,staTisBaCommonUpd,sizeof(T_COMMON));

	it_txcom.rtncd = DbsCOMMON(DBS_UPDATE, &wdCommon);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_COMMON_WERR, NULL);
		return;
	}
}

void aBaCommonUpdEnd()
{
	DbsCOMMON(DBS_CLOSE, &wdCommon);
}
