/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaTransdetailUpd                                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �޸Ľ�����ϸ��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711          bingliang.wu         Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_TRANSDETAIL	wdTransdetail;

void aBaTransdetailUpdProcess(aTisBaTransdetailUpd *, aTosBaTransdetailUpd *);
void aBaTransdetailUpdCheck(aTisBaTransdetailUpd *, aTosBaTransdetailUpd *);
void aBaTransdetailUpdUpdate(aTisBaTransdetailUpd *, aTosBaTransdetailUpd *);
void aBaTransdetailUpdEnd(void);

void aBaTransdetailUpdProcess(staTisBaTransdetailUpd, staTosBaTransdetailUpd)
aTisBaTransdetailUpd	*staTisBaTransdetailUpd;
aTosBaTransdetailUpd	*staTosBaTransdetailUpd;
{
	aBaTransdetailUpdCheck(staTisBaTransdetailUpd, staTosBaTransdetailUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaTransdetailUpdUpdate(staTisBaTransdetailUpd, staTosBaTransdetailUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaTransdetailUpdCheck(staTisBaTransdetailUpd, staTosBaTransdetailUpd)
aTisBaTransdetailUpd	*staTisBaTransdetailUpd;
aTosBaTransdetailUpd	*staTosBaTransdetailUpd;
{
	memset(&wdTransdetail, 0, sizeof(wdTransdetail));
	memcpy(wdTransdetail.sTrndate, staTisBaTransdetailUpd->sTrndate, DLEN_TRNDATE);
  memcpy(wdTransdetail.sTimestamp, staTisBaTransdetailUpd->sTimestamp, DLEN_TIMESLICE);
  memcpy(wdTransdetail.sJrnno, staTisBaTransdetailUpd->sJrnno, DLEN_JRNNO);

	it_txcom.rtncd = DbsTRANSDETAIL(DBS_LOCK, &wdTransdetail);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_TRANSDETAIL_RERR, "Trndate[%s],Timeslice[%s],Jrnno[%s]", 
				 wdTransdetail.sTrndate, wdTransdetail.sTimestamp, wdTransdetail.sJrnno);
		return;
	}

	return;
}

void aBaTransdetailUpdUpdate(staTisBaTransdetailUpd, staTosBaTransdetailUpd)
aTisBaTransdetailUpd	*staTisBaTransdetailUpd;
aTosBaTransdetailUpd	*staTosBaTransdetailUpd;
{
	memcpy(&wdTransdetail,staTisBaTransdetailUpd,sizeof(T_TRANSDETAIL));

	it_txcom.rtncd = DbsTRANSDETAIL(DBS_UPDATE, &wdTransdetail);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_TRANSDETAIL_WERR, NULL);
		return;
	}
}

void aBaTransdetailUpdEnd()
{
	DbsTRANSDETAIL(DBS_CLOSE, &wdTransdetail);
}
