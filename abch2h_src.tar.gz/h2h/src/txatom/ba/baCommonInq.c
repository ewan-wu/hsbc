/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaCommonInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ������Ϣ��                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	sunfei  			 				Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_COMMON    wdCommon;

void aBaCommonInqProcess(aTisBaCommonInq *, aTosBaCommonInq *);
void aBaCommonInqCheck(aTisBaCommonInq *, aTosBaCommonInq *);
void aBaCommonInqUpdate(aTisBaCommonInq *, aTosBaCommonInq *);
void aBaCommonInqEnd(void);

void aBaCommonInqProcess(staTisBaCommonInq, staTosBaCommonInq)
aTisBaCommonInq	*staTisBaCommonInq;
aTosBaCommonInq	*staTosBaCommonInq;
{
	aBaCommonInqCheck(staTisBaCommonInq, staTosBaCommonInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaCommonInqUpdate(staTisBaCommonInq, staTosBaCommonInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaCommonInqCheck(staTisBaCommonInq, staTosBaCommonInq)
aTisBaCommonInq	*staTisBaCommonInq;
aTosBaCommonInq	*staTosBaCommonInq;
{
	memset(&wdCommon, 0, sizeof(wdCommon));
	memcpy(wdCommon.sReqseqno, staTisBaCommonInq->sReqseqno, DLEN_REQSEQNO);

	it_txcom.rtncd = DbsCOMMON(DBS_FIND, &wdCommon);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_COMMON_RERR, NULL);
		return;
	}

	memcpy(staTosBaCommonInq, &wdCommon, sizeof(wdCommon));

}

void aBaCommonInqUpdate(staTisBaCommonInq, staTosBaCommonInq)
aTisBaCommonInq	*staTisBaCommonInq;
aTosBaCommonInq	*staTosBaCommonInq;
{
}

void aBaCommonInqEnd()
{
}
