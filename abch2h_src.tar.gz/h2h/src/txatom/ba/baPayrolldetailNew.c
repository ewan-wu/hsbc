/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����ļ���־��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*       Date            Author              Description                */
/*   --------       -----------          -----------------              */
/*       200711         	bingliang.wu     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLDETAIL	wdPayrolldetail;

void aBaPayrolldetailNewProcess(aTisBaPayrolldetailNew*, aTosBaPayrolldetailNew*);
void aBaPayrolldetailNewCheck(aTisBaPayrolldetailNew*, aTosBaPayrolldetailNew*);
void aBaPayrolldetailNewUpdate(aTisBaPayrolldetailNew*, aTosBaPayrolldetailNew*);
void aBaPayrolldetailNewEnd(void);

void aBaPayrolldetailNewProcess
(aTisBaPayrolldetailNew *staTisBaPayrolldetailNew,aTosBaPayrolldetailNew *staTosBaPayrolldetailNew)
{
	aBaPayrolldetailNewCheck(staTisBaPayrolldetailNew, staTosBaPayrolldetailNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrolldetailNewUpdate(staTisBaPayrolldetailNew, staTosBaPayrolldetailNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrolldetailNewCheck(staTisBaPayrolldetailNew, staTosBaPayrolldetailNew)
aTisBaPayrolldetailNew	*staTisBaPayrolldetailNew;
aTosBaPayrolldetailNew	*staTosBaPayrolldetailNew;
{	
}

void aBaPayrolldetailNewUpdate(staTisBaPayrolldetailNew, staTosBaPayrolldetailNew)
aTisBaPayrolldetailNew	*staTisBaPayrolldetailNew;
aTosBaPayrolldetailNew	*staTosBaPayrolldetailNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdPayrolldetail, 0, sizeof(wdPayrolldetail));

		memcpy(&wdPayrolldetail,staTisBaPayrolldetailNew,sizeof(T_PAYROLLDETAIL));

		it_txcom.rtncd = DbsPAYROLLDETAIL(DBS_INSERT, &wdPayrolldetail);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_PAYROLLDETAIL_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsPAYROLLDETAIL(DBS_DELETE, &wdPayrolldetail);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_PAYROLLDETAIL_DERR, NULL);
			return;
		}
	}
}

void aBaPayrolldetailNewEnd()
{
	DbsPAYROLLDETAIL(DBS_CLOSE, &wdPayrolldetail);
}
