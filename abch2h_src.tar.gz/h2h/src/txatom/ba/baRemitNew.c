/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ������ұ�                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*       Date            Author              Description                */
/*   --------       -----------          -----------------              */
/*       200711         	bingliang.wu     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_REMIT	wdRemit;

void aBaRemitNewProcess(aTisBaRemitNew*, aTosBaRemitNew*);
void aBaRemitNewCheck(aTisBaRemitNew*, aTosBaRemitNew*);
void aBaRemitNewUpdate(aTisBaRemitNew*, aTosBaRemitNew*);
void aBaRemitNewEnd(void);

void aBaRemitNewProcess
(aTisBaRemitNew *staTisBaRemitNew,aTosBaRemitNew *staTosBaRemitNew)
{
	aBaRemitNewCheck(staTisBaRemitNew, staTosBaRemitNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaRemitNewUpdate(staTisBaRemitNew, staTosBaRemitNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaRemitNewCheck(staTisBaRemitNew, staTosBaRemitNew)
aTisBaRemitNew	*staTisBaRemitNew;
aTosBaRemitNew	*staTosBaRemitNew;
{	
}

void aBaRemitNewUpdate(staTisBaRemitNew, staTosBaRemitNew)
aTisBaRemitNew	*staTisBaRemitNew;
aTosBaRemitNew	*staTosBaRemitNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdRemit, 0, sizeof(wdRemit));

		memcpy(&wdRemit,staTisBaRemitNew,sizeof(T_REMIT));

		it_txcom.rtncd = DbsREMIT(DBS_INSERT, &wdRemit);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_REMIT_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsREMIT(DBS_DELETE, &wdRemit);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_REMIT_DERR, NULL);
			return;
		}
	}
}

void aBaRemitNewEnd()
{
	DbsREMIT(DBS_CLOSE, &wdRemit);
}
