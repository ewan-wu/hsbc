/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaFilelogUpd                                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �޸��ļ���־��                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711          bingliang.wu         Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_FILELOG	wdFilelog;

void aBaFilelogUpdProcess(aTisBaFilelogUpd *, aTosBaFilelogUpd *);
void aBaFilelogUpdCheck(aTisBaFilelogUpd *, aTosBaFilelogUpd *);
void aBaFilelogUpdUpdate(aTisBaFilelogUpd *, aTosBaFilelogUpd *);
void aBaFilelogUpdEnd(void);

void aBaFilelogUpdProcess(staTisBaFilelogUpd, staTosBaFilelogUpd)
aTisBaFilelogUpd	*staTisBaFilelogUpd;
aTosBaFilelogUpd	*staTosBaFilelogUpd;
{
	aBaFilelogUpdCheck(staTisBaFilelogUpd, staTosBaFilelogUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFilelogUpdUpdate(staTisBaFilelogUpd, staTosBaFilelogUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFilelogUpdCheck(staTisBaFilelogUpd, staTosBaFilelogUpd)
aTisBaFilelogUpd	*staTisBaFilelogUpd;
aTosBaFilelogUpd	*staTosBaFilelogUpd;
{
	memset(&wdFilelog, 0, sizeof(wdFilelog));
	memcpy(wdFilelog.sFileName, staTisBaFilelogUpd->sFileName, DLEN_FILENAME);
  memcpy(wdFilelog.sTrscTime, staTisBaFilelogUpd->sTrscTime, DLEN_TRSCTIME);
  memcpy(wdFilelog.sFileSrc, staTisBaFilelogUpd->sFileSrc, DLEN_FILESRC);

	it_txcom.rtncd = DbsFILELOG(DBS_LOCK, &wdFilelog);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FILELOG_RERR, "FileName[%s],TrscTime[%s],FileSrc[%s]", 
				 wdFilelog.sFileName, wdFilelog.sTrscTime,wdFilelog.sFileSrc);
		return;
	}

	return;
}

void aBaFilelogUpdUpdate(staTisBaFilelogUpd, staTosBaFilelogUpd)
aTisBaFilelogUpd	*staTisBaFilelogUpd;
aTosBaFilelogUpd	*staTosBaFilelogUpd;
{
	memcpy(&wdFilelog,staTisBaFilelogUpd,sizeof(T_FILELOG));

	it_txcom.rtncd = DbsFILELOG(DBS_UPDATE, &wdFilelog);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_FILELOG_WERR, NULL);
		return;
	}
}

void aBaFilelogUpdEnd()
{
	DbsFILELOG(DBS_CLOSE, &wdFilelog);
}
