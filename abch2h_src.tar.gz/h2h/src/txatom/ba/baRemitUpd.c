/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaRemitUpd                                                        */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �޸Ļ�ұ�                                              */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711          bingliang.wu         Initial                       */
/************************************************************************/
#include "txatom_ba.h"

static T_REMIT	wdRemit;

void aBaRemitUpdProcess(aTisBaRemitUpd *, aTosBaRemitUpd *);
void aBaRemitUpdCheck(aTisBaRemitUpd *, aTosBaRemitUpd *);
void aBaRemitUpdUpdate(aTisBaRemitUpd *, aTosBaRemitUpd *);
void aBaRemitUpdEnd(void);

void aBaRemitUpdProcess(staTisBaRemitUpd, staTosBaRemitUpd)
aTisBaRemitUpd	*staTisBaRemitUpd;
aTosBaRemitUpd	*staTosBaRemitUpd;
{
	aBaRemitUpdCheck(staTisBaRemitUpd, staTosBaRemitUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaRemitUpdUpdate(staTisBaRemitUpd, staTosBaRemitUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaRemitUpdCheck(staTisBaRemitUpd, staTosBaRemitUpd)
aTisBaRemitUpd	*staTisBaRemitUpd;
aTosBaRemitUpd	*staTosBaRemitUpd;
{
	memset(&wdRemit, 0, sizeof(wdRemit));
	memcpy(wdRemit.sReqseqno, staTisBaRemitUpd->sReqseqno, DLEN_REQSEQNO);
  
	it_txcom.rtncd = DbsREMIT(DBS_LOCK, &wdRemit);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_REMIT_RERR, "Reqseqno[%s]", 
				 wdRemit.sReqseqno);
		return;
	}

	return;
}

void aBaRemitUpdUpdate(staTisBaRemitUpd, staTosBaRemitUpd)
aTisBaRemitUpd	*staTisBaRemitUpd;
aTosBaRemitUpd	*staTosBaRemitUpd;
{
	memcpy(&wdRemit,staTisBaRemitUpd,sizeof(T_REMIT));

	it_txcom.rtncd = DbsREMIT(DBS_UPDATE, &wdRemit);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_REMIT_WERR, NULL);
		return;
	}
}

void aBaRemitUpdEnd()
{
	DbsREMIT(DBS_CLOSE, &wdRemit);
}
