/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �˻���Ϣ��ѯ                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20071112         	nathan  		 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_ACCOUNT    wdAccount;

void aBaAccountInqProcess(aTisBaAccountInq *, aTosBaAccountInq *);
void aBaAccountInqCheck(aTisBaAccountInq *, aTosBaAccountInq *);
void aBaAccountInqUpdate(aTisBaAccountInq *, aTosBaAccountInq *);
void aBaAccountInqEnd(void);

void aBaAccountInqProcess(staTisBaAccountInq, staTosBaAccountInq)
aTisBaAccountInq	*staTisBaAccountInq;
aTosBaAccountInq	*staTosBaAccountInq;
{
	aBaAccountInqCheck(staTisBaAccountInq, staTosBaAccountInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaAccountInqUpdate(staTisBaAccountInq, staTosBaAccountInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaAccountInqCheck(staTisBaAccountInq, staTosBaAccountInq)
aTisBaAccountInq	*staTisBaAccountInq;
aTosBaAccountInq	*staTosBaAccountInq;
{
	memset(&wdAccount, 0, sizeof(wdAccount));
	memcpy(wdAccount.sAcct, staTisBaAccountInq->sAcct, DLEN_ACC);
	it_txcom.rtncd = DbsACCOUNT(DBS_FIND, &wdAccount);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_ACCOUNT_RERR, NULL);
		return;
	}

	memcpy(staTosBaAccountInq, &wdAccount, sizeof(wdAccount));

}

void aBaAccountInqUpdate(staTisBaAccountInq, staTosBaAccountInq)
aTisBaAccountInq	*staTisBaAccountInq;
aTosBaAccountInq	*staTosBaAccountInq;
{
}

void aBaAccountInqEnd()
{
}
