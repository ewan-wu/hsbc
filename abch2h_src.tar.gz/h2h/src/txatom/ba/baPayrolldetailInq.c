/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaPayrolldetailInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ���ι�����                                          */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711         	bingliang.wu   			 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLDETAIL    wdPayrolldetail;

void aBaPayrolldetailInqProcess(aTisBaPayrolldetailInq *, aTosBaPayrolldetailInq *);
void aBaPayrolldetailInqCheck(aTisBaPayrolldetailInq *, aTosBaPayrolldetailInq *);
void aBaPayrolldetailInqUpdate(aTisBaPayrolldetailInq *, aTosBaPayrolldetailInq *);
void aBaPayrolldetailInqEnd(void);

void aBaPayrolldetailInqProcess(staTisBaPayrolldetailInq, staTosBaPayrolldetailInq)
aTisBaPayrolldetailInq	*staTisBaPayrolldetailInq;
aTosBaPayrolldetailInq	*staTosBaPayrolldetailInq;
{
	aBaPayrolldetailInqCheck(staTisBaPayrolldetailInq, staTosBaPayrolldetailInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrolldetailInqUpdate(staTisBaPayrolldetailInq, staTosBaPayrolldetailInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrolldetailInqCheck(staTisBaPayrolldetailInq, staTosBaPayrolldetailInq)
aTisBaPayrolldetailInq	*staTisBaPayrolldetailInq;
aTosBaPayrolldetailInq	*staTosBaPayrolldetailInq;
{
	memset(&wdPayrolldetail, 0, sizeof(wdPayrolldetail));
	memcpy(wdPayrolldetail.sBtno, staTisBaPayrolldetailInq->sBtno, DLEN_BTNO);
  memcpy(wdPayrolldetail.sSeqno, staTisBaPayrolldetailInq->sSeqno, DLEN_SEQNO);
  memcpy(wdPayrolldetail.sTrndate, staTisBaPayrolldetailInq->sTrndate, DLEN_TRNDATE);

	it_txcom.rtncd = DbsPAYROLLDETAIL(DBS_FIND, &wdPayrolldetail);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLDETAIL_RERR, NULL);
		return;
	}

	memcpy(staTosBaPayrolldetailInq, &wdPayrolldetail, sizeof(wdPayrolldetail));

}

void aBaPayrolldetailInqUpdate(staTisBaPayrolldetailInq, staTosBaPayrolldetailInq)
aTisBaPayrolldetailInq	*staTisBaPayrolldetailInq;
aTosBaPayrolldetailInq	*staTosBaPayrolldetailInq;
{
}

void aBaPayrolldetailInqEnd()
{
}
