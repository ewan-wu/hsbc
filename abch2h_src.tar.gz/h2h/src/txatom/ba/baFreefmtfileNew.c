/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaFreefmtfileNew                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �������ɸ�ʽ�ļ���                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200508         	Anny     			 Initial                    */
/************************************************************************/
#include "txatom_ba.h"

static T_FREEFMTFILE	wdFreefmtfile;

void aBaFreefmtfileNewProcess(aTisBaFreefmtfileNew*, aTosBaFreefmtfileNew*);
void aBaFreefmtfileNewCheck(aTisBaFreefmtfileNew*, aTosBaFreefmtfileNew*);
void aBaFreefmtfileNewUpdate(aTisBaFreefmtfileNew*, aTosBaFreefmtfileNew*);
void aBaFreefmtfileNewEnd(void);

void aBaFreefmtfileNewProcess
(aTisBaFreefmtfileNew *staTisBaFreefmtfileNew,aTosBaFreefmtfileNew *staTosBaFreefmtfileNew)
{
	aBaFreefmtfileNewCheck(staTisBaFreefmtfileNew, staTosBaFreefmtfileNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaFreefmtfileNewUpdate(staTisBaFreefmtfileNew, staTosBaFreefmtfileNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaFreefmtfileNewCheck(staTisBaFreefmtfileNew, staTosBaFreefmtfileNew)
aTisBaFreefmtfileNew	*staTisBaFreefmtfileNew;
aTosBaFreefmtfileNew	*staTosBaFreefmtfileNew;
{
}

void aBaFreefmtfileNewUpdate(staTisBaFreefmtfileNew, staTosBaFreefmtfileNew)
aTisBaFreefmtfileNew	*staTisBaFreefmtfileNew;
aTosBaFreefmtfileNew	*staTosBaFreefmtfileNew;
{
	if(gwdXdtl.sHcode[0] == TX_HCODE_NORMAL)
	{
		memset(&wdFreefmtfile, 0, sizeof(wdFreefmtfile));

		memcpy(&wdFreefmtfile,staTisBaFreefmtfileNew,sizeof(T_FREEFMTFILE));
		it_txcom.rtncd = DbsFREEFMTFILE(DBS_INSERT, &wdFreefmtfile);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_FREEFMTFILE_IERR, NULL);
			return;
		}
	}
	else if(gwdXdtl.sHcode[0] == TX_HCODE_CANCEL)
	{
		it_txcom.rtncd = DbsFREEFMTFILE(DBS_DELETE, &wdFreefmtfile);

		if(it_txcom.rtncd != DB_OK)
		{
			ERRTRACE(E_DB_FREEFMTFILE_DERR, NULL);
			return;
		}
	}
}

void aBaFreefmtfileNewEnd()
{
	DbsFREEFMTFILE(DBS_CLOSE, &wdFreefmtfile);
}
