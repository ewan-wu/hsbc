/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaPayrollmainUpd                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���´������ʻ��ܱ�                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            SUNFEI  			 Initial                        */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLMAIN	wdPayrollmain;

void aBaPayrollmainUpdProcess(aTisBaPayrollmainUpd *, aTosBaPayrollmainUpd *);
void aBaPayrollmainUpdCheck(aTisBaPayrollmainUpd *, aTosBaPayrollmainUpd *);
void aBaPayrollmainUpdUpdate(aTisBaPayrollmainUpd *, aTosBaPayrollmainUpd *);
void aBaPayrollmainUpdEnd(void);

void aBaPayrollmainUpdProcess(staTisBaPayrollmainUpd, staTosBaPayrollmainUpd)
aTisBaPayrollmainUpd	*staTisBaPayrollmainUpd;
aTosBaPayrollmainUpd	*staTosBaPayrollmainUpd;
{
	aBaPayrollmainUpdCheck(staTisBaPayrollmainUpd, staTosBaPayrollmainUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrollmainUpdUpdate(staTisBaPayrollmainUpd, staTosBaPayrollmainUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrollmainUpdCheck(staTisBaPayrollmainUpd, staTosBaPayrollmainUpd)
aTisBaPayrollmainUpd	*staTisBaPayrollmainUpd;
aTosBaPayrollmainUpd	*staTosBaPayrollmainUpd;
{
	memset(&wdPayrollmain, 0, sizeof(wdPayrollmain));
	memcpy(wdPayrollmain.sReqseqno, staTisBaPayrollmainUpd->sReqseqno, DLEN_REQSEQNO);



	it_txcom.rtncd = DbsPAYROLLMAIN(DBS_LOCK, &wdPayrollmain);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLMAIN_RERR, "Reqseqno[%s]", 
				 wdPayrollmain.sReqseqno);
		return;
	}
	return;
}

void aBaPayrollmainUpdUpdate(staTisBaPayrollmainUpd, staTosBaPayrollmainUpd)
aTisBaPayrollmainUpd	*staTisBaPayrollmainUpd;
aTosBaPayrollmainUpd	*staTosBaPayrollmainUpd;
{
	memcpy(&wdPayrollmain,staTisBaPayrollmainUpd,sizeof(T_PAYROLLMAIN));

	it_txcom.rtncd = DbsPAYROLLMAIN(DBS_UPDATE, &wdPayrollmain);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLMAIN_WERR, NULL);
		return;
	}
}

void aBaPayrollmainUpdEnd()
{
	DbsPAYROLLMAIN(DBS_CLOSE, &wdPayrollmain);
}
