/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaAccountUpd                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �����˻���                                              */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            sunfei  			       Initial                      */
/************************************************************************/
#include "txatom_ba.h"

static T_ACCOUNT	wdAccount;

void aBaAccountUpdProcess(aTisBaAccountUpd *, aTosBaAccountUpd *);
void aBaAccountUpdCheck(aTisBaAccountUpd *, aTosBaAccountUpd *);
void aBaAccountUpdUpdate(aTisBaAccountUpd *, aTosBaAccountUpd *);
void aBaAccountUpdEnd(void);

void aBaAccountUpdProcess(staTisBaAccountUpd, staTosBaAccountUpd)
aTisBaAccountUpd	*staTisBaAccountUpd;
aTosBaAccountUpd	*staTosBaAccountUpd;
{
	aBaAccountUpdCheck(staTisBaAccountUpd, staTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaAccountUpdUpdate(staTisBaAccountUpd, staTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaAccountUpdCheck(staTisBaAccountUpd, staTosBaAccountUpd)
aTisBaAccountUpd	*staTisBaAccountUpd;
aTosBaAccountUpd	*staTosBaAccountUpd;
{

	memset(&wdAccount, 0, sizeof(wdAccount));
	memcpy(wdAccount.sAcct, staTisBaAccountUpd->sAcct, DLEN_ACC);

	it_txcom.rtncd = DbsACCOUNT(DBS_LOCK, &wdAccount);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_ACCOUNT_RERR, "Acct[%s]", 
				 wdAccount.sAcct);
		return;
	}
	return;
}

void aBaAccountUpdUpdate(staTisBaAccountUpd, staTosBaAccountUpd)
aTisBaAccountUpd	*staTisBaAccountUpd;
aTosBaAccountUpd	*staTosBaAccountUpd;
{
	memcpy(&wdAccount,staTisBaAccountUpd,sizeof(T_ACCOUNT));

	it_txcom.rtncd = DbsACCOUNT(DBS_UPDATE, &wdAccount);

	if(it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_ACCOUNT_WERR, NULL);
		return;
	}
}

void aBaAccountUpdEnd()
{
	DbsACCOUNT(DBS_CLOSE, &wdAccount);
}
