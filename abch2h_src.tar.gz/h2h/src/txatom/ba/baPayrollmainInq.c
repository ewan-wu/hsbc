/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction atom module                                     */
/*   aBaPayrollmainInq                                                     */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ��ѯ�������ʻ��ܱ�                                      */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711        	sunfei  			 	Initial                     */
/************************************************************************/
#include "txatom_ba.h"

static T_PAYROLLMAIN    wdPayrollmain;

void aBaPayrollmainInqProcess(aTisBaPayrollmainInq *, aTosBaPayrollmainInq *);
void aBaPayrollmainInqCheck(aTisBaPayrollmainInq *, aTosBaPayrollmainInq *);
void aBaPayrollmainInqUpdate(aTisBaPayrollmainInq *, aTosBaPayrollmainInq *);
void aBaPayrollmainInqEnd(void);

void aBaPayrollmainInqProcess(staTisBaPayrollmainInq, staTosBaPayrollmainInq)
aTisBaPayrollmainInq	*staTisBaPayrollmainInq;
aTosBaPayrollmainInq	*staTosBaPayrollmainInq;
{
	aBaPayrollmainInqCheck(staTisBaPayrollmainInq, staTosBaPayrollmainInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	aBaPayrollmainInqUpdate(staTisBaPayrollmainInq, staTosBaPayrollmainInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
}

void aBaPayrollmainInqCheck(staTisBaPayrollmainInq, staTosBaPayrollmainInq)
aTisBaPayrollmainInq	*staTisBaPayrollmainInq;
aTosBaPayrollmainInq	*staTosBaPayrollmainInq;
{
	memset(&wdPayrollmain, 0, sizeof(wdPayrollmain));
	memcpy(wdPayrollmain.sReqseqno, staTisBaPayrollmainInq->sReqseqno, DLEN_REQSEQNO);


	it_txcom.rtncd = DbsPAYROLLMAIN(DBS_FIND, &wdPayrollmain);

	if (it_txcom.rtncd != DB_OK)
	{
		ERRTRACE(E_DB_PAYROLLMAIN_RERR, NULL);
		return;
	}

	memcpy(staTosBaPayrollmainInq, &wdPayrollmain, sizeof(wdPayrollmain));

}

void aBaPayrollmainInqUpdate(staTisBaPayrollmainInq, staTosBaPayrollmainInq)
aTisBaPayrollmainInq	*staTisBaPayrollmainInq;
aTosBaPayrollmainInq	*staTosBaPayrollmainInq;
{
}

void aBaPayrollmainInqEnd()
{
}
