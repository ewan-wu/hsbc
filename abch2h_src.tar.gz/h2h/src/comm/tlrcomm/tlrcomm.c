#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include "msglog.h"
#include "ipc.h"

#define MAX_BUF_SIZE 20480
#define STCB_APHEADLEN    8
#define STCB_SERVICE_IDX  8
#define STCB_SERVICE_LEN  16

int tcpBind(int port);
int tcpAccept(int sockid);
int tcpReadN (int sd, char *buf, int nbytes);
int tcpWriteN (int sd, char *buf, int nbytes);
void Process(int sockid);
int tcpReadMsg(int sockid, char *rcvbuf);
int tcpWriteMsg(int sockid, char *sndbuf, long sndsize);
void comDebugString(FILE *fp, char *psBuf, int iLength, int iLine);
void signalHandler(int nSig);
void daemonInit(void);

int tcpBind(int port)
{
	struct sockaddr_in sa;
	int sd;
	int on = 1;

	printf("Enter TcpBind port=[%d]\n",port);
    memset (&sa, 0, sizeof (sa));                  /* set all zeros          */
	sa.sin_family = AF_INET;                       /* TCP stream socket      */
	sa.sin_addr.s_addr = inet_addr("0.0.0.0");     /* set IP address         */
	sa.sin_port = htons (port);                    /* server port number     */
	if (sa.sin_port == 0)                          /* invalid port number    */
	{
		printf("htons error\n");
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		return -1;
	}
	
	if ((sd = socket (AF_INET, SOCK_STREAM, 0)) < 0)
	{
		printf("socket error\n");
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		return -1;
	}


	if (setsockopt(sd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1)
	{
	  	printf("setsockopt REUSRADDR errno = %d", errno);
        return -1;
	}

    if (bind(sd, (struct sockaddr *) &sa, sizeof (sa)) < 0)
	{
		if (errno == EADDRINUSE)
		{
			fprintf(stderr, "Port %d already in use.\n", port);
			close(sd);
			return -1;
		}
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		close(sd);
		return -1;
	}

	if (listen(sd, 5) < 0)
	{
		fprintf(stderr, "Cannot bind to port %d.\n", port);
		close(sd);
		return -1;
	}

	printf("Bind port %d ok.\n", port);

	return sd;
}

int tcpAccept(int sockid)
{
	int sd;
	pid_t	pid;

	size_t sa_length;
	struct sockaddr_in sa;
    struct linger soLinger;
	int soReuseAddr;
	int soKeepAlive;

	sa_length = sizeof (sa);

	if ((sd = accept(sockid, (struct sockaddr *) &sa, &sa_length)) < 0)
	{
		fprintf(stderr, "Accept fail.\n");
		return -1;
	}

	soLinger.l_onoff  = 0;
	soLinger.l_linger = 0;
	if (setsockopt (sd, SOL_SOCKET, SO_LINGER, (char *) &soLinger,
		sizeof (soLinger)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

    soKeepAlive = 1;
	if (setsockopt (sd, SOL_SOCKET, SO_KEEPALIVE, &soKeepAlive,
		sizeof (int)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

	soReuseAddr = 1;
	if (setsockopt (sd, SOL_SOCKET, SO_REUSEADDR, &soReuseAddr,
		sizeof (int)) < 0)
	{
		fprintf(stderr, "Setsockopt fail.\n");
		close(sd);
		return -1;
	}

	if ((pid = fork()) == -1)
	{
		fprintf(stderr, "Fork error:%d:%s\n", errno, strerror(errno));
		close(sd);
		return -1;
	}
	else 
	{
		if (pid != 0) /* parent process */
		{
			printf("parent process %d ok\n", getpid());
			close(sd);
			return sd;
		}
		else
		{
			printf("child process %d ok\n", getpid());
			Process(sd);
			shutdown(sd, 2);
			close(sd);
			exit(0);
		}
	}
}

int tcpReadN (int sd, char *buf, int nbytes)
{

    int nleft = nbytes;                 /* number of bytes left to read  */
    int nread;                           /* number of bytes read this time*/

    /* read nbytes data from socket */
    while (nleft > 0)
    {
        nread = read (sd, buf, nleft); /* read socket */
        if (nread < 0)
        {
            return -1;                   /* read error */
        }
        if (nread == 0)
        {
            break;                         /* EOF; exit loop */
        }
        /* some data have been read */
        nleft -= nread;
        buf += nread;
    } /* end of while */

    /* actual number of bytes read */
    return (nbytes - nleft);             /* success */

} /* end of tcpReadN() */

int tcpWriteN(int sd, char *buf, int nbytes)
{

    int nleft = nbytes;             /* number of bytes left to readi     */
    int nwritten;                   /* number of bytes written this time */

    /* write iNbytes data to socket */
    while (nleft > 0)
    {
        nwritten = write(sd, buf, nleft);    /* write socket */
        if (nwritten <= 0)
        {
            return -1;                       /* write error */
        }
        /* some data have been written */
        nleft -= nwritten;
        buf += nwritten;
    } /* end of while */

    /* actual number of bytes written */
    if (nleft == 0)
    {
         return nbytes;                      /* success */
    }

    return -1;                               /* write error; impossible */

} /* end of tcpWriteN() */

void Process(int sockid)
{
	long rcvsize, sndsize;
	char rcvbuf[MAX_BUF_SIZE];
	char sndbuf[MAX_BUF_SIZE];
	long lMsgSource;
	long lPid = 0;
	short recvsize,sendsize;
	char sPid[9];
	short nRet;

   	lPid = getpid();
	sprintf(sPid, "%8d", lPid);

	while(1)
	{
		memset(rcvbuf, 0, sizeof(rcvbuf));
		memset(sndbuf, 0, sizeof(sndbuf));

		sndsize = 0;
		sendsize = 0;
		rcvsize = 0;
		recvsize = 0;

		if ((rcvsize = tcpReadMsg(sockid, rcvbuf)) < 0) return;
		/*sndsize = sizeof(sndbuf);*/
		
		SetTimeStart("begin");

		/* judge the target by taskid in TITA */
		/** TEST
		if (tTitaLabel.taskid[1] == 'M')
		{
			nRet = nCommonMsqSend(rcvsize, rcvbuf, CI_TLRCOMM, CI_MANAGER );
		}
		else
		{
			nRet = nCommonMsqSend(rcvsize, rcvbuf, CI_TLRCOMM, CI_SWTSVR );
		}
		TEST **/

		nRet = nCommonMsqSend(rcvsize, rcvbuf, lPid, CI_TLRBDG );
		if ( nRet != 0 )
		{
			ErrReport(CI_TLRCOMM,
                		EI_MESSAGEQUEUE,
                		errno,
                		CI_SEVERITY_SYSERROR,
                		ES_MSGQ_WRITE);

			printf("rcvsize=[%d]\n",rcvsize);
 			comDebugString(stdout, rcvbuf, rcvsize, 0);
			return;
		}

		/* added by xth */
		alarm(30);

		if ( nCommonMsqRecvT(&sendsize,sndbuf,&lMsgSource,lPid,CI_TLRCOMM) != 0 )
		{
			ErrReport(CI_TLRCOMM,
                    	EI_MESSAGEQUEUE,
                    	errno,
                    	CI_SEVERITY_SYSERROR,
                    	ES_MSGQ_READ);

			printf("sndsize=[%d]\n",sendsize);
 			comDebugString(stdout, sndbuf, sendsize, 0);
			return;
		}
		
		sndsize = sendsize;

		GetTimeTotal("end");
		alarm(0);

		if (tcpWriteMsg(sockid, sndbuf, sndsize) < 0) return; 
	}
}

int tcpReadMsg(int sockid, char *rcvbuf)
{
	long size;
	
	printf("Enter ReadMsg\n");

	if (tcpReadN(sockid, rcvbuf, STCB_APHEADLEN) != STCB_APHEADLEN)
	{
		fprintf(stderr, "Read socket error\n");
		printf("Read socket error\n");
		return -1;
	}

	size = (unsigned char)rcvbuf[0] * 256
			+ (unsigned char)rcvbuf[1];

	if (tcpReadN(sockid, rcvbuf + STCB_APHEADLEN, size - STCB_APHEADLEN) != size - STCB_APHEADLEN)
	{
		return -1;
	}

	printf("Receive ....\n");
 	comDebugString(stdout, rcvbuf, size, 0);

	return size;
}

int tcpWriteMsg(int sockid, char *sndbuf, long sndsize)
{
	printf("Enter WriteMsg\n");
	if (tcpWriteN(sockid, sndbuf, sndsize) != sndsize)
	{
		fprintf(stderr, "Write socket error.\n");
		return -1;
	}
	printf("Send ....\n");
 	comDebugString(stdout, sndbuf, sndsize, 0);
	return 0;
}

int main(int argc, char *argv[])
{
	int sd, scd;
	int c;	
	int port = 2510;
	long lReturn;
	short nRet;

	/* option handle */
	/*
	while ((c = getopt(argc, argv, "p:")) != -1)
	{
		switch (c)
		{
			case 'p':
				port = atoi(optarg);
				break;
			case ':':
			case '?':
				fprintf(stderr, "Usage: %s -p <port>\n", argv[0]);
				exit(1);
		}
	}
	*/
	if (argc != 3) 
	{
		fprintf(stderr, "Usage: %s <log-file> <port>\n", argv[0]);
		exit(1);
	}
	port = atoi(argv[2]);

	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	
	lReturn = DbConnect();
    if (lReturn != 0)
    {
       /* ErrReport(CI_TLRCOMM,
                  EI_DATABASE,
                  lReturn,
                  CI_SEVERITY_SYSERROR,
                  ES_DB_OPEN); */
        exit(1);
    }
	
	nRet = nLoadMsqDef();
    if (nRet != 0)
    {
		printf("load msq define error\n");
        exit(1);
	}
    nRet = nCommonMsqInit(CI_TLRCOMM);
    if (nRet != 0)
    {
		printf("msq init error\n");

        /*ErrReport(CI_TLRCOMM,
                EI_MESSAGEQUEUE,
                0,
                CI_SEVERITY_SYSERROR,
                ES_MSGQ_CONNECT); */
        exit(1);
    }

	printf("msq init ok\n");

	lReturn = DbDisConnect();
    if (lReturn != 0)
    {
        /*ErrReport(CI_BRIDGE,
                EI_DATABASE,
                lReturn,
                CI_SEVERITY_SYSERROR,
                ES_DB_CLOSE);*/
        exit(1);
    }
	
	if ((sd = tcpBind(port)) < 0)
	{
		printf("bind error\n");
        /*ErrReport(CI_TLRCOMM_MON,
                EI_COMMUNICATION,
                sd,
                CI_SEVERITY_SYSERROR,
                ES_COMM_ACCEPT); */
		exit(1);
	}

	daemonInit();

	signal(SIGCLD, SIG_IGN);
	signal(SIGCHLD, SIG_IGN);

	while(1)
	{
		if ((scd = tcpAccept(sd)) < 0)
		{
			printf("accept error\n");
        	/*ErrReport(CI_TLRCOMM_MON,
                	EI_COMMUNICATION,
                	scd,
                	CI_SEVERITY_SYSERROR,
                	ES_COMM_ACCEPT);*/
			close(sd);
			exit(1);
		}
	}

}

void comDebugString(FILE *fp, char *psBuf, int iLength, int iLine)
{
   int        i, j = 0;
   char       s[100], temp[5];

   fprintf(fp, "Debug Information from Line: %04d\n", iLine);

   for (i=0; i<iLength; i++)
   {
      if (j==0)
      {
         memset( s, ' ', 84);
         sprintf(temp,   " %03d:",i );
         memcpy( s, temp, 5);
         sprintf(temp,   ":%03d",i+15 );
         memcpy( &s[72], temp, 4);
      }
      sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
      memcpy( &s[j*3+5+(j>7)], temp, 3);
      if ( isprint( psBuf[i]))
      {
         s[j+55+(j>7)]=psBuf[i];
      }
      else
      {
         s[j+55+(j>7)]='.';
      }
      j++;
      if ( j==16)
      {
         s[76]=0;
         fprintf(fp, "%s\n", s);
         j=0;
      }
   }
   if ( j)
   {
      s[76]=0;
      fprintf(fp, "%s\n", s);
   }
}

void signalHandler(int nSig)
{
	fprintf(stdout, "**INFO--INFO**: Signal [%d]\n", nSig);
	signal(nSig, signalHandler);
}

void daemonInit(void)
{
	int    i;
	pid_t   pid;

	if ((pid = fork()) != 0)
		exit(0);    /* parent terminates */

	/* 1st child continues */
	setsid();    /* become session leader */

	signal(SIGHUP, SIG_IGN);
	if ((pid = fork()) != 0)
		exit(0);    /* 1st child terminates */


	/**
	close(1);
	open("TellerComm.out", O_WRONLY|O_CREAT|O_APPEND, S_IRUSR|S_IWUSR);
	close(2);
	open("TellerComm.err", O_WRONLY|O_CREAT|O_APPEND, S_IRUSR|S_IWUSR);
	**/

	/* 2nd child continues */
	chdir("/");    /* change working directory */

	umask(0);      /* clear our file mode creation mask */
}
