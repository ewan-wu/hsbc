#include "glb_def.h"
#include "msgque.h"
#include "htlog.h"
#include "ipc.h"
#include <sys/msg.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <sys/times.h>


#define CHD_PROCESS_NUM 1
int gnTimeOver = 600;			
void 	vCTcpSndEcho();
