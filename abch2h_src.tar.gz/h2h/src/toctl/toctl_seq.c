/*****************************************************************************/
/* TOCTL_SEQ :                                                               */
/*****************************************************************************/

#include "toctl_seq.h"
#include "htlog.h"

char logfile[256];
long glSrvId;

void main(short argc, char **argv)
{
    SwtToSEQReqDef ipcMsg;
    int nReturn;
	long lReturn;
	short nRet;
    char sTime[20];
	short nDataLen;
    long lMsgSource; 

    atexit(HandleExit);
    
	if ( argc != 2 )
    {
        fprintf(stdout, "Usage: toctl_seq < logfile >\n");
        exit(0);
    }

    setbuf(stdout, NULL);

    nReturn = GetLogName(argv[1], logfile);
    if (nReturn != 0 )
    {
        fprintf(stderr, "GetLogName error !\n");
    }

	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
    		"TimeOut Controller (SEQ) started, pid=%d\n", getpid());    

    DebugMemory("TO SEQ Start");

    /***************************/
    /* Connect to the database */
    /***************************/
    lReturn = DbConnect();
    if (lReturn != 0)
    {
        error_report("connect database error");
        exit(0);
    }

	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	glSrvId = CI_TOCTL_SEQ;
	nRet = nCommonMsqAllInit(glSrvId);
	if (nRet != 0) 
    {
        error_report("MSG_QUEUE_ERROR");
        exit(0);
    }
#ifdef _LOG
	printf("Connect TOCTL MSGQ success!\n");
#endif

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Connect TOCTL MSGQ success!\n");

/*
// HANDLE TRANSACTION
*/
    for(;;)
    {
        CommonGetCurrentTime(sTime);
		HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"\n====== TIME : %s ====================\n", sTime);

		nRet = nCommonMsqRecv (&nDataLen, (char*)&ipcMsg, &lMsgSource, glSrvId);
	    if (nRet != -1)
		{
			HtDebugString(logfile, (char*)&ipcMsg, sizeof(SwtToSEQReqDef), 
					__FILE__, __LINE__); 
			HandleRequest(&ipcMsg);
		}
		else
		{
    		if (errno != EINTR)
        	{
				HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
                	"\n errno[%d]\n", errno);
             
				if (nCommonMsqInit(glSrvId) == -1)
				{
					error_report( "RCV_TO_IN_QUEUE_ERROR");

					exit(1);
				}
            }
        }
    }  /*for(;;)*/

    /********************************/
    /* Disconnect from the database */
    /********************************/

    lReturn = DbDisConnect();
    if (lReturn != 0)
    {
        error_report("disconnect database error");
        exit(0);
    }

}


error_report( char *s)
{
	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
    		"Error: %s\n", s);
}


void HandleRequest( SwtToSEQReqDef *ipcMsg)
{
    SwtToSEQReqDef ipcReply;    
    char sTime[20];
	struct wd_bseqctl_area wd_bseqctl;
	int ret;
	int iSEQ;
	int iLen;
	char sSEQ[12+1];
	char sPat[10];

    CommonGetCurrentTime( sTime);
	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
    		"Send pid is %d at %s\n", ipcMsg->nSwitchPID, sTime);

    ipcReply.MsgType = ipcMsg->nSwitchPID;
    ipcReply.nMsgCode = ipcMsg->nMsgCode;
    ipcReply.nReplyCode = 0;
    ipcReply.nSwitchPID = ipcMsg->nSwitchPID;
	memcpy(ipcReply.sSeqType, ipcMsg->sSeqType, sizeof(ipcReply.sSeqType));
	ipcReply.nSeqLen = 0;
	memset(ipcReply.sSeqStr, ' ', sizeof(ipcReply.sSeqStr));

	memset(&wd_bseqctl, 0, sizeof(wd_bseqctl));
	memcpy(wd_bseqctl.rcd_id, ipcMsg->sSeqType, sizeof(ipcMsg->sSeqType));
	memset(sPat, 0, sizeof(sPat));
	memset(sSEQ, 0, sizeof(sSEQ));
	iSEQ = 0;
	iLen = 0;

	if(DbBeginTxn() != 0) 
	{
		/* reply error */
    	ipcReply.nReplyCode = -1;
        SendSwitch( &ipcReply);
		return;
	}

	if(DbsBSEQCTL(DBS_LOCK, &wd_bseqctl) != 0)
	{
		/* reply error */
		DbRollbackTxn();
    	ipcReply.nReplyCode = -2;
        SendSwitch( &ipcReply);
		return;
	}

	iSEQ = wd_bseqctl.sn_next_apply;
	iLen = wd_bseqctl.sn_len;
	sprintf(sPat, "%%0%dd", wd_bseqctl.sn_len);
	sprintf(sSEQ, sPat, wd_bseqctl.sn_next_apply);

	if (iSEQ == wd_bseqctl.sn_max)
	{
		wd_bseqctl.sn_next_apply = wd_bseqctl.sn_min;
	}
	else
	{
		wd_bseqctl.sn_next_apply = wd_bseqctl.sn_next_apply + 1;
	}

	CommonGetCurrentTimeDB(wd_bseqctl.rec_updt_time);

	if(DbsBSEQCTL(DBS_UPDATE, &wd_bseqctl) != 0)
	{
		/* reply error */
		DbRollbackTxn();
    	ipcReply.nReplyCode = -3;
        SendSwitch( &ipcReply);
		return;
	}

	if(DbsBSEQCTL(DBS_CLOSE, &wd_bseqctl) != 0)
	{
		/* reply error */
		DbRollbackTxn();
    	ipcReply.nReplyCode = -4;
        SendSwitch( &ipcReply);
		return;
	}
	
	if(DbCommitTxn() != 0) 
	{
		/* reply error */
		DbRollbackTxn();
    	ipcReply.nReplyCode = -5;
        SendSwitch( &ipcReply);
		return;
	}

	ipcReply.nSeqLen = iLen;
	memcpy(ipcReply.sSeqStr, sSEQ, iLen);
    SendSwitch( &ipcReply);

	return;
} 

void SendSwitch(SwtToSEQReqDef * ipcReply )
{
    int nReturn=0;
 
	HtDebugString(logfile, (char*)ipcReply, sizeof( SwtToSEQReqDef),
		__FILE__, __LINE__); 
    
	nReturn = nCommonMsqOutSend(sizeof(SwtToSEQReqDef), 
				(char*)ipcReply, ipcReply->nSwitchPID,glSrvId);
	if (nReturn != 0)
	{
		ErrReport(glSrvId,
			EI_MESSAGEQUEUE,
			0,
			CI_SEVERITY_SYSERROR,
			ES_MSGQ_WRITE);
	}
}

void HandleExit( )
{
    DebugMemory( "Exit Handled");
}


