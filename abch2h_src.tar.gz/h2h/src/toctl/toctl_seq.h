#ifndef _TOCTL_SEQ_H
#define _TOCTL_SEQ_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "msglog.h"
#include "swttoc.h"
#include "wd_incl.h"
#include "glb_def.h"

void    HandleExit();
void    HandleRequest(SwtToSEQReqDef * );
void    SendSwitch(SwtToSEQReqDef * ipcReply);

#define _LOG
#define _DEBUG

#endif /* _TOCTL_SEQ_H */
