#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
	char a[] = "sjkdfsjkdf";
	char b[] = "iuweyriwuer";

	char c[45];

	memset(c, 0, 45);

	sprintf(c, "a:%-20.20s;b:%-20.20s",a,b);
	printf("%s\n", c);
}

