#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <sys/errno.h>
#include    <dirent.h>
#include    <libgen.h>
#include    "common.h"
#include    "softenc.h"

//int		os_type = 1;


int main(int argc, char *argv[])
{
    char sFileName[256+1];
    int  nEncFlag;
	int nRet;

    memset(sFileName,0,sizeof(sFileName));

	if(argc<3)
	{
        printf("��������! �÷�:����, %s 1 �������ļ���\n",argv[0]);
        printf("              ����, %s 2 �������ļ���\n",argv[0]);
        return 1;
	}

    nEncFlag=atoi(argv[1]);
    strcpy(sFileName,argv[2]);

    if(nEncFlag==1)
        nRet=Encrypt_HUB_File(sFileName);
    else
        nRet=Decrypt_HUB_File(sFileName);

    if(nRet!=0){
        printf("�ļ�[%s]%sʧ��!\n",sFileName,nEncFlag==1?"����":"����");
        return 1;
    }
    else
        printf("�ļ�[%s]%s�ɹ�!\n",sFileName,nEncFlag==1?"����":"����");

    return 0;
}


int Encrypt_HUB_File(char *sInFileName)
{
    char    sEtcFileName[256+1];
    char    sToEncFile[256+1];
    char    sToEncFileTmp[256+1];
    char    sEncStr[100];
	unsigned char	bmk[16];
    FILE	*enfp;

    memset(sEtcFileName,0,sizeof(sEtcFileName));
    memset(sToEncFile,0,sizeof(sToEncFile));
    memset(sToEncFileTmp,0,sizeof(sToEncFileTmp));
    memset(sEncStr,0,sizeof(sEncStr));
    memset(bmk,0,sizeof(bmk));

    /*�ļ�����*/
    sprintf(sEtcFileName, "%s/%s/%s", getenv("APPL"), "etc", "EnKey");
    if ((enfp = fopen(sEtcFileName, "rb")) == NULL)
    {
    	printf("��key�ļ�[%s]ʧ��!", sEtcFileName);
    	return -9;
    }

    fread(sEncStr, 32, 1, enfp);
    fclose(enfp);
    Str2Hex(sEncStr,bmk,32);
    strcpy(sToEncFile,sInFileName);
    sprintf(sToEncFileTmp,"%s.Enc",sToEncFile);

    if (EncryptFile(sToEncFile, sToEncFileTmp, bmk))
    {
    	printf("�����ļ�[%s]ʧ��!", sToEncFile);
    	return -10;
    }

    //rename(sToEncFileTmp,sToEncFile);
    /*
    memset(sCommand, 0, sizeof(sCommand));
    sprintf(sCommand, "mv %s %s", file_name_tmp, file_name);
    if (system(sCommand) != 0)
    {
    	ERRTRACE(NULL, "command[%s]", sCommand);
    	return -12;
    }*/
    return 0;
}

int Decrypt_HUB_File(char *sInFileName)
{
	char TmpStr[100], TmpName[100];
	FILE *Enfp, *fp;
	unsigned char bmk[16];
	int		iFlag, len, i;
    int nRet;
	char	sFileName[256+1];
	char	sDeFileName[256+1];

	memset(TmpName,'\0',sizeof(TmpName));
	sprintf(TmpName,"%s/%s/%s",getenv("APPL"),"etc","EnKey");
	if((Enfp = fopen(TmpName, "rb")) == NULL)
	{
		printf("file open error %s", TmpName);
		return -1;
	}

	memset(TmpStr,'\0',sizeof(TmpStr));
	fread(TmpStr,32,1,Enfp);
	fclose(Enfp);
	Str2Hex(TmpStr,bmk,32);
	memset(sFileName,'\0',sizeof(sFileName));
	memset(sDeFileName,'\0',sizeof(sDeFileName));

	strcpy(sFileName, sInFileName);
	strcpy(sDeFileName, sFileName);
	strcat(sDeFileName, ".Dec");
	nRet= DecryptFile(sFileName, sDeFileName, bmk);
	if (nRet < 0)
	{
		printf("decryptfile error");
		return -2;
	}

	return 0;
}
