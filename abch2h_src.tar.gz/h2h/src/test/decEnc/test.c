#include <stdio.h>
void replace(char *s)
{
  int i,j;
  i = findstr(s);
  /*printf("i=[%d]\n",i);*/
  if ( i == 140 )
  {
    return;
  }else{
  j = 35*(i/35+1);
  /*printf("j=[%d]\n",j);*/
  memcpy(s+j,(s+i+1),140-j);
  memset(s+i,' ', (35 - i%35));
  replace(s);}
}

int findstr(char *s)
{
    int i;
    for(i=0;i<140;i++)
    {
        if(*(s+i) =='\0')
        return 140;
        if(*(s+i) ==39)
        return i;
    }
}
main()
{
	char a[141];
	memset(a,0,141);
	memcpy(a,"EO36'3.01055'A'",15);
	replace(a);
	printf("[%s]\n", a);
}

