import  jxl. * ;
import  jxl.format.UnderlineStyle;
import  jxl.write. * ;
import  jxl.write.Number;
import  jxl.write.Boolean;
import  java.io. * ;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class GenerateExcelTest {
	
	
    public   static   void  writeExcel(OutputStream os ,String fileInputName) {
        try  {
        	//����
        	jxl.write.Number n=null;
        	jxl.write.DateTime d=null;
        	String[] format= null;
        	int colum = 0;

        	WritableFont headerFont = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD, false, UnderlineStyle.NO_UNDERLINE, jxl.format.Colour.BLACK); 
        	WritableCellFormat headerFormat = new WritableCellFormat (headerFont); 
        	headerFormat.setAlignment(Alignment.CENTRE);
        	headerFormat.setBackground(Colour.GREY_25_PERCENT);
        	//���ñ߿�
        	//headerFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THICK);

        	WritableFont titleFont = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, jxl.format.Colour.BLUE); 
        	WritableCellFormat titleFormat = new WritableCellFormat (titleFont); 
        	//���ñ߿�
        	//titleFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THICK);
        	
        	
        	WritableFont detFont = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, jxl.format.Colour.BLACK); 
        	WritableCellFormat detFormat = new WritableCellFormat (detFont); 
        	//���ñ߿�
        	detFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN);
        	
        	NumberFormat cur=new NumberFormat("#,###.00"); //���ڻ��ҵĸ�ʽ
        	WritableCellFormat curFormat = new WritableCellFormat (detFont, cur); 
        	//���ñ߿�
        	curFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN);
        	
        	NumberFormat nf=new NumberFormat("0.00"); //�������ֵĸ�ʽ
        	WritableCellFormat numFormat = new WritableCellFormat (detFont, nf); 
        	//���ñ߿�
        	numFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN);
        	
        	
        	DateFormat df=new DateFormat("yyyy-MM-dd");//�������ڵ�
        	WritableCellFormat dateFormat = new WritableCellFormat (detFont, df); 
        	//���ñ߿�
        	dateFormat.setBorder(jxl.format.Border.ALL,jxl.format.BorderLineStyle.THIN);
        	
           WritableWorkbook wwb  =  Workbook.createWorkbook(os);
            //  ����excel������ �����ƺ�λ�� 
           WritableSheet ws  =  wwb.createSheet( "REPORT" ,  0 );       	
        	
        	
        	//���ļ�
        	File fileRead  =   new  File(fileInputName); 
        	BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(fileRead)));
        	
        	String linein=in.readLine();
        	int j = 0 ;
        	while(linein!=null)
        	{
        		System.out.println("linein:"+linein);
        		String[] temp=linein.split(";");
        		if(temp[0].equals("f#"))
        		{
        			format=linein.split(";");  
        		}
        		if(temp[0].equals("l#"))
        		{
        			for(int i=1;i<temp.length;i++)
        			{
        				ws.setColumnView(i-1, Integer.parseInt(temp[i]));
        			}
        		}
        		//��������
        		if(temp[0].equals("1#"))
        		{
        			Label label  =   new  Label( 0 ,  0 ,  temp[1] , headerFormat);
        	        ws.addCell(label);  
        	        System.out.println("temp[0]"+temp[0]);
        		}
        		//����TITLE
        		if(temp[0].equals("2#"))
        		{
        			for(int i = 1; i < temp.length; i++)
        			{
        				System.out.println("temp["+i+"]:"+temp[i]);
        				Label label  =   new  Label( i-1 ,  j-2 ,  temp[i] , titleFormat);
        				ws.addCell(label);
        				
        			}      			
        		}
        		//��������
        		if(temp[0].equals("3#"))
        		{
        			for(int i = 1; i < temp.length; i++)
        			{
        				if(format[i].equals("n"))
        				{
        					n=new jxl.write.Number(i-1, j-2, Double.parseDouble(temp[i]), numFormat);
        					ws.addCell(n);
        				}
        				if(format[i].equals("m"))
        				{
        					n=new jxl.write.Number(i-1, j-2, Double.parseDouble(temp[i]), curFormat);
        					ws.addCell(n);
        				}
        				if(format[i].equals("d"))
        				{
        					d=new DateTime(i-1, j-2, numberToDate(temp[i]), dateFormat);
        					ws.addCell(d);
        				}
        				if(format[i].equals("c"))
        				{
        					System.out.println("temp["+i+"]:"+temp[i]);
            				Label label  =   new  Label( i-1 ,  j-2 ,  temp[i], detFormat);
            				ws.addCell(label);
        				}
        			colum = i-1;	
        			}
        		}
        		j++;
        		linein = in.readLine();
        	}
        	ws.mergeCells(0, 0, colum, 0);
        	
          

            //  д�빤���� 
           in.close();
           wwb.write();
           wwb.close();
       }  catch  (Exception e) {
           System.out.println( ""   +  e);
       }

   }
    
	/**
	 * ��yyyyMMdd��ʽ���ַ�����������
	 * 
	 * @param date
	 * @return
	 */
	public static Date numberToDate(String string) throws Exception
	{
		if(string == null)
			return null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
		try
		{
			return simpleDateFormat.parse(string);
		}
		catch(ParseException e)
		{
			throw e;
		}
	}
	
    public   static   void  main(String args[]) {
        try  {
           String fileInputName = args[0]+".txt";
           String fileOutputName = args[0]+".xls";
           File fileWrite  =   new  File(fileOutputName);
           System.out.println("filename:"+fileWrite.getName());
           fileWrite.createNewFile();
           OutputStream os  =   new  FileOutputStream(fileWrite);
           writeExcel(os,fileInputName);
           os.close();
       
           
       }  catch  (Exception e) {
           System.out.println(e);
       }
   }


}
