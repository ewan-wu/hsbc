#!/usr/bin/sh
cd $HOME/h2h/src/test/excelfmt
LANG=zh_CN
java GenerateExcelTest.class ACK_03332200040026343_080710_00
