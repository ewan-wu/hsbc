#include "sctcp.h"

#define RETRYNUM  5

//#define ABC_FILE_DIR "src/test/ABCsimu/ABC_FILE"

char *GetCurTime();

char logfile[256];
int Socket_id, Pid;
long CnapsCommId,lDestSvrID;
long lMsqInId;


int main (int argc, char *argv[])
{
	int   I, J, Num, Flag, port;
	
	IPCMsgDef1 nMsgToXnet;
	short nRet;
	short nDataLen, nMsgSource;
	long lMsgSourceId;
	long lRet;
	
    DIR			*dp;
    struct dirent *dirp;
    FILE		*fp=NULL;
    char        sBuff[5000];
    char        sBuffAll[5000];
	char sABCDir[256];
	char sDBTime[40];
    char sMVDIR[256];
    char sMvFile[256];
    char sOpenFile[256];
	int icount=0;

	setbuf(stdout, NULL); 
	setbuf(stderr, NULL);
	
	
	if (argc != 5)
	{ 
		printf("ABCfileSnd argument error.\n");
		exit(0);
	}
	
	lRet = GetLogName(argv[4], logfile);
	if (lRet != 0)
	{
       exit(0);
	}
	
    strcpy(sABCDir,argv[1]);	
	CnapsCommId = atol(argv[2]);
	lDestSvrID = atol(argv[3]);
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"CnapsCommId=[%d]", lDestSvrID);

	lMsqInId = msgget(lDestSvrID, IPC_CREAT|MSG_FLAG);
	if ( nRet  < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"CNAPSComm MSQ INIT ERR...EXIT [%d]1",lDestSvrID);
		
		exit(1);
	}
	printf("CnapsCommId[%d], lMsqInId[%d]\n",lDestSvrID,lMsqInId);

	
	while(1)
	{
	    CommonGetCurrentTimeDB(sDBTime);
		printf("-------------------------begin to check dir [%s]-----------------------------------------------------\n",sDBTime);

		memset(&nMsgToXnet, 0 , sizeof(nMsgToXnet));
	
	    
        dp = opendir(sABCDir);
        if(dp==NULL)
        {
            printf("opendir[%s] error\n",sABCDir);
            //return -1;
            sleep(5);
            continue;
        }
        
        while(( dirp=readdir(dp)) != NULL )
        {
            if(dirp->d_name[0]=='.')
                continue;
            printf("find file[%s],begin to process\n",dirp->d_name);

    		sprintf(sOpenFile,"%s/%s",sABCDir,dirp->d_name);
    		sprintf(sMvFile,"%s/../TMP/%s",sABCDir,dirp->d_name);
    		
    		printf("sOpenFile[%s]\n",sOpenFile);
    		printf("sMvFile[%s]\n",sMvFile);
    		
            fp = fopen(sOpenFile,"r");
            if(fp==NULL)
            {
                printf("fopen[%s] error[%s]\n",dirp->d_name,strerror(errno));
                //return -1;
                continue;   
            }
            
            fread(sBuff,1,sizeof(sBuff),fp);
            fclose(fp);
            
            sprintf(sBuffAll,"0%06d%s",strlen(sBuff),sBuff);
    		Flag = nCommonMsqSend1(strlen(sBuff), sBuff, CnapsCommId,lDestSvrID);
    		if (Flag == -1)
    		{  
    			printf("nCommonMsqSend1 error AT %s", GetCurTime());
    			continue;
    		}
    		

    		rename(sOpenFile,sMvFile);
    		
    
        }
       
        closedir(dp);
		icount++;
		
		sleep(10);
	}
}
