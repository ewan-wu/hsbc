/******************************************************************************
* Soure file for EverBrightBank project on SCO UNIX                           *
*                                                                             *
* Copyright 2000, Shanghai Huateng Software System Inc.                       *
* All Rights Reserved.                                                        *
*                                                                             *
* This is UNPUBLISHED PROPRIETARY SOURCE CODE of Shanghai Huateng Software    *
* System Inc.; the contents of this file may not be disclosed to third        *
* parties, copied or  duplicated in any form, in whole or in part, without    *
* the prior written permission of Shanghai Huateng Software System Inc.       *
*                                                                             *
*******************************************************************************

*******************************************************************************
*                                                                             *
*  Name     : fromsc.c                                                        *
*  Desc     : TCP communication for XNET in program                           *
*  Author   : Zhong Bing                                                      *
*  Date     : 3/15/96                                                         *
*  Functions:                                                                 *
*  Modify By:                                                                 *
*    Name     Date     Desc                                                   *
*    Jacky    9/10/96  modify for new ErrHandle and coding style              *
*    Jakcy    12/10/96 call socket,bind repeatly if call failed first         *
*                      until success                                          *
*    Rebecca  02/10/00 Customize for EverBright Bank                          *
*  function :                                                                 *
*     accept connection                                                       *
*     read from socket                                                        *
*     write to in_queue                                                       *
*  parameter:                                                                 *
*     0   process name                                                        *
*     1   destination address #for tosnet only                                *
*     2   port number                                                         *
*                                                                             *
******************************************************************************/
#include "sctcp.h"

#define   RETRYNUM     5
int gnTimeOver = 600;			


int Creat_socket();
int Read_socket();
int Write_msg_snet();
void Quit();
char *GetCurTime();
long lMsqInId;

/*  for performance test */   long bt,et;
struct tms ttt;
char logfile[256];
int  Socket_id, Pid;
long CnapsCommId,lDestSvrID;

void HandleExit();


int main(int argc, char *argv[])
{
	int   nLen, I, J, Num,  Flag, port;
	IPCMsgDef1 ipcMsgFromXnet;
	char Buf_head[8];
	char tmpstr[4*IPC_MSG_SIZE];
	short nRet;
	long lRet;
	

	setbuf(stdout, NULL); 
	setbuf(stderr, NULL);
	
	
	if (argc != 6)
	{ 	
		
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"fromsc argument error.\n");
		exit(0);
	}

	
	lRet = GetLogName(argv[5], logfile);
	if (lRet != 0)
	{
       exit(0);
	}

	
	Pid = getpid();
	

	sigset(SIGUSR2, Quit);

	port = atol(argv[2]);
	CnapsCommId = atol(argv[3]);
	lDestSvrID = atol(argv[4]);

	/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            	"port= [%d], CnapsCommId=[%d], lDestSvrID=[%d]", 
            	port , CnapsCommId, lDestSvrID);*/
    

	lMsqInId = msgget(lDestSvrID, IPC_CREAT|MSG_FLAG);
	if ( nRet  < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"CNAPSComm MSQ INIT ERR...EXIT [%d]1",lDestSvrID);	
		exit(1);
	}
	printf("CnapsCommId[%d], lMsqInId[%d]\n",CnapsCommId,lMsqInId);

	
	while ((Socket_id = Creat_socket(port)) < 0)
		sleep(5);
	

    if (sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Info: iSIGNAL_ERROR");

	while(1)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"--------ABCserver begin to read socket--------\n");
		if ( (Num = read(Socket_id, Buf_head, 7)) <= 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"%d error time %s, errno=[%d]", Pid, GetCurTime(), errno);
			
			if ( Num == 0 ) {
				HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\n fromsc received 0 bytes" ) ;
				//�������ݷ��Ͷ�ȡ��ϣ������´�read socket
				continue;
			}
			else if ( Num < 0 ) 
				HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\n fromsc read < 0" ) ;
			if (errno != EINTR)
			Quit();
		}

		bt = times(&ttt);
		sighold(SIGUSR1);
		sighold(SIGUSR2);
		

		Buf_head[7] = '\0';
		nLen = atol(Buf_head);
		
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"nLen =[%d], Buf_head=[%s]", nLen, Buf_head);
			
		if (nLen <= 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Warning : Recv msg len = %d at %s",
				 nLen, GetCurTime());
			sigrelse(SIGUSR2);
			sigrelse(SIGUSR1);
			
			continue;
		}

		/*Num = Read_socket(Socket_id, ipcMsgFromXnet.sText, nLen);*/
		memset(tmpstr, 0, sizeof(tmpstr));
		Num = Read_socket(Socket_id, tmpstr, nLen-7);
		
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Ӧread[%d]�ֽ�,ʵ��read[%d]�ֽ�",nLen-7, Num);
		if (Num == -1) Quit();
		memset(ipcMsgFromXnet.sText, 0, sizeof(ipcMsgFromXnet.sText));
		memcpy(ipcMsgFromXnet.sText, Buf_head, 7);
		memcpy(ipcMsgFromXnet.sText + 7, tmpstr, nLen-7);
			
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Fromsc recv from XNET : len=%d\tport = %d\t%s\n ipcMsgFromXnet.sText = %s\n",
			 Num, port, GetCurTime(), ipcMsgFromXnet.sText);

		/* �ж��Ƿ������� */
		if (strncmp(ipcMsgFromXnet.sText, "0000015hsbccomm", 15) == 0)
		{
			HtLog( logfile,HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"test ok");
			sigrelse(SIGUSR2);
			sigrelse(SIGUSR1);
			
			continue;
		}
	    
	    	
		/*HtDebugString(logfile, ipcMsgFromXnet.sText, nLen, __FILE__, __LINE__);*/
		Flag = Write_msg_snet(&ipcMsgFromXnet, Num+7);
		if(Flag!=0)
		{
		}
		else
		{
		}
		et = times(&ttt);

		if (Flag == 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, "Fromsc write to BRIDGE : len = %d\n", Num);
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__, "fromsc PERFORMANCETEST ticks cost = %d at %s", 								et-bt, GetCurTime());
		}

		sigrelse(SIGUSR2);
		sigrelse(SIGUSR1);
		
	}
}

void HandleExit( )
{
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
    	"Info: fromsc comm is exits!!"); 
    exit(1);
}

int Write_msg_snet( IPCMsgDef1 *Msgp, int Len)
{
	int   i;
	

  	if ((nCommonMsqSend1(Len, (char *)Msgp->sText, 
                   CnapsCommId, lDestSvrID ) != 0))
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"msgsnd to Bridge Error[%d]", errno);
		return(-1);
	}
	return(0);
}


void Quit()
{
	close(Socket_id);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nfromsc : fromsc process(%d) exit at %s", Pid, GetCurTime());
	exit(1);
}


int Creat_socket(long Port)
{
	int   RetryTimeSap = 2;
	int   Socket_id, nRetryFlag = 0;
	struct sockaddr_in   Client;
	int   Socket_id_new;
	int on = 1;
	unsigned int Client_len= sizeof( Client);

	memset(&Client,0, sizeof(Client));
	Client.sin_port = htons(Port);
	Client.sin_family = AF_INET;
	Client.sin_addr.s_addr = inet_addr("0.0.0.0");

	while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d Error time %s", Pid, GetCurTime());
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"socket error [%d]", errno);
		if (nRetryFlag++ == RETRYNUM)
		{
			
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}
		sleep(RetryTimeSap);
	}
	RetryTimeSap = 2;
	nRetryFlag = 0;
	
	
    if (setsockopt(Socket_id, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1)
    {
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"setsockopt REUSRADDR errno = %d", errno);
        return -1;
    }

	while (bind(Socket_id, (struct sockaddr *)&Client, sizeof(Client)) < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d Error time %s", Pid, GetCurTime());
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"bind error [%d]", errno);
		if (nRetryFlag++ == RETRYNUM)
		{
			
			if ( RetryTimeSap<100) RetryTimeSap += 2;
			nRetryFlag = 0;
		}

		
		sleep(30);
	}

	listen(Socket_id, 5);
	/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nTRY to accept at port %d ... (pid = %d)\n", Port, Pid);*/

	Client_len = sizeof(Client);
	Socket_id_new = accept(Socket_id, ( struct sockaddr *)&Client, &Client_len);
	if(Socket_id_new <= 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d Error Time %s", Pid, GetCurTime());
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"accept errno[%d]", errno);
		
		close(Socket_id);
		return(-1);
	}
	close(Socket_id);
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nACCEPT at port %d from %s ok at %s",Port,inet_ntoa(Client.sin_addr), GetCurTime());
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\n accept ok!\n");
	return(Socket_id_new);
}


int Read_socket(int Socket_id, char *Buf, int Len)
{
	int   I, Num;

	I = 0;
	do {
		Num = read(Socket_id, &(Buf[I]), Len - I);
		if (Num <= 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d error time %s", Pid, GetCurTime());
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"read socket error...exit 1errno=[%d]", errno);
			return(-1);
		}
		I += Num;
		/* HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Num=[%d], i=[%d], [%s]", Num, I, Buf);*/
	} while (I < Len);

	return(Len);
}

