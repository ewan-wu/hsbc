/******************************************************************************
* Soure file for EverBrightBank project on SCO UNIX                           *
*                                                                             *
* Copyright 2000, Shanghai Huateng Software System Inc.                       *
* All Rights Reserved.                                                        *
*                                                                             *
* This is UNPUBLISHED PROPRIETARY SOURCE CODE of Shanghai Huateng Software    *
* System Inc.; the contents of this file may not be disclosed to third        *
* parties, copied or  duplicated in any form, in whole or in part, without    *
* the prior written permission of Shanghai Huateng Software System Inc.       *
*                                                                             *
*******************************************************************************

*******************************************************************************
*                                                                             *
*  Name     : tosc.c                                                          *
*  Desc     : TCP communication for XNET out program                         *
*  Author   : Zhong Bing                                                      *
*  Date     : 3/15/96                                                         *
*  Functions:                                                                 *
*  Modify By:                                                                 *
*    Name     Date     Desc                                                   *
*    Jacky    9/10/96  modify for new ErrHandle and coding style              *
*    Jakcy    12/10/96 call socket repeatly if call failed first              *
*                      until success                                          *
*    Rebecca  02/10/00 Customize for EverBright Bank                          *
*                                                                             *
*  function :                                                                 *
*     connect snet                                                            *
*     read from out_queue                                                     *
*     write to snet                                                           *
*  parameter:                                                                 *
*     0   process name                                                        *
*     1   destination address #for snetout only                               *
*     2   port number                                                         *
*                                                                             *
******************************************************************************/
#include "sctcp.h"

#define RETRYNUM  5

#define ABC_FILE_DIR "src/test/ABCsimu/ABC_FILE"

int Connect_socket();
int Write_socket();
void Quit( );
void Quit2( );
char *GetCurTime();

/*  for performance test */  long bt,et;
struct tms ttt;
char logfile[256];
int Socket_id, Pid;
long CnapsCommId,lDestSvrID;
long lMsqInId;

void HandleExit();



int main (int argc, char *argv[])
{
	int   I, J, Num, Flag, port;
	
	IPCMsgDef1 nMsgToXnet;
	short nRet;
	short nDataLen, nMsgSource;
	long lMsgSourceId;
	long lRet;
	
	char sRspBuf[4096];
	char sRspBufAll[5000];
	char sABCDir[256];
	
	memset(sRspBuf,0,sizeof(sRspBuf));
	memset(sRspBufAll,0,sizeof(sRspBufAll));

	
	int icount=0;

	setbuf(stdout, NULL); 
	setbuf(stderr, NULL);
	
	
	if (argc != 6)
	{ 
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"[%s][%s][%s][%s][%d]\n",argv[0],argv[1],argv[2],argv[3],argc);
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"tosc argument error.\n");
		exit(0);
	}
	
	lRet = GetLogName(argv[5], logfile);
	if (lRet != 0)
	{
       exit(0);
	}
	
	port = atol(argv[2]);
	
	lDestSvrID = atol(argv[3]);
	CnapsCommId = atol(argv[4]);
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
            "port= [%d], CnapsCommId=[%d],", 
            port , CnapsCommId);


	lMsqInId = msgget(CnapsCommId, IPC_CREAT|MSG_FLAG);
	if ( nRet  < 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"CNAPSComm MSQ INIT ERR...EXIT [%d]1",CnapsCommId);
		
		exit(1);
	}
	printf("CnapsCommId[%d], lMsqInId[%d]\n",CnapsCommId,lMsqInId);

	sigset(SIGUSR1, SIG_DFL);
	sigset(SIGUSR2, Quit);
	sigset(SIGPIPE, Quit2);
	sigset (SIGALRM, vCTcpSndEcho);
	
	Pid = getpid();
	
	while ((Socket_id = Connect_socket(port, argv[1])) < 0)
		sleep(5);
	
    if (sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
        HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
        "Info: iSIGNAL_ERROR");

    sprintf(sABCDir,"%s/%s",getenv("APPL"),ABC_FILE_DIR);	
	while(1)
	{
		printf("------------------------------------------------------------------------------\n");

		memset(&nMsgToXnet, 0 , sizeof(nMsgToXnet));
		
		alarm (300);
		Num = nCommonMsqRecv1(&nDataLen, nMsgToXnet.sText, 
                  &lMsgSourceId, CnapsCommId);
                   
		alarm (0);
		
		
		
		if(nDataLen == 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"Warning : read 0 bytes from msgque at %s", GetCurTime());
		   	sleep (1) ;	
			continue;
		} 
		bt = times(&ttt);
		if(Num < 0)
		{ 
			printf("nCommonMsqRecv1  error\n");
		   	sleep (1) ;	
			
			continue;
		}

		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"Tosc %d recv from SERVER : at time %s len=%d\n sendtoabc text =%s\n", Pid, GetCurTime(), nDataLen, nMsgToXnet.sText);
		sighold(SIGUSR2);

        printf("lMsgSourceId[%d]\n",lMsgSourceId);
        if(lMsgSourceId==lDestSvrID)
        {
            printf("msg from ABCserver\n");
            /*��ȡABCӦ����Ϣ*/
    	    if(getABC_RSP(nMsgToXnet.sText,sRspBuf)<0)
    	    {
    	        printf("getABC_RSP error!\n");
    	        continue;   
    	    }
        }
	    else{
	        printf("msg from ABCfileSnd\n");
            strcpy(sRspBuf,nMsgToXnet.sText);
        }
 
	    sprintf(sRspBufAll,"0%06d%s",strlen(sRspBuf),sRspBuf);
	    
		Flag = Write_socket(Socket_id, sRspBufAll, strlen(sRspBufAll));
		if (Flag == -1)
		{

			
			Flag = nCommonMsqSend1(nDataLen,  nMsgToXnet.sText, 
                   CnapsCommId, CnapsCommId );

			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"TOSC SEND MSG BACK TO MSGQ WHEN SEND TO CNAPS FAIL RET=%d AT %s", Flag, GetCurTime());
			Quit();
		}
		
		/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
				"icount=[%d]", icount);*/
				
		et = times(&ttt);
		sigrelse(SIGUSR2);
		
		/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"Tosc %d write to SC : len=%d\tport=%d\t%s", Pid, Flag, port, GetCurTime());*/
		
		
		/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
			"tosc PERFORMANCE ticks cost = %d at %s",et-bt, GetCurTime());*/
			
			
		icount++;
	}
}

void HandleExit( )
{
    HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
    	"Info: tosc comm is exits!!"); 
    exit(1);
}

void Quit()
{
	close(Socket_id);
	printf("\nTOSC PROCESS(%d) EXIT AT %s", Pid, GetCurTime());
	
	exit(1);
}

void Quit2()
{
	close(Socket_id);
	printf("\nTOSC PROCESS(%d) EXIT AT %s on SIGPIPE", Pid, GetCurTime());
	
	exit(1);
}


int Connect_socket(unsigned Port, char *Ip_addr)
{
	struct sockaddr_in   Sin;
	int   Socket_id, Flag, Error, RetryTimeSap = 2, nRetryFlag = 0;
	int iOptVal;
	int on = 1;
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,
		"\nTry to connect to %s at port %d ... (pid = %d)\n",Ip_addr, Port, Pid);

	memset(&Sin, 0, sizeof(Sin));
	Sin.sin_port = htons(Port);
	Sin.sin_family = AF_INET;
	Sin.sin_addr.s_addr = inet_addr(Ip_addr);
	while(1)
	{
		while ((Socket_id = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"socket error");
			if (nRetryFlag++ == RETRYNUM)
			{
				
				if ( RetryTimeSap<100) RetryTimeSap += 2;
				
				nRetryFlag = 0;
			}
			sleep(RetryTimeSap);
		}
		
		if (setsockopt(Socket_id, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1)
    	{
        	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"setsockopt REUSRADDR errno = %d", errno);
        	return -1;
    	}

		if (connect(Socket_id, (struct sockaddr *)&Sin, sizeof(Sin)) < 0)
		{
			close(Socket_id);
			if (errno == ECONNREFUSED)
			{
				HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nCannot connect port %d:[%d]", Port, errno);
				
				sleep(5);
				continue;
			}
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"Connect %s port %d error at %s, errno=[%d]",
				 Ip_addr, Port, GetCurTime(), errno);
			
			
			sleep( 100);
			continue;
		}
		/* set sock opt, keepalive */
		iOptVal = 1;
		if (setsockopt (Socket_id, SOL_SOCKET, SO_KEEPALIVE, 
			&iOptVal, sizeof (iOptVal)) < 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nsetsockopt failed %d.\n", errno);
			
		}
		break;
	}
	
	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"\nConnect to %s at port %d ok at %s",
		 Ip_addr, Port, GetCurTime());
	return(Socket_id);
}



int Write_socket (int Socket_id, char *Buf, int Len)
{
	int   I, Num;
	char   Buf_head[9];
	char 	pack[9000];

	if (Len == 0) return(0);
	/*sprintf(Buf_head, "%08d", Len);*/
	/*memcpy(pack, Buf_head, 8);*/
	memcpy(pack, Buf, Len);
	/*Len += 8;*/
	I = 0;
	
	HtDebugString(logfile, pack, Len, __FILE__, __LINE__);
	/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d Before write %d, %s", Pid, Len, GetCurTime());*/
	do {
		Num = write(Socket_id, &(pack[I]), Len - I);
		if (Num < 0)
		{
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d Error time %s", Pid, GetCurTime());
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"write sock error ... exit 1");
			
			return(-1);
		}
		/*HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__, __LINE__,"%d write success %d, %s", Pid, Num + I, GetCurTime());*/
		I += Num;
	} while (I < Len);
	Len -= 8;
	return(Len);
}

void vCTcpSndEcho() 			
{			
	int		lnDataL = 15;
					
	if (Write_socket(Socket_id,"0000015hsbccomm",lnDataL) == -1)		
	{		
		HtLog (logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, "send echo msg error %d", errno);	
		Quit ();	
	}		
}	
