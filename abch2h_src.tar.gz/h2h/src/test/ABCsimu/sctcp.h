#include "glb_def.h"
#include "msgque.h"
#include "htlog.h"
#include "ipc.h"
#include <sys/msg.h>
#include <stdio.h>
#include <errno.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/times.h>

#include <arpa/inet.h>

typedef struct {
    long     lMsgType;
    long     lMsgCode;
    char     sText[4*1000];
} IPCMsgDef1;

#define CHD_PROCESS_NUM 1
#define setnull(x) memset(&x,0,sizeof(x))
//int gnTimeOver = 600;			
void 	vCTcpSndEcho();

