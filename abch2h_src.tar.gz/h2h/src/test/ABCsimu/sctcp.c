/******************************************************************************
*       Source file for EverBright Bank project on SCO UNIX                   *
*                                                                             * 
*       Copyright 2000, Shanghai Huateng Software System Inc.                 *
*       All rights Reserved.                                                  *
*                                                                             * 
*      This is UNPUBLISHED PROPRIETARY SOURCE CODE of Shanghai                *
*      Huateng Software System Inc.; the contents of this file may            *
*      not be disclosed to third parties, copied or duplicated in             *
*      any form, in whole or in part, without the prior written               *
*      permission of Shanghai Huateng Software System Inc.                    *
*                                                                             * 
******************************************************************************/

/******************************************************************************
*  Name	: sctcp.c                                                             *
*  Desc	: MBPRO sytem snet communication process                              *
*  Author : guo jacky                                                         *
*  Date	: 05/04/1997                                                          *
*  Function:                                                                  *
*        1. implement TCP/IP communication with SCNET                         *
*  Location: $(TOPDIR)/comm/sccomm                                            *
*                                                                             * 
*  Modify By:                                                                 *
*  Name    Date			What                                          * 
*  ----    ----------		------------------------------                *
*  Rebecca 2000/02/10		Customize for EverBright Bank                 * 
*  paramter:                                                                  *
*     0   process name                                                        *
*     1   destinaion address                                                  *
*     2   flag # 0 = fork fromsnet first                                      *
*                1 = fork tosnet first                                        *
*     3/4   I/O port number                                                   *
*     as above                                                                *
*                                                                             *
******************************************************************************/


#include "sctcp.h"

pid_t   Child_pid[2 * CHD_PROCESS_NUM];

int Kill( void);
void Restart(int);
char *GetCurTime( void);
void HandleExit( );

void Restart( int sig)
{
	sigset(SIGCLD, SIG_IGN);
	printf("\n                         !!! =====  WARNING ===== !!!\n");
	printf("\n XNETTCP RESTART AT %s", GetCurTime());
	printf("\n THE TCP/IP CONNECTION TO MBFE WILL BE TEMPORALLY DISCONNETED " );
	Kill();
	printf("\n XNETTCP : ALL CHILD WERE KILLED, RESTART AFTER 30 SECONDS...at %s", GetCurTime());
	sleep(30);
	sigset(SIGCLD, Restart);
}

int main (int argc, char *argv[])
{
	int   Pid, I, J, K, Num, Turn, Status;
	char   *Child_name[2] = {
		"ABCserver", "ABCclient"	};

	setbuf(stdout, NULL); 
	setbuf(stderr, NULL);

	if ((argc < 5)||(argc != (CHD_PROCESS_NUM * 2 + 6)))
	{
		printf("argument error\n");
		exit(0);
	}
	if (sigset(SIGTERM, (void (*)())HandleExit) == SIG_ERR)
		printf("sigset SIGTERM error\n");
		
	sigset(SIGCLD, Restart);
	while(1)
	{
		printf("\n SCNettcp : start MBPRO's TCP for XNET at %s",
			 GetCurTime());
		for(I = 0; I < CHD_PROCESS_NUM * 2; I++)
			Child_pid[I] = -1;
		sighold(SIGCLD);
		Turn = atol(argv[2]);
		for (J = Turn, K = 0; K < 2; J = 1-J, K++)
		{
			for (I = 0; I < CHD_PROCESS_NUM; I++)
			{
				while ((Pid = fork()) < 0)
				{
					printf ( "\n fork error" ) ;
					sleep(5) ; 
				}
				Child_pid[I * 2 + K] = Pid;
				
				if (!Pid)
					execlp(Child_name[J],
						 Child_name[J], 
					     argv[1],
						 argv[3 + I * 2 + J],
						 argv[5], argv[6],argv[7],
						 (char *)0 );
			}
		}
		sigrelse(SIGCLD);
		pause();
	}  /* end while */
}

int Kill ()
{
	int   I;

	for(I = 0; I < CHD_PROCESS_NUM * 2; I++)
		if (Child_pid[I] > 0)
			kill(Child_pid[I], SIGUSR2);
	while(wait((char *)0) > 0) printf ("\n wait > 0 ") ;
}

char *GetCurTime()
{
	long tt;
	time(&tt);
	return(ctime(&tt));
}

void HandleExit( )
{
	sighold(SIGCLD);
    Kill ();
    
    printf("Info: fromsc comm is exits!!\n"); 
    exit(1);
}
