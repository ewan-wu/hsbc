#include <stdio.h>
#include <memory.h>
#include <fcntl.h>

#include "sctcp.h"

extern long lMsqInId;

/*��sInData�л�ȡ<TAG>��</TAG>֮���ֵ*/
char *getTagValue(char *sInData,char *sTagName,char *sOutValue)
{
    char sTagStart[50];
    char sTagEnd[50];
    char sValue[1024];
    char *pStart;
    char *pEnd;
    
    memset(sTagStart,0,sizeof(sTagStart));
    memset(sTagEnd,0,sizeof(sTagEnd));
    memset(sValue,0,sizeof(sValue));

    sprintf(sTagStart,"<%s>",sTagName);
    sprintf(sTagEnd,"</%s>",sTagName);

    pStart=strstr(sInData,sTagStart)+strlen(sTagStart);
    if(pStart==NULL)
    {
        printf("not find tag[%s]\n",   sTagName);
        return NULL;
    }
    pEnd=strstr(sInData,sTagEnd);
    if(pEnd==NULL)
    {
        printf("not find tag[%s]\n",   sTagName);
        return NULL;
    }
    
    if(pEnd-pStart==0)
    {
       sOutValue[0]='\0';
       return  sOutValue;    
    }
    
    memcpy(sValue,pStart,pEnd-pStart);   
    printf("sTagName[%s],sValue[%s]\n",sTagName,sValue);
    
    strcpy(sOutValue,sValue);
    return sOutValue;
}

int getABC_RSP(char *sTrans, char *sOutData)
{
	char  sPkgHead[7 + 1];	   /* ����ͷ��7λ */
	char* pInData = NULL;
	char *pStartTxnNo;          /*���׺ſ�ʼ��ַ*/
	int   iXmlType = 0;        /* XML���� */
	int   nReturn;
	char  sGetData[4096];    /* �������XML���� */
	char  sTxno[4+1]; /* �ڲ����״��� */
	char  sFunName[20];

	/* ��ʼ�� */
	memset(sPkgHead, 0, 8);
	memset(sGetData, 0, 4096);
	memset(sTxno, 0, (4+1));
	memset(sFunName,0,sizeof(sFunName));
	
	/* ����ͷ�� */
	memcpy(sPkgHead, sTrans, 7);

    /* ������ʼλ�� */
    pInData = &sTrans[7];
	printf("pInData = [%s]\n",pInData);
	/* remove space */
	RightTrim(pInData);
    
    getTagValue(pInData,"TransCode",sTxno);

 
    if(strcmp(sTxno,"1908")==0)
        Rsp1908(pInData,sOutData);
//    else if(strcmp(sTxno,"1909")==0)
//        Rsp1909(pInData,sOutData);
//    else if(strcmp(sTxno,"19a1")==0)
//        Rsp19a1(pInData,sOutData); 
//    else if(strcmp(sTxno,"19a2")==0)
//        Rsp19a2(pInData,sOutData);
//    else if(strcmp(sTxno,"19a3")==0)
//        Rsp19a3(pInData,sOutData);
    else if(strcmp(sTxno,"1908")==0||strcmp(sTxno,"19a1")==0)
       Rsp1909(pInData,sOutData); 
    else{
        printf("����Ľ�����[%s]\n",sTxno);    
        return -1;
    }
    return 0;
}


int Rsp1908(char *sInData, char *sOutData)
{
    char TransCode      [4      +1];
    char ReqSeqNo	    [30     +1];
    char ReqDate		[8      +1];
    char ReqTime		[6      +1];
    char Amt		    [17     +1];
    char DbAccNo		[35     +1];
    char DbProv		    [2      +1];
    char DbCur		    [2      +1];
    char DbLogAccNo	    [10     +1];
    char CrAccNo		[35     +1];
    char CrProv		    [2      +1];
    char CrCur		    [2      +1];
    char BookingDate	[8      +1];
    char BookingTime	[6      +1];
    char BookingFlag	[1      +1];
    char ExchangeType	[1      +1];
    char Postscript		[68     +1];
    char CustomNo		[70     +1];
    char ActInf	    	[1      +1];
    char UrgencyFlag	[1      +1];
    char OthBankFlag	[1      +1];
    char OthCenterFlag	[1      +1];
    char CrAccName		[68     +1];
    char CrBankName		[56     +1];
    char CrAddress		[70     +1];
    char DbAccName		[68     +1];
    char DbBankName		[70     +1];
    char WhyUse		    [28     +1];
    char TransId		[2      +1];
    char SpecField1		[35     +1];
    char SpecField2		[35     +1];
    char SpecField3		[35     +1];
    char SpecField4		[35     +1];

    char sRespSeqNo         [12   +1];    
    char sRespDate          [8   +1];
    char sRespTime          [6   +1];
    char sRespSource        [1   +1];
    char sRespCode          [7   +1];
    char sRespInfo          [256   +1];
    char sFileFlag          [1   +1];
    char sFee               [18   +1];
    char sAgtFee            [18   +1];
    char sRecordNum         [4   +1];
    char sFieldNum          [4   +1];
    char sRespPrvData       [2000   +1];
    char sBatchFileName     [256   +1];
    char sWaitFlag          [1   +1];

    char sTmpTime[14+1];
     
    setnull(TransCode	    );   
    setnull(ReqSeqNo	    );
    setnull(ReqDate		    );
    setnull(ReqTime		    );
    setnull(Amt		        );
    setnull(DbAccNo		    );
    setnull(DbProv		    );
    setnull(DbCur		    );
    setnull(DbLogAccNo	    );
    setnull(CrAccNo		    );
    setnull(CrProv		    );
    setnull(CrCur		    );
    setnull(BookingDate		);
    setnull(BookingTime		);
    setnull(BookingFlag		);
    setnull(ExchangeType	);
    setnull(Postscript		);
    setnull(CustomNo		);
    setnull(ActInf	    	);
    setnull(UrgencyFlag		);
    setnull(OthBankFlag		);
    setnull(OthCenterFlag	);
    setnull(CrAccName		);
    setnull(CrBankName		);
    setnull(CrAddress		);
    setnull(DbAccName		);
    setnull(DbBankName		);
    setnull(WhyUse		    );
    setnull(TransId		    );
    setnull(SpecField1      );
    setnull(SpecField2      );
    setnull(SpecField3      );
    setnull(SpecField4      );
    
    setnull(sRespSeqNo        ); 
    setnull(sRespDate         );
    setnull(sRespTime         );
    setnull(sRespSource       );
    setnull(sRespCode         );
    setnull(sRespInfo         );
    setnull(sFileFlag         );
    setnull(sFee              );
    setnull(sAgtFee           );
    setnull(sRecordNum        );
    setnull(sFieldNum         );
    setnull(sRespPrvData      );
    setnull(sBatchFileName    );
    setnull(sWaitFlag         );  
    

    getTagValue(sInData,"TransCode",TransCode	        );      
    getTagValue(sInData,"ReqSeqNo",ReqSeqNo	        );
    getTagValue(sInData,"ReqDate",ReqDate		    );
    getTagValue(sInData,"ReqTime",ReqTime		    );
    getTagValue(sInData,"Amt",Amt        );
    getTagValue(sInData,"DbAccNo",DbAccNo		    );
    getTagValue(sInData,"DbProv",DbProv		    );
    getTagValue(sInData,"DbCur",DbCur		        );
    getTagValue(sInData,"DbLogAccNo",DbLogAccNo	    );
    getTagValue(sInData,"CrAccNo",CrAccNo		    );
    getTagValue(sInData,"CrProv",CrProv		    );
    getTagValue(sInData,"CrCur",CrCur		        );
    getTagValue(sInData,"BookingDate",BookingDate		);
    getTagValue(sInData,"BookingTime",BookingTime		);
    getTagValue(sInData,"BookingFlag",BookingFlag		);
    getTagValue(sInData,"ExchangeType",ExchangeType	    );
    getTagValue(sInData,"Postscript",Postscript		);
    getTagValue(sInData,"CustomNo",CustomNo		    );
    getTagValue(sInData,"ActInf",ActInf	    	);
    getTagValue(sInData,"UrgencyFlag",UrgencyFlag		);
    getTagValue(sInData,"OthBankFlag",OthBankFlag		);
    getTagValue(sInData,"OthCenterFlag",OthCenterFlag	    );
    getTagValue(sInData,"CrAccName",CrAccName		    );
    getTagValue(sInData,"CrBankName",CrBankName		);
    getTagValue(sInData,"CrAddress",CrAddress		    );
    getTagValue(sInData,"DbAccName",DbAccName		    );
    getTagValue(sInData,"DbBankName",DbBankName		);
    getTagValue(sInData,"WhyUse",WhyUse		    );
    getTagValue(sInData,"TransId",TransId		    );
    getTagValue(sInData,"SpecField1",SpecField1		    );
    getTagValue(sInData,"SpecField2",SpecField2		    );
    getTagValue(sInData,"SpecField3",SpecField3		    );
    getTagValue(sInData,"SpecField4",SpecField4		    );
    
    setnull(sTmpTime);
    CommonGetCurrentTime(sTmpTime);
    memcpy(sRespDate,sTmpTime,8);
    memcpy(sRespTime,sTmpTime+8,6);
   
    getSimuId12(sRespSeqNo,"SimuId.dat");
    GetProfileString("1908","RespSource",sRespSource,1,"ABCsimu.ini");
    GetProfileString("1908","RespCode",sRespCode,7,"ABCsimu.ini");
    GetProfileString("1908","RespInfo",sRespInfo,256,"ABCsimu.ini");
    GetProfileString("1908","FileFlag",sFileFlag,1,"ABCsimu.ini");
    GetProfileString("1908","RecordNum",sRecordNum,4,"ABCsimu.ini");
    GetProfileString("1908","FieldNum",sFieldNum,4,"ABCsimu.ini");
    GetProfileString("1908","RespPrvData",sRespPrvData,2000,"ABCsimu.ini");
    GetProfileString("1908","BatchFileName",sBatchFileName,256,"ABCsimu.ini");
    GetProfileString("1908","Fee",sFee,18,"ABCsimu.ini");
    GetProfileString("1908","AgtFee",sAgtFee,18,"ABCsimu.ini");
    GetProfileString("1908","WaitFlag",sWaitFlag,1,"ABCsimu.ini");
            
    sprintf(sOutData,"<ap>\n<TransCode>%s</TransCode>\n<ReqSeqNo>%s</ReqSeqNo>\n<RespSeqNo>%s</RespSeqNo>\n<RespDate>%s<RespDate>\n<RespTime>%s<RespTime>\n<RespSource>%s</RespSource>\n<RespCode>%s</RespCode>\n<RespInfo>%s</RespInfo>\n<FileFlag>%s</FileFlag>\n<Amt>%s</Amt>\n<Fee>%s</Fee>\n<AgtFee>%s</AgtFee>\n<Cme>\n<RecordNum>%s</RecordNum>\n<FieldNum>%s</FieldNum>\n</Cme>\n<Cmp>\n<RespPrvData>%s</RespPrvData>\n<BatchFileName>%s</BatchFileName>\n<DbAccNo>%s</DbAccNo>\n<DbProv>%s</DbProv>\n<DbCur>%s</DbCur>\n<CrAccNo>%s</CrAccNo>\n<CrProv>%s</CrProv>\n<CrCur>%s</CrCur>\n</Cmp>\n<Corp>\n<WaitFlag>%s</WaitFlag>\n<DbAccName>%s</DbAccName>\n<CrAccName>%s</CrAccName>\n</Corp>\n</ap>\n",
        TransCode,
        ReqSeqNo,
        sRespSeqNo,
        sRespDate,
        sRespTime,
        sRespSource,
        sRespCode,
        sRespInfo,
        sFileFlag,
        Amt,
        sFee,
        sAgtFee,
        sRecordNum,
        sFieldNum,
        sRespPrvData,
        sBatchFileName,
        DbAccNo,
        DbProv,
        DbCur,
        CrAccNo,
        CrProv,
        CrCur,
        sWaitFlag,
        DbAccName,
        CrAccName);
        
    return 0;    
}




#if 0
TransCode	    
ReqSeqNo	    
ReqDate		    
ReqTime		    
Amt		        
DbAccNo		    
DbProv		    
DbCur		    
DbLogAccNo	    
CrAccNo		    
CrProv		    
CrCur		    
BookingDate		
BookingTime		
BookingFlag		
ExchangeType	
Postscript		
CustomNo		
ActInf	    	
UrgencyFlag		
OthBankFlag		
OthCenterFlag	
CrAccName		
CrBankName		
CrAddress		
DbAccName		
DbBankName		
WhyUse		    
TransId		    
SpecField1		
SpecField2		
SpecField3		
SpecField4		
#endif



int Rsp1909(char *sInData, char *sOutData)
{
    char TransCode      [4      +1];
    char ReqSeqNo	    [30     +1];

    char sRespSeqNo         [12   +1];    
    char sRespDate          [8   +1];
    char sRespTime          [6   +1];
    char sRespSource        [1   +1];
    char sRespCode          [7   +1];
    char sRespInfo          [256   +1];
    char sFileFlag          [1   +1];
    //char sFee               [18   +1];
    //char sAgtFee            [18   +1];
    char sRecordNum         [4   +1];
    char sFieldNum          [4   +1];
    char sRespPrvData       [2000   +1];
    char sBatchFileName     [256   +1];
    char sWaitFlag          [1   +1];

    char sTmpTime[14+1];

   
    setnull(TransCode	    );   
    setnull(ReqSeqNo	    );
    
    setnull(sRespSeqNo        ); 
    setnull(sRespDate         );
    setnull(sRespTime         );
    setnull(sRespSource       );
    setnull(sRespCode         );
    setnull(sRespInfo         );
    setnull(sFileFlag         );
    //setnull(sFee              );
    //setnull(sAgtFee           );
    setnull(sRecordNum        );
    setnull(sFieldNum         );
    setnull(sRespPrvData      );
    setnull(sBatchFileName    );
    setnull(sWaitFlag         );  
    

    getTagValue(sInData,"TransCode",TransCode	        );      
    getTagValue(sInData,"ReqSeqNo",ReqSeqNo	        );

    setnull(sTmpTime);
    CommonGetCurrentTime(sTmpTime);
    memcpy(sRespDate,sTmpTime,8);
    memcpy(sRespTime,sTmpTime+8,6);
     
    getSimuId12(sRespSeqNo,"SimuId.dat");
    GetProfileString("1909","RespSource",sRespSource,1,"ABCsimu.ini");
    GetProfileString("1909","RespCode",sRespCode,7,"ABCsimu.ini");
    GetProfileString("1909","RespInfo",sRespInfo,256,"ABCsimu.ini");
    GetProfileString("1909","FileFlag",sFileFlag,1,"ABCsimu.ini");
    GetProfileString("1909","RecordNum",sRecordNum,4,"ABCsimu.ini");
    GetProfileString("1909","FieldNum",sFieldNum,4,"ABCsimu.ini");
    GetProfileString("1909","RespPrvData",sRespPrvData,2000,"ABCsimu.ini");
    GetProfileString("1909","BatchFileName",sBatchFileName,256,"ABCsimu.ini");
    //GetProfileString("1909","Fee",sFee,18,"ABCsimu.ini");
    //GetProfileString("1909","AgtFee",sAgtFee,18,"ABCsimu.ini");
    //GetProfileString("1909","WaitFlag",sWaitFlag,1,"ABCsimu.ini");
            
    sprintf(sOutData,"<ap>\n<TransCode>%s</TransCode>\n<ReqSeqNo>%s</ReqSeqNo>\n<RespSeqNo>%s</RespSeqNo>\n<RespDate>%s<RespDate>\n<RespTime>%s<RespTime>\n<RespSource>%s</RespSource>\n<RespCode>%s</RespCode>\n<RespInfo>%s</RespInfo>\n<FileFlag>%s</FileFlag>\n<Cme>\n<RecordNum>%s</RecordNum>\n<FieldNum>%s</FieldNum>\n</Cme>\n<Cmp>\n<RespPrvData>%s</RespPrvData>\n<BatchFileName>%s</BatchFileName>\n</Cmp>\n</ap>\n",
        TransCode,
        ReqSeqNo,
        sRespSeqNo,
        sRespDate,
        sRespTime,
        sRespSource,
        sRespCode,
        sRespInfo,
        sFileFlag,
        sRecordNum,
        sFieldNum,
        sRespPrvData,
        sBatchFileName);
        
    return 0;    
}



int getSimuId12(char *sOutBuff,char *sFileName)
{
    char sDate[8+1];
    char sId6[6+1];
    int nRet;
    FILE *fp;
    
    memset(sDate,0,sizeof(sDate));
    memset(sId6,0,sizeof(sId6));
    
    fp=fopen(sFileName,"r+");
    if(fp==NULL)
    {
        printf("file[%s] not exist!\n",sFileName);
        return -1;   
    }    
    
    fread(sId6,6,1,fp);
    CommonGetCurrentDate(sDate);
    
    sprintf(sOutBuff,"%s%s",sDate+2,sId6);
    
    fseek(fp,0,SEEK_SET);
    nRet=atoi(sId6)+1;
    sprintf(sId6,"%06d",nRet);
    fwrite(sId6,6,1,fp);
    fclose(fp);
    
    return 0;
}


short nCommonMsqRecv1(short *nDataLen, char *psData, 
                   long *lMsgSourceId, long lSrvId)
{
    int i;
    IPCMsgDef1 tIPCMsg;
    long lRet;
    
	//printf("nCommonMsqRecv1,lSrvId[%d],lMsqInId[%d]\n",lSrvId,lMsqInId);

    lRet = msgrcv ( lMsqInId, 
                 	&tIPCMsg,
                 	sizeof(tIPCMsg) - sizeof(long),
                 	lSrvId,
                 	MSG_NOERROR);

    if (lRet == -1)
    {
       return -1;
    }    	
    else
    {
        *lMsgSourceId = tIPCMsg.lMsgCode;
        *nDataLen = lRet - sizeof(long);
        memcpy(&psData[0], tIPCMsg.sText, *nDataLen);
        return 0;
    }
}


short nCommonMsqSend1(short nDataLen, char *psData, 
                   long lMsgSourceId, long lSrvId )
{
    IPCMsgDef1 tIPCMsg;
    long lRet;
    int i;

	//printf("nCommonMsqSend1,lSrvId[%d],lMsqInId[%d]\n",lSrvId,lMsqInId);
	
    tIPCMsg.lMsgType = lSrvId;
    tIPCMsg.lMsgCode = lMsgSourceId;
    memcpy(tIPCMsg.sText, &psData[0], nDataLen);
	
    lRet = msgsnd ( lMsqInId, 
                 	&tIPCMsg,
                 	sizeof(long) + nDataLen,
                 	0);

   	if (lRet == -1)
    {
        printf("msgsnd error !\n");
        return -1;
    }    
   	return 0;
}


