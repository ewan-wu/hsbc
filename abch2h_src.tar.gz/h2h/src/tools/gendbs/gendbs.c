/********************************************/
/* Copywrite (C)            1998.3          */
/********************************************/
/* Used by FIT for DB Server Routines       */
/* !!! For Oracle (pc file generator) !!!   */
/********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define	TYPE_CHAR			1
#define TYPE_VARCHAR		2
#define TYPE_SMALLINT  		3
#define TYPE_INTEGER		4
#define TYPE_DECIMAL		5

char	GsModule[80];
char	GsTable[80];
char	GsTableCap[80];
char	GsFile[80];
char	GsBuffer[200];
int		GiSchema;
int		GiIdx;
int		GiStart;

FILE	*fsql;
FILE	*fwd;
FILE	*fhvar;
FILE	*fdbs;

struct Schema
{
	char  	name[20];
	char	cname[20];
	char	sname[20];
	int		type;
	int		len;
};

struct Schema  GtSchema[400];
struct Schema  GtIdx[50];

void gen_wd();
void gen_hvar();
void gen_dbs();
void cap_name(char*, char*, char*);

void main(int argc, char **argv)
{
	int	i;

	if(argc != 3)
	{
		printf("Usage: %s <modulename> <tablename>\n", argv[0]);
		exit(1);
	}

	system("clear");

	printf("\n\n\n\n");
	printf("*==========================================*\n");
	printf("* DATABASE Service Routine Generation Tool *\n");
	printf("*==========================================*\n");
	printf("\n\n");
	printf("This tool needs $APPL environment variable \n");
	printf("to locate the home directory\n");
	printf("The input file '%s.sql' must resides in %s/db/createsql/%s/.\n", argv[2], getenv("APPL"), argv[1]);
	printf("And there must be table index in this file\n");
	printf("\n\n");
	printf("The result includes 3 files in current directory:\n\n");
	printf("	 [tablename]_HVAR.H	-- header file of host variables\n");
	printf("	 [modulename_tablename].wd		 -- DBS routine working structure\n");
	printf("	 dbsvr_[tablename].pc -- DBS routine source code\n");

	strcpy(GsModule, argv[1]);
	for(i = 0; i < strlen(GsTable); i ++)
		GsModule[i] = tolower(GsModule[i]);

	strcpy(GsTable, argv[2]);
	strcpy(GsTableCap, argv[2]);
	for(i = 0; i < strlen(GsTable); i ++)
	{
		GsTable[i] = tolower(GsTable[i]);
		GsTableCap[i] = toupper(GsTable[i]);
	}

	sprintf(GsFile, "%s/db/createsql/%s/%s.sql", getenv("APPL"), GsModule, GsTable);
	if((fsql=fopen(GsFile,"r")) == NULL)
	{	
		printf("Cannot find file '%s'\n", GsFile);
		exit(1);
	}

	sprintf(GsFile, "%s_%s.wd", GsModule, GsTable);
	if((fwd=fopen(GsFile,"w")) == NULL)
	{
		printf("Cannot open file '%s' to write\n", GsFile);
		exit(1);
	}

	sprintf(GsFile, "%s_HVAR.h", GsTableCap);
	if((fhvar=fopen(GsFile,"w")) == NULL)
	{
		printf("Cannot open file '%s' to write\n", GsFile);
		exit(1);
	}

	sprintf(GsFile, "dbsvr_%s.pc", GsTable);
	if((fdbs=fopen(GsFile,"w")) == NULL)
	{
		printf("Cannot open file '%s' to write\n", GsFile);
		exit(1);
	}

	memset(GtSchema, '\0', sizeof(GtSchema));
	memset(GtIdx, '\0', sizeof(GtIdx));
	GiSchema = GiIdx = 0;

	gen_wd();
	gen_hvar();
	gen_dbs();

	fclose(fwd);
	fclose(fhvar);
	fclose(fdbs);

	printf("Database Service Routine finished successfully\n\n");

	exit(0);
}


void gen_wd()
{
	char	*LpKey, *LpC1, *LpC2;
	int		i, j;

	GiStart=0;
	while(1)
	{
		memset(GsBuffer, '\0', sizeof(GsBuffer));
		if(fgets(GsBuffer, sizeof(GsBuffer), fsql) == NULL)
			break;
		for(i=0; i < strlen(GsBuffer); i ++) 
			GsBuffer[i] = tolower(GsBuffer[i]);

		LpKey = strtok(GsBuffer, ", /*()\t\n}{;");
		if(LpKey == NULL) 
			continue;

		if(strcmp(LpKey, "create") == 0)
		{
			LpC1 = strtok(NULL, ", /*()\t\n;{}");
			if (LpC1 == NULL)
				continue;
			else if(strcmp(LpC1, "table") == 0)
			{
				GiStart = 1;
				fprintf(fwd, "typedef struct TABLE_%s\n{\n",GsTableCap);
			}
			
			continue;
		}

		if(strcmp(LpKey, "primary") == 0)
		{
			LpC1=strtok(NULL,", /*()\t\n;{}");
			if(LpC1 == NULL)
				continue;

			for(GiIdx=0; LpC1 != NULL; GiIdx ++)
			{
				LpC1=strtok(NULL, ", /*()\t\n;{}");
				if (LpC1 == NULL)
					break;
				strcpy(GtIdx[GiIdx].name, LpC1);
			}

			if(GiStart)
			{
				GiStart = 0;
				fprintf(fwd, "}T_%s;\n", GsTableCap);
			}

			continue;
		}
		
		if(GiStart == 0)
			continue;

		LpC1 = strtok(NULL, ", /*()\t\n;{}");
		if (LpC1 == NULL)
			continue;

		if(strcmp(LpC1, "integer") == 0 ||
			strcmp(LpC1, "serial") == 0  ||
			strcmp(LpC1, "int") == 0 ||
			strcmp(LpC1, "smallint") == 0)
		{
			strcpy(GtSchema[GiSchema].name, LpKey);
			cap_name(GtSchema[GiSchema].name, GtSchema[GiSchema].cname, GtSchema[GiSchema].sname);
			GtSchema[GiSchema].type=TYPE_INTEGER;
			fprintf(fwd, "\tint\t\ti%s;\n", GtSchema[GiSchema].sname);
			GiSchema ++;
		}
		else if(strcmp(LpC1,"number") == 0 || strcmp(LpC1, "decimal") == 0)
		{
			int	LiNum;
			int	LiDot = 0;
		 
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 == NULL )
				continue;
			LiNum=atoi(LpC2);
		 
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if ( LpC2 != NULL )
				LiDot=atoi(LpC2);

			if(LiNum < 10 && LiDot == 0) {
		 		strcpy(GtSchema[GiSchema].name,LpKey);
				cap_name(GtSchema[GiSchema].name, GtSchema[GiSchema].cname, GtSchema[GiSchema].sname);
			 	GtSchema[GiSchema].type=TYPE_INTEGER;
				fprintf(fwd, "\tint\t\ti%s;\n", GtSchema[GiSchema].sname);
		 		GiSchema++;
			}
			else {
		 		strcpy(GtSchema[GiSchema].name,LpKey);
				cap_name(GtSchema[GiSchema].name, GtSchema[GiSchema].cname, GtSchema[GiSchema].sname);
		 		GtSchema[GiSchema].type=TYPE_DECIMAL;
				fprintf(fwd, "\tdouble\td%s;\n", GtSchema[GiSchema].sname);
		 		GiSchema++;
			}
		}
		else if(strcmp(LpC1,"char") == 0)
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if (LpC2 == NULL)
				continue;
			LiNum=atoi(LpC2);
			strcpy(GtSchema[GiSchema].name, LpKey);
			cap_name(GtSchema[GiSchema].name, GtSchema[GiSchema].cname, GtSchema[GiSchema].sname);
			GtSchema[GiSchema].type=TYPE_CHAR;
			GtSchema[GiSchema].len=LiNum;
			fprintf(fwd, "\tchar\ts%s[%d];\n", GtSchema[GiSchema].sname, LiNum+1);
			GiSchema ++;
		}
		else if((strcmp(LpC1,"varchar") == 0) ||
			(strcmp(LpC1, "varchar2") == 0))
		{
			int	LiNum;
			
			LpC2=strtok(NULL,", /*()\t\n;{}");
			if (LpC2 == NULL)
				continue;
			LiNum=atoi(LpC2);
			strcpy(GtSchema[GiSchema].name, LpKey);
			cap_name(GtSchema[GiSchema].name, GtSchema[GiSchema].cname, GtSchema[GiSchema].sname);
			GtSchema[GiSchema].type=TYPE_VARCHAR;
			GtSchema[GiSchema].len=LiNum;
			fprintf(fwd, "\tchar\ts%s[%d];\n", GtSchema[GiSchema].sname, LiNum+1);
			GiSchema ++;
		}

		continue;
	}

	for(i=0; i < GiIdx; i ++)
		for(j=0; j < GiSchema; j ++)
			if (strcmp(GtIdx[i].name, GtSchema[j].name) == 0)
			{
				strcpy(GtIdx[i].cname, GtSchema[j].cname);
				strcpy(GtIdx[i].sname, GtSchema[j].sname);
				GtIdx[i].type=GtSchema[j].type;
				GtIdx[i].len=GtSchema[j].len;
			}
}

void gen_hvar()
{
	int		i;

	fprintf(fhvar, "EXEC SQL begin declare section;\n");

	for(i = 0; i < GiSchema; i ++)
		switch(GtSchema[i].type)
		{
		case TYPE_CHAR:
			fprintf(fhvar, "\tstatic char\t\tH_%s_%s[%d];\n", GsTableCap, GtSchema[i].cname, GtSchema[i].len+1);
			break;
		case TYPE_VARCHAR:
			fprintf(fhvar, "\tstatic varchar\tH_%s_%s[%d];\n", GsTableCap, GtSchema[i].cname, GtSchema[i].len+1);
			break;
		case TYPE_INTEGER:
			fprintf(fhvar, "\tstatic int\t\tH_%s_%s;\n", GsTableCap, GtSchema[i].cname);
			break;
		case TYPE_DECIMAL:
			fprintf(fhvar, "\tstatic double\tH_%s_%s;\n", GsTableCap, GtSchema[i].cname);
			break;
		}
	
	fprintf(fhvar, "EXEC SQL end declare section;\n");
}

void gen_dbs()
{
	char	*LpKey, *LpC1;
	int		i, j;
	int		nAllKey = 0;

	fprintf(fdbs, "/*************************************/\n");
	fprintf(fdbs, "/* Copywrite (c) 2002                */\n");
	fprintf(fdbs, "/* Huateng Software System Co. Ltd.  */\n");
	fprintf(fdbs, "/*************************************/\n");
	fprintf(fdbs, "#include \"glb_def.h\"\n");
	fprintf(fdbs, "#include \"%s_wd.h\"\n", GsModule);
	fprintf(fdbs, "EXEC SQL include sqlca;\n");
	fprintf(fdbs, "EXEC SQL include sqlda;\n");
	fprintf(fdbs, "EXEC SQL include \"%s_HVAR.h\";\n", GsTableCap);
	fprintf(fdbs, "static T_%s\tsd_%s;\n", GsTableCap, GsTable);
	fprintf(fdbs, "static T_%s\tsv_%s;\n", GsTableCap, GsTable);
	fprintf(fdbs, "/*************************************************************************/\n");
	fprintf(fdbs, "/*      input : DBS_FUNC  the batch dbs func                             */\n");
	fprintf(fdbs, "/*      return : the sqlca.sqlcode                                       */\n");
	fprintf(fdbs, "/*                             DBS_FIND                                  */\n");
	fprintf(fdbs, "/*                             DBS_LOCK                                  */\n");
	fprintf(fdbs, "/*                             DBS_UPDATE                                */\n");
	fprintf(fdbs, "/*                             DBS_INSERT                                */\n");
	fprintf(fdbs, "/*                             DBS_DELETE                                */\n");
	fprintf(fdbs, "/*                             DBS_CLOSE                                 */\n");
	fprintf(fdbs, "/*                             CUR_OPEN                                  */\n");
	fprintf(fdbs, "/*                             CUR_FETCH                                 */\n");
	fprintf(fdbs, "/*                             CUR_CLOSE                                 */\n");
	fprintf(fdbs, "/*************************************************************************/\n");
	fprintf(fdbs, "Dbs%shv2wd()\n{\n", GsTableCap);	
	
	for(i=0;i<GiSchema;i ++)
	{
		switch(GtSchema[i].type)
		{
		case TYPE_INTEGER:
		case TYPE_SMALLINT:
			fprintf(fdbs, "\tsd_%s.i%s = H_%s_%s;\n", GsTable, GtSchema[i].sname, GsTableCap, GtSchema[i].cname);
			break;
		case TYPE_DECIMAL:
			fprintf(fdbs, "\tsd_%s.d%s = H_%s_%s;\n", GsTable, GtSchema[i].sname, GsTableCap, GtSchema[i].cname);
			break;
		case TYPE_CHAR:
			fprintf(fdbs, "\tvar2str(H_%s_%s, sd_%s.s%s);\n", GsTableCap, GtSchema[i].cname, GsTable, GtSchema[i].sname);
			break;
		case TYPE_VARCHAR:
			fprintf(fdbs, "\tvar2str_V(H_%s_%s, sd_%s.s%s);\n", GsTableCap, GtSchema[i].cname, GsTable, GtSchema[i].sname);
			break;
		}
	}
	fprintf(fdbs, "}\n\n");

	fprintf(fdbs, "Dbs%swd2hv()\n{\n", GsTableCap);	
	
	for(i=0; i<GiSchema; i ++)
	{
		switch(GtSchema[i].type)
		{
		case TYPE_INTEGER:
		case TYPE_SMALLINT:
			fprintf(fdbs, "\tH_%s_%s = sd_%s.i%s;\n", GsTableCap, GtSchema[i].cname, GsTable, GtSchema[i].sname);
			break;
		case TYPE_DECIMAL:
			fprintf(fdbs, "\tH_%s_%s = sd_%s.d%s;\n", GsTableCap, GtSchema[i].cname, GsTable, GtSchema[i].sname);
			break;
		case TYPE_CHAR:
			fprintf(fdbs, "\tstr2var(sd_%s.s%s, H_%s_%s);\n", GsTable, GtSchema[i].sname, GsTableCap, GtSchema[i].cname);
			break;
		case TYPE_VARCHAR:
			fprintf(fdbs, "\tstr2var_V(sd_%s.s%s, H_%s_%s);\n", GsTable, GtSchema[i].sname, GsTableCap, GtSchema[i].cname);
			break;
		}
	}
	fprintf(fdbs, "}\n\n");

	fprintf(fdbs, "Dbs%s(int ifunc, T_%s *LtpWd%s)\n", GsTableCap, GsTableCap, GsTableCap);
	fprintf(fdbs, "{\n");
	fprintf(fdbs, "\tsqlca.sqlcode = 0;\n");
	fprintf(fdbs, "\tmemcpy(&sd_%s , LtpWd%s ,sizeof(sd_%s));\n",GsTable,GsTableCap,GsTable);
	fprintf(fdbs, "\tDbs%swd2hv();\n",GsTableCap);
	fprintf(fdbs, "\tswitch(ifunc) \n\t{\n");
	fprintf(fdbs, "\tcase DBS_FIND : \n");
	fprintf(fdbs, "\t\tEXEC SQL select * into \n");
	for(i=0; i<GiSchema; i ++)
		if(i == GiSchema-1)
			fprintf(fdbs, "\t\t\t:H_%s_%s\n", GsTableCap, GtSchema[i].cname);
		else
			fprintf(fdbs, "\t\t\t:H_%s_%s,\n", GsTableCap, GtSchema[i].cname);

	fprintf(fdbs, "\t\tfrom %s\n", GsTable);
	fprintf(fdbs, "\t\twhere\n");
	for(i=0; i<GiIdx; i ++)
	{
		if(i == GiIdx -1)
			fprintf(fdbs, "\t\t\t%s = :H_%s_%s;\n", GtIdx[i].cname, GsTableCap, GtIdx[i].cname);	
		else
			fprintf(fdbs, "\t\t\t%s = :H_%s_%s and\n", GtIdx[i].cname, GsTableCap, GtIdx[i].cname);	
	}
 
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\t\tDbs%shv2wd();\n", GsTableCap);
	fprintf(fdbs, "\t\tmemcpy(LtpWd%s, &sd_%s, sizeof(sd_%s));\n", GsTableCap, GsTable, GsTable);
	fprintf(fdbs, "\t\treturn(0);\n");

	/*** LOCK UPDATE DELETE ***/
	fprintf(fdbs, "\tcase DBS_LOCK   :\n");
	fprintf(fdbs, "\tcase DBS_UPDATE :\n");
	fprintf(fdbs, "\tcase DBS_DELETE :\n");
	fprintf(fdbs, "\tif (ifunc == DBS_LOCK)\n");
	fprintf(fdbs, "\t{\n");

	fprintf(fdbs, "\t\tif (\n");
	for(i=0; i<GiIdx; i ++)
	{
		switch(GtIdx[i].type)
		{
		case TYPE_INTEGER:
		case TYPE_SMALLINT:
			if (i == GiIdx-1)
				fprintf(fdbs,"\t\t\tsv_%s.i%s == sd_%s.i%s\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs,"\t\t\tsv_%s.i%s == sd_%s.i%s &&\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		case TYPE_DECIMAL:
			if (i == GiIdx-1)
				fprintf(fdbs,"\t\t\tsv_%s.d%s == sd_%s.d%s\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs,"\t\t\tsv_%s.d%s == sd_%s.d%s &&\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		case TYPE_CHAR:
		case TYPE_VARCHAR:
			if (i == GiIdx-1)
				fprintf(fdbs,"\t\tstrcmp(sv_%s.s%s , sd_%s.s%s) == 0 \n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs,"\t\tstrcmp(sv_%s.s%s , sd_%s.s%s) == 0 &&\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		}
	}
	fprintf(fdbs, "\t\t)\n");
	fprintf(fdbs, "\t\t{\n");
	fprintf(fdbs, "\t\t\tmemcpy(LtpWd%s , &sv_%s , sizeof(sv_%s));\n", GsTableCap, GsTable, GsTable);
	fprintf(fdbs, "\t\t\treturn(0);\n");
	fprintf(fdbs, "\t\t}\n");

	fprintf(fdbs, "\t\tEXEC SQL declare %s_cur cursor for select\n", GsTable);
	for(i=0; i<GiSchema; i ++)
		if(i == GiSchema-1)
			fprintf(fdbs,"\t\t\t%s\n", GtSchema[i].cname);
		else
			fprintf(fdbs,"\t\t\t%s,\n", GtSchema[i].cname);
	fprintf(fdbs, "\t\tfrom %s\n", GsTable);
	fprintf(fdbs, "\t\twhere\n");
	for(i=0; i<GiIdx; i ++)
		if (i == GiIdx -1)
			fprintf(fdbs, "\t\t\t%s = :H_%s_%s for update;\n", GtIdx[i].cname, GsTableCap, GtIdx[i].cname);
		else
			fprintf(fdbs, "\t\t\t%s = :H_%s_%s and\n", GtIdx[i].cname, GsTableCap, GtIdx[i].cname);
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\t\tEXEC SQL open %s_cur;\n",GsTable);
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\t\tEXEC SQL fetch %s_cur into\n", GsTable, GsTableCap);
	for(i = 0; i<GiSchema; i ++)
		if (i == GiSchema-1)
			fprintf(fdbs,"\t\t\t:H_%s_%s;\n", GsTableCap, GtSchema[i].cname);
		else
			fprintf(fdbs,"\t\t\t:H_%s_%s,\n", GsTableCap, GtSchema[i].cname);
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405)) {\n");
	fprintf(fdbs, "\t\t\tmemset(&sv_%s, 0, sizeof(sv_%s));\n", GsTable, GsTable );
	fprintf(fdbs, "\t\t\treturn(sqlca.sqlcode);}\n");
	fprintf(fdbs, "\t\tDbs%shv2wd();\n", GsTableCap);
	fprintf(fdbs, "\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n", GsTableCap, GsTable, GsTable);
	fprintf(fdbs, "\t\tmemcpy(&sv_%s, &sd_%s, sizeof(sv_%s));\n", GsTable, GsTable, GsTable);
	fprintf(fdbs, "\t\treturn(0);\n");
	fprintf(fdbs, "\t}\n\telse\n\t{\n");
	fprintf(fdbs, "\t\tif(\n");
	for(i = 0; i<GiIdx; i ++)
		switch(GtIdx[i].type)
		{
		case TYPE_INTEGER:
		case TYPE_SMALLINT:
			if (i == GiIdx-1)
				fprintf(fdbs, "\t\t\tsv_%s.i%s != sd_%s.i%s\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs, "\t\t\tsv_%s.i%s != sd_%s.i%s ||\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		case TYPE_DECIMAL:
			if (i == GiIdx-1)
				fprintf(fdbs,"\t\t\tsv_%s.d%s != sd_%s.d%s\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs,"\t\t\tsv_%s.d%s != sd_%s.d%s ||\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		default :
			if (i == GiIdx-1)
				fprintf(fdbs,"\t\tstrcmp(sv_%s.s%s , sd_%s.s%s) != 0\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			else
				fprintf(fdbs,"\t\tstrcmp(sv_%s.s%s , sd_%s.s%s) != 0 ||\n", GsTable, GtIdx[i].sname, GsTable, GtIdx[i].sname);
			break;
		}
	fprintf(fdbs, "\t\t)\n\t\treturn(544);\n");

	fprintf(fdbs, "\t\tif (ifunc == DBS_UPDATE)\n\t\t{\n");
	for(i = 0; i<GiSchema; i ++)
	{
		int		LiKey;

		LiKey = 0;
		for(j = 0; j < GiIdx; j ++) 
			if(strcmp(GtIdx[j].name, GtSchema[i].name) == 0)
			{
				LiKey = 1;
				break;
			}

		if(LiKey)
			continue;

		if ( nAllKey == 0 )
		{
			fprintf(fdbs, "\t\tEXEC SQL update %s set \n", GsTable);
			nAllKey = 1;
			fprintf(fdbs, "\t\t\t%s = :H_%s_%s", GtSchema[i].cname, GsTableCap, GtSchema[i].cname);
		}
		else
		{
			fprintf(fdbs, ",\n\t\t\t%s = :H_%s_%s", GtSchema[i].cname, GsTableCap, GtSchema[i].cname);
		}
	}
	fprintf(fdbs, "\n");
	if ( nAllKey == 1 )
	{
		fprintf(fdbs, "\t\twhere current of %s_cur;\n", GsTable);
		fprintf(fdbs, "\t\tmemcpy(&sv_%s, &sd_%s, sizeof(sv_%s));\n", GsTable, GsTable, GsTable);
		fprintf(fdbs, "\t\treturn(sqlca.sqlcode);\n");
	}
	else
		fprintf(fdbs, "\t\treturn(545);\n");

	fprintf(fdbs, "\t\t}\n\t\telse\n\t\t{\n");
	fprintf(fdbs, "\t\tEXEC SQL delete from %s where current of %s_cur ;\n", GsTable, GsTable);
	fprintf(fdbs, "\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\t\t}\n");
	fprintf(fdbs, "\t}\n");

	/*** INSERT ***/
	fprintf(fdbs, "\tcase DBS_INSERT :\n");
	fprintf(fdbs, "\t\tEXEC SQL insert into %s values (\n", GsTable);
	for(i = 0; i<GiSchema; i ++)
		if (i == GiSchema-1)
			fprintf(fdbs,"\t\t:H_%s_%s);\n", GsTableCap, GtSchema[i].cname);
		else
			fprintf(fdbs,"\t\t:H_%s_%s,\n", GsTableCap, GtSchema[i].cname);
	fprintf(fdbs, "\t\treturn(sqlca.sqlcode);\n");

	fprintf(fdbs, "\tcase DBS_CLOSE :\n");
	fprintf(fdbs, "\t\tEXEC SQL close %s_cur;\n", GsTable);
	/*
	fprintf(fdbs, "\t\tEXEC SQL free %s_cur;\n", GsTable);
	*/
	fprintf(fdbs, "\t\tmemset(&sv_%s, '\\", GsTable);
	fprintf(fdbs, "0', sizeof(sv_%s));\n", GsTable);
	fprintf(fdbs, "\t\treturn(0);\n");
	fprintf(fdbs, "\tcase CUR_OPEN   :\n");
	/*
	fprintf(fdbs, "\t\tEXEC SQL declare cur_%s cursor with hold for select\n", GsTable);
	*/
	fprintf(fdbs, "\t\tEXEC SQL declare cur_%s cursor for select\n", GsTable);
	for(i=0; i<GiSchema; i ++)
		if(i == GiSchema-1)
			fprintf(fdbs, "\t\t\t%s\n", GtSchema[i].cname);
		else
			fprintf(fdbs, "\t\t\t%s,\n", GtSchema[i].cname);
	fprintf(fdbs, "\t\tfrom %s\n", GsTable);
	fprintf(fdbs, "\t\twhere");
	fprintf(fdbs, " %s = :H_%s_%s\n", GtSchema[0].cname, GsTableCap, GtSchema[0].cname);
	for(i=1; i<GiSchema; i ++)
		fprintf(fdbs, "\t\t\tand %s = :H_%s_%s\n", GtSchema[i].cname, GsTableCap, GtSchema[i].cname);
	fprintf(fdbs, "\t\torder by \n");
	for(i=0; i<GiIdx; i ++)
		if(i == GiIdx-1)
			fprintf(fdbs, "\t\t\t%s;\n", GtIdx[i].cname);
		else
			fprintf(fdbs, "\t\t\t%s,\n", GtIdx[i].cname);
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n");
	fprintf(fdbs, "\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\tEXEC SQL open cur_%s;\n", GsTable);
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n");
	fprintf(fdbs, "\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\treturn(0);\n");
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\tcase CUR_FETCH :\n");
	fprintf(fdbs, "\t\tEXEC SQL fetch cur_%s into\n", GsTable);
	for(i=0; i<GiSchema; i ++)
		if(i == GiSchema-1)
			fprintf(fdbs, "\t\t\t:H_%s_%s;\n", GsTableCap, GtSchema[i].cname);
		else
			fprintf(fdbs, "\t\t\t:H_%s_%s,\n", GsTableCap, GtSchema[i].cname);
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != -1405))\n");
	fprintf(fdbs, "\t\t\treturn(sqlca.sqlcode);\n");
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\tDbs%shv2wd();\n", GsTableCap);
	fprintf(fdbs, "\t\tmemcpy(LtpWd%s , &sd_%s , sizeof(sd_%s));\n", GsTableCap, GsTable, GsTable);
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\treturn(0);\n");
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\tcase CUR_CLOSE :\n");
	fprintf(fdbs, "\t\tEXEC SQL close cur_%s;\n", GsTable);
	/*
	fprintf(fdbs, "\t\tEXEC SQL free cur_%s;\n", GsTable);
	*/
	fprintf(fdbs, "\n");
	fprintf(fdbs, "\t\treturn(0);\n");
	fprintf(fdbs, "\tdefault :  return(543);\n");
	fprintf(fdbs, "\t}\n");
	fprintf(fdbs, "}\n");
}

void cap_name(char *iBuf, char *cBuf, char *sBuf)
{
	char	string[20];
	char	*ptr;
	int		i;
	
	for(i = 0; i < strlen(iBuf); i ++)
		*(cBuf+i) = toupper(*(iBuf+i));
		
	sBuf[0] = '\0';
	strcpy(string, iBuf);
	ptr = strtok(string, "_");
	while(ptr != NULL)
	{
		*ptr = toupper(*ptr);
		strcat(sBuf, ptr);
		ptr = strtok(NULL, "_");
	}
}
