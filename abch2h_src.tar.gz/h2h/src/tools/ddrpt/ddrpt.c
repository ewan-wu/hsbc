#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "genrpt.h"

char LineBuf[300];
char DataBuf[10240];
int fGenPrompt=0;
rpt_cntl_def RptCntl;

int InitSection( FILE *fp, rpt_cntl_def *pRptCntl );
int BodySection( FILE *fp, rpt_cntl_def *pRptCntl, int *pbFirstDataBlock );
int SimpleDataSection( FILE *fp, rpt_cntl_def *pRptCntl, int Command );
int explainToken( char *inst );

int ScanNextToken( FILE *f )
{
	while( ! feof(f) )
	{
		if ( fgets( LineBuf, sizeof(LineBuf), f ) != NULL )
		{
			if ( LineBuf[0]=='#' ) return explainToken( LineBuf );
		}
		else
		{
			if ( !feof(f) )
			{
				fprintf( stderr, "201: Read data file fail!\n" );
				return FAIL;
			}
		}
	}
	return RPT_CLOSE;
}

int explainToken( char *inst )
{
	char st[100],*p ;
	if ( strlen(inst) < 2 ) return FAIL;
	strncpy(st, &inst[1], 100 );
	p = strtok( st, " \t\n" );
	Capstr( p );
	if ( p == NULL ) return FAIL;
	if ( strcmp( p, "REPORT" ) == 0 )
		return RPT_INIT;
	if ( strcmp( p, "TITLE" ) == 0 )
		return RPT_TITLE;
	if ( strcmp( p, "HEAD" ) == 0 )
		return RPT_HEAD;
	if ( strcmp( p, "BODY" ) == 0 )
		return RPT_BODY;
	if ( strcmp( p, "STARTBODY" ) == 0 )
		return RPT_START_BODY;
	if ( strcmp( p, "TAIL" ) == 0 )
		return RPT_TAIL;
	if ( strcmp( p, "SUMMARY" ) == 0 )
		return RPT_SUMMARY;
	if ( strcmp( p, "PREHEAD" ) == 0 )
		return RPT_PRE_HEAD;
	if ( strcmp( p, "PRETAIL" ) == 0 )
		return RPT_PRE_TAIL;
	if ( strcmp( p, "PRESUMMARY" ) == 0 )
		return RPT_PRE_SUMMARY;
	fprintf( stderr, "202: Unknown Section %s\n", p );
	return FAIL;
}

short bTitlePrinted, bHeadPrinted, bTailPrinted, bSummaryPrinted;

int CheckPrintTitle( rpt_cntl_def *pRptCntl )
{
	if ( ! bTitlePrinted )
	{
		CmRpt( pRptCntl, RPT_TITLE, "" );
		bTitlePrinted = TRUE;
	}
	return SUCCESS;
}

int CheckPrintHead( rpt_cntl_def *pRptCntl )
{
	if ( ! bHeadPrinted )
	{
		if ( CheckPrintTitle( pRptCntl ) == FAIL )
			return FAIL;
		CmRpt( pRptCntl, RPT_HEAD, "" );
		bHeadPrinted = TRUE;
	}  
	return SUCCESS;
}

int CheckPrintTail( rpt_cntl_def *pRptCntl )
{
	if ( ! bTailPrinted )
	{
		if ( CheckPrintHead( pRptCntl ) == FAIL )
			return FAIL;
		CmRpt( pRptCntl, RPT_TAIL, "" );
		bTailPrinted = TRUE;
	}  
	return SUCCESS;
}

int CheckPrintSummary( rpt_cntl_def *pRptCntl )
{
	if ( ! bSummaryPrinted )
	{
		if ( CheckPrintTail( pRptCntl ) == FAIL )
			return FAIL;
		CmRpt( pRptCntl, RPT_SUMMARY, "" );
		bSummaryPrinted = TRUE;
	}
	return SUCCESS;
}

int bHeadPrepared, bTailPrepared, bSummaryPrepared;

int main( int argc, char *argv[] )
{
	int nextSection, bTablePrinting;

	int bFirstDataBlock,i;
	FILE *DataFp;
	bTablePrinting = FALSE;
	DataFp = NULL;
	for ( i=1; i<argc; i++ )
	{
		if ( argv[i][0] != '-' )
		{
			if ( DataFp != NULL )
			{
				fprintf( stderr, "Error: to many files given!\n" );
				exit(1);
			}
			if ( NULL == (DataFp = fopen( argv[i], "r" ) ) )
			{
				fprintf( stderr, "Error: Can't open file %s!\n", argv[i] );
				exit(1);
			}
		}
		else
			switch ( argv[i][1] )
			{
				case 'i':
					fGenPrompt = 1;
					break; 
				default:
					fprintf( stderr, "Error: Unknown parameter %s!\n", argv[i] );
					exit(1);
			}
	}
	if ( DataFp == NULL ) DataFp = stdin;
	nextSection = ScanNextToken(DataFp);
	while ( ! feof( DataFp ) && nextSection != FAIL && nextSection != RPT_CLOSE )
	{
		switch ( nextSection )
		{
		case RPT_INIT:
			if ( bTablePrinting )
			{
			/* New table data have begin, check to output unprinted sections & close */
				if ( CheckPrintSummary(&RptCntl ) == FAIL )
				{
					nextSection = FAIL;
					break;
				}
				if ( CmRpt( &RptCntl, RPT_CLOSE ) == FAIL )
				{
					nextSection = FAIL;
					break;
				}
				fprintf( RptCntl.RptFp, "\f\n" );
			}
			if ( ( nextSection = InitSection( DataFp, &RptCntl )) == FAIL ) break;
			bTablePrinting = bFirstDataBlock = TRUE;
			bTitlePrinted = bHeadPrinted = bTailPrinted = bSummaryPrinted = FALSE;
			bHeadPrepared = bTailPrepared = FALSE;
			break;
		case RPT_TITLE:
			if ( ! bTablePrinting )
			{
				nextSection = FAIL;
				break;
			}
			nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_TITLE );
			bTitlePrinted = TRUE;
			bHeadPrinted = bTailPrinted = bSummaryPrinted = FALSE;
			break;
		case RPT_HEAD:
			if ( ! bTablePrinting )
			{
				nextSection = FAIL;
				break;
			}
			if ( CheckPrintTitle( &RptCntl ) == FAIL )
			{
				nextSection = FAIL;
				break;
			}   
			if ( !bHeadPrepared )
				nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_HEAD );
			else 
			{
				nextSection = ScanNextToken(DataFp);
				if ( CmRpt( &RptCntl, RPT_HEAD, "" ) == FAIL )
					nextSection = FAIL;
			}
			bHeadPrinted = TRUE;
			bTailPrinted = bSummaryPrinted = FALSE;
			break;   
		case RPT_TAIL:
			if ( ! bTablePrinting )
			{
				nextSection = FAIL;
				break;
			}
			if ( CheckPrintHead( &RptCntl ) == FAIL )
			{
				nextSection = FAIL;
				break;
			}
			if ( ! bTailPrepared )
				nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_TAIL );
			else 
			{
				nextSection = ScanNextToken(DataFp);
				if ( CmRpt( &RptCntl, RPT_TAIL, "" ) == FAIL )
					nextSection = FAIL;
			}
			bTailPrinted = TRUE;
			bSummaryPrinted = FALSE;
			break;
		case RPT_SUMMARY:
			if ( ! bTablePrinting )
			{
				nextSection = FAIL;
				break;
			}
			if ( CheckPrintTail( &RptCntl ) == FAIL )
			{
				nextSection = FAIL;
				break;
			}
			if ( ! bSummaryPrepared )
				nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_SUMMARY );
			else
			{
				nextSection = ScanNextToken(DataFp);
				if ( CmRpt( &RptCntl, RPT_SUMMARY, "" ) == FAIL )
					nextSection = FAIL;
			}
			bSummaryPrinted = TRUE;
			break;
		case RPT_BODY:
		case RPT_START_BODY:
			if ( ! bTablePrinting )
			{
				nextSection = FAIL;
				break;
			}
			if ( CheckPrintHead( &RptCntl ) == FAIL )
			{
				nextSection = FAIL;
				break;
			}
			if ( nextSection == RPT_START_BODY )
				bFirstDataBlock = TRUE;
			nextSection = BodySection( DataFp, &RptCntl, &bFirstDataBlock );
			break;
		case RPT_PRE_HEAD:
			nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_PRE_HEAD );
			bHeadPrepared = TRUE;
			break;
		case RPT_PRE_TAIL:
			nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_PRE_TAIL );
			bTailPrepared = TRUE;
			break;
		case RPT_PRE_SUMMARY:
			nextSection = SimpleDataSection( DataFp, &RptCntl, RPT_PRE_SUMMARY );
			bSummaryPrepared = TRUE;
			break;
		}
	}

	if ( bTablePrinting && nextSection != FAIL )
	{
		nextSection = SUCCESS;
		/* New table data have begin, check to output unprinted sections & close */
		if ( CheckPrintSummary(&RptCntl) == FAIL )
			nextSection = FAIL;
		if ( CmRpt( &RptCntl, RPT_CLOSE ) == FAIL )
			nextSection = FAIL;
	}
	return nextSection;
}

int InitSection( FILE *fp, rpt_cntl_def *pRptCntl )
{
	char *pFmtName,*pch;
	strtok(&LineBuf[1]," \t\n,");
	pFmtName = strtok(NULL," \t\n,");
	if ( CmRpt( pRptCntl, RPT_INIT, pFmtName ) == FAIL )
		return FAIL;
	while ( ( pFmtName = strtok(NULL," \t\n,")) != NULL )
	{
		if ( *pFmtName == '-' )
		{
			switch( pFmtName[1] )
			{
			case 'S':
			case 's':
				pRptCntl->rpt_flag |= RPT_FLAG_ONEPAGE ;
				break;
			case 'P':
			case 'p':
				pFmtName = strtok( NULL, " \t\n," );
				if ( pFmtName == NULL )
				{
					fprintf( stderr, "Page Length missing after -P\n" );
					return FAIL;
				}
				pRptCntl->page_length = strtol( pFmtName, &pch, 10 );
				if ( *pch != 0 || pRptCntl->page_length <= 0 )
				{
					fprintf( stderr, "Invalid page length given!\n" );
					return FAIL;
				}
				break;
			}
		}
	}
	if ( fGenPrompt ) return SimpleDataSection( fp, pRptCntl, RPT_PROMPT );
	return ScanNextToken(fp);
}

int BodySection( FILE *fp, rpt_cntl_def *pRptCntl, int *pbFirstDataBlock )
{
	int Lines;
	int bFirstLine;
	int iPrintedLines = 0;
	char *pLines;
	strtok(&LineBuf[1]," \t\n");
	pLines = strtok(NULL," \t\n");
	if ( pLines == NULL ) Lines = 2;
	else Lines = atoi( pLines );
	if ( Lines == 0 )
	{
		fprintf(stderr,"203: Invalid BODY parameter!\n" );
		return FAIL;
	}
	bFirstLine = TRUE;
	while (!feof(fp))
	{
		if ( fgets( LineBuf, sizeof(LineBuf), fp ) == NULL )
		{
			if ( !feof(fp)) {
				fprintf( stderr, "201: Read data file fail!\n" );
				return FAIL;
			}
			break;
		}
		if ( LineBuf[0] == '#' ) break;
		if ( bFirstLine )
		{
			if ( *pbFirstDataBlock )
			{
				if ( CmRpt( pRptCntl, RPT_BODY_N, Lines, LineBuf ) == FAIL )
					return FAIL;
			}
			else
			{
				if ( CmRpt( pRptCntl, RPT_BODYNEXT_N, Lines, LineBuf ) == FAIL )
					return FAIL;
			}
		}
		else
		{
			if ( CmRpt( pRptCntl, RPT_BODYLOOP, LineBuf ) == FAIL )
				return FAIL;
		}
		iPrintedLines ++;
		bFirstLine = FALSE;
		*pbFirstDataBlock = FALSE;
	}
	if ( iPrintedLines == 0 )
	{
		if ( *pbFirstDataBlock )
		{
			/* SKIP form very begin */
			pRptCntl->BodyPosition = -1;
			*pbFirstDataBlock = FALSE;
		}
		if ( CmRpt( pRptCntl, RPT_SKIPBODY_N, Lines ) == FAIL )
			return FAIL;
	}
	if ( !feof(fp) )
		return explainToken( LineBuf );
	else return RPT_CLOSE;
}

int SimpleDataSection( FILE *fp, rpt_cntl_def *pRptCntl, int Command )
{
	DataBuf[0] = 0;
	while (!feof(fp))
	{
		if ( fgets( LineBuf, sizeof(LineBuf), fp ) == NULL )
		{
			if ( !feof(fp) ) {
				fprintf( stderr, "201: Read data file fail!\n" );
				return FAIL;
			}
			break;
		}
		if ( LineBuf[0] == '#' ) break;
		strncat(DataBuf,LineBuf,sizeof(DataBuf));
	}
	if ( CmRpt( pRptCntl, Command, DataBuf ) == FAIL )
		return FAIL;
	if ( !feof(fp) )
		return explainToken( LineBuf );
	return RPT_CLOSE;
}
