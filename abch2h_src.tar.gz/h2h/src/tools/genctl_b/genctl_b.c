#include <stdio.h>
#include <stdlib.h>
#include <string.h>

main(int argc, char **argv)
{
	FILE	*fsql, *fctl;
	char	buffer[2048], table[20], sqlfile[80], ctlfile[80];
	char	*col1, *col2;
	int		i, stflg =0;

	if(argc != 2) {
		printf("Usage:%s <table name>\n", argv[0]);
		exit(1);
	}

	strcpy(table, argv[1]);

	sprintf(sqlfile, "%s/db/sql/%s.sql", getenv("APPL"), table);
	if((fsql = fopen(sqlfile, "r")) == NULL) {
		printf("open file %s error\n", sqlfile);
		exit(1);
	}

	sprintf(ctlfile, "%s/db/ctl/%s.ctl", getenv("APPL"), table);
	if((fctl = fopen(ctlfile, "w")) == NULL) {
		printf("open file %s error\n", ctlfile);
		exit(1);
	}

	while(1) {
		memset(buffer, '\0', sizeof(buffer));
		if(fgets(buffer, sizeof(buffer), fsql) == NULL)
		{
			fprintf(fctl, ")\n");
			break;
		}

		for(i = 0; i < strlen(buffer); i ++)
			buffer[i] = tolower(buffer[i]);

		col1 = strtok(buffer, ", /*()\t\n}{;");
		if(col1 == NULL)
			continue;

		if(!strcmp(col1, "create")) {
			col2 = strtok(NULL, ", /*()\t\n}{;");
			if(col2 == NULL)
				continue;

			if(!strcmp(col2, "table")) {
				fprintf(fctl, "load data\n");
				fprintf(fctl, "\tinfile '%s.txt2'\n", table);
				fprintf(fctl, "\tinto table %s append (\n", table);
			}

			continue;
		}

		if((col1[0] == '\0') || 
			(!strcmp(col1, "primary")) ||
			(!strcmp(col1, "tablespace")))
		{
			fprintf(fctl, ")\n");
			if(stflg)
				stflg = 0;
			break;
		}
		else
			if(stflg)
				fprintf(fctl, ",\n");

		col2 = strtok(NULL, ", /*()\t\n}{;");
		if(col2 == NULL)
			continue;

		if(!strcmp(col2, "integer") ||
			!strcmp(col2, "serial") ||
			!strcmp(col2, "int") ||
			!strcmp(col2, "smallint") ||
			!strcmp(col2, "decimal") ||
			!strcmp(col2, "numeric") ||
			!strcmp(col2, "number") ||
			!strcmp(col2, "money") ||
			!strcmp(col2, "char") ||
			!strcmp(col2, "varchar") ||
			!strcmp(col2, "varchar2")) {
			stflg = 1;
			fprintf(fctl, "\t%s char terminated by '|'", col1);
		}
		else
		{
			stflg = 0;
		}
	}

	fclose(fsql);
	fclose(fctl);

	exit(0);
}
