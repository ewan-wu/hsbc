/*************************************************************************/
/* Name      :    baswt                                                  */
/*************************************************************************/
#include "baswt.h"
#include "htlog.h"

char logfile[256];
char ErrorDescription[51];

void vABCProcess(char *sTrans);
void vFileProcess(void *sTrans);

void HandleExit( )
{
	DebugMemory( "Exit Handled");
}

void main(short argc, char **argv)
{
	long lReturn;
	short nRet;
	short nDataLen;
	long lMsgSource;
	CmdMsgDef ipcMsg;
	char cTime[14+1];

	atexit( HandleExit );
	setbuf( stdout, NULL );
	sigset( SIGCLD, SIG_IGN ); 
	printf( "Command Server started, pid=%d\n", getpid());   
	DebugMemory( "Start");

	/********************/
	/* Connect DataBase */
	/*******************/
	lReturn = DbConnect();
	if (lReturn != 0)
	{
		printf( "Open database return %d\n", lReturn );
		ErrReport(CI_BASWT, 
				EI_DATABASE,
				lReturn, 
		   	CI_SEVERITY_SYSERROR,
		   	ES_DB_OPEN);
		exit(1);
	}

	/*nRet = GetLogName(argv[1], logfile);
	if (nRet != 0 )
	{
		printf( "getlogname return %d\n", nRet );
		ErrReport(CI_TLRBDG,
				 	EI_PROCESS,
	     		  	0,
				  	CI_SEVERITY_SYSERROR,
					ES_PROCESS_EXIT);
		exit(1);
	}	*/

	

	/*****************************/
   	/* Initial the message queue */
	/*****************************/

	nRet = nCommonMsqAllInit(CI_BASWT);
	if (nRet != 0) 
   	{
     	printf("msqallinit retrun %d\n", nRet);  	
       	ErrReport(CI_BASWT, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
	/* HANDLE TRANSACTION */
	while(1)
	{
		/* READ MANAGE MESSAGE QUEUE */
		memset(ipcMsg.sText, 0, sizeof(ipcMsg.sText));
		nRet = nCommonMsqRecv (&nDataLen, ipcMsg.sText, &lMsgSource, CI_BASWT);
		if (nRet != 0)
 		{
 			if (errno != EINTR)
 			{
				printf( "errno[%d]\n", errno );

 				if (nCommonMsqInit(CI_BASWT) == -1)
 				{
 					ErrReport(CI_BASWT,
 						EI_MESSAGEQUEUE,
 						0,
 						CI_SEVERITY_SYSERROR,
 						ES_MSGQ_READ);
 					exit(1);
 				}
				continue;
			}
		}
		memset(cTime, 0, sizeof(cTime));
		CommonGetCurrentTime( cTime );
		
		printf( "\n===========================================\n");

		nRet = GetSysDate(gsDBTxdate);
		if (nRet != 0)
		{
   	    	ErrReport(CI_BASWT, 
   	               	EI_PROCESS, 
   	               	0,
   	               	CI_SEVERITY_TXNERROR,
   	               	"���ϵͳ�������ڳ���");
			exit(1);
		}

		printf("Time: [%14.14s]msgrcv  : source [%d]", cTime,lMsgSource);
		DebugString( ipcMsg.sText, nDataLen, __LINE__);

		switch(lMsgSource)
		{
		case CI_FILESCAN:
			vFileProcess((void *)&(ipcMsg.sText));
			break;
		case CI_BACOMMSND:
			vABCProcess(ipcMsg.sText);
			break;
		default:
			printf("Invalid message source!\n");
			break;
		}

	}  /*while(1)*/
}

/**************************************/
/* Transactions from Filescan         */
/**************************************/
void vFileProcess(void *sTrans)
{
	T_MngBufFromTlrDef	*ptMngInBuf;
	T_MngBufToTlrDef	tMngOutBuf;

	int nReturn;
	char sTxno[DLEN_TXNCD+1],Tlsrno[5];
	int nOutLen, nTcpLen;
	char sPid[9];
	int iBepsIntTxno;
	char caBepsTxno[20];
	long lTxnNo=0, lSrvId=0;
	char caError[DLEN_LDESC+1];

	ptMngInBuf = sTrans;
	memset(&tMngOutBuf, 0, sizeof(tMngOutBuf));
	memset(sTxno, 0, sizeof(sTxno));
	memcpy(sTxno, ptMngInBuf->tTitaLabel.txno, DLEN_TXNCD);
	memcpy(&TITA, &(ptMngInBuf->tTitaLabel), TITA_LABEL_LENGTH);

	memcpy(it_txcom.tbsdy, gsDBTxdate, DLEN_DATE);

	memset(caError, 0, sizeof(caError));
	
	nReturn = nNewSysClsSsn(gsTlsrno);
	if (nReturn != 0)
	{
       	ErrReport(CI_BASWT, 
               	EI_PROCESS, 
               	0, 
               	CI_SEVERITY_TXNERROR,
               	"���ϵͳ��ˮ�ų���");
		exit(1);
	}

	/*************************************************/
	/* prepare it_txcom, gwdXdtl, gwdBctl, gwdTlrctl */
	/*************************************************/
	nReturn = aSysBasicCheck();
	if (nReturn != SYS_OK)
	{
		aSysBasicCheckEnd();
		return;
	}

	printf("BASWT:vFileProcess - (External) Txno = [%s]\n", sTxno);

	switch (atoi(sTxno))
	{
		case 3101:
			/*ϵͳ�Զ������Ļ�Һʹ��������ļ�����*/
			process_3101(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3102:
			/*���ɸ�ʽ�ļ�����*/
			process_3102(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3103:
			/*ibm������������*/
			process_3103(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		default:
			printf("Invalid transaction number!\n");
			Process_MoveTotaCommon(ptMngInBuf, &tMngOutBuf);
			tMngOutBuf.tTotaLabel.msgtype = 'E';
			memcpy(tMngOutBuf.tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "�Ƿ��Ľ��״��룡");
			memcpy(tMngOutBuf.sTotaText, sError, strlen(sError));
			nOutLen = sizeof(tMngOutBuf.tTotaLabel) + strlen(sError);
			}
			break;
	}
	
	nReturn = aSysBasicUpdate();
	if (nReturn != SYS_OK)
	{
		aSysBasicCheckEnd();
		return;
	}
	
	return;
}

/**************************************/
/* ����Common������                   */
/**************************************/
int UpdateCommon(T_RespGenHead	tRespHead)
{
	aTisBaCommonInq	tTisBaCommonInq;
	aTosBaCommonInq	tTosBaCommonInq;	
	aTisBaCommonUpd	tTisBaCommonUpd;
	aTosBaCommonUpd	tTosBaCommonUpd;
	
	memset(&tTisBaCommonInq, 0, sizeof(aTisBaCommonInq));
	memset(&tTosBaCommonInq, 0, sizeof(aTosBaCommonInq));
	memset(&tTisBaCommonUpd, 0, sizeof(aTisBaCommonUpd));
	memset(&tTosBaCommonUpd, 0, sizeof(aTosBaCommonUpd));

	/* ���ݲ�ѯ */
	memcpy(tTisBaCommonInq.sReqseqno, tRespHead.tGenHead.sReqSeqNo, strlen(tRespHead.tGenHead.sReqSeqNo));
	/* ��ѯCommon�� */
	it_txcom.txrsut = TX_SUCCESS;
	aBaCommonInqProcess(&tTisBaCommonInq, &tTosBaCommonInq);
	if(it_txcom.txrsut != TX_SUCCESS)
  	{
		return -1;
  	}
	/* ��ֵ */
	memcpy(&tTisBaCommonUpd, &tTosBaCommonInq, sizeof(aTosBaCommonInq));
	memcpy(tTisBaCommonUpd.sTranscode, tRespHead.tGenHead.sTransCode, strlen(tRespHead.tGenHead.sTransCode));
	memcpy(tTisBaCommonUpd.sReqseqno, tRespHead.tGenHead.sReqSeqNo, strlen(tRespHead.tGenHead.sReqSeqNo));
	memcpy(tTisBaCommonUpd.sRespseqno, tRespHead.sRespSeqNo, strlen(tRespHead.sRespSeqNo));
	memcpy(tTisBaCommonUpd.sRespdate, tRespHead.sRespDate, strlen(tRespHead.sRespDate));
	memcpy(tTisBaCommonUpd.sResptime, tRespHead.sRespTime, strlen(tRespHead.sRespTime));
	memcpy(tTisBaCommonUpd.sRespsource, tRespHead.sRespSource, strlen(tRespHead.sRespSource));
	memcpy(tTisBaCommonUpd.sRespcode, tRespHead.sRespCode, strlen(tRespHead.sRespCode));
	memcpy(tTisBaCommonUpd.sRespinfo, tRespHead.sRespInfo, strlen(tRespHead.sRespInfo));
	memcpy(tTisBaCommonUpd.sFileflag, tRespHead.sFileFlag, strlen(tRespHead.sFileFlag));
	memcpy(tTisBaCommonUpd.sRecordnum, tRespHead.tCme.sRecordNum, strlen(tRespHead.tCme.sRecordNum));
	memcpy(tTisBaCommonUpd.sFieldnum, tRespHead.tCme.sFieldNum, strlen(tRespHead.tCme.sFieldNum));
	memcpy(tTisBaCommonUpd.sBatfilename, tRespHead.tCmp.sBatchFileName, strlen(tRespHead.tCmp.sBatchFileName));
	tTisBaCommonUpd.sCmdstat[0]= '1';
	
	/* ����Common�� */
	it_txcom.txrsut = TX_SUCCESS;
	aBaCommonUpdProcess(&tTisBaCommonUpd, &tTosBaCommonUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
  	{
		return -1;
  	}
	return 0;
}

/**************************************/
/* Transactions from BAcomm           */
/**************************************/
void vABCProcess(char *sTrans)
{
	char  sPkgHead[7 + 1];	   /* ����ͷ��7λ */
	char* pInData = NULL;
	int   iCodeLen = 0;        /* ���ĳ��� */
	int   iXmlType = 0;        /* XML���� */
	int   nReturn;
	char  sGetData[BUFSIZ];    /* �������XML���� */
	char  sTxno[DLEN_TXNCD+1]; /* �ڲ����״��� */
	T_ReqFreeFmt	tReqFreeFmt;
	T_RespExchange	tRespExchange;
	T_RespGenHead	tRespGenHead;

	/*************************************************/
	/* prepare it_txcom, gwdXdtl, gwdBctl, gwdTlrctl */
	/*************************************************/
	memcpy(it_tita.labtex.label.kinbr, "001",DLEN_BRNO);
	TITA.hcode = TX_HCODE_NORMAL;
	memcpy(it_txcom.tbsdy, gsDBTxdate, DLEN_DATE);
	nReturn = aSysBasicCheck();
	if (nReturn != SYS_OK)
	{
		aSysBasicCheckEnd();
		return;
	}
	/* ��ʼ�� */
	memset(sPkgHead, 0, 8);
	memset(sGetData, 0, BUFSIZ);
	memset(sTxno, 0, (DLEN_TXNCD+1));
	memset(&tReqFreeFmt, 0, sizeof(T_ReqFreeFmt));
	memset(&tRespExchange, 0, sizeof(T_RespExchange));
	memset(&tRespGenHead, 0, sizeof(T_RespGenHead));
	
	/* ����ͷ�� */
	memcpy(sPkgHead, sTrans, 7);
	/* ���ĳ��� */
	iCodeLen = atoi(&sPkgHead[1]);
	/* �жϱ����Ƿ���� */
	if(sPkgHead[0] == '1')
	{
		/*����
		pInData = decABCCode();*/
	}
	else
	{
		/* ������ʼλ�� */
		pInData = &sTrans[7];
	}
	printf("pInData = [%s]\n",pInData);
	/* remove space */
	cmRightTrim(pInData);
	/* ����XML���뱨�� */
	/*iXmlType = parseXML(pInData, (iCodeLen - 7), sGetData);*/
	iXmlType = parseXML(pInData, strlen(pInData), sGetData);
	
	printf("iXmlType = [%d]\n", iXmlType);
	switch(iXmlType)
	{
		case XML_TYPE_REQ_EXCHANGE:
			/* ������� */
			break;
		case XML_TYPE_RESP_EXCHANGE:
			/* ���Ӧ�� */
			memcpy(&tRespExchange, sGetData, sizeof(T_RespExchange));
			if(UpdateCommon(tRespExchange.tRespGenHead) != 0)
			{
				ERRTRACE(E_DB_COMMON_WERR, NULL);
				return;
			}
			strcpy(sTxno, "3202");
			break;
		case XML_TYPE_REQ_PAYROLL:
			/* ������������ */
			memcpy(&tRespExchange, sGetData, sizeof(T_RespExchange));
			if(UpdateCommon(tRespExchange.tRespGenHead) != 0)
			{
				ERRTRACE(E_DB_COMMON_WERR, NULL);
				return;
			}
			strcpy(sTxno, "3203");
			break;
		case XML_TYPE_REQ_FREEFMT:
			/* ABC��HSBC�������ɸ�ʽ���� */
			memcpy(&tReqFreeFmt, sGetData, sizeof(T_ReqFreeFmt));
			strcpy(sTxno, "3205");
			break;
		case XML_TYPE_REQ_ACCTDETL:
			/* ������ϸ���� */
			break;
		case XML_TYPE_RESP:
			memcpy(&tRespGenHead, sGetData, sizeof(T_RespGenHead));
			if(UpdateCommon(tRespGenHead) != 0)
			{
				ERRTRACE(E_DB_COMMON_WERR, NULL);
				return;
			}
			if(strcmp(tRespGenHead.tGenHead.sTransCode, "1909") == 0)
			{
				/* ��������Ӧ�� */
				strcpy(sTxno, "3203");
			}
			else if(strcmp(tRespGenHead.tGenHead.sTransCode, "19a1") == 0)
			{
				/* HSBC��ABC���ɸ�ʽ�ļ�Ӧ�� */
				strcpy(sTxno, "3204");
			}
			break;
		default:
			printf("�����ڸ����͵�XML����!\n");
			break;
	}
	/* ҵ���� */
	switch(atoi(sTxno))
	{
		/*case 3201:
			��ѯ�˻���ϸ�����Ӧ��
			process_3201(&tReqFreeFmt);
			break;*/
		case 3202:
			/* ���Ӧ�� */
			process_3202(&tRespExchange);
			break;
		case 3203:
			/* ��������Ӧ�� */
			process_3203(&tRespGenHead);
			break;
		case 3204:
			/* HSBC��ABC���ɸ�ʽ�ļ�Ӧ�� */
			process_3204(&tRespGenHead);
			break;
		case 3205:
			/* ABC��HSBC�������ɸ�ʽ���� */
			process_3205(&tReqFreeFmt);
			break;
		/* ������ϸӦ������Ժ����Ӵ˴� */
		default:
			printf("�����ҵ������!\n");
			break;
	}
}
