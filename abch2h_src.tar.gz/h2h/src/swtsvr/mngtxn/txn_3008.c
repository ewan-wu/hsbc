/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   3008                                                               */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ֹ��������ɸ�ʽ�ļ�                                    */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20071114       nathan jin           Initial                        */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3008_GROUP
{
	char	filename[80];
	char  	filetype[DLEN_FILETYPE];
	char	postscript[70];
} tis3008;

static struct TOS3008_GROUP
{
	char null;
} tos3008;

static aTisBaFreefmtfileNew			taTisBaFreefmtfileNew;
static aTosBaFreefmtfileNew			taTosBaFreefmtfileNew;

static aTisBaCommonNew			taTisBaCommonNew;
static aTosBaCommonNew			taTosBaCommonNew;

void ba3008Initial(void);
void ba3008Process(void);
void ba3008PutMessage(void);

void ba3008(void)
{
	ba3008Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3008Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3008PutMessage();
}

void ba3008Initial(void)
{
	memcpy(&tis3008, it_tita.labtex.text, sizeof(tis3008));
	memset(&tos3008, ' ', sizeof(tos3008));
}

void ba3008Process(void)
{
	char currentTime[14];
	char sClsSsn[8];
	char reqmsg[1024];
	char sCommand[512];
	int  nRet;
	memset(&reqmsg, 0, sizeof(reqmsg));
	memset(&taTisBaFreefmtfileNew, 0, sizeof(taTisBaFreefmtfileNew));
	memset(&taTosBaFreefmtfileNew, 0, sizeof(taTosBaFreefmtfileNew));
	
		
	CommonGetCurrentTime(currentTime);
	nRet = nNewClsSsn(sClsSsn);
 	if (nRet == 0)
  {
      memcpy(taTisBaFreefmtfileNew.sReqseqno, currentTime, 14);
      memcpy(taTisBaFreefmtfileNew.sReqseqno+14, FREEFMTFILE_SEQNO, 8);
      memcpy(taTisBaFreefmtfileNew.sReqseqno+22, sClsSsn, 8);
  }
  else
  {
      return;
  }
  
  memcpy(taTisBaFreefmtfileNew.sDirection, "2", 1);
  
	memcpy(taTisBaFreefmtfileNew.sFilename, tis3008.filename, sizeof(tis3008.filename));
	
	memcpy(taTisBaFreefmtfileNew.sFiletype, tis3008.filetype,DLEN_FILETYPE);
	memcpy(taTisBaFreefmtfileNew.sPostscript, tis3008.postscript,sizeof(tis3008.postscript));
	memcpy(taTisBaFreefmtfileNew.sTrndate, gwdXdtl.sTxday,DLEN_DATE);
  memcpy(taTisBaFreefmtfileNew.sReqtime, currentTime+8, DLEN_TIME);
	memcpy(taTisBaFreefmtfileNew.sTellerno, gwdXdtl.sTlrno, DLEN_TELLERNO);
	
	aBaFreefmtfileNewProcess(&taTisBaFreefmtfileNew, &taTosBaFreefmtfileNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
		
	/*************************************************************/
	/*����д�ڴ˴�                                               */
	/*   1.����HUB���͹������ļ�                                 */
	/*   2.����ũ��Լ����ʽ����                                  */
	/*   3.���ļ��ϴ���ũ��                                      */
	/*************************************************************/	
		
	/*�ϴ��ļ�*/
	signal(SIGCHLD,SIG_DFL); /*�ź�SIGCHLD����ΪĬ�Ϸ�ʽ����*/
 	memset(sCommand, 0, sizeof(sCommand));
    sprintf(sCommand, "%s/sbin/abcput %s/HAFile/%s %s", getenv("APPL"),  getenv("IODATA"), tis3008.filename, tis3008.filename);
    if(system(sCommand) != 0)
    {
		ERRTRACE(E_DB_FTP_ERR, "put fmtfile err!");
        return;
    }
	signal(SIGCHLD,SIG_IGN);  

	memset(&taTisBaCommonNew, 0, sizeof(taTisBaCommonNew));
	memset(&taTosBaCommonNew, 0, sizeof(taTosBaCommonNew));
	
  memcpy(taTisBaCommonNew.sReqseqno, taTisBaFreefmtfileNew.sReqseqno, sizeof(taTisBaFreefmtfileNew.sReqseqno));
  memcpy(taTisBaCommonNew.sTranscode, "19a1", DLEN_TRANSCODE);
  memcpy(taTisBaCommonNew.sBatfilename, tis3008.filename, sizeof(taTisBaCommonNew.sBatfilename));
  memcpy(taTisBaCommonNew.sTrndate, gwdXdtl.sTxday, DLEN_DATE);
  memcpy(taTisBaCommonNew.sReqtime, currentTime+8, DLEN_TIME);
  memcpy(taTisBaCommonNew.sCmdsource, "1",1);
  memcpy(taTisBaCommonNew.sResendflag, "0", 1);
  memcpy(taTisBaCommonNew.sCmdstat, "0", 1);
  memcpy(taTisBaCommonNew.sSendtimes, "00", DLEN_SENDTIMES);
  taTisBaCommonNew.dAmt=0;
  sprintf(reqmsg,"<ap>\n  <TransCode>19a1</TransCode>\n  <ReqSeqNo>%-30.30s</ReqSeqNo>\n  <ReqDate>%-8.8s</ReqDate>\n  <ReqTime>%-6.6s</ReqTime>\n  <Corp>\n     <Postscript>%-70.70s</Postscript>\n  </Corp>\n  <Cmp>\n    <BatchFileName>%-80.80s</BatchFileName>\n    <FileType>%-4.4s</FileType>\n  </Cmp>\n</ap>",taTisBaCommonNew.sReqseqno,taTisBaCommonNew.sTrndate,taTisBaCommonNew.sReqtime,tis3008.postscript,tis3008.filename,tis3008.filetype);
  memcpy(taTisBaCommonNew.sReqmsg, reqmsg, strlen(reqmsg));
  
	aBaCommonNewProcess(&taTisBaCommonNew, &taTosBaCommonNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
	
}

void ba3008PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3008), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3008, sizeof(tos3008));
}

void ba3008End()
{
	aBaFreefmtfileNewEnd();
	aBaCommonNewEnd();
}

void Process_3008(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3008));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3008();
	ba3008End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3008));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3008);
		DbCommitTxn();
	}

	return;
}

