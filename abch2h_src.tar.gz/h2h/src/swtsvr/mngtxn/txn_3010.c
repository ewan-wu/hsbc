/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   be3010                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ָ���ط�¼��                                         */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            bingliang.wu              Initial                      */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3010_GROUP{
	char  reqseqno[DLEN_REQSEQNO];	
}tis3010;

static struct TOS3010_GROUP
{
	char null; 
} tos3010;


static aTisBaCommonInq 			taTisBaCommonInq;
static aTosBaCommonInq				taTosBaCommonInq;

static aTisBaCommonUpd 			taTisBaCommonUpd;
static aTosBaCommonUpd				taTosBaCommonUpd;

void ba3010Initial(void);
void ba3010Process(void);
void ba3010PutMessage(void);

void ba3010(void)
{
	ba3010Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3010Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3010PutMessage();
}

void ba3010Initial(void)
{
	memcpy(&tis3010, it_tita.labtex.text, sizeof(tis3010));
	memset(&tos3010, ' ', sizeof(tos3010));
}

void ba3010PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3010), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3010, sizeof(tos3010));
}

void ba3010End()
{
	aBaCommonInqEnd();
	aBaCommonUpdEnd();
}

void ba3010Process(void)
{ memset(&taTisBaCommonInq, 0, sizeof(taTisBaCommonInq));
	memset(&taTosBaCommonInq, 0, sizeof(taTosBaCommonInq));
	
  memset(&taTisBaCommonUpd, 0, sizeof(taTisBaCommonUpd));
	memset(&taTosBaCommonUpd, 0, sizeof(taTosBaCommonUpd));
	
	memcpy(taTisBaCommonInq.sReqseqno, tis3010.reqseqno, DLEN_REQSEQNO);

	aBaCommonInqProcess(&taTisBaCommonInq, &taTosBaCommonInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
		
  memcpy(&taTisBaCommonUpd,&taTosBaCommonInq,sizeof(taTisBaCommonUpd));  
 
  memcpy(taTisBaCommonUpd.sResendflag, "1",1);
  memcpy(taTisBaCommonUpd.sCmdstat, "7", 1);
  
  aBaCommonUpdProcess(&taTisBaCommonUpd, &taTosBaCommonUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
  
}

void Process_3010(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3010));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3010();
	ba3010End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3010));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3010);
		DbCommitTxn();
	}

	return;
}

