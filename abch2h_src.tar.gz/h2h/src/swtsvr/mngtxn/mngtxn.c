/*************************************************************************/
/* Name      :    MANAGE                                                 */
/*************************************************************************/
#include "mngtxn_main.h"
#include "htlog.h"

char logfile[256];
char ErrorDescription[51];

void vTellerProcess(void *sTrans);
void GetSystemTime14(char *stime);

void HandleExit( )
{
	DebugMemory( "Exit Handled");
}

void main(short argc, char **argv)
{
	long lReturn;
	short nRet;
	short nDataLen;
	long lMsgSource;
	CmdMsgDef ipcMsg;
	char cTime[14];

	atexit( HandleExit );
	setbuf( stdout, NULL );
	sigset( SIGCLD, SIG_IGN );   
	printf( "Command Server started, pid=%d\n", getpid());   
	DebugMemory( "Start");

	/********************/
	/* Connect DataBase */
	/*******************/
	lReturn = DbConnect();
	if (lReturn != 0)
	{
		printf( "Open database return %d\n", lReturn );
		ErrReport(CI_BDGMNG, 
			EI_DATABASE,
			lReturn, 
		   	CI_SEVERITY_SYSERROR,
		   	ES_DB_OPEN);
		exit(1);
	}
 
  memset(logfile, 0, sizeof(logfile));
	nRet = GetLogName(argv[1], logfile);
	if (nRet != 0 )
	{ 
		printf("GetLogName error:nRet = [%d]\n",nRet);
		ErrReport(CI_TLRBDG,
				 	EI_PROCESS,
	     		  	0,
				  	CI_SEVERITY_SYSERROR,
					ES_PROCESS_EXIT);
		
		fprintf(stderr, "GetLogName error !\n");
	}

	/*****************************************/
	/* Load the server information in SRVINF */
	/*****************************************/
	if (0 != LoadSrvMsq())
	{
		ErrReport(CI_TLRBDG,
					EI_DATABASE,
					0,
				    CI_SEVERITY_SYSERROR,
				    ES_DB_SELECT);
	   exit(1); 
	 }
																												  
	 HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			  "InitBridge:Load server route information from SRVMSQ success!\n");
	/********************************************/
    /* Load the TxnMap information of TXNNOMAP  */
    /********************************************/

	if (0 != LoadTxnnoMap())
    {
		ErrReport(CI_TLRBDG,
					EI_DATABASE,
					0,
					CI_SEVERITY_SYSERROR,
					ES_DB_SELECT);
	   exit(1); 
	}

	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"InitBridge:Load txnnomap information from TXNNOMAP success!\n");

	/*****************************/
   	/* Initial the message queue */
	/*****************************/

	nRet = nCommonMsqAllInit(CI_BDGMNG);
	if (nRet != 0) 
   	{
       	ErrReport(CI_BDGMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }

	nRet = nCommonMsqAllInit(CI_TLRCOMM);
	if (nRet != 0) 
   	{
       	ErrReport(CI_BDGMNG, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }

	/* HANDLE TRANSACTION */
	while(1)
	{
		/* READ MANAGE MESSAGE QUEUE */
		nRet = nCommonMsqRecv (&nDataLen, ipcMsg.sText, &lMsgSource, CI_BDGMNG);
		if (nRet != 0)
 		{
 			if (errno != EINTR)
 			{
				printf( "errno[%d]\n", errno );

 				if (nCommonMsqInit(CI_BDGMNG) == -1)
 				{
 					ErrReport(CI_BDGMNG,
 						EI_MESSAGEQUEUE,
 						0,
 						CI_SEVERITY_SYSERROR,
 						ES_MSGQ_READ);
 					exit(1);
 				}
				continue;
			}
		}			
		
		CommonGetCurrentTime( cTime );
		
		printf( "\n===========================================\n");

		nRet = GetSysDate(gsDBTxdate);
		if (nRet != 0)
		{
   	    	ErrReport(CI_BDGMNG, 
   	               	EI_PROCESS, 
   	               	0, 
   	               	CI_SEVERITY_TXNERROR,
   	               	"���ϵͳ�������ڳ���");
			exit(1);
		}

		printf("msgrcv  : source [%d]\n", lMsgSource); 
		DebugString( ipcMsg.sText, nDataLen, __LINE__);

		switch(lMsgSource)
		{
		case CI_TLRBDG:
			vTellerProcess((void *)&(ipcMsg.sText));
			break;
		case CI_BEPS_SWT:
		case CI_BEPS_FILE_SRV:
		default:
			printf("Invalid message source!\n");
			break;
		}

	}  /*for(;;)*/
}

/**************************************/
/* Transactions from Teller PCs       */
/**************************************/
void vTellerProcess(void *sTrans)
{
	T_MngBufFromTlrDef	*ptMngInBuf;
	T_MngBufToTlrDef	tMngOutBuf;

	int nReturn;
	char sTxno[DLEN_TXNCD+1];
	int nOutLen, nTcpLen;
	char sPid[9];
	int iBepsIntTxno;
	char caBepsTxno[20];
	long lTxnNo=0, lSrvId=0;
	char caError[DLEN_LDESC+1];
	

	ptMngInBuf = sTrans;
	memset(&tMngOutBuf, 0, sizeof(tMngOutBuf));
	memset(sTxno, 0, sizeof(sTxno));
	memcpy(sTxno, ptMngInBuf->tTitaLabel.txno, DLEN_TXNCD);
	memcpy(&TITA, &(ptMngInBuf->tTitaLabel), TITA_LABEL_LENGTH);

	memcpy(it_txcom.tbsdy, gsDBTxdate, DLEN_DATE);


	memset(caError, 0, sizeof(caError));

	if( memcmp(sTxno, "0023", DLEN_TXNO) && 
		memcmp(sTxno, "0012", DLEN_TXNO) && 
		memcmp(sTxno, "0000", DLEN_TXNO)  )
	{
 		nReturn = TransCheck(ptMngInBuf, caError);
    	if (nReturn != 0)
    	{
			printf("Invalid transaction number!\n");
 			Process_MoveTotaCommon(ptMngInBuf, &tMngOutBuf);
			tMngOutBuf.tTotaLabel.msgtype = 'E';
			memcpy(tMngOutBuf.tTotaLabel.msgno, "9527", 4);
 			{
				memcpy(tMngOutBuf.sTotaText, caError, strlen(caError));
       	 		nOutLen = sizeof(tMngOutBuf.tTotaLabel) + strlen(caError);
       	 	}
			memset(sPid, 0, sizeof(sPid));
    		memcpy(sPid, ptMngInBuf->tTitaLabel.termid, 8);
    		DebugString( &tMngOutBuf, nOutLen, __LINE__);
    		printf("Pid of tlrcomm [%d]\n", atol(sPid));
    		tMngOutBuf.tTotaLabel.header[0] = nOutLen / 256;
    		tMngOutBuf.tTotaLabel.header[1] = nOutLen % 256;

    		nReturn = nCommonMsqSendT(nOutLen, &tMngOutBuf, 
										atol(sPid), CI_TLRCOMM);
    		if (nReturn != 0)
    		{
        		strcpy(ErrorDescription, "MSQ TLRCOMM SEND");

        		ErrReport(CI_MANAGER,
           	  			EI_MESSAGEQUEUE,
       					0,
           				CI_SEVERITY_SYSERROR,
           	   			ErrorDescription);
    		}

    		return;
    	}
	}
	if( memcmp(sTxno, "8888", DLEN_TXNO))
		{
			nReturn = nNewSysClsSsn(gsTlsrno);
			if (nReturn != 0)
			{
  		     	ErrReport(CI_BDGMNG, 
  		 	               	EI_PROCESS, 
  		 	               	0, 
  		 	               	CI_SEVERITY_TXNERROR,
  		 	               	"���ϵͳ��ˮ�ų���");
				exit(1);
			}
		}
	/*************************************************/
	/* prepare it_txcom, gwdXdtl, gwdBctl, gwdTlrctl */
	/*************************************************/
	nReturn = aSysBasicCheck();
	if (nReturn != SYS_OK)
	{
		aSysBasicCheckEnd();
		return;
	}

	printf("mngtxn:vTellerProcess - (External) Txno = [%s]\n", sTxno);
	switch (atoi(sTxno))
	{
		case 3001:
			Process_3001(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3002:
			Process_3002(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3003:
			Process_3003(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3004:
			Process_3004(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3005:
			Process_3005(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3007:
			Process_3007(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3006:
			Process_3006(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3008:
			Process_3008(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3010:
			Process_3010(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 3011:
			Process_3011(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2030:
			Process_2030(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		/*case 2102:
			Process_2102(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;*/
		case 8888:			
			Process_8888(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		default:
			printf("Invalid transaction number!\n");
			Process_MoveTotaCommon(ptMngInBuf, &tMngOutBuf);
			tMngOutBuf.tTotaLabel.msgtype = 'E';
			memcpy(tMngOutBuf.tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "�Ƿ��Ľ��״��룡");
			memcpy(tMngOutBuf.sTotaText, sError, strlen(sError));
			nOutLen = sizeof(tMngOutBuf.tTotaLabel) + strlen(sError);
			}
			break;
	}
	
	nReturn = aSysBasicUpdate();
	if (nReturn != SYS_OK)
	{
		aSysBasicCheckEnd();
		return;
	}

	memset(sPid, 0, sizeof(sPid));
	memcpy(sPid, ptMngInBuf->tTitaLabel.termid, 8);
	DebugString( &tMngOutBuf, nOutLen, __LINE__);
	printf("Pid of tlrcomm [%d]\n", atol(sPid));
	tMngOutBuf.tTotaLabel.header[0] = nOutLen / 256;
	tMngOutBuf.tTotaLabel.header[1] = nOutLen % 256;

	nReturn = nCommonMsqSendT(nOutLen, &tMngOutBuf, atol(sPid), CI_TLRCOMM);
	if (nReturn != 0)
	{
		strcpy(ErrorDescription, "MSQ TLRCOMM SEND");

		ErrReport(CI_BDGMNG,
                EI_MESSAGEQUEUE,
                0,
                CI_SEVERITY_SYSERROR,
                ErrorDescription);
    }
	/*
	// �õ�ǰ���ڲ�������//
	lTxnNo = 0;
	nReturn = nGetClsTxno(CI_BDGMNG, &lTxnNo, sTxno); 
	if (nReturn != 0)
	{
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"GetClsTxno error =[%d], lTxnNo=[%d], sTxno=[%s]", nReturn, lTxnNo, sTxno);
		return ;
	}

	HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
		"ClsTxno  =[%d]", lTxnNo);

	// ���ӷ���С��ģ����ж� //
	if (lTxnNo == BEPS_SND_FILESPLIT_9105 || lTxnNo== BEPS_SND_FILESPLIT_9106)
	{
		nReturn = nCommonMsqSend(nOutLen, &tMngOutBuf, CI_BDGMNG, CI_BEPS_FILE_SRV );
		if (nReturn != 0)
		{
			ErrReport(CI_BDGMNG,
				EI_MESSAGEQUEUE,
				0,
				CI_SEVERITY_SYSERROR,
				ES_MSGQ_WRITE);
			return;
		}			
	}
	else
	{
		// txn_step == 2 Ϊ���͸�С��SWT�Ľ��� //
		lSrvId = 0;
		lSrvId = nFindServerId(CI_BDGMNG,lTxnNo,2);
				
		HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
   		   		"the msg send to beps [%d]\n", lSrvId);

		// ==0 �����Ҳ���SVRID //
		if (lSrvId != 0)
		{
			// ���Ⱥͱ��Ķ�ȥ�� TOTAͷ //
			nTcpLen = nOutLen - sizeof(tMngOutBuf.tTotaLabel);
			
			// ����С���ڲ������� //
			iBepsIntTxno = 0;

			// ����·�ɱ��е�rsv�ֶηŶ�Ӧ��С����� //

			iBepsIntTxno = nFindBepsTxno(CI_BDGMNG,lTxnNo,2);
		
			memset(caBepsTxno, 0, sizeof(caBepsTxno));
			sprintf(caBepsTxno, "%08d", iBepsIntTxno);

			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"caTxno=[%s], lTxno=[%d]", caBepsTxno, iBepsIntTxno);

			memcpy(tMngOutBuf.sTotaText, caBepsTxno, 8);
			
			nReturn = nCommonMsqSend(nTcpLen, tMngOutBuf.sTotaText, CI_BDGMNG, lSrvId );
			if (nReturn != 0)
			{
				HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
   		   				"nCommonMsqSend [%d] nRet=[%d]\n", lSrvId,nReturn);

				ErrReport(CI_BDGMNG,
					EI_MESSAGEQUEUE,
					0,
					CI_SEVERITY_SYSERROR,
					ES_MSGQ_WRITE);
				return;
			}				
			
		}
	}*/

	return;
}

void GetSystemTime14(char *stime)
{
   time_t current;
   struct tm *tmCurrentTime;
   

   memset(stime, 0, sizeof(stime));

   time(&current);
   tmCurrentTime = localtime(&current);

   sprintf(stime, "%04d%02d%02d%02d%02d%02d", 
				1900 + tmCurrentTime->tm_year,
				tmCurrentTime->tm_mon+1,
				tmCurrentTime->tm_mday,
   				tmCurrentTime->tm_hour,
				tmCurrentTime->tm_min ,
   				tmCurrentTime->tm_sec );

   /*return stime;*/
}
