/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   3004                                                               */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �˻�ͣ������                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20071114       nathan jin           Initial                        */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3004_GROUP
{
	char	acct[DLEN_ACC];
	char  operate;
	char	rejreason[30];
} tis3004;

static struct TOS3004_GROUP
{
	char null;
} tos3004;

static aTisBaAccountInq			taTisBaAccountInq;
static aTosBaAccountInq			taTosBaAccountInq;

static aTisBaAccountUpd			taTisBaAccountUpd;
static aTosBaAccountUpd			taTosBaAccountUpd;

void ba3004Initial(void);
void ba3004Process(void);
void ba3004PutMessage(void);

void ba3004(void)
{
	ba3004Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3004Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3004PutMessage();
}

void ba3004Initial(void)
{
	memcpy(&tis3004, it_tita.labtex.text, sizeof(tis3004));
	memset(&tos3004, ' ', sizeof(tos3004));
}

void ba3004Process(void)
{

	memset(&taTisBaAccountInq, 0, sizeof(taTisBaAccountInq));
	memset(&taTosBaAccountInq, 0, sizeof(taTosBaAccountInq));
	
	memset(&taTisBaAccountUpd, 0, sizeof(taTisBaAccountUpd));
	memset(&taTosBaAccountUpd, 0, sizeof(taTosBaAccountUpd));

	memcpy(taTisBaAccountInq.sAcct, tis3004.acct, DLEN_ACC);

	aBaAccountInqProcess(&taTisBaAccountInq, &taTosBaAccountInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	memcpy(&taTisBaAccountUpd,&taTosBaAccountInq,sizeof(taTisBaAccountUpd));


	if(tis3004.operate == '0' )
	{
		if(taTisBaAccountUpd.sAcctstat[0] == '3')
			taTisBaAccountUpd.sAcctstat[0] = '4';
		if(taTisBaAccountUpd.sAcctstat[0] == '5')
			taTisBaAccountUpd.sAcctstat[0] = '0';
	}else
	{
		memcpy(taTisBaAccountUpd.sRejreason, tis3004.rejreason, sizeof(tis3004.rejreason));
		if(taTisBaAccountUpd.sAcctstat[0] == '3')
			taTisBaAccountUpd.sAcctstat[0] = '0';
		if(taTisBaAccountUpd.sAcctstat[0] == '5')
			taTisBaAccountUpd.sAcctstat[0] = '4';
	}

	aBaAccountUpdProcess(&taTisBaAccountUpd, &taTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
	
}

void ba3004PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3004), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3004, sizeof(tos3004));
}

void ba3004End()
{
	aBaAccountUpdEnd();
}

void Process_3004(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3004));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3004();
	ba3004End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3004));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3004);
		DbCommitTxn();
	}

	return;
}

