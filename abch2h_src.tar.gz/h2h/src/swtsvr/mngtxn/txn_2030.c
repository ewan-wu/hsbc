/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   be2030                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ������ӡ                                                */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20071122          sunfei                Initial                      */
/************************************************************************/
#include "mngtxn.h"

static struct TIS2030_GROUP{
	char	TxDate[DLEN_DATE];			/*��������*/
	char	RpNo[2];					/*�������*/
}tis2030;

static struct TOS2030_GROUP
{
    char    sReportName[50];	
} tos2030;

void be2030Initial(void);
void be2030Process(void);
void be2030PutMessage(void);

void be2030(void)
{
	be2030Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	be2030Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	be2030PutMessage();
}

void be2030Initial(void)
{
	memcpy(&tis2030, it_tita.labtex.text, sizeof(tis2030));
	memset(&tos2030, ' ', sizeof(tos2030));
}

void be2030PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos2030), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);
	printf("tos2030=%s\n",tos2030.sReportName);
	memcpy(it_totw.labtex.text, &tos2030, sizeof(tos2030));
}

void be2030End()
{
}

void be2030Process(void)
{
	char sCommand[512];
	char TxDate[DLEN_DATE+1];
	char sFileName[100];
	char sNewFileName[100];
	char Name[20];
	char sReportName[50];

	signal(SIGCHLD,SIG_DFL);

	memcpy(TxDate,tis2030.TxDate,DLEN_DATE);
	TxDate[DLEN_DATE] = '\0';

	memset(sFileName,'\0',100);
	memset(sNewFileName,'\0',100);
	memset(Name,'\0',20);

	switch(apatoi(tis2030.RpNo,2))	
	{
		case	1:
			memcpy(Name,"remitreport",11);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);
			if(system(sCommand) != 0) 
			{
   				return;
			}	
 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/remit.txt", TxDate);
			break;
		case	2:
			memcpy(Name,"commonreport",12);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);
			if(system(sCommand) != 0) 
			{
   				return;
			}	
 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/common.txt", TxDate);
			break;
		case	3:
			memcpy(Name,"freefmt",7);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);
			if(system(sCommand) != 0) 
			{
   				return;
			}	
 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/freefmt.txt", TxDate);
			break;
		case	4:
			memcpy(Name,"commondetail",12);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);
			if(system(sCommand) != 0) 
			{
   				return;
			}	
 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/commonDetail.txt", TxDate);
			break;
		case	5:
			memcpy(Name,"payrollmain",11);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);
			if(system(sCommand) != 0) 
			{
   				return;
			}	
 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/payrollmain.txt", TxDate);
			break;
		case	6:
			memcpy(Name,"noProcessFile",13);
			sprintf(sCommand, "%s/bin/%s %s", 
			getenv("APPL"), Name, TxDate);

			if(system(sCommand) != 0) 
			{
   				return;
			}	

 			memset(sReportName, 0, sizeof(sReportName));
			sprintf(sReportName,"/h2h/iodata/report/%s/noProcessFile.txt", TxDate);
			break;
		case	7:
		case	8:
		case	9:

		default:
			it_txcom.txrsut = TX_REJECT;
			memcpy(gsErrDesc,"�޶�Ӧ����",strlen(gsErrDesc));
			break;
	}
			
  	memcpy(tos2030.sReportName,sReportName,49); 

	signal(SIGCHLD,SIG_IGN);  
/*	sleep(1);

	sprintf(sFileName, "%s/TXT/%s/%s/%s%.2s.txt", getenv("APPL"), 
			TxDate, gwdXdtl.sKinbr, Name, tis2030.RpNo);
	sprintf(sNewFileName, "%s/TXT/%s/%s/%sFmt%.2s.txt", getenv("APPL"), 
			TxDate, gwdXdtl.sKinbr, Name, tis2030.RpNo);
    memset(sReportName,0,50);

    sprintf(sReportName,"/beps/TXT/%s/%s/%sFmt%.2s.txt",
			TxDate,gwdXdtl.sKinbr,Name,tis2030.RpNo);

    memcpy(tos2030.sReportName,sReportName,49); 

	sprintf(sCommand, "%s/bin/ddrpt %s > %s", getenv("APPL"), 
			sFileName, sNewFileName);

	system(sCommand);

	sleep(1);

	sprintf(sCommand, "%s/sbin/ConvRpt2Win_bh.sh %s %s %s", getenv("APPL"), 
			sNewFileName,gwdXdtl.sTlrno,gwdXdtl.sKinbr);
	system(sCommand);*/

	return;

}

void Process_2030(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis2030));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	be2030();
	be2030End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos2030));
		printf("it_totw.labtex.text=%s\n", it_totw.labtex.text);
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2030);
		DbCommitTxn();
	}

	return;
}

