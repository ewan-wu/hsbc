/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   be3001                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ʻ�¼��                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            bingliang.wu              Initial                */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3001_GROUP{
	char	flag;
	char  	acct[DLEN_ACC];
	char	customid[2];
	char  	acctname[DLEN_ACCTNAME];
	char  	openbankname[DLEN_OPENBANKNAME];	
}tis3001;

static struct TOS3001_GROUP
{
	char null;
} tos3001;


static aTisBaAccountNew 			taTisBaAccountNew;
static aTosBaAccountNew				taTosBaAccountNew;

static aTisBaAccountUpd             taTisBaAccountUpd;
static aTosBaAccountUpd             taTosBaAccountUpd;

void ba3001Initial(void);
void ba3001Process(void);
void ba3001PutMessage(void);

void ba3001(void)
{
	ba3001Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3001Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3001PutMessage();
}

void ba3001Initial(void)
{
	memcpy(&tis3001, it_tita.labtex.text, sizeof(tis3001));
	memset(&tos3001, ' ', sizeof(tos3001));
}

void ba3001PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3001), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3001, sizeof(tos3001));
}

void ba3001End()
{
	aBaAccountNewEnd();
}

void ba3001Process(void)
{ 

  char tmpacct[DLEN_ACC+1];

  memset(tmpacct, 0, sizeof(tmpacct));
  memcpy(tmpacct,tis3001.acct,DLEN_ACC);
  memset(tis3001.acct, ' ', DLEN_ACC);
  memcpy(tis3001.acct, tmpacct, strlen(tmpacct));
  /*printf("tis3001.acct=[%s],tmpacct = [%35.35s]\n", tis3001.acct,tmpacct);*/
  /*�˻�����*/
  printf("tis3001.acctname=[%s]\n",tis3001.acctname);
  printf("tis3001.openbankname=[%s]\n",tis3001.openbankname);
  if (tis3001.flag == 'I')
  {
  	memset(&taTisBaAccountNew, 0, sizeof(taTisBaAccountNew));
  	memcpy(taTisBaAccountNew.sAcct, tis3001.acct, DLEN_ACC);
  	memcpy(taTisBaAccountNew.sAcctname, tis3001.acctname, sizeof(tis3001.acctname));
	memcpy(taTisBaAccountNew.sCustomid, tis3001.customid, sizeof(taTisBaAccountNew.sCustomid)-1);
  	memcpy(taTisBaAccountNew.sOpenbankname, tis3001.openbankname, sizeof(tis3001.openbankname));
  	memcpy(taTisBaAccountNew.sLasttrandt,"00000000", DLEN_DATE);
  	memcpy(taTisBaAccountNew.sLasttimeslice, "00000000000000000000000000", DLEN_LASTTIMESLICE);
  	memcpy(taTisBaAccountNew.sLastjrnno, "000000000", DLEN_LASTJRNNO);
  	memcpy(taTisBaAccountNew.sCmdstat, "1", DLEN_CMDSTAT);
  	memcpy(taTisBaAccountNew.sAcctstat, "1", DLEN_ACCTSTAT);  
	memcpy(taTisBaAccountNew.sTellerno, gwdXdtl.sTlrno, DLEN_TELLERNO);
	taTisBaAccountNew.dBalance=0;
		
  	aBaAccountNewProcess(&taTisBaAccountNew, &taTosBaAccountNew);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
  }
	/*�˻��޸�*/
  else if (tis3001.flag == 'U')
  {
	memset(&taTisBaAccountUpd, 0, sizeof(taTisBaAccountUpd));
	memcpy(taTisBaAccountUpd.sAcct, tis3001.acct, DLEN_ACC);
  	memcpy(taTisBaAccountUpd.sAcctname, tis3001.acctname, sizeof(tis3001.acctname));
  	memcpy(taTisBaAccountUpd.sOpenbankname, tis3001.openbankname, sizeof(tis3001.openbankname));
	memcpy(taTisBaAccountUpd.sCustomid, tis3001.customid, sizeof(taTisBaAccountUpd.sCustomid)-1);
  	memcpy(taTisBaAccountUpd.sLasttrandt,"00000000", DLEN_DATE);
  	memcpy(taTisBaAccountUpd.sLasttimeslice, "00000000000000000000000000", DLEN_LASTTIMESLICE);
  	memcpy(taTisBaAccountUpd.sLastjrnno, "000000000", DLEN_LASTJRNNO);
  	memcpy(taTisBaAccountUpd.sCmdstat, "1", DLEN_CMDSTAT);
  	memcpy(taTisBaAccountUpd.sAcctstat, "1", DLEN_ACCTSTAT);  
	memcpy(taTisBaAccountUpd.sTellerno, gwdXdtl.sTlrno, DLEN_TELLERNO);
	taTisBaAccountUpd.dBalance=0;
		
  	aBaAccountUpdProcess(&taTisBaAccountUpd, &taTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
	}
	else
	{
		it_txcom.txrsut = TX_REJECT;
		return;
	}
}

void Process_3001(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3001));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3001();
	ba3001End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3001));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3001);
		DbCommitTxn();
	}

	return;
}

