/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   be3011                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ָ���ط�¼����Ȩ                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            bingliang.wu              Initial                      */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3011_GROUP{
	char  reqseqno[DLEN_REQSEQNO];
	char  operate;	
}tis3011;

static struct TOS3011_GROUP
{
	char null; 
} tos3011;


static aTisBaCommonInq 			taTisBaCommonInq;
static aTosBaCommonInq				taTosBaCommonInq;

static aTisBaCommonUpd 			taTisBaCommonUpd;
static aTosBaCommonUpd				taTosBaCommonUpd;

void ba3011Initial(void);
void ba3011Process(void);
void ba3011PutMessage(void);

void ba3011(void)
{
	ba3011Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3011Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3011PutMessage();
}

void ba3011Initial(void)
{
	memcpy(&tis3011, it_tita.labtex.text, sizeof(tis3011));
	memset(&tos3011, ' ', sizeof(tos3011));
}

void ba3011PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3011), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3011, sizeof(tos3011));
}

void ba3011End()
{
	aBaCommonInqEnd();
	aBaCommonUpdEnd();
}

void ba3011Process(void)
{ memset(&taTisBaCommonInq, 0, sizeof(taTisBaCommonInq));
	memset(&taTosBaCommonInq, 0, sizeof(taTosBaCommonInq));
	
  memset(&taTisBaCommonUpd, 0, sizeof(taTisBaCommonUpd));
	memset(&taTosBaCommonUpd, 0, sizeof(taTosBaCommonUpd));
	
	memcpy(taTisBaCommonInq.sReqseqno, tis3011.reqseqno, DLEN_REQSEQNO);

	aBaCommonInqProcess(&taTisBaCommonInq, &taTosBaCommonInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
		
  memcpy(&taTisBaCommonUpd,&taTosBaCommonInq,sizeof(taTisBaCommonUpd));
  
  if(tis3011.operate=='0'){
  	memcpy(taTisBaCommonUpd.sCmdstat, "0", DLEN_CMDSTAT);
    memcpy(taTisBaCommonUpd.sResendflag, "2",2);
    memcpy(taTisBaCommonUpd.sSendtimes, "0",1);
  }else{
  	memcpy(taTisBaCommonUpd.sResendflag, "0", 1); 
  	memcpy(taTisBaCommonUpd.sCmdstat, "8", DLEN_CMDSTAT);   
  } 
  
  aBaCommonUpdProcess(&taTisBaCommonUpd, &taTosBaCommonUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
  
}

void Process_3011(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3011));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3011();
	ba3011End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3011));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3011);
		DbCommitTxn();
	}

	return;
}

