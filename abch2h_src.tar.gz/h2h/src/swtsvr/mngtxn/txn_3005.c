/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   ba3005                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ����ֹ�¼��                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            sunfei              Initial                      */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3005_GROUP{
	char  bookingDate[DLEN_DATE];
	char	bookingTime[DLEN_TIME];
	char  customId[2];
	char  customNo[DLEN_CUSTOMNO];
	char  actInf[DLEN_ACTINF];
	char  urgencyFlag[DLEN_URGENCYFLAG];
	char	othBankFlag[DLEN_OTHBANKFLAG];
	char  othCenterFlag[DLEN_OTHCENTERFLAG];
	char  dbBankName[DLEN_DBBANKNAME];
	char  crAccName[DLEN_CRACCNAME];
	char  crBankName[DLEN_CRBANKNAME];
	char  dbAccName[DLEN_DBACCNAME];
	char  crAddress[DLEN_CRADDRESS];
	char  whyUse[DLEN_WHYUSE];
	char  dbAccNo[DLEN_DBACCNO];
	char  dbProv[DLEN_DBPROV];
	char  dbCur[DLEN_DBCUR];
	/*char  dbLogAccNo[DLEN_DBLOGACCNO];*/
	char  crAccNo[DLEN_CRACCNO];
	char  crProv[DLEN_CRPROV];
	char  crCur[DLEN_CRCUR];
	char  amt[DLEN_AMT];
	char  specfield1[DLEN_POSTSCRIPT];
	char  specfield2[DLEN_POSTSCRIPT];
	char  specfield3[DLEN_POSTSCRIPT];
	char  specfield4[DLEN_POSTSCRIPT];
}tis3005;

static struct TOS3005_GROUP
{
    char reqSeqNo[DLEN_REQSEQNO];
}tos3005;


static aTisBaRemitNew				taTisBaRemitNew;
static aTosBaRemitNew				taTosBaRemitNew;

void ba3005Initial(void);
void ba3005Process(void);
void ba3005PutMessage(void);

void ba3005(void)
{
	ba3005Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3005Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3005PutMessage();
}

void ba3005Initial(void)
{
	memcpy(&tis3005, it_tita.labtex.text, sizeof(tis3005));
	memset(&tos3005, ' ', sizeof(tos3005));
}

void ba3005PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3005), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3005, sizeof(tos3005));
}

void ba3005End()
{
	aBaRemitNewEnd();
}

void ba3005Process(void)
{
	char currentTime[14];
	char sClsSsn[8];
	char tmpAmt[DLEN_AMT+1];
	short nRet;
	
	memset(currentTime, 0 , sizeof(currentTime));
	memset(sClsSsn, 0 , sizeof(sClsSsn));
	memset(tmpAmt, 0 , sizeof(tmpAmt));
	
	memset(&taTisBaRemitNew, 0 , sizeof(taTisBaRemitNew));
	memset(&taTosBaRemitNew, 0 , sizeof(taTosBaRemitNew));
	
	CommonGetCurrentTime(currentTime);
	nRet = nNewClsSsn(sClsSsn);
 	if (nRet == 0)
  {
      memcpy(taTisBaRemitNew.sReqseqno, currentTime, 14);
      memcpy(taTisBaRemitNew.sReqseqno+14, REMIT_SEQNO, 8);
      memcpy(taTisBaRemitNew.sReqseqno+22, sClsSsn, 8);
  }
  else
  {
      return;
  }
		 
		 
  memcpy(taTisBaRemitNew.sTrndate, gwdXdtl.sTxday, DLEN_DATE);
	memcpy(taTisBaRemitNew.sBookingdate, tis3005.bookingDate, DLEN_DATE);
	memcpy(taTisBaRemitNew.sBookingtime, tis3005.bookingTime, DLEN_TIME);
	/*memcpy(taTisBaRemitNew.sBookingflag, tis3005.bookingFlag, DLEN_FLAG);
	memcpy(taTisBaRemitNew.sExchangetype, tis3005.exchangeType, sizeof(tis3005.exchangeType));*/
	taTisBaRemitNew.sBookingflag[0] = '0';
	taTisBaRemitNew.sExchangetype[0] = '0';
	printf("tis3005.customId =%s\n", tis3005.customId);
	printf("tis3005.customNo=%s\n", tis3005.customNo);
	/*memcpy(taTisBaRemitNew.sCustomid, tis3005.customId, sizeof(tis3005.customNo));*/
	memcpy(taTisBaRemitNew.sCustomid, tis3005.customId, 2);
	memcpy(taTisBaRemitNew.sCustomno, tis3005.customNo, sizeof(tis3005.customNo));

	printf("tis3005.actInf = %s\n", tis3005.actInf);
	memcpy(taTisBaRemitNew.sActinf, tis3005.actInf, sizeof(tis3005.actInf));
	memcpy(taTisBaRemitNew.sUrgencyflag, tis3005.urgencyFlag, DLEN_URGENCYFLAG);
	memcpy(taTisBaRemitNew.sOthbankflag, tis3005.othBankFlag, DLEN_OTHBANKFLAG);
	memcpy(taTisBaRemitNew.sOthcenterflag, tis3005.othCenterFlag, DLEN_OTHCENTERFLAG);
	memcpy(taTisBaRemitNew.sDbbankname, tis3005.dbBankName, sizeof(tis3005.dbBankName));
	memcpy(taTisBaRemitNew.sCraccname, tis3005.crAccName, sizeof(tis3005.crAccName));
	memcpy(taTisBaRemitNew.sCrbankname, tis3005.crBankName, sizeof(tis3005.crBankName));
	
	memcpy(taTisBaRemitNew.sDbaccname, tis3005.dbAccName, sizeof(tis3005.dbAccName));
	memcpy(taTisBaRemitNew.sCraddress, tis3005.crAddress, sizeof(tis3005.crAddress));
	memcpy(taTisBaRemitNew.sWhyuse, tis3005.whyUse, sizeof(tis3005.whyUse));
	memcpy(taTisBaRemitNew.sDbaccno, tis3005.dbAccNo, sizeof(tis3005.dbAccNo));
	memcpy(taTisBaRemitNew.sDbprov, tis3005.dbProv, sizeof(tis3005.dbProv));
	memcpy(taTisBaRemitNew.sDbcur, tis3005.dbCur, DLEN_DBCUR);
	/*memcpy(taTisBaRemitNew.sDblogaccno, tis3005.dbLogAccNo, DLEN_DBLOGACCNO);*/
	memcpy(taTisBaRemitNew.sCraccno, tis3005.crAccNo, sizeof(tis3005.crAccNo));
	memcpy(taTisBaRemitNew.sCrprov, tis3005.crProv, sizeof(tis3005.crProv));
	memcpy(taTisBaRemitNew.sCrcur, tis3005.crCur, DLEN_CRCUR);
	printf("tis3005.amt = %s\n", tis3005.amt);
	memcpy(tmpAmt,tis3005.amt,DLEN_AMT);
	tmpAmt[DLEN_AMT] = '\0';
	taTisBaRemitNew.dAmt=atof(tmpAmt);
	printf("tis3005.amt = %f\n", taTisBaRemitNew.dAmt);
	memcpy(taTisBaRemitNew.sCmdstat, "0", DLEN_CMDSTAT);
	memcpy(taTisBaRemitNew.sTellerno, gwdXdtl.sTlrno, DLEN_TELLERNO);
	
	memcpy(taTisBaRemitNew.sTransid, tis3005.specfield1, 2);
	memcpy(taTisBaRemitNew.sSpecfield1, tis3005.specfield1, DLEN_POSTSCRIPT);
	memcpy(taTisBaRemitNew.sSpecfield2, tis3005.specfield2, DLEN_POSTSCRIPT);
	memcpy(taTisBaRemitNew.sSpecfield3, tis3005.specfield3, DLEN_POSTSCRIPT);
	memcpy(taTisBaRemitNew.sSpecfield4, tis3005.specfield4, DLEN_POSTSCRIPT);
	
	aBaRemitNewProcess(&taTisBaRemitNew, &taTosBaRemitNew);
	if(it_txcom.txrsut != TX_SUCCESS)
			return;
			
	memcpy(tos3005.reqSeqNo, taTisBaRemitNew.sReqseqno,DLEN_REQSEQNO);
}

void Process_3005(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3005));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3005();
	ba3005End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3005));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3005);
		DbCommitTxn();
	}

	return;
}

