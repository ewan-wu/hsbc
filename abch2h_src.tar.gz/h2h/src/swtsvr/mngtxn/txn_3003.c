/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   3003                                                               */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �˻�ͣ������                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   20071114       nathan jin           Initial                        */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3003_GROUP
{
	char	acct[DLEN_ACC];
	char  operate;
} tis3003;

static struct TOS3003_GROUP
{
	char null;
} tos3003;

static aTisBaAccountInq			taTisBaAccountInq;
static aTosBaAccountInq			taTosBaAccountInq;

static aTisBaAccountUpd			taTisBaAccountUpd;
static aTosBaAccountUpd			taTosBaAccountUpd;

void ba3003Initial(void);
void ba3003Process(void);
void ba3003PutMessage(void);

void ba3003(void)
{
	ba3003Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3003Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3003PutMessage();
}

void ba3003Initial(void)
{
	memcpy(&tis3003, it_tita.labtex.text, sizeof(tis3003));
	memset(&tos3003, ' ', sizeof(tos3003));
}

void ba3003Process(void)
{

	memset(&taTisBaAccountInq, 0, sizeof(taTisBaAccountInq));
	memset(&taTosBaAccountInq, 0, sizeof(taTosBaAccountInq));
	
	memset(&taTisBaAccountUpd, 0, sizeof(taTisBaAccountUpd));
	memset(&taTosBaAccountUpd, 0, sizeof(taTosBaAccountUpd));

	memcpy(taTisBaAccountInq.sAcct, tis3003.acct, DLEN_ACC);

	aBaAccountInqProcess(&taTisBaAccountInq, &taTosBaAccountInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	memcpy(&taTisBaAccountUpd,&taTosBaAccountInq,sizeof(taTisBaAccountUpd));
	taTisBaAccountUpd.sCmdstat[0]='1';
	if(tis3003.operate == '0')
		taTisBaAccountUpd.sAcctstat[0]='5';
	if(tis3003.operate == '1')
		taTisBaAccountUpd.sAcctstat[0]='3';

	aBaAccountUpdProcess(&taTisBaAccountUpd, &taTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
	
}

void ba3003PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3003), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3003, sizeof(tos3003));
}

void ba3003End()
{
	aBaAccountUpdEnd();
}

void Process_3003(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3003));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3003();
	ba3003End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3003));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3003);
		DbCommitTxn();
	}

	return;
}

