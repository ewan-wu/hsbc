/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   ba3007                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���¼����Ȩ                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            sunfei              Initial                      */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3007_GROUP{
	char 	reqseqno[DLEN_REQSEQNO];
	char 	rejreason[DLEN_REJREASON];
	char 	operate[DLEN_OPERATE];
}tis3007;

static struct TOS3007_GROUP
{
    char cmdStat[DLEN_CMDSTAT];
}tos3007;

static aTisBaRemitUpd		taTisBaRemitUpd;
static aTosBaRemitUpd		taTosBaRemitUpd;

static aTisBaRemitInq		taTisBaRemitInq;
static aTosBaRemitInq		taTosBaRemitInq;

static aTisBaCommonNew		taTisBaCommonNew;
static aTosBaCommonNew		taTosBaCommonNew;

void ba3007Initial(void);
void ba3007Process(void);
void ba3007PutMessage(void);
void getstr(char *s)
{
    while(*s != '\0')
    {
 		if (*s >= 128|| *s < 0)
 		{
 			if (*(s + 1) == '\0')
            	*s = '\0';
        	else
            	s = s + 2;
        }
        else
            s++;
  }
  return;

}

void ba3007(void)
{
	ba3007Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3007Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3007PutMessage();
}

void ba3007Initial(void)
{
	memcpy(&tis3007, it_tita.labtex.text, sizeof(tis3007));
	memset(&tos3007, ' ', sizeof(tos3007));
}

void ba3007PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3007), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3007, sizeof(tos3007));
}

void ba3007End()
{
	aBaCommonNewEnd();
	aBaRemitUpdEnd();
	aBaRemitInqEnd();
}

void ba3007Process(void)
{
	char currentTime[14];
	char tmpXMLfile[2048];
	char crbankname[56+1], dbaccname[68+1], craccname[68+1], post_tmp1[70+1], post_tmp2[68+1], whyuse[28+1];

	
	memset(&taTisBaCommonNew, 0, sizeof(taTisBaCommonNew));
    memset(crbankname, 0, sizeof(crbankname));
    memset(dbaccname, 0, sizeof(dbaccname));
    memset(craccname, 0, sizeof(craccname));
    memset(post_tmp1, 0, sizeof(post_tmp1));
    memset(post_tmp2, 0, sizeof(post_tmp2));
    memset(whyuse, 0, sizeof(whyuse));
	
	memset(currentTime, 0 , sizeof(currentTime));
	memset(tmpXMLfile, 0 , sizeof(tmpXMLfile));
	
	memset(&taTisBaRemitInq, 0 , sizeof(taTisBaRemitInq));
	memset(&taTosBaRemitInq, 0 , sizeof(taTosBaRemitInq));
	
	memset(&taTisBaRemitUpd, 0 , sizeof(taTisBaRemitUpd));
	memset(&taTosBaRemitUpd, 0 , sizeof(taTosBaRemitUpd));
	
 	memcpy(taTisBaRemitInq.sReqseqno, tis3007.reqseqno, DLEN_REQSEQNO);
	aBaRemitInqProcess(&taTisBaRemitInq,&taTosBaRemitInq);
	if(it_txcom.txrsut != TX_SUCCESS)
			return;	 
	
	memcpy(&taTisBaRemitUpd,&taTosBaRemitInq,sizeof(taTisBaRemitUpd));
	
	/*��˲�ͨ��*/
	if(tis3007.operate[0] =='1')
	{
		memcpy(taTisBaRemitUpd.sCmdstat,"3",DLEN_CMDSTAT);
		memcpy(taTisBaRemitUpd.sRejreason,tis3007.rejreason,DLEN_REJREASON);
		memcpy(taTisBaRemitUpd.sChckno,gwdXdtl.sTlrno,DLEN_TELLERNO);
		aBaRemitUpdProcess(&taTisBaRemitUpd,&taTosBaRemitUpd);
		if(it_txcom.txrsut != TX_SUCCESS)
			return;	 
	}
	/*���ͨ��*/
	if(tis3007.operate[0] =='0')
	{
		memcpy(taTisBaRemitUpd.sCmdstat,"2",DLEN_CMDSTAT);
		memcpy(taTisBaRemitUpd.sChckno,gwdXdtl.sTlrno,DLEN_TELLERNO);
		aBaRemitUpdProcess(&taTisBaRemitUpd,&taTosBaRemitUpd);
		if(it_txcom.txrsut != TX_SUCCESS)
			return;

		memcpy(crbankname, taTosBaRemitInq.sCrbankname, 56);
		getstr(crbankname);
    	memcpy(dbaccname,  taTosBaRemitInq.sDbaccname, sizeof(dbaccname)-1);
    	getstr(dbaccname);
    	memcpy(craccname, taTosBaRemitInq.sCraccname, sizeof(craccname)-1);
    	getstr(craccname);
    	memcpy(whyuse, taTosBaRemitInq.sWhyuse, sizeof(whyuse)-1);
    	getstr(whyuse);

		
		/*����COMMON��*/
		memset(&taTisBaCommonNew, 0 , sizeof(taTisBaCommonNew));
		memset(&taTosBaCommonNew, 0 , sizeof(taTosBaCommonNew));
		
		memcpy(taTisBaCommonNew.sReqseqno, tis3007.reqseqno, DLEN_REQSEQNO);
		memcpy(taTisBaCommonNew.sTranscode, "1908", DLEN_TRAMSCODE);
		CommonGetCurrentTime(currentTime);
		memcpy(taTisBaCommonNew.sTrndate, gwdXdtl.sTxday, DLEN_DATE);
		memcpy(taTisBaCommonNew.sReqtime, currentTime+DLEN_DATE, DLEN_TIME);	
		memcpy(taTisBaCommonNew.sCmdsource , "1", DLEN_CMDSOURCE);
		memcpy(taTisBaCommonNew.sResendflag, "0", DLEN_RESENDFLAG); 
		memcpy(taTisBaCommonNew.sCmdstat, "0", DLEN_CMDSTAT);
		memcpy(taTisBaCommonNew.sSendtimes, "0", DLEN_SENDTIMES);
		memcpy(taTisBaCommonNew.sTranscode, "1908", DLEN_TRAMSCODE);
		taTisBaCommonNew.dAmt=taTosBaRemitInq.dAmt;
		
		if(strcmp(taTosBaRemitInq.sTransid, "PM") != 0)
		{
			sprintf(tmpXMLfile,
					"<ap>\n<TransCode>%-4.4s</TransCode>\n<ReqSeqNo>%-30.30s</ReqSeqNo>\n<ReqDate>%-8.8s</ReqDate>\n<ReqTime>%-6.6s</ReqTime>\n<Amt>%17.2f</Amt>\n<Cmp>\n<DbAccNo>%-35.35s</DbAccNo>\n<DbProv>%-2.2s</DbProv>\n<DbCur>%-2.2s</DbCur>\n<DbLogAccNo>%-10.10s</DbLogAccNo>\n<CrAccNo>%-35.35s</CrAccNo>\n<CrProv>%-2.2s</CrProv>\n<CrCur>%-2.2s</CrCur>\n</Cmp>\n<Corp>\n<BookingDate>%-8.8s</BookingDate>\n<BookingTime>%-6.6s</BookingTime>\n<BookingFlag>%-1.1s</BookingFlag>\n<ExchangeType>%-1.1s</ExchangeType>\n<Postscript></Postscript>\n<CustomNo>%-70.70s</CustomNo>\n<ActInf>%-1.1s</ActInf>\n<UrgencyFlag>%-1.1s</UrgencyFlag>\n<OthBankFlag>%-1.1s</OthBankFlag>\n<OthCenterFlag>%-1.1s</OthCenterFlag>\n<CrAccName>%-68.68s</CrAccName>\n<CrBankName>%-56.56s</CrBankName>\n<DbAccName>%-68.68s</DbAccName>\n<DbBankName>%-70.70s</DbBankName>\n<WhyUse>%-28.28s</WhyUse>\n<TransId>%-2.2s</TransId>\n<SpecField1>%-35.35s</SpecField1>\n<SpecField2>%-35.35s</SpecField2>\n<SpecField3>%-35.35s</SpecField3>\n<SpecField4>%-35.35s</SpecField4>\n</Corp>\n</ap>",
					taTisBaCommonNew.sTranscode,taTisBaCommonNew.sReqseqno,
					taTisBaCommonNew.sTrndate,taTisBaCommonNew.sReqtime,(taTisBaCommonNew.dAmt)/100,
					taTosBaRemitInq.sDbaccno+2,taTosBaRemitInq.sDbprov,taTosBaRemitInq.sDbcur,
					taTosBaRemitInq.sDblogaccno,taTosBaRemitInq.sCraccno+2,taTosBaRemitInq.sCrprov,
					taTosBaRemitInq.sCrcur,
					taTosBaRemitInq.sBookingdate,taTosBaRemitInq.sBookingtime,
					taTosBaRemitInq.sBookingflag,taTosBaRemitInq.sExchangetype,taTosBaRemitInq.sCustomno,
					taTosBaRemitInq.sActinf,taTosBaRemitInq.sUrgencyflag,
					taTosBaRemitInq.sOthbankflag,taTosBaRemitInq.sOthcenterflag,
					craccname,crbankname,
					dbaccname,
					taTosBaRemitInq.sDbbankname,whyuse,
					taTosBaRemitInq.sTransid,
					taTosBaRemitInq.sSpecfield1,taTosBaRemitInq.sSpecfield2,
					taTosBaRemitInq.sSpecfield3,taTosBaRemitInq.sSpecfield4);
		}
		else
		{
			cmRightTrim(taTosBaRemitInq.sSpecfield1);
			strcpy(post_tmp1, taTosBaRemitInq.sSpecfield1);
			strcat(post_tmp1, ";");
			strcat(post_tmp1, taTosBaRemitInq.sSpecfield2); 
			memcpy(post_tmp2, post_tmp1, sizeof(post_tmp2) -1);
			getstr(post_tmp2);
			sprintf(tmpXMLfile,
					"<ap>\n<TransCode>%-4.4s</TransCode>\n<ReqSeqNo>%-30.30s</ReqSeqNo>\n<ReqDate>%-8.8s</ReqDate>\n<ReqTime>%-6.6s</ReqTime>\n<Amt>%17.2f</Amt>\n<Cmp>\n<DbAccNo>%-35.35s</DbAccNo>\n<DbProv>%-2.2s</DbProv>\n<DbCur>%-2.2s</DbCur>\n<DbLogAccNo>%-10.10s</DbLogAccNo>\n<CrAccNo>%-35.35s</CrAccNo>\n<CrProv>%-2.2s</CrProv>\n<CrCur>%-2.2s</CrCur>\n</Cmp>\n<Corp>\n<BookingDate>%-8.8s</BookingDate>\n<BookingTime>%-6.6s</BookingTime>\n<BookingFlag>%-1.1s</BookingFlag>\n<ExchangeType>%-1.1s</ExchangeType>\n<Postscript>%-68.68s</Postscript>\n<CustomNo>%-70.70s</CustomNo>\n<ActInf>%-1.1s</ActInf>\n<UrgencyFlag>%-1.1s</UrgencyFlag>\n<OthBankFlag>%-1.1s</OthBankFlag>\n<OthCenterFlag>%-1.1s</OthCenterFlag>\n<CrAccName>%-68.68s</CrAccName>\n<CrBankName>%-56.56s</CrBankName>\n<DbAccName>%-68.68s</DbAccName>\n<DbBankName>%-70.70s</DbBankName>\n<WhyUse>%-30.30s</WhyUse>\n<TransId>%-2.2s</TransId>\n<SpecField1>%-35.35s</SpecField1>\n<SpecField2>%35.35s</SpecField2>\n<SpecField3></SpecField3>\n<SpecField4></SpecField4>\n</Corp>\n</ap>",
					taTisBaCommonNew.sTranscode,taTisBaCommonNew.sReqseqno,
					taTisBaCommonNew.sTrndate,taTisBaCommonNew.sReqtime,(taTisBaCommonNew.dAmt)/100,
					taTosBaRemitInq.sDbaccno+2,taTosBaRemitInq.sDbprov,taTosBaRemitInq.sDbcur,
					taTosBaRemitInq.sDblogaccno,taTosBaRemitInq.sCraccno+2,taTosBaRemitInq.sCrprov,
					taTosBaRemitInq.sCrcur,
					taTosBaRemitInq.sBookingdate,taTosBaRemitInq.sBookingtime,
					taTosBaRemitInq.sBookingflag,taTosBaRemitInq.sExchangetype,
					post_tmp2,taTosBaRemitInq.sCustomno,
					taTosBaRemitInq.sActinf,taTosBaRemitInq.sUrgencyflag,
					taTosBaRemitInq.sOthbankflag,taTosBaRemitInq.sOthcenterflag,
					craccname,crbankname,
					dbaccname,
					taTosBaRemitInq.sDbbankname,whyuse,
					taTosBaRemitInq.sTransid,
					taTosBaRemitInq.sSpecfield1,taTosBaRemitInq.sSpecfield2);
		}
		memcpy(taTisBaCommonNew.sReqmsg,tmpXMLfile,strlen(tmpXMLfile));

		aBaCommonNewProcess(&taTisBaCommonNew, &taTosBaCommonNew);
		if(it_txcom.txrsut != TX_SUCCESS)
			return;
	}		
	memcpy(tos3007.cmdStat, taTosBaRemitUpd.sCmdstat,DLEN_CMDSTAT);
}

void Process_3007(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3007));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3007();
	ba3007End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3007));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3007);
		DbCommitTxn();
	}

	return;
}
