/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   ba3006                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: ���¼�븴��                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200712            chenyp				Initial                     */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3006_GROUP{
	char 	reqseqno[DLEN_REQSEQNO];
	char 	rejreason[DLEN_REJREASON];
	char 	operate[DLEN_OPERATE];
}tis3006;

static struct TOS3006_GROUP
{
    char cmdStat[DLEN_CMDSTAT];
}tos3006;

static aTisBaRemitUpd		taTisBaRemitUpd;
static aTosBaRemitUpd		taTosBaRemitUpd;

static aTisBaRemitInq		taTisBaRemitInq;
static aTosBaRemitInq		taTosBaRemitInq;

void ba3006Initial(void);
void ba3006Process(void);
void ba3006PutMessage(void);

void ba3006(void)
{
	ba3006Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3006Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3006PutMessage();
}

void ba3006Initial(void)
{
	memcpy(&tis3006, it_tita.labtex.text, sizeof(tis3006));
	memset(&tos3006, ' ', sizeof(tos3006));
}

void ba3006PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3006), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3006, sizeof(tos3006));
}

void ba3006End()
{
	aBaRemitUpdEnd();
	aBaRemitInqEnd();
}

void ba3006Process(void)
{
	memset(&taTisBaRemitInq, 0 , sizeof(taTisBaRemitInq));
	memset(&taTosBaRemitInq, 0 , sizeof(taTosBaRemitInq));
	
	memset(&taTisBaRemitUpd, 0 , sizeof(taTisBaRemitUpd));
	memset(&taTosBaRemitUpd, 0 , sizeof(taTosBaRemitUpd));
	
 	memcpy(taTisBaRemitInq.sReqseqno, tis3006.reqseqno, DLEN_REQSEQNO);
	aBaRemitInqProcess(&taTisBaRemitInq,&taTosBaRemitInq);
	if(it_txcom.txrsut != TX_SUCCESS)
			return;	 

	memcpy(&taTisBaRemitUpd,&taTosBaRemitInq,sizeof(taTisBaRemitUpd));
	
	/*���˲�ͨ��*/
	if(tis3006.operate[0] =='1')
	{
		memcpy(taTisBaRemitUpd.sCmdstat,"4",DLEN_CMDSTAT);
		memcpy(taTisBaRemitUpd.sRejreason,tis3006.rejreason,DLEN_REJREASON);
		memcpy(taTisBaRemitUpd.sApvno,gwdXdtl.sTlrno,DLEN_TELLERNO);
		aBaRemitUpdProcess(&taTisBaRemitUpd,&taTosBaRemitUpd);
		if(it_txcom.txrsut != TX_SUCCESS)
			return;	 
	}
	/*����ͨ��*/
	if(tis3006.operate[0] =='0')
	{
		memcpy(taTisBaRemitUpd.sCmdstat,"1",DLEN_CMDSTAT);
		memcpy(taTisBaRemitUpd.sApvno,gwdXdtl.sTlrno,DLEN_TELLERNO);
		aBaRemitUpdProcess(&taTisBaRemitUpd,&taTosBaRemitUpd);
		if(it_txcom.txrsut != TX_SUCCESS)
			return;
	}		
	memcpy(tos3006.cmdStat, taTosBaRemitUpd.sCmdstat,DLEN_CMDSTAT);
}

void Process_3006(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3006));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3006();
	ba3006End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, "���ݿ����������", 16);
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3006));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3006);
		DbCommitTxn();
	}

	return;
}

