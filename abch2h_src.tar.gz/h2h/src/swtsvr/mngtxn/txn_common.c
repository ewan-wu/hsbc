/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "mngtxn.h"

void Process_MoveTotaCommon(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf);
int CheckPasswordDuplicate(char *sNew, char *sRecent);
void RecordRecentPswdStr(char *sNew, char *sRecent);
void vPswdErrLogInsert(struct wd_btlrctl_area *pwd_btlrctl, char *sWorkDate, char cRetry, char *sError);
int nNewRetrySeq(char *sRetrySeq);


void Process_MoveTotaCommon(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf)
{
	memcpy(ptMngOutBuf->tTotaLabel.header, ptMngInBuf->tTitaLabel.header, 
		sizeof(ptMngOutBuf->tTotaLabel.header));
	memcpy(ptMngOutBuf->tTotaLabel.clsno, ptMngInBuf->tTitaLabel.clsno, 
		sizeof(ptMngOutBuf->tTotaLabel.clsno));
	memcpy(ptMngOutBuf->tTotaLabel.termid, ptMngInBuf->tTitaLabel.termid, 
		sizeof(ptMngOutBuf->tTotaLabel.termid));
	memcpy(ptMngOutBuf->tTotaLabel.kinbr, ptMngInBuf->tTitaLabel.kinbr, 
		sizeof(ptMngOutBuf->tTotaLabel.kinbr));
	memcpy(ptMngOutBuf->tTotaLabel.trmseq, ptMngInBuf->tTitaLabel.trmseq, 
		sizeof(ptMngOutBuf->tTotaLabel.trmseq));
	ptMngOutBuf->tTotaLabel.tmtype = ptMngInBuf->tTitaLabel.tmtype ;
	memcpy(ptMngOutBuf->tTotaLabel.taskid, ptMngInBuf->tTitaLabel.taskid, 
		sizeof(ptMngOutBuf->tTotaLabel.taskid));
	memcpy(ptMngOutBuf->tTotaLabel.txno, ptMngInBuf->tTitaLabel.txno, 
		sizeof(ptMngOutBuf->tTotaLabel.txno));
	memcpy(ptMngOutBuf->tTotaLabel.tlrno, ptMngInBuf->tTitaLabel.tlrno, 
		sizeof(ptMngOutBuf->tTotaLabel.tlrno));
	memcpy(ptMngOutBuf->tTotaLabel.ejfno, ptMngInBuf->tTitaLabel.ejfno, 
		sizeof(ptMngOutBuf->tTotaLabel.ejfno));

	memcpy(ptMngOutBuf->tTotaLabel.txdate, gsDBTxdate,
		sizeof(ptMngOutBuf->tTotaLabel.txdate));
	/*
	GetGlobalTxtime();
	*/
	{
		char sTime[14+1];
		CommonGetCurrentTime(sTime);
		memcpy(gsDBTxtime, sTime+8, 6);
		gsDBTxtime[6] = 0;
	}
	memcpy(ptMngOutBuf->tTotaLabel.txtime, gsDBTxtime,
		sizeof(ptMngOutBuf->tTotaLabel.txtime));

	ptMngOutBuf->tTotaLabel.msgend = '0';
	ptMngOutBuf->tTotaLabel.msgtype = ptMngInBuf->tTitaLabel.taskid[1];
	memcpy(ptMngOutBuf->tTotaLabel.msgno, ptMngInBuf->tTitaLabel.txno, 
		sizeof(ptMngOutBuf->tTotaLabel.msgno));
	memcpy(ptMngOutBuf->tTotaLabel.msglng, "0000", 4);
}


/********************/
/* 0      - not dup */
/* -1     - dup     */
/* others - error   */
/********************/
int CheckPasswordDuplicate(char *sNew, char *sRecent)
{
	char	sRecentStr[BTLRCTL_PASSWORD_MAX_LENGTH*BTLRCTL_PASSWORD_MAX_HIS+1];
	char	sCmpStr[BTLRCTL_PASSWORD_MAX_LENGTH+1];
	int		i;

	if (strlen(sNew) < BTLRCTL_PASSWORD_MAX_LENGTH) return -2;

	if (strlen(sRecent) > BTLRCTL_PASSWORD_MAX_LENGTH*BTLRCTL_PASSWORD_MAX_HIS)
		return -3;

	memset(sRecentStr, ' ', sizeof(sRecentStr)-1);
	sRecentStr[sizeof(sRecentStr)-1] = 0;
	memcpy(sRecentStr, sRecent, strlen(sRecent));

	for (i = 0; i < BTLRCTL_PASSWORD_MAX_HIS; i ++)
	{
		memcpy(sCmpStr, 
			sRecentStr+i*BTLRCTL_PASSWORD_MAX_LENGTH, 
			BTLRCTL_PASSWORD_MAX_LENGTH);
		
		if (memcmp(sNew, sCmpStr, BTLRCTL_PASSWORD_MAX_LENGTH) == 0)
			return -1;
	}

	return 0;
}

void RecordRecentPswdStr(char *sNew, char *sRecent)
{
	char	sRecentStr[BTLRCTL_PASSWORD_MAX_LENGTH*BTLRCTL_PASSWORD_MAX_HIS+BTLRCTL_PASSWORD_MAX_LENGTH+1];

	if (strlen(sNew) < BTLRCTL_PASSWORD_MAX_LENGTH) return;

	if (strlen(sRecent) > BTLRCTL_PASSWORD_MAX_LENGTH*BTLRCTL_PASSWORD_MAX_HIS)
		return;

	memset(sRecentStr, ' ', sizeof(sRecentStr)-1);
	sRecentStr[sizeof(sRecentStr)-1] = 0;

	memcpy(sRecentStr, sNew, BTLRCTL_PASSWORD_MAX_LENGTH);
	memcpy(sRecentStr+BTLRCTL_PASSWORD_MAX_LENGTH, sRecent, strlen(sRecent));
	sRecentStr[BTLRCTL_PASSWORD_MAX_LENGTH*BTLRCTL_PASSWORD_MAX_HIS] = 0;

	strcpy(sRecent, sRecentStr);

	return;
}


void vPswdErrLogInsert(struct wd_btlrctl_area *pwd_btlrctl, char *sWorkDate, char cRetry, char *sError)
{
	struct wd_btlrpswderr_area wd_btlrpswderr;
	char sRetrySeq[8+1];
	char sTime[14+1];

	memset(&wd_btlrpswderr, 0, sizeof(wd_btlrpswderr));
	memset(sRetrySeq, 0, sizeof(sRetrySeq));

	/* get retry sequence number */
	if (nNewRetrySeq(sRetrySeq) == 0)
	{
		memcpy(wd_btlrpswderr.retryseq, sRetrySeq, 8);
	}
	else
	{
		return;
	}

	memcpy(wd_btlrpswderr.dept_id, pwd_btlrctl->dept_id, 
		sizeof(wd_btlrpswderr.dept_id) - 1);
	memcpy(wd_btlrpswderr.tlr_id, pwd_btlrctl->tlr_id, 
		sizeof(wd_btlrpswderr.tlr_id) - 1);
	CommonGetCurrentTime(sTime);
	memcpy(wd_btlrpswderr.local_time, sTime, 
		sizeof(wd_btlrpswderr.local_time) - 1);
	memcpy(wd_btlrpswderr.work_date, sWorkDate, 
		sizeof(wd_btlrpswderr.work_date) - 1);
	wd_btlrpswderr.retry[0] = cRetry;
	if (strlen(sError) >= sizeof(wd_btlrpswderr.memo))
	{
		memcpy(wd_btlrpswderr.memo, sError, 
			sizeof(wd_btlrpswderr.memo) - 1);
	}
	else
	{
		memcpy(wd_btlrpswderr.memo, sError, strlen(sError));
	}
	
	DbsBTLRPSWDERR(DBS_INSERT, &wd_btlrpswderr);

	return;
}

int nNewRetrySeq(char *sRetrySeq)
{
	long	lPid;
	short	nRet;
	SwtToSEQReqDef		tSwtTocSeq;

	lPid = getpid();

	memset(&tSwtTocSeq, 0, sizeof(tSwtTocSeq));

	tSwtTocSeq.MsgType=CI_TOCTL_SEQ;
	tSwtTocSeq.nMsgCode=lPid;
	tSwtTocSeq.nSwitchPID=lPid;
	tSwtTocSeq.nReplyCode=0;
	tSwtTocSeq.nSeqLen=0;
	memset(tSwtTocSeq.sSeqStr, '0', sizeof(tSwtTocSeq.sSeqStr));
	memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_RETRYSEQ, 
		sizeof(tSwtTocSeq.sSeqType));

	nRet=SwtSnd2ToSEQ(&tSwtTocSeq);
	printf("nReturnCode SwtSnd2ToSEQ=[%d],nReplyCode=[%d]\n", 
		nRet, tSwtTocSeq.nReplyCode);
	if (nRet!=0)
	{
		return -1;
	}
	if (tSwtTocSeq.nReplyCode!=0)
	{
		return -2;
	}
	memcpy ( sRetrySeq, tSwtTocSeq.sSeqStr, tSwtTocSeq.nSeqLen);
	sRetrySeq[tSwtTocSeq.nSeqLen] = 0;
	printf("SwtSnd2ToSEQ sRetrySeq[%s]\n",sRetrySeq);
	
	return 0;
}

