/************************************************************************/
/*                                                                      */
/* Product: Top Kernel Banking System                                   */
/*          transaction logic module                                    */
/*   be3002                                                             */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Description: �ʻ�¼����Ȩ                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* Modification log:                                                    */
/*                                                                      */
/*     Date            Author              Description                  */
/*   --------       -----------          -----------------              */
/*   200711            bingliang.wu              Initial                */
/************************************************************************/
#include "mngtxn.h"

static struct TIS3002_GROUP{
	char  acct[DLEN_ACC];
	char  nopassreason[30];	
	char  operate;
}tis3002;

static struct TOS3002_GROUP
{
	char null; 
} tos3002;


static aTisBaAccountInq 			taTisBaAccountInq;
static aTosBaAccountInq				taTosBaAccountInq;

static aTisBaAccountUpd 			taTisBaAccountUpd;
static aTosBaAccountUpd				taTosBaAccountUpd;

void ba3002Initial(void);
void ba3002Process(void);
void ba3002PutMessage(void);

void ba3002(void)
{
	ba3002Initial();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3002Process();
	if(it_txcom.txrsut != TX_SUCCESS)
		return;

	ba3002PutMessage();
}

void ba3002Initial(void)
{
	memcpy(&tis3002, it_tita.labtex.text, sizeof(tis3002));
	memset(&tos3002, ' ', sizeof(tos3002));
}

void ba3002PutMessage(void)
{
	balMvBasic();

	TOTW.msgend = '1';
	TOTW.msgtype = TITA.taskid[1];
	memcpy(TOTW.msgno, TITA.txno, DLEN_TXNCD);
	apitoa(TOTA_LABEL_LENGTH + sizeof(tos3002), sizeof(TOTW.msglng), TOTW.msglng);
	memcpy(TOTW.tlsrno, gwdXdtl.sTlsrno, DLEN_TLSRNO);

	memcpy(it_totw.labtex.text, &tos3002, sizeof(tos3002));
}

void ba3002End()
{
	aBaAccountInqEnd();
	aBaAccountUpdEnd();
}

void ba3002Process(void)
{ memset(&taTisBaAccountInq, 0, sizeof(taTisBaAccountInq));
	memset(&taTosBaAccountInq, 0, sizeof(taTosBaAccountInq));
	
  memset(&taTisBaAccountUpd, 0, sizeof(taTisBaAccountUpd));
	memset(&taTosBaAccountUpd, 0, sizeof(taTosBaAccountUpd));
	
	memcpy(taTisBaAccountInq.sAcct, tis3002.acct, DLEN_ACC);

	aBaAccountInqProcess(&taTisBaAccountInq, &taTosBaAccountInq);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
		
  memcpy(&taTisBaAccountUpd,&taTosBaAccountInq,sizeof(taTisBaAccountUpd));
  
  if(tis3002.operate=='0'){
  	memcpy(taTisBaAccountUpd.sCmdstat, "2", DLEN_CMDSTAT);
    memcpy(taTisBaAccountUpd.sAcctstat, "0", DLEN_ACCTSTAT);  
  }else{
  	memcpy(taTisBaAccountUpd.sCmdstat, "3", DLEN_CMDSTAT);
    memcpy(taTisBaAccountUpd.sAcctstat, "4", DLEN_ACCTSTAT);  
    memcpy(taTisBaAccountUpd.sRejreason, tis3002.nopassreason, sizeof(tis3002.nopassreason)); 
  }
  
  memcpy(taTisBaAccountUpd.sChckno, gwdXdtl.sTlrno, DLEN_TELLERNO);  
  printf("taTisBaAccountUpd.Customid=%s\n", taTisBaAccountUpd.sCustomid);
  printf("taTisBaAccountUpd.acct=%s\n", taTisBaAccountUpd.sAcct);
  
  aBaAccountUpdProcess(&taTisBaAccountUpd, &taTosBaAccountUpd);
	if(it_txcom.txrsut != TX_SUCCESS)
		return;
  
}

void Process_3002(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	memcpy(it_tita.labtex.text, ptMngInBuf->sTitaText, sizeof(tis3002));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	it_txcom.txrsut = TX_SUCCESS;

	ba3002();
	ba3002End();

	if(it_txcom.txrsut != TX_SUCCESS)
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		memcpy(ptMngOutBuf->sTotaText, gsErrDesc, strlen(gsErrDesc));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(gsErrDesc);
		DbRollbackTxn();
	}
	else
	{
		memcpy(ptMngOutBuf->sTotaText, it_totw.labtex.text, sizeof(tos3002));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos3002);
		DbCommitTxn();
	}

	return;
}

