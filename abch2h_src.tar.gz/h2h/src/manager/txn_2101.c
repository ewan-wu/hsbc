/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2101(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2101_GROUP
	{
		char	null;
	} tis2101;
	static struct TOS2101_GROUP
	{
		char	status;
		char	date[8];
	} tos2101;

	/* work */
	struct wd_bsysctl_area	wd_bsysctl;

	memset(&tis2101, 0, sizeof(tis2101));
	memset(&tos2101, 0, sizeof(tos2101));

	memcpy(&tis2101, ptMngInBuf->sTitaText, sizeof(tis2101));
	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, "DBBRGSYS", sizeof(wd_bsysctl.rcd_id));

	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
			char sError[256];
			strcpy(sError, "�кſ��Ʊ�������");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	memcpy(wd_bsysctl.eft_status, "1", sizeof(wd_bsysctl.eft_status));
	CommonGetCurrentTimeDB(wd_bsysctl.rec_updt_time);

	if (DbsBSYSCTL(DBS_IUPD, &wd_bsysctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
			char sError[256];
			strcpy(sError, "ǩ��ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */
		tos2101.status = wd_bsysctl.eft_status[0];
		memcpy(tos2101.date, wd_bsysctl.work_date, 8);
		memcpy(ptMngOutBuf->sTotaText, &tos2101, sizeof(tos2101));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2101);
		DbCommitTxn();
		return;
	}
}

