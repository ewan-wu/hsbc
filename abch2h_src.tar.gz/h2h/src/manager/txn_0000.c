/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_0000(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS0000_GROUP
	{
		char	null;
	} tis0000;
	static struct TOS0000_GROUP
	{
		char	tbsdy[8];
		char	time[6];
	} tos0000;

	/* work */
	/*struct wd_bdeptctl_area	wd_bdeptctl;*/
	struct wd_bsysctl_area	wd_bsysctl;

	memset(&tis0000, 0, sizeof(tis0000));
	memset(&tos0000, 0, sizeof(tos0000));

	memcpy(&tis0000, ptMngInBuf->sTitaText, sizeof(tis0000));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		memcpy(tos0000.tbsdy, wd_bsysctl.work_date, sizeof(tos0000.tbsdy));
	}
	else
	{
		memcpy(tos0000.tbsdy, gsDBTxdate, sizeof(tos0000.tbsdy));
	}

	{
		char sTime[14+1];
		CommonGetCurrentTime(sTime);
		memcpy(gsDBTxtime, sTime+8, 6);
		gsDBTxtime[6] = 0;
	}
	/*
	GetGlobalTxtime();
	*/
	memcpy(tos0000.time, gsDBTxtime, sizeof(tos0000.time));
	
	memcpy(ptMngOutBuf->sTotaText, &tos0000, sizeof(tos0000));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos0000);

	return;
}


