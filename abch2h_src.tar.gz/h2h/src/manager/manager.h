#ifndef _MANAGER_H
#define _MANAGER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>
#include <math.h>
#include <signal.h>
#include <malloc.h>
#include <memory.h>
#include <assert.h>
#include <errno.h>

#include "ipc.h"
#include "sysdef.h"
#include "msglog.h"
#include "glb_dic.h"
#include "wd_incl.h"
#include "status.h"
#include "sys_wd.h"
#include "sys_def.h"
#include "sys_itf.h"
#include "glb_def.h"
#include "glb_ext.h"
#include "swttoc.h"

#define MAX_CNTRSTLM_COUNT        1

/* commands from pc console */
#define CMD_COMM_START 		10
#define CMD_COMM_END 		11
#define CMD_BATCH_START 	12

#define BUF_MAX_SIZE 8192
#define TITA_TEXT_MAX 5*1024
#define TOTA_TEXT_MAX 5*1024

#define ShowError(string) printf("%s", string)

typedef struct
{
	long MsgType;
	long nMsgCode;
	char sText[BUF_MAX_SIZE];
} CmdMsgDef;

typedef struct
{
	T_IPCHeader   tIPCHeader;
	T_TitaLabel   tTitaLabel;
	char          sTitaText[TITA_TEXT_MAX];
} T_MngBufFromTlrDef;

typedef struct
{
	T_TotaLabel   tTotaLabel;
	char          sTotaText[TOTA_TEXT_MAX];
} T_MngBufToTlrDef;

typedef struct
{
	 char  sTxnId[6];
	 char  sApFunLen[2];
	 char  sApFun[16];
	 char  sApTimeOut[2];
	 char  sUserDef[12];
	 char  sSessionHeader[8];
	 char  sDataBuf[BUF_MAX_SIZE];
} MsgToHostDef;

void vConSwtProcess(void *);
void HandleExit();
void SendConsole( char *, int );

#endif /* _MANAGE_H */
