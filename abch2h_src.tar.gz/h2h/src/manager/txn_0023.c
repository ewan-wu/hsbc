/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_0023(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS0023_GROUP
	{
		/*char	dept_id;*/
		char	ipaddr[15];
	} tis0023;
	static struct TOS0023_GROUP
	{
		char	dummy;
	} tos0023;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;

	memset(&tis0023, 0, sizeof(tis0023));
	memset(&tos0023, 0, sizeof(tos0023));

	memcpy(&tis0023, ptMngInBuf->sTitaText, sizeof(tis0023));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	/*wd_btlrctl.dept_id[0] = tis0023.dept_id;*/
	memcpy(wd_btlrctl.tlr_id, ptMngInBuf->tTitaLabel.tlrno, 
		sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, gwdXdtl.sKinbr,  DLEN_BRNO);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) == 0)
	{
		/* succeed */
		if (wd_btlrctl.work_flag[0] == BTLRCTL_WORK_FLAG_OFF)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "ǩ��ʧ�ܣ��ò���Ա���ɹ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "ǩ��ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	wd_btlrctl.status[0] = BTLRCTL_STATUS_LOG_OFF;
	CommonGetCurrentDate(wd_btlrctl.last_status_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "ǩ��ʧ�ܣ��޸Ĳ���Ա״̬ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator logoff */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = wd_btlrctl.dept_id[0];
		memcpy(wd_bsignlog.tlr_id, ptMngInBuf->tTitaLabel.tlrno, 
			sizeof(wd_bsignlog.tlr_id)-1);
		memcpy(wd_bsignlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_SIGNOFF;
		memcpy(wd_bsignlog.act_data, tis0023.ipaddr, sizeof(tis0023.ipaddr));
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "ǩ��ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(ptMngOutBuf->sTotaText, &tos0023, sizeof(tos0023));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos0023);
			DbCommitTxn();

			return;
		}
	}
}


