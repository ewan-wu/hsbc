/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2010(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2010_GROUP
	{
		char	dept_id;
		char	tlr_id[8];
		char	old_pswd[12];
		char	new_pswd[12];
	} tis2010;
	static struct TOS2010_GROUP
	{
		char	tlr_name[40];
	} tos2010;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;
	char sPswd0[21];
	char sPswd1[21];
	int iRet;

	memset(&tis2010, 0, sizeof(tis2010));
	memset(&tos2010, 0, sizeof(tos2010));

	memcpy(&tis2010, ptMngInBuf->sTitaText, sizeof(tis2010));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	wd_btlrctl.dept_id[0] = tis2010.dept_id;
	memcpy(wd_btlrctl.tlr_id, tis2010.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, gwdXdtl.sKinbr, DLEN_BRNO);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) == 0)
	{
		/* succeed */
		if (wd_btlrctl.work_flag[0] == BTLRCTL_WORK_FLAG_OFF)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ��ò���Ա���ɹ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		/* check password */
		memset(sPswd0, 0, sizeof(sPswd0));
		memcpy(sPswd0, tis2010.old_pswd, sizeof(tis2010.old_pswd));
		memset(sPswd1, ' ', sizeof(sPswd1));
		memcpy(sPswd1, sPswd0, strlen(sPswd0));
		sPswd1[sizeof(wd_btlrctl.password)-1] = 0;
		if (memcmp(wd_btlrctl.password, sPswd1, 
			sizeof(tis2010.old_pswd)) != 0)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ�����Ա���������");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		/* check password duplicated */
		memset(sPswd0, 0, sizeof(sPswd0));
		memcpy(sPswd0, tis2010.new_pswd, sizeof(tis2010.new_pswd));
		memset(sPswd1, ' ', sizeof(sPswd1));
		memcpy(sPswd1, sPswd0, strlen(sPswd0));
		sPswd1[sizeof(wd_btlrctl.password)-1] = 0;
		if (CheckPasswordDuplicate(sPswd1, wd_btlrctl.recent_pswd_str) != 0)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ�����Ա������������ʷ��¼�ظ���");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "������ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	memcpy(wd_btlrctl.password, tis2010.new_pswd, sizeof(tis2010.new_pswd));
	CommonGetCurrentDate(wd_btlrctl.last_pswd_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	memset(sPswd0, 0, sizeof(sPswd0));
	memcpy(sPswd0, tis2010.new_pswd, sizeof(tis2010.new_pswd));
	memset(sPswd1, ' ', sizeof(sPswd1));
	memcpy(sPswd1, sPswd0, strlen(sPswd0));
	RecordRecentPswdStr(sPswd1, wd_btlrctl.recent_pswd_str);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "������ʧ�ܣ����²���Ա����ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator password change */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = tis2010.dept_id;
		memcpy(wd_bsignlog.tlr_id, tis2010.tlr_id, sizeof(tis2010.tlr_id));
		memcpy(wd_bsignlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_CHGPSWD;
		memcpy(wd_bsignlog.act_data, 
			tis2010.old_pswd, sizeof(tis2010.old_pswd));
		memcpy(wd_bsignlog.act_data + sizeof(tis2010.old_pswd), 
			tis2010.new_pswd, sizeof(tis2010.new_pswd));
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos2010.tlr_name, wd_btlrctl.tlr_name, sizeof(tos2010.tlr_name));
			memcpy(ptMngOutBuf->sTotaText, &tos2010, sizeof(tos2010));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2010);
			DbCommitTxn();

			return;
		}
	}
}


