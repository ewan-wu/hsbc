/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2008(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2008_GROUP
	{
		char	opind;
		char	brh_id[3];		/*���к�*/
		char	tlr_id[8];
		char	by_dept_id;
		char	by_tlr_id[8];
		char	flag;		
	} tis2008;
	static struct TOS2008_GROUP
	{
		char	dummy;
	} tos2008;

	int iRet = 0;
	char act_data[16 + 1];

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_btlrctl_tmp_area	wd_btlrctl_tmp;
	struct wd_bscmlog_area	wd_bscmlog;

	memset(&tis2008, 0, sizeof(tis2008));
	memset(&tos2008, 0, sizeof(tos2008));

	memcpy(&tis2008, ptMngInBuf->sTitaText, sizeof(tis2008));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	memset(&wd_btlrctl_tmp, 0, sizeof(wd_btlrctl_tmp));
	wd_btlrctl_tmp.opcode[0] = tis2008.opind;		
	memcpy(wd_btlrctl_tmp.tlr_id, tis2008.tlr_id, sizeof(tis2008.tlr_id));
	memcpy(wd_btlrctl_tmp.brno, tis2008.brh_id, DLEN_BRNO);
	
	iRet = DbsBTLRCTL_TMP(DBS_FIND, &wd_btlrctl_tmp);
	if (iRet != 0)
	{
		/* insert fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����Ա��Ϣ��˱���ѯʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	if (tis2008.flag == '0'){
		if (tis2008.opind == 'I'){
			/*memcpy(&wd_btlrctl,&wd_btlrctl_tmp+2,sizeof(wd_btlrctl));
			��ֵ*/
			memcpy(wd_btlrctl.tlr_id, wd_btlrctl_tmp.tlr_id, sizeof(wd_btlrctl_tmp.tlr_id));
			memcpy(wd_btlrctl.brno, wd_btlrctl_tmp.brno, DLEN_BRNO);
			wd_btlrctl.dept_id[0] = wd_btlrctl_tmp.dept_id[0]; 
			memcpy(wd_btlrctl.tlr_name, wd_btlrctl_tmp.tlr_name, sizeof(wd_btlrctl_tmp.tlr_name));
			wd_btlrctl.work_flag[0] = wd_btlrctl_tmp.work_flag[0];
			wd_btlrctl.work_level[0] = '0';
			memcpy(wd_btlrctl.password, wd_btlrctl_tmp.password, sizeof(wd_btlrctl_tmp.password));
			CommonGetCurrentDate(wd_btlrctl.last_pswd_chg);
			wd_btlrctl.status[0] = BTLRCTL_STATUS_LOG_OFF;
			wd_btlrctl.init_flag[0] = BTLRCTL_INIT_FLAG_OFF;
			CommonGetCurrentDate(wd_btlrctl.last_status_chg);
			CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
			wd_btlrctl.add_by_dept_id[0] = wd_btlrctl_tmp.add_by_dept_id[0];
			memcpy(wd_btlrctl.add_by_tlr_id, wd_btlrctl_tmp.add_by_tlr_id, 
				sizeof(wd_btlrctl_tmp.add_by_tlr_id));
			wd_btlrctl.auth_by_dept_id[0] = tis2008.by_dept_id;
			memcpy(wd_btlrctl.auth_by_tlr_id, tis2008.by_tlr_id, 
				sizeof(tis2008.by_tlr_id));
			memcpy(wd_btlrctl.recent_pswd_str, wd_btlrctl_tmp.recent_pswd_str, 
			sizeof(wd_btlrctl_tmp.recent_pswd_str));
			
			
			
			iRet = DbsBTLRCTL(DBS_INSERT, &wd_btlrctl);
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣ������ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}	
		}
		if (tis2008.opind == 'U'){
			memcpy(wd_btlrctl.tlr_id, tis2008.tlr_id, sizeof(tis2008.tlr_id));
			memcpy(wd_btlrctl.brno, tis2008.brh_id, DLEN_BRNO);
			iRet = DbsBTLRCTL(DBS_FIND, &wd_btlrctl);
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣ����ѯʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}
			wd_btlrctl.dept_id[0] = wd_btlrctl_tmp.dept_id[0]; 
			memcpy(wd_btlrctl.tlr_name, wd_btlrctl_tmp.tlr_name, sizeof(wd_btlrctl_tmp.tlr_name));
			wd_btlrctl.work_flag[0] = wd_btlrctl_tmp.work_flag[0];
			CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
			iRet = DbsBTLRCTL(DBS_IUPD, &wd_btlrctl);
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣ������ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}		
		}
			
		if (tis2008.opind == 'M'){
			memcpy(wd_btlrctl.tlr_id, tis2008.tlr_id, sizeof(tis2008.tlr_id));
			memcpy(wd_btlrctl.brno, tis2008.brh_id, DLEN_BRNO);
			iRet = DbsBTLRCTL(DBS_FIND, &wd_btlrctl);
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣ����ѯʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}
			CommonGetCurrentDate(wd_btlrctl.last_pswd_chg);
			memcpy(wd_btlrctl.password, wd_btlrctl_tmp.password, sizeof(wd_btlrctl_tmp.password));
			iRet = DbsBTLRCTL(DBS_IUPD, &wd_btlrctl);
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣ���������ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}			
		}
			
		if (tis2008.opind == 'D'){
		memcpy(wd_btlrctl.tlr_id, tis2008.tlr_id, sizeof(tis2008.tlr_id));
		memcpy(wd_btlrctl.brno, tis2008.brh_id, DLEN_BRNO);
		iRet = DbsBTLRCTL(DBS_FIND, &wd_btlrctl);
		if (iRet != 0)
		{
			/* insert fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����Ա��Ϣ����ѯʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		iRet = DbsBTLRCTL(DBS_IDEL, &wd_btlrctl);
		if (iRet != 0)
		{
			/* insert fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����Ա��Ϣ��ɾ��ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}			
		}	
	}
	iRet = DbsBTLRCTL_TMP(DBS_IDEL, &wd_btlrctl_tmp);
	if (iRet != 0)
	{
		/* insert fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����Ա��Ϣ��˱���ѯɾ��ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
			/* succeed */
	memset(&wd_bscmlog, 0, sizeof(wd_bscmlog));
	wd_bscmlog.dept_id[0] = '-';
	memcpy(wd_bscmlog.brno, tis2008.brh_id, DLEN_BRNO); 
	CommonGetCurrentTimeDB(wd_bscmlog.act_time);
	wd_bscmlog.act_type[0] = BSCMLOG_ACTION_TYPE_APR;
	wd_bscmlog.act_subtype[0] = tis2008.opind;
	memset(act_data, ' ', sizeof(act_data));
	sprintf(act_data, "%-8.8s%-8.8s", gwdXdtl.sTlrno, tis2008.tlr_id);
	memcpy(wd_bscmlog.act_data, act_data, 16);
	CommonGetCurrentTimeDB(wd_bscmlog.rec_updt_time);

	if (DbsBSCMLOG(DBS_INSERT, &wd_bscmlog) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����Ա��Ϣά������¼ά����־ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */
		memcpy(ptMngOutBuf->sTotaText, &tos2008, sizeof(tos2008));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2008);
		DbCommitTxn();
		return;
	}
}
