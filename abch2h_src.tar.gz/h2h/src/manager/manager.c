/************************************************************************
* Name      :    MANAGE                                                 *
*************************************************************************/
#include "manager_main.h"

char ErrorDescription[51];

void vCnapsProcess( void *sTrans);
void vTellerProcess(void *sTrans);

#ifdef _CNAPS_HVPS
void vProcessCMT418(T_CnsSwtTitaDef *pCnsReq);
void vProcessCMT417(T_CnsSwtTitaDef *pCnsReq);
#endif

void HandleExit( )
{
	DebugMemory( "Exit Handled");
}

void main(short argc, char **argv)
{
	long lReturn;
	short nRet;
	short nDataLen;
	long lMsgSource;
	CmdMsgDef ipcMsg;
	char cTime[14];

	atexit( HandleExit );
	setbuf( stdout, NULL );
	sigset( SIGCLD, SIG_IGN );   
	printf( "Command Server started, pid=%d\n", getpid());   
	DebugMemory( "Start");

	/********************/
	/* Connect DataBase */
	/*******************/
	lReturn = DbConnect();
	if (lReturn != 0)
	{
		printf( "Open database return %d\n", lReturn );
		ErrReport(CI_MANAGER, 
			EI_DATABASE,
			lReturn, 
		   	CI_SEVERITY_SYSERROR,
		   	ES_DB_OPEN);
		exit(1);
	}

	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	nRet = nCommonMsqAllInit(CI_MANAGER);
	if (nRet != 0) 
   	{
       	ErrReport(CI_MANAGER, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }
	nRet = nCommonMsqAllInit(CI_TLRCOMM);
	if (nRet != 0) 
   	{
       	ErrReport(CI_MANAGER, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_CONNECT);
		exit(1);
    }

	/* get global transaction working date */
	/*
	nRet = GetGlobalTxdate();
	*/


	/* HANDLE TRANSACTION */
	while(1)
	{
		printf( "\n===========================================\n");

		/* READ MANAGE MESSAGE QUEUE */
		nRet = nCommonMsqRecv (&nDataLen, ipcMsg.sText, &lMsgSource, CI_MANAGER);
		if (nRet != 0)
 		{
 			if (errno != EINTR)
 			{
				printf( "errno[%d]\n", errno );

 				if (nCommonMsqInit(CI_MANAGER) == -1)
 				{
 					ErrReport(CI_MANAGER,
 						EI_MESSAGEQUEUE,
 						0,
 						CI_SEVERITY_SYSERROR,
 						ES_MSGQ_READ);
 					exit(1);
 				}
				continue;
			}
		}			
		
		CommonGetCurrentTime( cTime );

        printf( "\n===========================================\n");

        nRet = GetSysDate(gsDBTxdate);
        if (nRet != 0)
        {
            ErrReport(CI_MANAGER,
                    EI_PROCESS,
                    0,
                    CI_SEVERITY_TXNERROR,
                    "���ϵͳ�������ڳ���");
            exit(1);
        }
		
		printf("msgrcv  : source [%d]", lMsgSource); 
		/*DebugString( ipcMsg.sText, nDataLen, __LINE__);*/

		switch(lMsgSource)
		{
#ifdef _CNAPS_HVPS
		case CI_CNAPSBDG:
			vCnapsProcess((void *)&(ipcMsg.sText));
			break;
#endif
		case CI_TLRBDG:
			vTellerProcess((void *)&(ipcMsg.sText));
			break;

		default:
			/*
			vConSwtProcess((void *)&(ipcMsg.sText));
			*/
			printf("Invalid message source!\n");
			break;
		}

	}  /*for(;;)*/
}

/**************************************/
/* Do with the command from PC client */
/**************************************/
void vConSwtProcess( void* sTrans)
{
	short    nTransCode;
	char     szTemp[40], APFlag;
	int      PId, len;
	int      nReturn;
	int      nTemp;
	short    Ret, Ret2, nRet;
	short    nLineCode;
	char     sTime[14];
	char	 sCmd[100];

	ShowError( "HandleConsoleTrans\n");
	DebugString( sTrans, 10, __LINE__);

	memcpy( szTemp, sTrans, 2);
	szTemp[2]=0;
	nTransCode=atoi( szTemp);

	CommonGetCurrentTime( sTime );

	switch( nTransCode )
	{
		case CMD_BATCH_START:
			ShowError( "BatchStart\n");
			memset ( sCmd,'\0',sizeof(sCmd));
			strcpy(sCmd, getenv("APPL"));
			strcat(sCmd, "/sbin/batchstart");
			printf("Start batch command is %s", sCmd);
			system(sCmd);
			SendConsole( "0000", 4);
			/*if ( !(PId = fork()))                
			{
				SendConsole( "0000", 4);
				execlp("batchsvr","batchsvr", 0);
			}            
			else if (PId == -1)
			{
				strcpy(ErrorDescription, "BATCHSVR");
				strcat(ErrorDescription, ES_APP_FORK);
				ErrReport(CI_MANAGE, 
						EI_FORK, 
						errno, 
						CI_SEVERITY_SYSERROR, 
						ErrorDescription);
				SendConsole("0001", 4);
				break;
			}*/
			break;
		case CMD_COMM_START:
			ShowError( "CommStart\n");
			memset ( sCmd,'\0',sizeof(sCmd));
			strcpy(sCmd, getenv("APPL"));
			strcat(sCmd, "/bin/startcomm");
			printf("Start comm command is %s", sCmd);
			system(sCmd);
			SendConsole( "0000", 4);

			/*if ( !(PId = fork()))                
			{
				execlp("startcomm","startcomm", 0);
			}            
			else if (PId == -1)
			{
				strcpy(ErrorDescription, "STARTCOMM");
				strcat(ErrorDescription, ES_APP_FORK);
				ErrReport(CI_MANAGE, EI_FORK, errno, CI_SEVERITY_SYSERROR, ErrorDescription);
				SendConsole("0001", 4);
				break;
			}*/
			break;
		case CMD_COMM_END:
			ShowError( "CommEnd\n");
			memset ( sCmd,'\0',sizeof(sCmd));
			strcpy(sCmd, getenv("APPL"));
			strcat(sCmd, "/bin/stopcomm");
			printf("Stop comm command is %s", sCmd);
			system(sCmd);
			SendConsole( "0000", 4);
			/*if ( !(PId = fork()))                
			{
				execlp("startcomm","startcomm", 0);
			}            
			else if (PId == -1)
			{
				strcpy(ErrorDescription, "STARTCOMM");
				strcat(ErrorDescription, ES_APP_FORK);
				ErrReport(CI_MANAGE, EI_FORK, errno, CI_SEVERITY_SYSERROR, ErrorDescription);
				SendConsole("0001", 4);
				break;
			}*/
			break;
		/*case CMD_GET_TIME:
			memcpy( szTemp, "0000", 4);
			CommonGetCurrentTime( &szTemp[4]);
			SendConsole( szTemp, 18);*/
			break;
		default:
			ShowError( "Invalid nTransCode\n");
	}
}

/*****************************************************************************/
/* FUNC:   shosrt SendConsole(char *sTrans, int nTransLen);                  */
/* INPUT:  sTrans       -- the message to PC Console                         */
/*         nTransLen    -- the length of message                             */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Send the message to the message queue of PC Console               */
/*****************************************************************************/
void SendConsole( char * sTrans, int nTransLen)
{
   short nReturn=0;

   DebugString( sTrans, nTransLen, __LINE__);

   ShowError( "Send to Console message\n");
   /*nReturn = MsqSynCommSnd(nTransLen,sTrans,CI_MANAGE);*/
   
   /*
   nReturn = nCommonMsqSend(nTransLen, sTrans, CI_MANAGER, CI_CONCOMM );
   if (nReturn != 0)
   {
      strcpy(ErrorDescription, "CONCOMM-MSQ");
      strcat(ErrorDescription, ES_MSGQ_CONNECT);

      ErrReport(CI_MANAGER,
                EI_MESSAGEQUEUE,
                0,
                CI_SEVERITY_SYSERROR,
                ErrorDescription);
    }
   */
	return;
}

#ifdef _CNAPS_HVPS
/**************************************/
/* Deal with the command from CNAPS   */
/**************************************/
void vCnapsProcess( void* sTrans)
{
	T_CnsSwtTitaDef *pCnsReq;

	char sTxnno[CR_CLSTXNNO_LEN+1];
	long lTxnno;

	pCnsReq = (T_CnsSwtTitaDef *)sTrans;

	memset(sTxnno, 0, sizeof(sTxnno));
	memcpy(sTxnno, pCnsReq->tIPCHeader.sClsTxnNo, CR_CLSTXNNO_LEN);
	lTxnno = atol(sTxnno);
	printf("manager:vCnapsProcess - (Internal) Txno = [%d]\n", lTxnno);

	switch (lTxnno)
	{
		case 10056: /* CMT418 */
			vProcessCMT418(pCnsReq);
			break;

		case 10054: /* CMT417 */
			vProcessCMT417(pCnsReq);
			break;

		default:
			printf("Invalid transaction number!\n");
			break;
	}

	return;
}
#endif

/**************************************/
/* Transactions from Teller PCs       */
/**************************************/
void vTellerProcess(void *sTrans)
{
	T_MngBufFromTlrDef	*ptMngInBuf;
	T_MngBufToTlrDef	tMngOutBuf;

	int nReturn;
	char sTxno[DLEN_TXNCD+1];
	char caError[DLEN_LDESC+1];
	int nOutLen;
	char sPid[9];

	ptMngInBuf = sTrans;
	memset(&tMngOutBuf, 0, sizeof(tMngOutBuf));
	memset(sTxno, 0, sizeof(sTxno));
	memcpy(sTxno, ptMngInBuf->tTitaLabel.txno, DLEN_TXNCD);
	memcpy(&TITA, &(ptMngInBuf->tTitaLabel), TITA_LABEL_LENGTH);
	memcpy(it_txcom.tbsdy, gsDBTxdate, DLEN_DATE);

	printf("manager:vTellerProcess - (External) Txno = [%s]\n", sTxno);
	memset(caError, 0, sizeof(caError));

	if( memcmp(sTxno, "0023", DLEN_TXNO) && 
		memcmp(sTxno, "0012", DLEN_TXNO) && 
		memcmp(sTxno, "0000", DLEN_TXNO)  )
	{
 		nReturn = TransCheck(ptMngInBuf, caError);
    	if (nReturn != 0)
    	{
			printf("Invalid transaction number!\n");
 			Process_MoveTotaCommon(ptMngInBuf, &tMngOutBuf);
			tMngOutBuf.tTotaLabel.msgtype = 'E';
			memcpy(tMngOutBuf.tTotaLabel.msgno, "9527", 4);
 			{
				memcpy(tMngOutBuf.sTotaText, caError, strlen(caError));
       	 		nOutLen = sizeof(tMngOutBuf.tTotaLabel) + strlen(caError);
       	 	}
			memset(sPid, 0, sizeof(sPid));
    		memcpy(sPid, ptMngInBuf->tTitaLabel.termid, 8);
    		DebugString( &tMngOutBuf, nOutLen, __LINE__);
    		printf("Pid of tlrcomm [%d]\n", atol(sPid));
    		tMngOutBuf.tTotaLabel.header[0] = nOutLen / 256;
    		tMngOutBuf.tTotaLabel.header[1] = nOutLen % 256;

    		nReturn = nCommonMsqSendT(nOutLen, &tMngOutBuf, 
										atol(sPid), CI_TLRCOMM);
    		if (nReturn != 0)
    		{
        		strcpy(ErrorDescription, "MSQ TLRCOMM SEND");

        		ErrReport(CI_MANAGER,
           	  			EI_MESSAGEQUEUE,
       					0,
           				CI_SEVERITY_SYSERROR,
           	   			ErrorDescription);
    		}

    		return;
    	}
	}
    /*************************************************/
    /* prepare it_txcom, gwdXdtl, gwdBctl, gwdTlrctl */
    /*************************************************/
    nReturn = aSysBasicCheck();
    if (nReturn != SYS_OK)
    {
        aSysBasicCheckEnd();
        return;
    }
	switch (atoi(sTxno))
	{
		case 0:
			Process_0000(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 12:
			Process_0012(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 13:
			Process_0013(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 23:
			Process_0023(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1007:
			Process_1007(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1008:
			Process_1008(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1005:
			Process_1005(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2005:
			Process_2005(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2007:
			Process_2007(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2008:
			Process_2008(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2010:
			Process_2010(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2011:
			Process_2011(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2012:
			Process_2012(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2015:
			Process_2015(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2017:
			Process_2017(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2020:
			Process_2020(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1011:
			Process_1011(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1012:
			Process_1012(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1013:
			Process_1013(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1025:
			Process_1025(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1027:
			Process_1027(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1003:
			Process_1003(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2101:
			Process_2101(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 2102:
			Process_2102(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		case 1009:
			Process_1009(ptMngInBuf, &tMngOutBuf, &nOutLen);
			break;
		default:
			printf("Invalid transaction number!\n");
			Process_MoveTotaCommon(ptMngInBuf, &tMngOutBuf);
			tMngOutBuf.tTotaLabel.msgtype = 'E';
			memcpy(tMngOutBuf.tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "�Ƿ��Ľ��״��룡");
			memcpy(tMngOutBuf.sTotaText, sError, strlen(sError));
			nOutLen = sizeof(tMngOutBuf.tTotaLabel) + strlen(sError);
			}
			break;
	}
	memset(sPid, 0, sizeof(sPid));
	memcpy(sPid, ptMngInBuf->tTitaLabel.termid, 8);
	DebugString( &tMngOutBuf, nOutLen, __LINE__);
	printf("Pid of tlrcomm [%d]\n", atol(sPid));
	tMngOutBuf.tTotaLabel.header[0] = nOutLen / 256;
	tMngOutBuf.tTotaLabel.header[1] = nOutLen % 256;

	nReturn = nCommonMsqSendT(nOutLen, &tMngOutBuf, atol(sPid), CI_TLRCOMM);
	if (nReturn != 0)
	{
		strcpy(ErrorDescription, "MSQ TLRCOMM SEND");

		ErrReport(CI_MANAGER,
                EI_MESSAGEQUEUE,
                0,
                CI_SEVERITY_SYSERROR,
                ErrorDescription);
    }
	return;
}

#ifdef _CNAPS_HVPS
void vProcessCMT417(T_CnsSwtTitaDef *pCnsReq)
{
	CMT417DEF	tCmt417;
	char		sRetForComm[19];
	int			nRet;
	int			nMsgType;
	char		sMsgType[3+1];
	struct wd_bsysctl_area				wd_bsysctl;
	struct wd_btblcmt417_area			wd_btblcmt417;
	struct wd_btblcmttime417_area		wd_btblcmttime417;
	char		sClsSsn[6+1];
	char		sCnapsDate[8+1];
	char		sTemp[4000];
	char		sTemp0[3000];
	char		sBankIssno[8+1];
	char		sWorkDate[8+1];
	char		*ptr=NULL, *last=NULL;
	int			nCount;
	char		sCount[3+1];
	int			i,j;
	char		sCmd[2048];
	char		sTime[15];


	memset(&tCmt417, 0, sizeof(tCmt417));
	memcpy(&tCmt417, pCnsReq->tTitaPkt.sRsv, sizeof(tCmt417));

	memcpy(sMsgType, tCmt417.datatype, 3);
	sMsgType[3] = 0;
	nMsgType = atoi(sMsgType);
	
	/* reply to CNAPS */
	memset(sRetForComm, 0, sizeof(sRetForComm));
	memcpy(sRetForComm, "CNAPS:000:", 10);
	memcpy(sRetForComm+10, pCnsReq->tTitaPkt.tCnapsGen.sPktID, 8);

	nRet = nCommonMsqSend(sizeof(sRetForComm)-1, sRetForComm, 
		CI_MANAGER, CI_MBFECFM);
	if (nRet != 0)
	{
		strcpy(ErrorDescription, "MSQ MBFECFM SEND");

		ErrReport(CI_MANAGER,
				EI_MESSAGEQUEUE,
				0,
				CI_SEVERITY_SYSERROR,
				ErrorDescription);
	}

	switch (nMsgType)
	{
		case 104: /* CNAPS�к����� */
			memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
			memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
				sizeof(wd_bsysctl.rcd_id) - 1);
			if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
			{
				printf("manager: (CMT417)fetch system control record error\n");
				break;
			}
			else
			{
				memcpy(sWorkDate, wd_bsysctl.work_date, 8);
				sWorkDate[8] = 0;
			}

			printf("manager: (CMT417-104)INFO DATA [%s]\n", tCmt417.data);
			memset(sTemp, 0, sizeof(sTemp));
			memcpy(sTemp, tCmt417.data, sizeof(tCmt417.data));

			/* line 1 - "CNAPS_BANK_UPDATE_INFO" or "CNAPS_EBANK_UPDATE_INFO" */
			ptr = strtok_r(sTemp, "\n", &last);
			if (ptr == NULL) break;
			strcpy(sTemp0, ptr);
			printf("manager: INFO Bank Flag [%s]\n", sTemp0);

			/* line 2 - length of header */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			printf("manager: INFO length of header\n");

			/* line 3 - length of body */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			printf("manager: INFO length of body\n");

			/* line 4 - batch number */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			strcpy(sTemp0, ptr);
			memcpy(sBankIssno, sTemp0+8, 8);
			sBankIssno[8] = 0;
			printf("manager: INFO Bank Issno [%s]\n", sBankIssno);

			/* from line 5 - details */
			while (1)
			{
				ptr = strtok_r((char *)NULL, "\n", &last);
				if (ptr == NULL) break;
				strcpy(sTemp0, ptr);
				printf("manager: INFO details line\n");
	
				nRet = nProcessCMT417FileCnapsString(sTemp0, sWorkDate, sBankIssno);
				if (nRet == 1) break;
				if (nRet == 2) continue;

			} /* end of while */

			break;


		case 105: /* EIS�к����� */
			memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
			memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
				sizeof(wd_bsysctl.rcd_id) - 1);
			if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
			{
				printf("manager: (CMT417)fetch system control record error\n");
				break;
			}
			else
			{
				memcpy(sWorkDate, wd_bsysctl.work_date, 8);
				sWorkDate[8] = 0;
			}

			printf("manager: (CMT417-105)INFO DATA [%s]\n", tCmt417.data);
			memset(sTemp, 0, sizeof(sTemp));
			memcpy(sTemp, tCmt417.data, sizeof(tCmt417.data));

			/* line 1 - "CNAPS_BANK_UPDATE_INFO" or "CNAPS_EBANK_UPDATE_INFO" */
			ptr = strtok_r(sTemp, "\n", &last);
			if (ptr == NULL) break;
			strcpy(sTemp0, ptr);
			printf("manager: INFO Bank Flag [%s]\n", sTemp0);

			/* line 2 - length of header */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			printf("manager: INFO length of header\n");

			/* line 3 - length of body */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			printf("manager: INFO length of body\n");

			/* line 4 - batch number */
			ptr = strtok_r((char *)NULL, "\n", &last);
			if (ptr == NULL) break;
			strcpy(sTemp0, ptr);
			memcpy(sBankIssno, sTemp0+8, 8);
			sBankIssno[8] = 0;
			printf("manager: INFO Bank Issno [%s]\n", sBankIssno);

			/* from line 5 - details */
			while (1)
			{
				ptr = strtok_r((char *)NULL, "\n", &last);
				if (ptr == NULL) break;
				strcpy(sTemp0, ptr);
				printf("manager: INFO details line\n");
	
				nRet = nProcessCMT417FileEisString(sTemp0, sWorkDate, sBankIssno);
				if (nRet == 1) break;
				if (nRet == 2) continue;

			} /* end of while */

			break;

		case 0:   /* �ļ����� */
			printf("manager: (CMT417-000)INFO DATA [%s]\n", tCmt417.data);

			memset(&wd_btblcmt417, 0, sizeof(wd_btblcmt417));

			/* get a new cls ssn */
			memset(sClsSsn, 0, sizeof(sClsSsn));
			nRet = nNewClsSsn(sClsSsn);
			if (nRet == 0)
			{
				memcpy(wd_btblcmt417.cls_ssn, sClsSsn, 6);
			}
			else
			{
				strcpy(sClsSsn, "000000");
				memcpy(wd_btblcmt417.cls_ssn, sClsSsn, 6);
			}

			wd_btblcmt417.type[0] = '1';
			GetSystemTime14(wd_btblcmt417.recdate);
			memcpy(wd_btblcmt417.cmtce7, "000", 3);
			if (strlen(tCmt417.data) <= 1024)
			{
				memcpy(wd_btblcmt417.cmtclx, tCmt417.data, strlen(tCmt417.data));
			}
			else
			{
				memcpy(wd_btblcmt417.cmtclx, tCmt417.data, 1024);
			}

			nRet = DbsBtblcmt417(DBS_INSERT, &wd_btblcmt417);
			if (nRet != 0)
			{
				/* insert error */
				printf("manager: (CMT417)insert Btblcmt417 record error\n");
			}

			/* add by Laura, 2004/03/16, begin */
			if (nRet == 0)
			{
				sleep(1);
				memset(sCmd, 0, sizeof(sCmd));
				memset(sTime, 0, sizeof(sTime));
				CommonGetCurrentTime(sTime);
				sprintf(sCmd, 
					"%s/bin/batch/process_cmt417_file_single %s > %s/log/batch/process_cmt417_file_single_%s.log.%s &", 
					getenv("APPL"), sClsSsn, getenv("APPL"), sClsSsn, sTime);
				if (system(sCmd) == 0)
					printf("\nProcess CMT417 file succeed! Check log file for details.\n");
				else
					printf("\nProcess CMT417 file fail!\n");
			}
			/* add by Laura, 2004/03/16, end */

			break;

		case 202: /* ϵͳ����ʱ����� */
			printf("manager: (CMT417-202)INFO DATA [%s]\n", tCmt417.data);

			memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
			memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
				sizeof(wd_bsysctl.rcd_id) - 1);
		
			if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
			{
				/* fetch system control record error */
				printf("manager: (CMT417)fetch system control record error\n");
				strcpy(sCnapsDate, "19900101");
			}
			else
			{
				memcpy(sCnapsDate, wd_bsysctl.work_date, 8);
				sCnapsDate[8] = 0;
			}

			/* get a new cls ssn */
			memset(sClsSsn, 0, sizeof(sClsSsn));
			nRet = nNewClsSsn(sClsSsn);
			if (nRet == 0)
			{
				memcpy(sCount, tCmt417.data, 3);
				sCount[3] = 0;
				nCount = atoi(sCount);
				if (nCount > 80) nCount = 80; /* for test */

				j = 3;
				for (i=0; i<nCount; i++)
				{
					memset(&wd_btblcmttime417, 0, sizeof(wd_btblcmttime417));
					memcpy(wd_btblcmttime417.cnaps_date, sCnapsDate, 8);
					memcpy(wd_btblcmttime417.cls_ssn, "00", 2);
					memcpy(wd_btblcmttime417.cls_ssn+2, sClsSsn, 6);
					memcpy(wd_btblcmttime417.update_type, tCmt417.data+j, 1);
					switch (wd_btblcmttime417.update_type[0])
					{
						case '1':
							memcpy(wd_btblcmttime417.update_type_desc, 
								"����", 4);
							break;
						case '2':
							memcpy(wd_btblcmttime417.update_type_desc, 
								"ע��", 4);
							break;
						case '3':
							memcpy(wd_btblcmttime417.update_type_desc, 
								"���", 4);
							break;
						default:
							memcpy(wd_btblcmttime417.update_type_desc, 
								"����", 4);
							break;
					}
					memcpy(wd_btblcmttime417.type_code, 
						tCmt417.data+j+1, 8);
					memcpy(wd_btblcmttime417.type_name, 
						tCmt417.data+j+9, 20);
					memcpy(wd_btblcmttime417.type_data, 
						tCmt417.data+j+29, 18);
					memcpy(wd_btblcmttime417.update_style, 
						tCmt417.data+j+47, 1);
					switch (wd_btblcmttime417.update_style[0])
					{
						case '1':
							strcpy(wd_btblcmttime417.update_style_desc, 
								"����������Ч");
							break;
						case '2':
							strcpy(wd_btblcmttime417.update_style_desc, 
								"����ָ��������Ч");
							break;
						case '3':
							strcpy(wd_btblcmttime417.update_style_desc, 
								"�·�������Ч");
							break;
						case '4':
							strcpy(wd_btblcmttime417.update_style_desc, 
								"�·�ָ��������Ч");
							break;
						default:
							strcpy(wd_btblcmttime417.update_style_desc, 
								"����");
							break;
					}
					memcpy(wd_btblcmttime417.update_date, 
						tCmt417.data+j+48, 8);

					if (DbsBtblcmttime417(DBS_INSERT, &wd_btblcmttime417) != 0)
					{
					/* insert error */
					printf("manager: (CMT417)insert Btblcmttime417 record error\n");
					}

					j = j + 56;
				}
			}

			/* reply to CNAPS */
			memset(sRetForComm, 0, sizeof(sRetForComm));
			memcpy(sRetForComm, "CNAPS:000:", 10);
			memcpy(sRetForComm+10, pCnsReq->tTitaPkt.tCnapsGen.sPktID, 8);
		
			nRet = nCommonMsqSend(sizeof(sRetForComm)-1, sRetForComm, 
				CI_MANAGER, CI_MBFECFM);
			if (nRet != 0)
			{
				strcpy(ErrorDescription, "MSQ MBFECFM SEND");
		
				ErrReport(CI_MANAGER,
						EI_MESSAGEQUEUE,
						0,
						CI_SEVERITY_SYSERROR,
						ErrorDescription);
			}

			break;
			
		case 205: /* ���ҵ������� */
			printf("manager: (CMT417-205)INFO DATA [%s]\n", tCmt417.data);

			memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
			memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
				sizeof(wd_bsysctl.rcd_id) - 1);
		
			if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
			{
				/* fetch system control record error */
				printf("manager: (CMT417)fetch system control record error\n");
			}
			else
			{
				/* new high amount payment start point value */
				memcpy(wd_bsysctl.namount1, tCmt417.data+4, 15);
				memcpy(wd_bsysctl.nadate1, tCmt417.data+19, 8); 
		
				if (DbsBSYSCTL(DBS_IUPD, &wd_bsysctl) != 0)
				{
					/* update system control record error */
					printf("manager: (CMT417)update system control record error\n");
				}
			}
		
			/* reply to CNAPS */
			memset(sRetForComm, 0, sizeof(sRetForComm));
			memcpy(sRetForComm, "CNAPS:000:", 10);
			memcpy(sRetForComm+10, pCnsReq->tTitaPkt.tCnapsGen.sPktID, 8);
		
			nRet = nCommonMsqSend(sizeof(sRetForComm)-1, sRetForComm, 
				CI_MANAGER, CI_MBFECFM);
			if (nRet != 0)
			{
				strcpy(ErrorDescription, "MSQ MBFECFM SEND");
		
				ErrReport(CI_MANAGER,
						EI_MESSAGEQUEUE,
						0,
						CI_SEVERITY_SYSERROR,
						ErrorDescription);
			}

			break;
			
		default:
			printf("manager: invalid data type in CMT417 [%d]\n", nMsgType);
			break;
	}

	return;
}
#endif

#ifdef _CNAPS_HVPS
void vProcessCMT418(T_CnsSwtTitaDef *pCnsReq)
{
	CMT418DEF	tCmt418;
	char		sRetForComm[19];
	char		sCmd[2048];
	char		sTime[15];
	int			nRet;
	struct wd_bsysctl_area		wd_bsysctl;

	memset(&tCmt418, 0, sizeof(tCmt418));
	memcpy(&tCmt418, pCnsReq->tTitaPkt.sRsv, sizeof(tCmt418));

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
		sizeof(wd_bsysctl.rcd_id) - 1);

	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
	{
		/* fetch system control record error */
		printf("manager: fetch system control record error\n");
	}
	else
	{
		/* move work_date to last_work_date */
		if (memcmp(tCmt418.status, "00", 2) == 0)
		{
			memcpy(wd_bsysctl.last_work_date, wd_bsysctl.work_date,
				sizeof(wd_bsysctl.last_work_date) - 1);
		}

		/* new date and status data from CMT418 */
		memcpy(wd_bsysctl.work_date, tCmt418.workdate, 
			sizeof(wd_bsysctl.work_date) - 1);
		memcpy(wd_bsysctl.cnaps_status, tCmt418.status, 
			sizeof(wd_bsysctl.cnaps_status) - 1);
		memcpy(wd_bsysctl.work_date_1, tCmt418.fworkdate1, 
			sizeof(wd_bsysctl.work_date_1) - 1);
		memcpy(wd_bsysctl.work_date_2, tCmt418.fworkdate2, 
			sizeof(wd_bsysctl.work_date_2) - 1);
		memcpy(wd_bsysctl.remarks, tCmt418.remarks, 
			sizeof(wd_bsysctl.remarks) - 1);

		if (DbsBSYSCTL(DBS_IUPD, &wd_bsysctl) != 0)
		{
			/* update system control record error */
			printf("manager: update system control record error\n");
		}

		if (memcmp(tCmt418.status, "00", 2) == 0)
		{
			printf("BOD Batch process of date [%s] : Begin\n", 
				wd_bsysctl.work_date);

			memset(sCmd, 0, sizeof(sCmd));
			sprintf(sCmd, "%s/sbin/bodbatch.sh %s &", 
				getenv("APPL"), wd_bsysctl.work_date);
			if (system(sCmd) == 0)
				printf("\nBOD Batch process start succeed! Check log files for details.\n");
			else
				printf("\nBOD Batch process start fail!\n");
		}

		/* start batch processing */
		if (memcmp(tCmt418.status, "40", 2) == 0)
		{
			printf("Batch process of date [%s] : Begin\n", 
				wd_bsysctl.work_date);

			memset(sCmd, 0, sizeof(sCmd));
			sprintf(sCmd, "%s/sbin/bsbatch.sh %s &", 
				getenv("APPL"), wd_bsysctl.work_date);
			if (system(sCmd) == 0)
				printf("\nBatch process start succeed! Check log files for details.\n");
			else
				printf("\nBatch process start fail!\n");
		}
	}

	/* reply to CNAPS */
	memset(sRetForComm, 0, sizeof(sRetForComm));
	memcpy(sRetForComm, "CNAPS:000:", 10);
	memcpy(sRetForComm+10, pCnsReq->tTitaPkt.tCnapsGen.sPktID, 8);

	nRet = nCommonMsqSend(sizeof(sRetForComm)-1, sRetForComm, 
		CI_MANAGER, CI_MBFECFM);
	if (nRet != 0)
	{
		strcpy(ErrorDescription, "MSQ MBFECFM SEND");

		ErrReport(CI_MANAGER,
				EI_MESSAGEQUEUE,
				0,
				CI_SEVERITY_SYSERROR,
				ErrorDescription);
	}

	return;
}
#endif

