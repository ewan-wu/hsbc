/************************************************************************
* Name      :    TXN 1003 (��) ϵͳ�����ֹ��л�ģ��(��ѯ)		        *
*************************************************************************/
#include "manager.h"

void Process_1003(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1003_GROUP
	{
		char	null;
	} tis1003;
	static struct TOS1003_GROUP
	{
		char	work_date[8];
		char	last_work_date[8];
		char	eft_status;
	} tos1003;

	/* work */
	/*struct wd_bdeptctl_area	wd_bdeptctl;*/
	struct wd_bsysctl_area	wd_bsysctl;

	memset(&tis1003, 0, sizeof(tis1003));
	memset(&tos1003, 0, sizeof(tos1003));

	memcpy(&tis1003, ptMngInBuf->sTitaText, sizeof(tis1003));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);
	
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		memcpy(tos1003.work_date, wd_bsysctl.work_date, sizeof(tos1003.work_date));
		memcpy(tos1003.last_work_date, wd_bsysctl.last_work_date, sizeof(tos1003.last_work_date));
		tos1003.eft_status=wd_bsysctl.eft_status[0];
		
	}
	else
	{
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯϵͳ���Ʊ����������ݲ����ڣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
	
	memcpy(ptMngOutBuf->sTotaText, &tos1003, sizeof(tos1003));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1003);

	return;
}
