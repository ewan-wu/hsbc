/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1007(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1007_GROUP
	{
		char	brh_id[3];		/*���к�*/
		char	tlr_id[8];
	} tis1007;
	static struct TOS1007_GROUP
	{
		char	dept_id;
		char	tlr_id[8];
		char	tlr_name[40];
		char	init_flag;
		char	work_flag;
		char	work_level;
		char	status;
		char	last_status_chg[8];
		char	last_pswd_chg[8];
		char	add_by_dept_id;
		char	add_by_tlr_id[8];
		char	auth_by_dept_id;
		char	auth_by_tlr_id[8];
		char	retry;
	} tos1007;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;

	memset(&tis1007, 0, sizeof(tis1007));
	memset(&tos1007, 0, sizeof(tos1007));

	memcpy(&tis1007, ptMngInBuf->sTitaText, sizeof(tis1007));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	memcpy(wd_btlrctl.tlr_id, tis1007.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, tis1007.brh_id, DLEN_BRNO);
	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) == 0)
	{
		/* succeed */
		tos1007.init_flag = wd_btlrctl.init_flag[0]; 
		tos1007.work_flag = wd_btlrctl.work_flag[0]; 
		tos1007.work_level = wd_btlrctl.work_level[0]; 
		tos1007.status = wd_btlrctl.status[0]; 
		tos1007.dept_id = wd_btlrctl.dept_id[0]; 
		memcpy(tos1007.tlr_id, wd_btlrctl.tlr_id, sizeof(tos1007.tlr_id));
		memcpy(tos1007.tlr_name, wd_btlrctl.tlr_name, 
			sizeof(tos1007.tlr_name));
		memcpy(tos1007.last_status_chg, wd_btlrctl.last_status_chg, 
			sizeof(tos1007.last_status_chg));
		memcpy(tos1007.last_pswd_chg, wd_btlrctl.last_pswd_chg, 
			sizeof(tos1007.last_pswd_chg));
		tos1007.add_by_dept_id = wd_btlrctl.add_by_dept_id[0]; 
		memcpy(tos1007.add_by_tlr_id, wd_btlrctl.add_by_tlr_id, 
			sizeof(tos1007.add_by_tlr_id));
		tos1007.auth_by_dept_id = wd_btlrctl.auth_by_dept_id[0]; 
		memcpy(tos1007.auth_by_tlr_id, wd_btlrctl.auth_by_tlr_id, 
			sizeof(tos1007.auth_by_tlr_id));
		tos1007.retry = wd_btlrctl.pswd_retry_cnt + 0x30;

		memcpy(ptMngOutBuf->sTotaText, &tos1007, sizeof(tos1007));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1007);

		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯ����Ա��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}

		return;
	}
}


