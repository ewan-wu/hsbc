/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2012(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2012_GROUP
	{
		char	tlr_id[8];
	} tis2012;
	static struct TOS2012_GROUP
	{
		char	tlr_name[40];
	} tos2012;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;

	memset(&tis2012, 0, sizeof(tis2012));
	memset(&tos2012, 0, sizeof(tos2012));

	memcpy(&tis2012, ptMngInBuf->sTitaText, sizeof(tis2012));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	memcpy(wd_btlrctl.tlr_id, tis2012.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, gwdXdtl.sKinbr, DLEN_BRNO);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����ʧЧ�ָ�ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	CommonGetCurrentDate(wd_btlrctl.last_pswd_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����ʧЧ�ָ�ʧ�ܣ����²���Ա����ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */
		/* log operator password change */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = wd_btlrctl.dept_id[0];
		memcpy(wd_bsignlog.tlr_id, tis2012.tlr_id, sizeof(tis2012.tlr_id));
		memcpy(wd_bsignlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_RCVPSWD;
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����ʧЧ�ָ�ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos2012.tlr_name, wd_btlrctl.tlr_name, sizeof(tos2012.tlr_name));
			memcpy(ptMngOutBuf->sTotaText, &tos2012, sizeof(tos2012));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2012);
			DbCommitTxn();

			return;
		}
	}
}


