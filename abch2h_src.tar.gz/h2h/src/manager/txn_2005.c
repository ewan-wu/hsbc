/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2005(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2005_GROUP
	{
		char	opind;
		char	dept_id;
		char	dept_name[60];
		char	work_flag;
		char	work_type;
	} tis2005;
	static struct TOS2005_GROUP
	{
		char	dummy;
	} tos2005;

	/* work */
	struct wd_bdeptctl_area	wd_bdeptctl;
	struct wd_bscmlog_area	wd_bscmlog;

	memset(&tis2005, 0, sizeof(tis2005));
	memset(&tos2005, 0, sizeof(tos2005));

	memcpy(&tis2005, ptMngInBuf->sTitaText, sizeof(tis2005));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	if (tis2005.opind == 'I')
	{
		memset(&wd_bdeptctl, 0, sizeof(wd_bdeptctl));
		wd_bdeptctl.dept_id[0] = tis2005.dept_id;
		memcpy(wd_bdeptctl.dept_name, tis2005.dept_name, 
			sizeof(tis2005.dept_name));
		wd_bdeptctl.work_flag[0] = tis2005.work_flag;
		wd_bdeptctl.work_type[0] = tis2005.work_type;
		CommonGetCurrentTimeDB(wd_bdeptctl.rec_updt_time);

		if (DbsBDEPTCTL(DBS_INSERT, &wd_bdeptctl) != 0)
		{
			/* insert fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������Ϣά�������Ӳ���ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* insert succeed */

			/* log department insert */
			memset(&wd_bscmlog, 0, sizeof(wd_bscmlog));
			wd_bscmlog.dept_id[0] = tis2005.dept_id;
			memcpy(wd_bscmlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
			CommonGetCurrentTimeDB(wd_bscmlog.act_time);
			wd_bscmlog.act_type[0] = BSCMLOG_ACTION_TYPE_DEPT;
			wd_bscmlog.act_subtype[0] = BSCMLOG_ACTION_SUBTYPE_ADD;
			memcpy(wd_bscmlog.act_data, gwdXdtl.sTlrno, 8);
			CommonGetCurrentTimeDB(wd_bscmlog.rec_updt_time);

			if (DbsBSCMLOG(DBS_INSERT, &wd_bscmlog) != 0)
			{
				/* fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "������Ϣά������¼ά����־ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}
			else
			{
				/* succeed */
				memcpy(ptMngOutBuf->sTotaText, &tos2005, sizeof(tos2005));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2005);
				DbCommitTxn();
				return;
			}
		}
	} /* end of insert */
	else
	{
		/* update */
		memset(&wd_bdeptctl, 0, sizeof(wd_bdeptctl));
		wd_bdeptctl.dept_id[0] = tis2005.dept_id;

		if (DbsBDEPTCTL(DBS_FIND, &wd_bdeptctl) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������Ϣά�������µĲ��Ų����ڣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
		memcpy(wd_bdeptctl.dept_name, tis2005.dept_name, 
			sizeof(tis2005.dept_name));
		wd_bdeptctl.work_flag[0] = tis2005.work_flag;
		wd_bdeptctl.work_type[0] = tis2005.work_type;
		CommonGetCurrentTimeDB(wd_bdeptctl.rec_updt_time);

		if (DbsBDEPTCTL(DBS_IUPD, &wd_bdeptctl) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "������Ϣά�������²�����Ϣʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
	
			/* log department update */
			memset(&wd_bscmlog, 0, sizeof(wd_bscmlog));
			wd_bscmlog.dept_id[0] = tis2005.dept_id;
			memcpy(wd_bscmlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
			CommonGetCurrentTimeDB(wd_bscmlog.act_time);
			wd_bscmlog.act_type[0] = BSCMLOG_ACTION_TYPE_DEPT;
			wd_bscmlog.act_subtype[0] = BSCMLOG_ACTION_SUBTYPE_UPD;
			memcpy(wd_bscmlog.act_data, gwdXdtl.sTlrno, 8);
			CommonGetCurrentTimeDB(wd_bscmlog.rec_updt_time);

			if (DbsBSCMLOG(DBS_INSERT, &wd_bscmlog) != 0)
			{
				/* fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "������Ϣά������¼ά����־ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}
			else
			{
				/* succeed */
				memcpy(ptMngOutBuf->sTotaText, &tos2005, sizeof(tos2005));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2005);
				DbCommitTxn();
				return;
			}
		}
	}
}


