/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_0012(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS0012_GROUP
	{
		/*char	dept_id;*/
		char	ipaddr[15];
		char	retry;
		char	tlrpwd[12];
	} tis0012;
	static struct TOS0012_GROUP
	{
		char	tlr_name[40];
		char	tlr_auth[60];
		char	msg_flag;
		char	dept_id;
		char	deptname[30];
		char	msg_text[60];
		char	exp_days[4];
	} tos0012;

	/* work */
	struct wd_bsysctl_area	wd_bsysctl;
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;
	struct wd_bdeptctl_area	wd_bdeptctl;
	
	char sPswd0[21];
	char sPswd1[21];
	char sDate[9];

	memset(&tis0012, 0, sizeof(tis0012));
	memset(&tos0012, 0, sizeof(tos0012));

	memcpy(&tis0012, ptMngInBuf->sTitaText, sizeof(tis0012));
	tos0012.msg_flag = '0';

	/* get system config on teller expire days */
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
	{
		wd_bsysctl.tlr_p_exp_days = SYS_DEFAULT_TLR_P_EXPIRE_DAYS;
		wd_bsysctl.tlr_s_exp_days = SYS_DEFAULT_TLR_S_EXPIRE_DAYS;
	}

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	/*wd_btlrctl.dept_id[0] = tis0012.dept_id;*/
	memcpy(wd_btlrctl.tlr_id, ptMngInBuf->tTitaLabel.tlrno, 
		sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, gwdXdtl.sKinbr, DLEN_BRNO); 

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) == 0)
	{
		/* succeed */
		if (wd_btlrctl.work_flag[0] == BTLRCTL_WORK_FLAG_OFF)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ��ò���Ա���ɹ�����");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, '0', sError);
			DbCommitTxn();
			}
			return;
		}
		/* check log on/off/lock status, if already LOG ON, reject it */
		if (wd_btlrctl.status[0] == BTLRCTL_STATUS_LOG_ON)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ��ò���Ա�ѵ�¼����һ�նˣ�����δ����ǩ�ˣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

			/*
			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, tis0012.retry, sError);
			*/
			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, '0', sError);
			DbCommitTxn();
			}
			return;
		}
		/* check log on/off/lock status, if already LOCK, reject it */
		if (wd_btlrctl.status[0] == BTLRCTL_STATUS_LOCK)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ��ò���Ա�ѱ���������ϵͳ����Ա��������ʹ�ã�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

			/*
			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, tis0012.retry, sError);
			*/
			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, '0', sError);
			DbCommitTxn();
			}
			return;
		}
		/* check password */
		memset(sPswd0, 0, sizeof(sPswd0));
		memcpy(sPswd0, tis0012.tlrpwd, sizeof(tis0012.tlrpwd));
		memset(sPswd1, ' ', sizeof(sPswd1));
		memcpy(sPswd1, sPswd0, strlen(sPswd0));
		sPswd1[sizeof(wd_btlrctl.password)-1] = 0;
		if (memcmp(wd_btlrctl.password, sPswd1, 
			sizeof(tis0012.tlrpwd)) != 0)
		{
			wd_btlrctl.pswd_retry_cnt = wd_btlrctl.pswd_retry_cnt + 1;

			if (wd_btlrctl.pswd_retry_cnt == 3)
			{
				char sError[256];
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
				strcpy(sError, "��¼ʧ�ܣ�����Ա���������������Σ���������");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

				vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, 
					wd_btlrctl.pswd_retry_cnt + 0x30, sError);

				wd_btlrctl.pswd_retry_cnt = 0;
				wd_btlrctl.status[0] = BTLRCTL_STATUS_LOCK;
				CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
				DbsBTLRCTL(DBS_IUPD, &wd_btlrctl);
			}
			else
			{
				char sError[256];
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				strcpy(sError, "��¼ʧ�ܣ�����Ա�������");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

				vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, 
					wd_btlrctl.pswd_retry_cnt + 0x30, sError);

				CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
				DbsBTLRCTL(DBS_IUPD, &wd_btlrctl);
			}
			DbCommitTxn();
			return;
		}
		/* check status expire: work valid */
		/*
		if (CommonInterval(wd_btlrctl.last_status_chg, gsDBTxdate) 
			> wd_bsysctl.tlr_s_exp_days)
		*/
		/* compare with system time */
		CommonGetCurrentDate(sDate);
		if (CommonInterval(wd_btlrctl.last_status_chg, sDate)
			> wd_bsysctl.tlr_s_exp_days)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ�����Ա��ʧЧ������ϵϵͳ����Ա��");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, '0', sError);
			DbCommitTxn();
			}
			return;
		}
		/* check password expire */
		/*
		if (CommonInterval(wd_btlrctl.last_pswd_chg, gsDBTxdate) 
			> wd_bsysctl.tlr_p_exp_days)
		*/
		/* compare with system time */
		CommonGetCurrentDate(sDate);
		if (CommonInterval(wd_btlrctl.last_pswd_chg, sDate)
			> wd_bsysctl.tlr_p_exp_days)
		{
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ�����Ա�����ѹ��ڣ�����ϵϵͳ����Ա��");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);

			vPswdErrLogInsert(&wd_btlrctl, wd_bsysctl.work_date, '0', sError);
			DbCommitTxn();
			}
			return;
		}
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
		{
		char sError[256];
		strcpy(sError, "��¼ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	{
	int nDays;
	CommonGetCurrentDate(sDate);
	nDays = CommonInterval(wd_btlrctl.last_pswd_chg, sDate);
	if ((wd_bsysctl.tlr_p_exp_days - nDays) <= 10)
	{
		tos0012.msg_flag = '1';
		sprintf(tos0012.msg_text, 
			"��ע�⣺������뽫��%d������", wd_bsysctl.tlr_p_exp_days - nDays);
	}
	}

	{
	if (wd_btlrctl.init_flag[0] == BTLRCTL_INIT_FLAG_ON)
	{
		tos0012.msg_flag = '2';
		sprintf(tos0012.msg_text, 
			"��ע�⣺������ĵ�һ�ε�¼�����޸����룡");
	}
	}

	wd_btlrctl.status[0] = BTLRCTL_STATUS_LOG_ON;
	wd_btlrctl.pswd_retry_cnt = 0;
	CommonGetCurrentDate(wd_btlrctl.last_status_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
		{
		char sError[256];
		strcpy(sError, "��¼ʧ�ܣ��޸Ĳ���Ա״̬ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator logon */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = wd_btlrctl.dept_id[0];
		memcpy(wd_bsignlog.tlr_id, ptMngInBuf->tTitaLabel.tlrno, 
			sizeof(wd_bsignlog.tlr_id)-1);
		memcpy(wd_bsignlog.brno, gwdXdtl.sKinbr, DLEN_BRNO); 
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_SIGNON;
		memcpy(wd_bsignlog.act_data, tis0012.ipaddr, sizeof(tis0012.ipaddr));
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);
			{
			char sError[256];
			strcpy(sError, "��¼ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos0012.tlr_name, wd_btlrctl.tlr_name, sizeof(tos0012.tlr_name));
			tos0012.tlr_auth[0] = wd_btlrctl.dept_id[0];
			tos0012.tlr_auth[1] = wd_btlrctl.work_level[0];

			tos0012.dept_id	=	wd_btlrctl.dept_id[0];
			/*add for sf*/
			memset(tos0012.exp_days, 0, sizeof(tos0012.exp_days));
			sprintf(tos0012.exp_days, "%4d", wd_bsysctl.tlr_p_exp_days);
			memset(&wd_bdeptctl, 0, sizeof(wd_bdeptctl));
			wd_bdeptctl.dept_id[0] = wd_btlrctl.dept_id[0];
			if (DbsBDEPTCTL(DBS_FIND, &wd_bdeptctl) == 0)
			{
			memcpy(tos0012.deptname,wd_bdeptctl.dept_name, sizeof(tos0012.deptname));		
			}
			else
			{
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9528", 4);				
				char sError[256];
				strcpy(sError, "��½ϵͳʧ�ܣ��ò���Ա�������ŷǷ���");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}	
			memcpy(ptMngOutBuf->sTotaText, &tos0012, sizeof(tos0012));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos0012);
			DbCommitTxn();

			return;
		}
	}
}


