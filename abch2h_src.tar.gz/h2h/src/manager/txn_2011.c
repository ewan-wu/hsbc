/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2011(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2011_GROUP
	{
		char	tlr_id[8];
		char	new_pswd[12];
	} tis2011;
	static struct TOS2011_GROUP
	{
		char	tlr_name[40];
	} tos2011;

	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_bsignlog_area	wd_bsignlog;

	memset(&tis2011, 0, sizeof(tis2011));
	memset(&tos2011, 0, sizeof(tos2011));

	memcpy(&tis2011, ptMngInBuf->sTitaText, sizeof(tis2011));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
	memcpy(wd_btlrctl.tlr_id, tis2011.tlr_id, sizeof(wd_btlrctl.tlr_id)-1);
	memcpy(wd_btlrctl.brno, gwdXdtl.sKinbr, DLEN_BRNO);

	if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����ǿ�Ʊ��ʧ�ܣ��Ƿ��Ĳ���Ա��");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	memcpy(wd_btlrctl.password, tis2011.new_pswd, sizeof(tis2011.new_pswd));
	CommonGetCurrentDate(wd_btlrctl.last_pswd_chg);
	CommonGetCurrentTimeDB(wd_btlrctl.rec_updt_time);
	if (DbsBTLRCTL(DBS_IUPD, &wd_btlrctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����ǿ�Ʊ��ʧ�ܣ����²���Ա����ʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */

		/* log operator password change */
		memset(&wd_bsignlog, 0, sizeof(wd_bsignlog));
		wd_bsignlog.dept_id[0] = wd_btlrctl.dept_id[0];
		memcpy(wd_bsignlog.tlr_id, tis2011.tlr_id, sizeof(tis2011.tlr_id));
		memcpy(wd_bsignlog.brno, gwdXdtl.sKinbr, DLEN_BRNO);
		CommonGetCurrentTimeDB(wd_bsignlog.act_time);
		wd_bsignlog.act_type[0] = BSIGNLOG_ACTION_TYPE_RSTPSWD;
		memcpy(wd_bsignlog.act_data,
			tis2011.new_pswd, sizeof(tis2011.new_pswd));
		CommonGetCurrentTimeDB(wd_bsignlog.rec_updt_time);

		if (DbsBSIGNLOG(DBS_INSERT, &wd_bsignlog) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����ǿ�Ʊ��ʧ�ܣ���¼����Ա��־ʧ�ܣ�");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			DbRollbackTxn();
			}
			return;
		}
		else
		{
			/* succeed */
			memcpy(tos2011.tlr_name, wd_btlrctl.tlr_name, sizeof(tos2011.tlr_name));
			memcpy(ptMngOutBuf->sTotaText, &tos2011, sizeof(tos2011));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2011);
			DbCommitTxn();

			return;
		}
	}
}


