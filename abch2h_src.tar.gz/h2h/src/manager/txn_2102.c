/************************************************************************
* Name      :    TXN 2102 (��) ϵͳ�����ֹ��л�ģ�� 					*
*************************************************************************/
#include "manager.h"

void Process_2102(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2102_GROUP
	{
		char	work_date[8];
	} tis2102;

	static struct TOS2102_GROUP
	{
		char	null;
	} tos2102;

	struct	wd_bsysctl_area	wd_bsysctl;

	/* work */
	memset(&tis2102, 0, sizeof(tis2102));
	memset(&tos2102, 0, sizeof(tos2102));

	memcpy(&tis2102, ptMngInBuf->sTitaText, sizeof(tis2102));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	/* get system config on teller expire days */
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, (sizeof(wd_bsysctl.rcd_id) - 1));
	if(DbsBSYSCTL(DBS_LOCK, &wd_bsysctl) != 0)
	{
		DbsBSYSCTL(DBS_CLOSE, &wd_bsysctl);
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯϵͳ���Ʊ����������ݲ����ڣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
	memcpy(wd_bsysctl.last_work_date, wd_bsysctl.work_date, sizeof(wd_bsysctl.work_date));
	memcpy(wd_bsysctl.work_date, tis2102.work_date, sizeof(tis2102.work_date));
	wd_bsysctl.eft_status[0] = '0';

	if(DbsBSYSCTL(DBS_UPDATE, &wd_bsysctl) != 0)
	{
		DbsBSYSCTL(DBS_CLOSE, &wd_bsysctl);
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "����ϵͳ���Ʊ����������ݸ��´���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
	
	/* succeed */
	DbsBSYSCTL(DBS_CLOSE, &wd_bsysctl);
	memcpy(ptMngOutBuf->sTotaText, &tos2102, sizeof(tos2102));
	*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2102);
	DbCommitTxn();
	return;
}
