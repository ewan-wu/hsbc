/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_1001(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS1001_GROUP
	{
		char	dummy;
	} tis1001;
	static struct TOS1001_GROUP
	{
		char	sys_status;
		char	cnaps_status[2];
		char	cnaps_sign;
		char	work_date[8];
		char	last_work_date[8];
		char	work_date_1[8];
		char	work_date_2[8];
		char	online_days[4];
		char	history_max_days[4];
		char	tlr_p_exp_days[4];
		char	tlr_s_exp_days[4];
		char	namount[15];
		char	remarks[60];
	} tos1001;

	/* work */
	struct wd_bsysctl_area	wd_bsysctl;

	memset(&tis1001, 0, sizeof(tis1001));
	memset(&tos1001, 0, sizeof(tos1001));

	memcpy(&tis1001, ptMngInBuf->sTitaText, sizeof(tis1001));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		/* succeed */
		tos1001.sys_status = wd_bsysctl.sys_status[0]; 
		memcpy(tos1001.cnaps_status, wd_bsysctl.cnaps_status, 
			sizeof(tos1001.cnaps_status));
		tos1001.cnaps_sign = wd_bsysctl.cnaps_sign[0]; 
		memcpy(tos1001.work_date, wd_bsysctl.work_date, 
			sizeof(tos1001.work_date));
		memcpy(tos1001.last_work_date, wd_bsysctl.last_work_date, 
			sizeof(tos1001.last_work_date));
		memcpy(tos1001.work_date_1, wd_bsysctl.work_date_1, 
			sizeof(tos1001.work_date_1));
		memcpy(tos1001.work_date_2, wd_bsysctl.work_date_2, 
			sizeof(tos1001.work_date_2));
		{
		char sDays[5];
		sprintf(sDays, "%04d", wd_bsysctl.online_days);
		memcpy(tos1001.online_days, sDays, sizeof(tos1001.online_days));
		sprintf(sDays, "%04d", wd_bsysctl.history_max_days);
		memcpy(tos1001.history_max_days, sDays, 
			sizeof(tos1001.history_max_days));
		sprintf(sDays, "%04d", wd_bsysctl.tlr_p_exp_days);
		memcpy(tos1001.tlr_p_exp_days, sDays, sizeof(tos1001.tlr_p_exp_days));
		sprintf(sDays, "%04d", wd_bsysctl.tlr_s_exp_days);
		memcpy(tos1001.tlr_s_exp_days, sDays, sizeof(tos1001.tlr_s_exp_days));
		memcpy(tos1001.namount, wd_bsysctl.namount, sizeof(tos1001.namount));
		printf("namount[%s]\n", wd_bsysctl.namount);
		}
		memcpy(tos1001.remarks, wd_bsysctl.remarks, 
			sizeof(tos1001.remarks));
		
		memcpy(ptMngOutBuf->sTotaText, &tos1001, sizeof(tos1001));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos1001);

		return;
	}
	else
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "��ѯϵͳ������Ϣ��¼��������¼δ�ҵ���");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}
}


