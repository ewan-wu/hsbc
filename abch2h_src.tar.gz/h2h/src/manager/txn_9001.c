/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_9001(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS9001_GROUP
	{
		char	online_days[4];
		char	history_max_days[4];
		char	tlr_p_exp_days[4];
		char	tlr_s_exp_days[4];
	} tis9001;
	static struct TOS9001_GROUP
	{
		char	dummy;
	} tos9001;

	/* work */
	struct wd_bsysctl_area	wd_bsysctl;

	memset(&tis9001, 0, sizeof(tis9001));
	memset(&tos9001, 0, sizeof(tos9001));

	memcpy(&tis9001, ptMngInBuf->sTitaText, sizeof(tis9001));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);

	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "ϵͳ������Ϣά������¼�����ڣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		}
		return;
	}

	{
	char	sTemp[5];
	memset(sTemp, 0, sizeof(sTemp));
	memcpy(sTemp, tis9001.online_days, 4);
	wd_bsysctl.online_days = atoi(sTemp);
	memcpy(sTemp, tis9001.history_max_days, 4);
	wd_bsysctl.history_max_days = atoi(sTemp);
	memcpy(sTemp, tis9001.tlr_p_exp_days, 4);
	wd_bsysctl.tlr_p_exp_days = atoi(sTemp);
	memcpy(sTemp, tis9001.tlr_s_exp_days, 4);
	wd_bsysctl.tlr_s_exp_days = atoi(sTemp);
	}
	CommonGetCurrentTimeDB(wd_bsysctl.rec_updt_time);

	if (DbsBSYSCTL(DBS_IUPD, &wd_bsysctl) != 0)
	{
		/* fail */
		ptMngOutBuf->tTotaLabel.msgtype = 'E';
		memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
		{
		char sError[256];
		strcpy(sError, "ϵͳ������Ϣά����������Ϣʧ�ܣ�");
		memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
		DbRollbackTxn();
		}
		return;
	}
	else
	{
		/* succeed */
		memcpy(ptMngOutBuf->sTotaText, &tos9001, sizeof(tos9001));
		*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos9001);
		DbCommitTxn();
		return;
	}
}

