/************************************************************************
* Name      :    TXN 1XXX                                               *
*************************************************************************/

#include "manager.h"

void Process_2007(T_MngBufFromTlrDef *ptMngInBuf, T_MngBufToTlrDef *ptMngOutBuf, int *pnOutLen)
{
	/* Tita & Tota Text */
	static struct TIS2007_GROUP
	{
		char	opind;
		char	brh_id[3];		/*���к�*/
		char	dept_id;
		char	tlr_id[8];
		char	tlr_name[40];
		char	work_flag;
		char	work_level;
		char	password[12];
		char	by_dept_id;
		char	by_tlr_id[8];
	} tis2007;
	static struct TOS2007_GROUP
	{
		char	dummy;
	} tos2007;

	int iRet = 0;
  	int iFind = 0;
  	
  	char act_data[16 + 1];
  
	/* work */
	struct wd_btlrctl_area	wd_btlrctl;
	struct wd_btlrctl_tmp_area	wd_btlrctl_tmp;
	struct wd_bscmlog_area	wd_bscmlog;

	memset(&tis2007, 0, sizeof(tis2007));
	memset(&tos2007, 0, sizeof(tos2007));

	memcpy(&tis2007, ptMngInBuf->sTitaText, sizeof(tis2007));

	Process_MoveTotaCommon(ptMngInBuf, ptMngOutBuf);

	if (tis2007.opind != 'I')
		{
	  memset(&wd_btlrctl, 0, sizeof(wd_btlrctl));
		memcpy(wd_btlrctl.tlr_id, tis2007.tlr_id, sizeof(tis2007.tlr_id));
		memcpy(wd_btlrctl.brno, tis2007.brh_id, DLEN_BRNO); 

		if (DbsBTLRCTL(DBS_FIND, &wd_btlrctl) != 0)
		{
			/* fail */
			ptMngOutBuf->tTotaLabel.msgtype = 'E';
			memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
			{
			char sError[256];
			strcpy(sError, "����Ա��Ϣά�����ò���ԱΪ�Ƿ��Ĳ���Ա��");
			memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
			*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
			}
			return;
		}
	}

		memset(&wd_btlrctl_tmp, 0, sizeof(wd_btlrctl_tmp));
		wd_btlrctl_tmp.opcode[0] = tis2007.opind;		
		memcpy(wd_btlrctl_tmp.tlr_id, tis2007.tlr_id, sizeof(tis2007.tlr_id));
		memcpy(wd_btlrctl_tmp.brno, tis2007.brh_id, DLEN_BRNO);
		CommonGetCurrentTimeDB(wd_btlrctl_tmp.rec_updt_time);
		wd_btlrctl_tmp.add_by_dept_id[0] = tis2007.by_dept_id;
		memcpy(wd_btlrctl_tmp.add_by_tlr_id, tis2007.by_tlr_id, 
			sizeof(tis2007.by_tlr_id));
		
		if (tis2007.opind == 'I'){		
		wd_btlrctl_tmp.dept_id[0] = tis2007.dept_id; 
		memcpy(wd_btlrctl_tmp.tlr_name, tis2007.tlr_name, sizeof(tis2007.tlr_name));
		wd_btlrctl_tmp.work_flag[0] = tis2007.work_flag;
		wd_btlrctl_tmp.work_level[0] = '0';
		memcpy(wd_btlrctl_tmp.password, tis2007.password, sizeof(tis2007.password));
		CommonGetCurrentDate(wd_btlrctl_tmp.last_pswd_chg);
		wd_btlrctl_tmp.status[0] = BTLRCTL_STATUS_LOG_OFF;
		wd_btlrctl_tmp.init_flag[0] = BTLRCTL_INIT_FLAG_OFF;
		CommonGetCurrentDate(wd_btlrctl_tmp.last_status_chg);		
		memcpy(wd_btlrctl_tmp.recent_pswd_str, tis2007.password, 
		sizeof(tis2007.password));}
		
		if (tis2007.opind == 'D'){		
		wd_btlrctl_tmp.dept_id[0] = wd_btlrctl.dept_id[0]; 
		memcpy(wd_btlrctl_tmp.tlr_name, wd_btlrctl.tlr_name, sizeof(tis2007.tlr_name));
		wd_btlrctl_tmp.work_flag[0] = wd_btlrctl.work_flag[0];
		wd_btlrctl_tmp.work_level[0] = wd_btlrctl.work_level[0];
		CommonGetCurrentDate(wd_btlrctl_tmp.last_pswd_chg);
		wd_btlrctl_tmp.status[0] = wd_btlrctl.status[0];
		wd_btlrctl_tmp.init_flag[0] = BTLRCTL_INIT_FLAG_OFF;
		CommonGetCurrentDate(wd_btlrctl_tmp.last_status_chg);		
		}

		
		if (tis2007.opind == 'U'){
			wd_btlrctl_tmp.dept_id[0] = tis2007.dept_id; 
			memcpy(wd_btlrctl_tmp.tlr_name, tis2007.tlr_name, sizeof(tis2007.tlr_name));
			wd_btlrctl_tmp.work_flag[0] = tis2007.work_flag;
			if (DbsBTLRCTL_TMP(DBS_LOCK, &wd_btlrctl_tmp) == 0)
			{
			     wd_btlrctl_tmp.dept_id[0] = tis2007.dept_id; 
			     memcpy(wd_btlrctl_tmp.tlr_name, tis2007.tlr_name, sizeof(tis2007.tlr_name));
			     wd_btlrctl_tmp.work_flag[0] = tis2007.work_flag;
                if (DbsBTLRCTL_TMP(DBS_UPDATE, &wd_btlrctl_tmp) != 0)
			    {
				    ptMngOutBuf->tTotaLabel.msgtype = 'E';
					memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
					{
							char sError[256];
							strcpy(sError, "����Ա��Ϣά�������¸ò���Աʧ�ܣ�");
							memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
							*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
					}
					return;

				
			    }
				iFind = 1;
				DbsBTLRCTL_TMP(DBS_CLOSE, &wd_btlrctl_tmp);
			}
			
		 }
			
		if (tis2007.opind == 'M'){
				CommonGetCurrentDate(wd_btlrctl_tmp.last_pswd_chg);
				memcpy(wd_btlrctl_tmp.password, tis2007.password, sizeof(tis2007.password));
			}	
			
        if (iFind == 0)
		{
		     iRet = DbsBTLRCTL_TMP(DBS_INSERT, &wd_btlrctl_tmp);
        }
			if (iRet != 0)
			{
				/* insert fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "�������Ա��ʱ��ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
			}
			return;
			}
			else
			{
				/* insert succeed */

			/* log operator insert */
			memset(&wd_bscmlog, 0, sizeof(wd_bscmlog));
			if (tis2007.opind == 'M'||tis2007.opind == 'D')
			{
				wd_bscmlog.dept_id[0] = '-';
			}else{
				wd_bscmlog.dept_id[0] = tis2007.dept_id;
			}
			memcpy(wd_bscmlog.brno, tis2007.brh_id, DLEN_BRNO); 
			CommonGetCurrentTimeDB(wd_bscmlog.act_time);
			wd_bscmlog.act_type[0] = BSCMLOG_ACTION_TYPE_CAP;
			wd_bscmlog.act_subtype[0] = tis2007.opind;
			memset(act_data, ' ', sizeof(act_data));
			sprintf(act_data, "%-8.8s%-8.8s", gwdXdtl.sTlrno, tis2007.tlr_id);
			memcpy(wd_bscmlog.act_data, act_data, 16);
			CommonGetCurrentTimeDB(wd_bscmlog.rec_updt_time);

			int nRet = 0;
			nRet = DbsBSCMLOG(DBS_INSERT, &wd_bscmlog);
			printf("test nRet = [%d]\n",nRet);
			if(nRet != 0) 
			{
				/* fail */
				ptMngOutBuf->tTotaLabel.msgtype = 'E';
				memcpy(ptMngOutBuf->tTotaLabel.msgno, "9527", 4);
				{
				char sError[256];
				strcpy(sError, "����Ա��Ϣά������¼ά����־ʧ�ܣ�");
				memcpy(ptMngOutBuf->sTotaText, sError, strlen(sError));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + strlen(sError);
				DbRollbackTxn();
				}
				return;
			}
			else
			{
				/* succeed */
				memcpy(ptMngOutBuf->sTotaText, &tos2007, sizeof(tos2007));
				*pnOutLen = sizeof(ptMngOutBuf->tTotaLabel) + sizeof(tos2007);
				DbCommitTxn();
				return;
			}
		
		}	
}
