#include <sybfront.h>
#include <sybdb.h>

#include "cplusplus.h"

#include "htlog.h"
#include "public.h"
#include "glb_def.h"
#include "ipc.h"
#include "common.h"
#include "sysdef.h"
#include "msglog.h"

extern DBPROCESS *dbproc;

extern DBSMALLINT    FindMtNo(char *pString);
extern void          GetTokenStringChr(char *pString, char chSeperate,char *sTmp);
extern short         FindCharPos(char *pString, char *pSeperate1, char *pSeperate3, char *pSeperate2, void *pLen);
extern void          DeleteTailSpace(char *pString,ULONG lTail);
extern void          CommonGetCurrentTime(char *sCurrentTime);

int nProcessCMT417FileCnapsString(char *sTemp0, char *sWorkDate, char *sBankIssno);
int nProcessCMT417FileEisString(char *sTemp0, char *sWorkDate, char *sBankIssno);
void CnapsBankCodeSend2EFT(char *sWorkDate, int type, struct wd_bcnapsbank_area *pwd_bcnapsbank);
void EisBankCodeSend2EFT(char *sWorkDate, int type, struct wd_beisbank_area *pwd_beisbank);
void WriteLogFileToEFT(char *sWorkDate, char *sDataBuf);



int checkTag(char * tTagContent, char tag_type, int len);
char *findTag(char * tag, char * InBuf, char* sTagContent);
char *searchTag(char * InBuf, char * tag);


/*void         GetTokenStringStr(char *, char *,char *);
void         GetTokenStringChr(char *, char ,char *);
short        FindCharPos(char *, char *, char *, char *, void *);
DBSMALLINT   FindMtNo(char *);*/
short        nGetBswfNext(char , short *, short,struct wd_bswiftfld_area *,struct wd_bswiftfld_area *,struct wd_bswiftfld_area *);

short        nDeclareMtCursor(short,char *);
short        nOpenMtCursor();
short        nGetBswfNextFld(struct wd_bswiftfld_area *);
short        nCloseMtCursor();
short        nFreeMtCursor();

short        nDeclareCmtCursor(short);
short        nOpenCmtCursor();
short        nGetBcnsNextTag(struct wd_bcnapsfld_area *);
short        nCloseCmtCursor();
short        nFreeCmtCursor();

long nAddBlock4Data(char *sBlockName, char *sBlockData, char *sPacket);
long nAddTagData(char *sTagName, char *sTagData, char *sPacket);
long nAddBlockData(char *sBlockName, char *sBlockData, char *sPacket);


#define EXIT_PROCESS(nReturn)    {nRet=nReturn;break;}
/*#define EXIT_PROCESS(nRet)    {if(nCloseMtCursor()!=0) \
					{ \
						printf("Cannot Close Cursor!\n"); \
						return -94; \
					} \
					if(nFreeMtCursor()!=0) \
					{ \
						printf("Cannot Free Cursor!\n"); \
						return -95; \
					} \
					return nRet;}
*/

/*****************************************************************************/
/* FUNC:   short MtOutToIn(MT_PACKET *pInPacket,T_HostSwtOutDef *pOut)          */
/* INPUT:  MT_PACKET *pInPacket     ----Mt Packet                            */
/*         T_HostSwtOutDef *pOut       ----T_HostSwtOutDef                */
/* OUTPUT: <none>                                                            */
/* RETURN: 0       -- success                                                */
/*         <0      -- fail                                                   */
/* DESC:   Convert Mt Message to T_HostSwtOutDef structure                      */
/*****************************************************************************/

short MtOutToIn(MT_PACKET *pInPacket,T_HostSwtOutDef *pOut)
{
	/*Table BSWIFTFLD  Variable*/
	struct wd_bswiftfld_area  tBlock,tSubBlock,tTag;
	/*Host Struct*/
	char            *pHostGen;
	T_HostSwtOutDef *pHostMsg;
	MT_PACKET       *pMPacket;
	char            *pInMsg;
	/*User Variable*/	
	ULONG            i,lLenTmp;
	short            nRet;
	short            nMtIndex,nFldIndex;
	DBCHAR           sTmp[MAX_TAGCNT_LEN];
	/*DBCHAR           sNameTmp[FLD_NAME_LEN+1];*/
	DBSMALLINT       nBlkNameLen,nSubBlkNameLen,nTagNameLen;
	DBSMALLINT       nBlkDataLen,nSubBlkDataLen,nTagDataLen;
	/*DBSMALLINT       nBlkFldInx, nSubBlkFldInx, nTagFldInx;*/
	DBSMALLINT       nBlkStart,  nSubBlkStart,  nTagStart;
	/*DBSMALLINT       nBlkEnd,    nSubBlkEnd,    nTagEnd;*/
	/*DBSMALLINT       nBlkFldLen, nSubBlkFldLen, nTagFldLen;*/
	/*DBCHAR           sBlkAttr[FLD_ATTR_LEN+1],
	                 sSubBlkAttr[FLD_ATTR_LEN+1],
	                 sTagAttr[FLD_ATTR_LEN+1];*/
	DBCHAR           sBlkName[FLD_NAME_LEN+1],
	                 sSubBlkName[FLD_NAME_LEN+1],
	                 sTagName[FLD_NAME_LEN+1];


	/*Start Processing*/
	printf("\n------------MtOutToIn Start--------------\n");

	pMPacket=(MT_PACKET *)pInPacket;
	pHostMsg=(T_HostSwtOutDef *)pOut;
	pHostGen=(char *)&pHostMsg->tHostGen;
	pInMsg=pMPacket->sPacket;

	memcpy(pHostMsg->sMsgAck, pMPacket->sMsgAck, PACKET_MSG_ACK);

	lLenTmp=strlen(pInMsg);
	printf("[%d][%d][%s]\n",pMPacket->packet_len,lLenTmp,pInMsg);
	/*Judge the Message Length*/
	if ((pMPacket->packet_len!=lLenTmp)&&(pMPacket->packet_len!=lLenTmp+1))
	{
		printf("Invalid Message Length!\n");
		return -9;
	}

	/*Identify Message Type*/
	if (memcmp(pHostMsg->sMsgAck, "MSGACK", strlen("MSGACK"))==0)
	{
		nMtIndex=7;/*007;*/
		memcpy(pHostMsg->tHostGen.sMsgType, "ACK", strlen("ACK"));
	}
	else
	{
		nMtIndex=FindMtNo(pInMsg);
		printf("MsgType[%d]\n", nMtIndex);
		if(nMtIndex==-1)
		{
				printf("Cannot Find Message Type!\n");
				return -91;
		}
		sprintf(sTmp, "%03d", nMtIndex);
		memcpy(pHostMsg->tHostGen.sMsgType, sTmp, strlen(sTmp));
	}


	if(nDeclareMtCursor(nMtIndex,"2")!=0)
	{
		printf("Cannot Declare Cursor MtConvert_CUR!\n");
		return -92;
	}

	if(nOpenMtCursor()!=0)
	{
		printf("Cannot Open Cursor MtConvert_CUR!\n");
		return -93;
	}

	/*Initial Variable*/
	nBlkNameLen=0;
	nSubBlkNameLen=0;
	nTagNameLen=0;

	nBlkDataLen=0;
	nSubBlkDataLen=0;
	nTagDataLen=0;

	/*nBlkFldInx=0;
	nSubBlkFldInx=0;
	nTagFldInx=0;*/

	nBlkStart=0;
	nSubBlkStart=0;
	nTagStart=0;

	/*nBlkEnd=0;
	nSubBlkEnd=0;
	nTagEnd=0;*/

	/*nBlkFldLen=0;
	nSubBlkLen=0;
	nTagLen=0;*/
	
	/*nRecordAttr=NO_RECODE_DEF;*/
	
	/*memset(sBlkAttr, 0, FLD_NAME_LEN+1);
	memset(sSubBlkAttr, 0, FLD_NAME_LEN+1);
	memset(sTagAttr, 0, FLD_NAME_LEN+1);*/

	memset(sBlkName, 0, FLD_NAME_LEN+1);
	memset(sSubBlkName, 0, FLD_NAME_LEN+1);
	memset(sTagName, 0, FLD_NAME_LEN+1);
	
	memset(&tBlock, 0, sizeof(tBlock));
	memset(&tSubBlock, 0, sizeof(tSubBlock));
	memset(&tTag, 0, sizeof(tTag));

	nFldIndex=1;
	i=0;
	nRet=0;
	while(i<pMPacket->packet_len)
	{
		/*Push Stack*/
		if (pInMsg[i]=='{')
		{	/*block*/

			if (nBlkNameLen==0)
			{
				GetTokenStringChr(&pInMsg[i+1], ':', sBlkName);
				nBlkNameLen=strlen(sBlkName);
				if (nBlkNameLen==0) 
				{
					printf("Block name missing!\n");
					EXIT_PROCESS(-21);
				}
				i=i+nBlkNameLen+2;
				nBlkStart=i;
				do{
					if (nGetBswfNext('b',&nFldIndex,nMtIndex,&tBlock,&tSubBlock,&tTag)==0)
					{
						printf("Block[%s] is unexpected!\n", sBlkName);
						EXIT_PROCESS(-51);
					}
					if((tBlock.fld_opt[0]=='1')
							&&((nBlkNameLen!=(tBlock.fld_name_len[0]-'0'))
							||(memcmp(sBlkName, tBlock.fld_name, nBlkNameLen)!=0)))
					{
						printf("Block[%s] record is lost!\n", tBlock.fld_name);
						EXIT_PROCESS(-52);
					}
					if ((tBlock.fld_opt[0]=='0')
							&&((nBlkNameLen!=(tBlock.fld_name_len[0]-'0'))
							||(memcmp(sBlkName, tBlock.fld_name, nBlkNameLen)!=0)))
						nFldIndex+=tBlock.sub_tag;
				}while((tBlock.fld_opt[0]=='0')
						&&((nBlkNameLen!=(tBlock.fld_name_len[0]-'0'))
						||(memcmp(sBlkName, tBlock.fld_name, nBlkNameLen)!=0)));

			}
			else if ((nBlkNameLen>0)&&(nSubBlkNameLen==0))
			{
				GetTokenStringChr(&pInMsg[i+1], ':', sSubBlkName);
				nSubBlkNameLen=strlen(sSubBlkName);
				if (nSubBlkNameLen==0) 
				{
					printf("Subblock name missing!\n");
					EXIT_PROCESS(-22);
				}
				i=i+nSubBlkNameLen+2;
				nSubBlkStart=i;
				do{
					if (nGetBswfNext('s',&nFldIndex,nMtIndex,&tBlock,&tSubBlock,&tTag)==0)
					{
						printf("SubBlock[%s] is unexpected!\n", sSubBlkName);
						EXIT_PROCESS(-53);
					}
					if((tSubBlock.fld_opt[0]=='1')
							&&((nSubBlkNameLen!=(tSubBlock.fld_name_len[0]-'0'))
							||(memcmp(sSubBlkName, tSubBlock.fld_name, nSubBlkNameLen)!=0)))
					{
						printf("SubBlock[%s] record is lost!\n", tSubBlock.fld_name);
						EXIT_PROCESS(-54);
					}
				}while((tSubBlock.fld_opt[0]=='0')
						&&((nSubBlkNameLen!=(tSubBlock.fld_name_len[0]-'0'))
						||(memcmp(sSubBlkName, tSubBlock.fld_name, nSubBlkNameLen)!=0)));
			}
			else /*More Layer Contained or Incorrect Format*/
			{
				printf("Incorrect Block Start Format !\n");
				EXIT_PROCESS(-2);
			}/*Start block identification end*/
			
			continue;
			
		}/*end '{'*/
		else if (pInMsg[i]=='}')
		{
			if ((nSubBlkNameLen>0)&&(nBlkNameLen>0))
			{
				/*nSubBlkEnd=i-1;*/
				nSubBlkDataLen=i-nSubBlkStart;
				if (nSubBlkDataLen>tSubBlock.data_len) 
				{
					printf("Subblock[%s] data length[%d]invalid!\n",sSubBlkName,nSubBlkDataLen);
					EXIT_PROCESS(-62);
				}
				if ((tSubBlock.len_flg[0]=='0')&&(tSubBlock.data_len!=nSubBlkDataLen))
				{
					printf("Subblock[%s] data length (fixed)[%d]invalid!\n",sSubBlkName,nSubBlkDataLen);
					EXIT_PROCESS(-64);
				}
#ifdef DEBUG
				printf("subblock name[%5s]taglen[%5d]startpos[%5d]endpos[%5d]datalen[%5d]\n",
					sSubBlkName, nSubBlkNameLen, nSubBlkStart,
					nSubBlkEnd, nSubBlkDataLen);
				printf("[%d][%2d][%s][%6s][%1s][%1s][%3s][%2d][%1s][%1s][%1s][%4d][%4d][%1s]\n",
					tSubBlock.mt_index,tSubBlock.fld_index,
					tSubBlock.mt,tSubBlock.fld_name,tSubBlock.fld_name_len,tSubBlock.fld_type,tSubBlock.fld_attr,
					tSubBlock.sub_tag,
					tSubBlock.fld_opt,tSubBlock.fld_flg,tSubBlock.len_flg,
					tSubBlock.fld_data_pos,tSubBlock.data_len,
					tSubBlock.fld_team);
#endif
				memcpy(&pHostGen[tSubBlock.fld_data_pos], &pInMsg[nSubBlkStart], nSubBlkDataLen);

				memcpy(sTmp, &pInMsg[nSubBlkStart], nSubBlkDataLen);
				sTmp[nSubBlkDataLen]=0;
				printf("\tSubblock:[%6s][%s]\n\n", sSubBlkName, sTmp);
				if((tSubBlock.fld_flg[0]=='0')&&(nRet<tSubBlock.fld_data_pos-sizeof(T_HostOutGenFldDef)+tSubBlock.data_len))
					nRet=tSubBlock.fld_data_pos-sizeof(T_HostOutGenFldDef)+tSubBlock.data_len;

/* laura */
/*printf("nRet [%d][%d][%d][%d]\n", nRet,tSubBlock.data_len,tSubBlock.fld_data_pos, __LINE__);*/

				memset(&tSubBlock, 0, sizeof(struct wd_bswiftfld_area));

				nSubBlkNameLen=0;
				nSubBlkStart=0;
				/*nSubBlkEnd=0;*/
			}
			else if ((nSubBlkNameLen==0)&&(nBlkNameLen>0))
			{

				/*nBlkEnd=i-1;*/
				nBlkDataLen=i-nBlkStart;
				if ((nBlkDataLen>tBlock.data_len)&&(memcmp(tBlock.fld_attr, "000", 3)==0))
				{
					printf("Block[%s] data length[%d] invalid!\n",sBlkName,nBlkDataLen);
					EXIT_PROCESS(-61);
				}
				if ((tBlock.len_flg[0]=='0')&&(tBlock.data_len!=nBlkDataLen))
				{
					printf("Block[%s] data length[%d](fixed) invalid!\n",sBlkName,nBlkDataLen);
					EXIT_PROCESS(-63);
				}
#ifdef DEBUG
				printf("---block name[%5s]taglen[%5d]startpos[%5d]endpos[%5d]datalen[%5d]attr[%3s]\n",
					sBlkName, nBlkNameLen, nBlkStart,
					nBlkEnd, nBlkDataLen,
					tBlock.fld_attr);
				printf("[%d][%2d][%s][%6s][%1s][%1s][%3s][%2d][%1s][%1s][%1s][%4d][%4d][%1s]\n",
					tBlock.mt_index,tBlock.fld_index,
					tBlock.mt,tBlock.fld_name,tBlock.fld_name_len,tBlock.fld_type,tBlock.fld_attr,
					tBlock.sub_tag,
					tBlock.fld_opt,tBlock.fld_flg,tBlock.len_flg,
					tBlock.fld_data_pos,tBlock.data_len,
					tBlock.fld_team);
#endif

				if (memcmp(tBlock.fld_attr, "000", 3)==0)
				{
					memcpy(&pHostGen[tBlock.fld_data_pos], &pInMsg[nBlkStart], nBlkDataLen);
					memcpy(sTmp, &pInMsg[nBlkStart], nBlkDataLen);
					sTmp[nBlkDataLen]=0;
					printf("Block:[%6s][%s]\n\n", sBlkName, sTmp);
					if((tBlock.fld_flg[0]=='0')&&(nRet<tBlock.fld_data_pos-sizeof(T_HostOutGenFldDef)+tBlock.data_len))
						nRet=tBlock.data_len+tBlock.fld_data_pos-sizeof(T_HostOutGenFldDef);
/* laura */
/*printf("nRet [%d][%d][%d][%d]\n", nRet,tBlock.data_len,tBlock.fld_data_pos, __LINE__);*/

				}

				memset(&tBlock, 0, sizeof(struct wd_bswiftfld_area));

				nBlkNameLen=0;
				nBlkStart=0;
				/*nBlkEnd=0;*/
			}
			else 
			{
				printf("Incorrect Block End Format!\n");
				EXIT_PROCESS(-3);
			}/*End block identification end */
			
		}/*end '}'*/
		else if ((pInMsg[i]==':')&&(pInMsg[i-1]=='\x0a')&&(pInMsg[i-2]=='\x0d'))
		{
			if ((nBlkNameLen>0)&&(nSubBlkNameLen==0))
			{
				GetTokenStringChr(&pInMsg[i+1], ':', sTagName);
				nTagNameLen=strlen(sTagName);
				if (nTagNameLen==0) 
				{
					printf("Tag name missing!\n");
					EXIT_PROCESS(-41);
				}
				i=i+nTagNameLen+2;
				nTagStart=i;

				if (FindCharPos(&pInMsg[i], "\x0d\x0a:", "\x0d\x0a-",  "\x0d\x0a}",&nTagDataLen)!=0) 
				{
					printf("Tag data lost!\n");
					EXIT_PROCESS(-42);
				}
				/*nTagDataLen+=2;*/
				/*nTagEnd=nTagStart+nTagDataLen-1;*/

				do{
					if (nGetBswfNext('t',&nFldIndex,nMtIndex,&tBlock,&tSubBlock,&tTag)==0)
					{
						printf("Tag[%s] is unexpected!\n", sTagName);
						EXIT_PROCESS(-43);
					}
					/*add by garhee li 2003/11/12*/
					if((tTag.fld_name_len[0]=='6')&&(memcmp(tTag.fld_name, "ZZZZZZ", 6)==0))
					{
						if (FindCharPos(&pInMsg[i], "\x0d\x0a-}", "\x0d\x0a-", "\x0d\x0a}",  &nTagDataLen)!=0) 
						{
							printf("Tag data lost!\n");
							EXIT_PROCESS(-45);
						}
						i=i+nTagDataLen-1;
						nTagNameLen=tTag.fld_name_len[0]-'0';
						memcpy(sTagName, tTag.fld_name, nTagNameLen);
						break;
					}
					if((tTag.fld_opt[0]=='1')
							&&((nTagNameLen!=(tTag.fld_name_len[0]-'0'))
							||(memcmp(sTagName, tTag.fld_name, nTagNameLen)!=0)))
					{
						printf("Tag[%s] record is lost!\n", tTag.fld_name);
						EXIT_PROCESS(-44);
					}
				}while((tTag.fld_opt[0]=='0')
						&&((nTagNameLen!=(tTag.fld_name_len[0]-'0'))
						||(memcmp(sTagName, tTag.fld_name, nTagNameLen)!=0)));

#ifdef DEBUG
				printf("tag----name[:%5s:]taglen[%5d]startpos[%5d]endpos[%5d]datalen[%5d]\n",
					sTagName, nTagNameLen, nTagStart,
					nTagEnd, nTagDataLen);
				printf("[%d][%2d][%s][%6s][%1s][%1s][%3s][%2d][%1s][%1s][%1s][%4d][%4d][%1s]\n",
					tTag.mt_index,tTag.fld_index,
					tTag.mt,tTag.fld_name,tTag.fld_name_len,tTag.fld_type,tTag.fld_attr,
					tTag.sub_tag,
					tTag.fld_opt,tTag.fld_flg,tTag.len_flg,
					tTag.fld_data_pos,tTag.data_len,
					tTag.fld_team);
#endif

				/* Modified by Laura, 2004/04/28, temp
				if (nTagDataLen>tTag.data_len) 
				*/
				if (nTagDataLen-8>tTag.data_len) 
				{
					printf("Tag[%s] data length[%d] invalid!\n",sTagName,nTagDataLen);
					EXIT_PROCESS(-65);
				}
				if ((tTag.len_flg[0]=='0')&&(tTag.data_len!=nTagDataLen))
				{
					printf("Tag[%s] data length (fixed)[%d] invalid!\n",sTagName,nTagDataLen);
					EXIT_PROCESS(-67);
				}
				/* Modified by Laura, 2004/04/28, temp
				memcpy(&pHostGen[tTag.fld_data_pos], &pInMsg[nTagStart], nTagDataLen);
					memcpy(sTmp, &pInMsg[nTagStart], nTagDataLen);
					sTmp[nTagDataLen]=0;
				*/
				if (nTagDataLen>tTag.data_len) 
				{
				memcpy(&pHostGen[tTag.fld_data_pos], &pInMsg[nTagStart], tTag.data_len);
					memcpy(sTmp, &pInMsg[nTagStart], tTag.data_len);
					sTmp[tTag.data_len]=0;
				}
				else
				{
				memcpy(&pHostGen[tTag.fld_data_pos], &pInMsg[nTagStart], nTagDataLen);
					memcpy(sTmp, &pInMsg[nTagStart], nTagDataLen);
					sTmp[nTagDataLen]=0;
				}
					printf("\t     Tag:[%6s][%s]\n\n", sTagName, sTmp);

				if((tTag.fld_flg[0]=='0')&&(nRet<tTag.fld_data_pos-sizeof(T_HostOutGenFldDef)+tTag.data_len))
					nRet=tTag.data_len+tTag.fld_data_pos-sizeof(T_HostOutGenFldDef);
/* laura */
/*printf("nRet [%d][%d][%d][%d]\n", nRet,tTag.data_len,tTag.fld_data_pos, __LINE__);*/

				memset(&tTag, 0, sizeof(struct wd_bswiftfld_area));
			}
			else 
			{
				printf("Incorrect Tag Format!\n");
				EXIT_PROCESS(-4);
			}/*Tag identification end */
		}/*end ':'*/

		i++;
	}/*end while*/



	

	if(nCloseMtCursor()!=0)
	{
		printf("Cannot Close Cursor MtConvert_CUR!\n");
		return -94;
	}
	if(nFreeMtCursor()!=0)
	{
		printf("Cannot Free Cursor MtConvert_CUR!\n");
		return -95;
	}
	printf("\n------------MtOutToIn End--------------\n");
/* laura */
printf("nRet [%d]\n", nRet);

	return nRet;


}/*End of MtOutToIn*/

/****************************************************************************/
/* FUNC:   short MtInToOut (T_HostSwtInDef   *pHostIn, MT_PACKET  *pPacketOut)*/
/* INPUT:   T_HostSwtInDef    *pHostIn;                                       */
/* OUTPUT:  MT_PACKET       *pPacketOut;                                    */
/* RETURN: 0       -- format convert success    		            */
/*         <0      -- format convert fail		                    */
/* DESC:   convert the  T_HostSwtInDef to Host Packet                           */
/****************************************************************************/
short MtInToOut (T_HostSwtInDef   *pHostIn, MT_PACKET  *pPacketOut)
{
	ULONG lPktLen,lTagLen,lTagDataLen,lBlkLen;/**/
	/*long  iRsvPos;*/
	short nRet,nFldIndex;
	char  sPktLen[PACKET_LEN_BIT+1];
	char  sMtNo[MT_BIT+1];
	/*char  sPktDat[9];
	char  sTag[FLD_NAME_LEN+1];*/	
	char  sTagContent[MAX_TAGCNT_LEN];
	char  sBlkContent[MAX_PACKET_LEN];
	char  *curPos,*inBuf;
	/*int   i=0,j=0;*/
	int   nMtNo;		
	struct wd_bswiftfld_area  tBlock,tTag;/*,tSubBlock*/



	printf("\n------------MtInToOut Start--------------\n");

	memset(pPacketOut, 0, sizeof(MT_PACKET));

	curPos=pPacketOut->sPacket;
	inBuf=(char *)&pHostIn->tHostGen;
	/*ȡ��MT����*/
	memset(sMtNo, 0, sizeof(sMtNo));
	memcpy(sMtNo, "MT", 2);
	memcpy(sMtNo+2, pHostIn->tHostGen.sMsgType, 3);		
	nMtNo=atol(&sMtNo[2]);
	if (nMtNo<100) return -1;
	
	/*����ȡ����MT�����ѯ�ӿڱ��ı�BSWIFTFLD*/
	
	if(nDeclareMtCursor(nMtNo,"1")!=0)
	{
		printf("Cannot Declare Cursor!\n");
		return -3;
	}

	if(nOpenMtCursor()!=0)
	{
		printf("Cannot Open Cursor!\n");
		return -4;
	}
	lPktLen=0;
	nRet=0;
	nFldIndex=1;
	/*tTag.fld_index=nFldIndex;*/
	memset(&tBlock, 0, sizeof(tBlock));
	/*memset(&tSubBlock, 0, sizeof(tSubBlock));*/
	memset(&tTag, 0, sizeof(tTag));
	while ((tTag.fld_index=nFldIndex)&&(nGetBswfNextFld(&tTag)==1))
	{
		nFldIndex++;
		lBlkLen=strlen(sBlkContent);
		if ((tBlock.fld_index>0)
			&&(memcmp(tBlock.fld_attr,"000",3)!=0)
			&&(lBlkLen>0)
			&&(tTag.fld_index==tBlock.fld_index+tBlock.sub_tag+1)) /*Block(with sub)*/
		{
			curPos=&pPacketOut->sPacket[lPktLen];
			if (strcmp(tBlock.fld_name, "4")!=0)
				lPktLen=lPktLen+lBlkLen
					+nAddBlockData(tBlock.fld_name, sBlkContent, curPos);
			else
				lPktLen=lPktLen+lBlkLen
					+nAddBlock4Data(tBlock.fld_name, sBlkContent, curPos);
printf("\nsBlock[%s]sBlkContent[%s]\n",tBlock.fld_name,sBlkContent);
			memset(&tBlock, 0, sizeof(tBlock));
			memset(sBlkContent, 0, MAX_PACKET_LEN);
		}

		if ((tTag.fld_type[0]=='b')
			&&(memcmp(tTag.fld_attr,"000",3)!=0)) /*Block(with sub)*/
		{
			memset(sBlkContent, 0, MAX_PACKET_LEN);
			memcpy(&tBlock, &tTag, sizeof(tTag));
			curPos=sBlkContent;
			continue;
		}
		if (tTag.data_len==0) continue;
		memset(sTagContent, 0, MAX_TAGCNT_LEN);
		memcpy(sTagContent, &inBuf[tTag.fld_data_pos], tTag.data_len);

		if (tTag.len_flg[0]!='0') DeleteTailSpace(sTagContent,strlen(sTagContent));
		lTagDataLen=strlen(sTagContent);
		
		
		if (lTagDataLen>tTag.data_len)
		{
			printf("[%d][%s][%ld][%d]too long\n", nMtNo, tTag.fld_name, lTagDataLen, __LINE__);
			EXIT_PROCESS(-101);
		}
		/*���Tag���ǿ�ѡ*/
		if ((lTagDataLen==0)&&(tTag.fld_opt[0]=='0'))
		{
			continue;
		}
		else  /*���Block�ǿ�ѡ��Tag���ǲ���ѡ*/
		if ((lTagDataLen==0)&&(tTag.fld_opt[0]=='1')
			&&(tBlock.fld_opt[0]=='0')
			&&(strlen(sBlkContent)==0))
		{
			memset(&tBlock, 0, sizeof(tBlock));
			nFldIndex=tBlock.fld_index+tBlock.sub_tag+1;
			continue;
		}
		else if (lTagDataLen==0)
		{
			printf("[%d][%s][%ld][%d]missing\n", nMtNo, tTag.fld_name, lTagDataLen, __LINE__);
			EXIT_PROCESS(-103);
		}
		/*���Tag���Ƕ���*/
		if ((tTag.len_flg[0]=='0')&&(lTagDataLen!=tTag.data_len))
		{
			printf("[%d][%s][%ld][%d]fixed length error\n", nMtNo, tTag.fld_name, lTagDataLen, __LINE__);
			EXIT_PROCESS(-102);
		}


		if ((tTag.fld_type[0]=='b')
			&&(memcmp(tTag.fld_attr,"000",3)==0)) /*Block(fixed length)*/
		{
			curPos=&pPacketOut->sPacket[lPktLen];
			lPktLen=lPktLen+lTagDataLen+nAddBlockData(tTag.fld_name, sTagContent, curPos);
		}
		else
		if (tTag.fld_type[0]=='s') /*SubBlock*/
		
		{
			if (tBlock.fld_attr[0]=='0') continue;
			if (tBlock.fld_attr[1]!='1') continue;
			if (tBlock.fld_attr[0]=='1')
				tBlock.fld_attr[2]='0';
			lTagLen=nAddBlockData(tTag.fld_name, sTagContent, curPos);
			curPos=&curPos[lTagDataLen+lTagLen];
		}
		else
		if (tTag.fld_type[0]=='t') /*Tag*/
		
		{
			if (tBlock.fld_attr[0]=='0') continue;
			if (tBlock.fld_attr[2]!='1') continue;
			if (tBlock.fld_attr[0]=='1')
				tBlock.fld_attr[1]='0';
			lTagLen=nAddTagData(tTag.fld_name, sTagContent, curPos);
			curPos=&curPos[lTagDataLen+lTagLen];
		}

printf("\nTag_type[%c]; sTag[%s]; sTagContent[%s][%ld]\n",tTag.fld_type[0], tTag.fld_name, sTagContent,lTagDataLen);
/*printf("Block[%s]\n",sBlkContent);*/
	}


	lBlkLen=strlen(sBlkContent);
	if ((tBlock.fld_index>0)
		&&(memcmp(tBlock.fld_attr,"000",3)!=0)
		&&(lBlkLen>0)
		&&(nFldIndex==tBlock.fld_index+tBlock.sub_tag+1)) /*Block(with sub)*/
	{
		curPos=&pPacketOut->sPacket[lPktLen];
		if (strcmp(tBlock.fld_name, "4")!=0)
			lPktLen=lPktLen+lBlkLen
				+nAddBlockData(tBlock.fld_name, sBlkContent, curPos);
		else
			lPktLen=lPktLen+lBlkLen
				+nAddBlock4Data(tBlock.fld_name, sBlkContent, curPos);
printf("\nsBlock[%s]sBlkContent[%s]\n",tBlock.fld_name,sBlkContent);
	}



	curPos=&pPacketOut->sPacket[lPktLen];
	strcpy(curPos, "\x0a");
	lPktLen+=strlen("\x0a");

	if(nCloseMtCursor()!=0)
	{
		printf("Cannot Close Cursor!\n");
		return -5;
	}
	if(nFreeMtCursor()!=0)
	{
		printf("Cannot Free Cursor!\n");
		return -6;
	}

	pPacketOut->packet_len=lPktLen;
	sprintf(sPktLen,"%08ld",lPktLen);
	memcpy(pPacketOut->sPacketLen, sPktLen, PACKET_LEN_BIT);

	printf("\n------------MtInToOut End--------------\n");

	return nRet;
}/*end of MtInToOut*/



/****************************************************************************/
/* FUNC:   int CnsOutToIn (char * InBuf��T_TitaPktDef * cnsSwtBuf)          */
/* INPUT:  InBuf                CNAPS Packet                                */
/* OUTPUT: T_TitaPktDef	        CnapsSwtIPC                                 */
/* RETURN: 0       -- format convert success    		            */
/*         <0      -- format convert fail		                    */
/* DESC:   convert the  CNAPS Packet to  CnapsSwtIPC                        */
/****************************************************************************/
int CnsOutToIn (char * InBuf, T_TitaPktDef * cnsSwtBuf)
{
	long  lPktLen,lCmtNo,lLenTmp,lPktLenTmp;
	int   iRsvPos;
	short nRet;
	char  sPktLen[7];
	char  sPktRef[21];
	char  sCmtNo[7];
	char  sPktDat[9];
	char  sTag[6];	
	char  sTagContent[MAX_TAGCNT_LEN];
	char *curPos,*curTmp;		
	struct wd_bcnapsfld_area tPktInf;

	char *tCnsSwtBuf;

	printf("\n------------CnsOutToIn Start--------------\n");

	tCnsSwtBuf = (char *)cnsSwtBuf;
	iRsvPos = 0;
	if(memcmp(InBuf, "{1:", 3 )!=0) 
	{
		
		return -1;
	}
	
	/*ȡ�����ĳ��ȣ��Ƚ��Ƿ�����������򱨴�����*/	
	memset(sPktLen, 0, 7);
	memcpy(sPktLen, InBuf+3, 6);
	lPktLen = atol(sPktLen);
	if(InBuf[lPktLen-1]!='}')
	{
		return -2;	
	}

	InBuf[lPktLen] = 0;
	

	/*ȡ�����Ĳο���23,20*/
	memset(sPktRef, 0, 21);
	memcpy(sPktRef, InBuf+23, 20);	
	/*ȡ��CMT����57��3*/
	memset(sCmtNo, 0, 7);
	memcpy(sCmtNo, "CMT", 3);
	memcpy(&sCmtNo[3], InBuf+57, 3);
	lCmtNo=atol(&sCmtNo[3]);
	/*ȡ������60��8*/
	memset(sPktDat, 0, 9);
	memcpy(sPktDat, InBuf+60, 8);	
	/*����ͷ�����*/
	memcpy(tCnsSwtBuf+329, InBuf+57, 3);/*CNAPS���״���*/			
	memcpy(tCnsSwtBuf+469, InBuf+11, 1);/*ҵ������*/		
	memcpy(tCnsSwtBuf+470, InBuf+12, 3);/*ҵ��״̬*/	
	memcpy(tCnsSwtBuf+332, InBuf+15, 8);/*���ı�ʶ��*/
	memcpy(tCnsSwtBuf+340, InBuf+23, 20);/*���Ĳο���*/			
	memcpy(tCnsSwtBuf+360, InBuf+60, 8);/*���Ĳο���*/			


	/*������������*/
printf("\n sPktRef [%s],sCmtNo[%s],sPktDat[%s]\n", sPktRef,sCmtNo,sPktDat);
	
	if(nDeclareCmtCursor(lCmtNo)!=0)
	{
		printf("Cannot Declare Cursor CMTConvert_CUR!\n");
		return -3;
	}

	if(nOpenCmtCursor()!=0)
	{
		printf("Cannot Open Cursor CMTConvert_CUR!\n");
		return -4;
	}
	curPos=InBuf;
/*	if (memcmp(&InBuf[CNS_PKTHEAD_LEN],"{3:",3)==0)
		curPos=&InBuf[CNS_PKTHEAD_LEN+3];
	else
	if (memcmp(&InBuf[CNS_PKTHEAD_LEN2],"{3:",3)==0)
		curPos=&InBuf[CNS_PKTHEAD_LEN2+3];
*/	if (memcmp(&InBuf[CNS_PKTHEAD_LEN],"{3:",3)==0)
	{
		lPktLenTmp=CNS_PKTHEAD_LEN+3;
		curPos=&InBuf[CNS_PKTHEAD_LEN+3];
	}
	else
	if (memcmp(&InBuf[CNS_PKTHEAD_LEN2],"{3:",3)==0)
	{
		lPktLenTmp=CNS_PKTHEAD_LEN2+3;
		curPos=&InBuf[CNS_PKTHEAD_LEN2+3];
	}
	nRet=0;
	while (nGetBcnsNextTag(&tPktInf)==1)
	{
		
		strcpy(tPktInf.cmt,sCmtNo);
		/*printf("[%s]\n", curPos);*/

		sTag[0]=':';
		memcpy(sTag+1, tPktInf.tag, 3);
		sTag[4]=':';
		sTag[5]=0;				
		memset(sTagContent, 0, MAX_TAGCNT_LEN);
		
		/*���Tag���Ǳ�ѡ��*/
		if(tPktInf.tag_opt[0]=='1')
		{	
				if((curPos=findTag(sTag, curPos, sTagContent))==0) 
				{
					printf("[%s][%s][%d] missing\n", tPktInf.cmt, tPktInf.tag, __LINE__);
					EXIT_PROCESS(-100);
				}
				lLenTmp=strlen(sTagContent);
				if(lLenTmp>tPktInf.data_len)/*���Ȳ��Ϸ�*/
				{
					printf("[%s][%s][%d]invalid length\n", tPktInf.cmt, tPktInf.tag, __LINE__);
					printf("[%d][%d]invalid length\n", tPktInf.data_len, lLenTmp);
					EXIT_PROCESS(-101);
				}
				if ((tPktInf.len_flg[0]=='0')&&(lLenTmp!=tPktInf.data_len)) /*��������*/
				{
					printf("[%s][%s][%ld][%d]fixed length error\n", tPktInf.cmt, tPktInf.tag, lLenTmp, __LINE__);
					EXIT_PROCESS(-103);
				}
				

				if(tPktInf.tag_flg[0]=='1')/*ͨ����*/
				{
					memcpy(tCnsSwtBuf+tPktInf.tag_data_pos, sTagContent, lLenTmp);
				}
				else/*��ͨ����*/
				{
					if((iRsvPos+lLenTmp)>IPC_RSV_LEN)/*�Զ����򲻹���*/
					{
						printf("[%s][%s][%d]too long\n", tPktInf.cmt, tPktInf.tag, __LINE__);
						EXIT_PROCESS(-102);
					}
					memcpy(tCnsSwtBuf+tPktInf.tag_data_pos, sTagContent, lLenTmp);
					iRsvPos+=tPktInf.data_len;
				}
		}
		/*���Tag���ǿ�ѡ��*/
		else
		{
				curTmp=curPos;
				if((curPos=findTag(sTag, curPos, sTagContent))==0) 
				{
					if(tPktInf.tag_flg[0]!='1')/*��ͨ����*/
					{
						if((iRsvPos+tPktInf.data_len)>IPC_RSV_LEN)/*�Զ����򲻹���*/
						{
							printf("[%s][%s][%d]too long\n", tPktInf.cmt, tPktInf.tag, __LINE__);
							EXIT_PROCESS(-102);
						}
						/*memset(tCnsSwtBuf+tPktInf.tag_data_pos, ' ', tPktInf.data_len); */
						iRsvPos+=tPktInf.data_len;
					}
					curPos=curTmp;
					continue;
				}
				lLenTmp=strlen(sTagContent);
				if(lLenTmp>tPktInf.data_len)/*���Ȳ��Ϸ�*/
				{
					printf("[%s][%s][%d]invalid length\n", tPktInf.cmt, tPktInf.tag, __LINE__);
					EXIT_PROCESS(-106);
				}
				if ((tPktInf.len_flg[0]=='0')&&(lLenTmp!=tPktInf.data_len)) /*��������*/
				{
					printf("[%s][%s][%ld][%d]fixed length error\n", tPktInf.cmt, tPktInf.tag, lLenTmp, __LINE__);
					EXIT_PROCESS(-104);
				}
				if(tPktInf.tag_flg[0]=='1')/*ͨ����*/
				{
					memcpy(tCnsSwtBuf+tPktInf.tag_data_pos, sTagContent, lLenTmp);
				}
				else/*��ͨ����*/
				{
					if((iRsvPos+lLenTmp)>IPC_RSV_LEN)/*�Զ����򲻹���*/
					{
						printf("[%s][%s][%d]too long\n", tPktInf.cmt, tPktInf.tag, __LINE__);
						EXIT_PROCESS(-102);
					}
					memcpy(tCnsSwtBuf+tPktInf.tag_data_pos, sTagContent, lLenTmp); 
					iRsvPos+=tPktInf.data_len;
				}	
		}
		lPktLenTmp=lPktLenTmp+5+lLenTmp;
printf("sTag[%s], len[%4d], sTagContent[%s]\n",sTag,lLenTmp,sTagContent);		
	}

printf("len[%4d]\n",lPktLenTmp);		
	if(lPktLenTmp!=lPktLen-1)
	{
		nCloseCmtCursor();
		nFreeCmtCursor();
		strcpy(tPktInf.cmt,sCmtNo);
		printf("[%s][%d][%d]Invalid Packet\n", tPktInf.cmt, lPktLen, __LINE__);
		return -99;
	}
/*	if((*curPos!='}')&&(nRet==0))
	{
		strcpy(tPktInf.cmt,sCmtNo);
		printf("[%s][%d][%d]Invalid Packet\n", tPktInf.cmt, lPktLen, __LINE__);
		nRet=-99;
	}
*/

	if(nCloseCmtCursor()!=0)
	{
		printf("Cannot Close Cursor CMTConvert_CUR!\n");
		return -5;
	}
	if(nFreeCmtCursor()!=0)
	{
		printf("Cannot Free Cursor CMTConvert_CUR!\n");
		return -6;
	}
	printf("\n------------CnsOutToIn End--------------\n");

	if(nRet==0) return iRsvPos;
	return nRet;
}/*end of CnsOutToIn*/

/****************************************************************************/
/* FUNC:   int CnsInToOut (char * outBuf��T_CnsTotaPktDef * cnsSwtBuf)	       			*/
/* INPUT:  cnsSwtBufDef		CnapsSwtIPC                                     */
/* OUTPUT: outBuf   CNAPS Packet                 		                    */
/* RETURN: 0       -- format convert success    		              		*/
/*         <0      -- format convert fail		                     		*/
/* DESC:   convert the  CnapsSwtIPC to CNAPS Packet                        	*/
/****************************************************************************/
int CnsInToOut (char * outBuf,  T_CnsTotaPktDef* cnsSwtBuf)
{
	ULONG lPktLen,lTagLen;
	long  nTagIndex;
	short nRet;
	char  sPktLen[7],*pTagPos;
	/*char  sPktRef[21];*/
	char  sCmtNo[7];
	char  sPktDat[9];
	char  sTag[6];	
	char  sTagContent[MAX_TAGCNT_LEN];
	/*char  sTemp[MAX_TAGCNT_LEN];	*/
	char  *curPos;
	/*int   lPktLen = 0;	
	int   i=0,j=0,*/
	int   nCmtNo;		
	struct wd_bcnapsfld_area tPktInf;
	T_CnsTotaPktDef* tCnsSwtBuf;
	tCnsSwtBuf = cnsSwtBuf;

	
	printf("\n------------CnsInToOut Start--------------\n");

	/*ȡ��CMT����57��3*/
	memset(sCmtNo, 0, 7);
	memcpy(sCmtNo, "CMT", 3);		
	memcpy(sCmtNo+3, tCnsSwtBuf->tCnapsGen.sCmtNo, 3);		
	nCmtNo=atol(&sCmtNo[3]);
	if (nCmtNo<100) return -1;
	
	/*������������*/
	memset(outBuf, ' ', CNS_PKTHEAD_LEN);
	memcpy(outBuf+CNS_PKTHEAD_LEN, "{3:", 3);
	curPos=&outBuf[CNS_PKTHEAD_LEN+3];
	lPktLen=CNS_PKTHEAD_LEN+3;
	/*����ȡ����CMT�����ѯCNAPS�ӿڱ��ı�BCNAPSFLD*/
	
	if(nDeclareCmtCursor(nCmtNo)!=0)
	{
		printf("Cannot Declare Cursor CMTConvert_CUR!\n");
		return -3;
	}

	if(nOpenCmtCursor()!=0)
	{
		printf("Cannot Open Cursor CMTConvert_CUR!\n");
		return -4;
	}
	nRet=0;
	nTagIndex=1;
	while (nGetBcnsNextTag(&tPktInf)==1)
	{
		
		if (nTagIndex!=tPktInf.tag_index) continue;
		nTagIndex++;

		strcpy(tPktInf.cmt,sCmtNo);
		sTag[0]=':';
		memcpy(sTag+1, tPktInf.tag, 3);
		sTag[4]=':';
		sTag[5]=0;
		pTagPos=((char*)tCnsSwtBuf)+tPktInf.tag_data_pos-DELTA_TITA_TOTA;
		memset(sTagContent, 0, MAX_TAGCNT_LEN);
		memcpy(sTagContent, pTagPos, tPktInf.data_len);
		if (tPktInf.len_flg[0]=='1') DeleteTailSpace(sTagContent,strlen(sTagContent));
		lTagLen=strlen(sTagContent);

printf("\nsTag[%s]; sTagContent[%s]\n", sTag, sTagContent);
		if (lTagLen>tPktInf.data_len)
		{
			printf("[%s][%s][%ld][%d]too long\n", tPktInf.cmt, tPktInf.tag, lTagLen, __LINE__);
			EXIT_PROCESS(-101);
		}
		/*���Tag���Ƕ���*/
		if ((tPktInf.len_flg[0]=='0')&&(lTagLen!=tPktInf.data_len))
		{
			printf("[%s][%s][%ld][%d]fixed length error\n", tPktInf.cmt, tPktInf.tag, lTagLen, __LINE__);
			EXIT_PROCESS(-102);
		}
		/*���Tag���ǿ�ѡ*/
		if ((lTagLen==0)&&(tPktInf.tag_opt[0]=='0'))
			continue;
		
		if(checkTag( sTagContent, tPktInf.tag_type[0], lTagLen)) 
		{
			printf("[%s][%s][%d]invalid data type\n", tPktInf.cmt, tPktInf.tag, __LINE__);
			EXIT_PROCESS(-103);
		}
		memcpy(curPos, sTag, 5);
		curPos=&curPos[5];
		lPktLen+=5;
		if (lTagLen>0) memcpy(curPos, sTagContent, lTagLen);
		curPos=&curPos[lTagLen];
		lPktLen+=lTagLen;
	}

	if(nCloseCmtCursor()!=0)
	{
		printf("Cannot Close Cursor CMTConvert_CUR!\n");
		return -5;
	}
	if(nFreeCmtCursor()!=0)
	{
		printf("Cannot Free Cursor CMTConvert_CUR!\n");
		return -6;
	}

	if(nRet!=0) return nRet;

	memcpy(curPos, "}", 1);
	curPos=&curPos[1];
	lPktLen+=1;
	
	/*������ͷ*/
	memcpy(outBuf,    "{1:", 3);						 /*ҵ������*/	
	memcpy(outBuf+11, tCnsSwtBuf->tCnapsGen.sTrnType, 1);/*ҵ������*/
	memcpy(outBuf+12, tCnsSwtBuf->tCnapsGen.sTrnStat, 3);/*ҵ��״̬*/	
	memcpy(outBuf+15, tCnsSwtBuf->tCnapsGen.sPktID, 8);/*���ı�ʶ��*/	
	memcpy(outBuf+23, tCnsSwtBuf->tCnapsGen.sPktNo, 20);/*���ı�ʶ��*/		
	memcpy(outBuf+57, tCnsSwtBuf->tCnapsGen.sCmtNo, 3);/*CNAPS���״���*/	
	memcpy(outBuf+60, tCnsSwtBuf->tCnapsGen.sWrkdate, 8);/*��������*/	
	memset(sPktDat, 0, 15);
	CommonGetCurrentTime(sPktDat);/*��������*/
	memcpy(outBuf+43, sPktDat, 14);
	
	sprintf(sPktLen, "%06d", lPktLen);/*���ĳ���*/		
	memcpy(outBuf+3, sPktLen, 6);
	memcpy(outBuf+68, "}", 1);	

	printf("\n------------CnsInToOut End--------------\n");

	return 0;
}/*end of CnsInToOut*/



/****************************************************************************/
/* FUNC:   int CnsInToOut2 (char * outBuf��T_CnsTotaPktDef* cnsSwtBuf, char cLevel)*/
/* INPUT:  T_CnsTotaPktDef*	CnapsSwtIPC                                     */
/* OUTPUT: outBuf   CNAPS Packet                 		                    */
/* RETURN: 0       -- format convert success    		              		*/
/*         <0      -- format convert fail		                     		*/
/* DESC:   convert the  CnapsSwtIPC to CNAPS Packet with "{2:}"                     	*/
/****************************************************************************/
int CnsInToOut2 (char * outBuf,  T_CnsTotaPktDef* cnsSwtBuf, char cLevel)
{
	ULONG lPktLen,lTagLen;
	long  nTagIndex;
	short nRet;
	char  sPktLen[7],*pTagPos;
	/*char  sPktRef[21];*/
	char  sCmtNo[7];
	char  sPktDat[9];
	char  sTag[6];	
	char  sTagContent[MAX_TAGCNT_LEN];
	/*char  sTemp[MAX_TAGCNT_LEN];	*/
	char  *curPos;
	/*int   lPktLen = 0;
	int   i=0,j=0,*/
	int   nCmtNo;		
	struct wd_bcnapsfld_area tPktInf;
	T_CnsTotaPktDef* tCnsSwtBuf;
	tCnsSwtBuf = cnsSwtBuf;

	
	printf("\n------------CnsInToOut2 Start--------------\n");

	/*ȡ��CMT����57��3*/
	memset(sCmtNo, 0, 7);
	memcpy(sCmtNo, "CMT", 3);		
	memcpy(sCmtNo+3, tCnsSwtBuf->tCnapsGen.sCmtNo, 3);		
	nCmtNo=atol(&sCmtNo[3]);
	if (nCmtNo<100) return -1;
	
	/*������������*/
	memset(outBuf, ' ', CNS_PKTHEAD_LEN2);
	memcpy(outBuf+CNS_PKTHEAD_LEN2, "{3:", 3);
	curPos=&outBuf[CNS_PKTHEAD_LEN2+3];
	lPktLen=CNS_PKTHEAD_LEN2+3;
	/*����ȡ����CMT�����ѯCNAPS�ӿڱ��ı�BCNAPSFLD*/



	
	if(nDeclareCmtCursor(nCmtNo)!=0)
	{
		printf("Cannot Declare Cursor CMTConvert_CUR!\n");
		return -3;
	}

	if(nOpenCmtCursor()!=0)
	{
		printf("Cannot Open Cursor CMTConvert_CUR!\n");
		return -4;
	}
	nRet=0;
	nTagIndex=1;
	while (nGetBcnsNextTag(&tPktInf)==1)
	{
		if (nTagIndex!=tPktInf.tag_index) continue;
		nTagIndex++;
		
		strcpy(tPktInf.cmt,sCmtNo);
		sTag[0]=':';
		memcpy(sTag+1, tPktInf.tag, 3);
		sTag[4]=':';
		sTag[5]=0;
		pTagPos=((char*)tCnsSwtBuf)+tPktInf.tag_data_pos-DELTA_TITA_TOTA;
		memset(sTagContent, 0, MAX_TAGCNT_LEN);
		memcpy(sTagContent, pTagPos, tPktInf.data_len);
		if (tPktInf.len_flg[0]=='1') DeleteTailSpace(sTagContent,strlen(sTagContent));
		lTagLen=strlen(sTagContent);

printf("\nsTag[%s]; sTagContent[%s]\n", sTag, sTagContent);
		if (lTagLen>tPktInf.data_len)
		{
			printf("[%s][%s][%ld][%d]too long\n", tPktInf.cmt, tPktInf.tag, lTagLen, __LINE__);
			EXIT_PROCESS(-101);
		}
		/*���Tag���Ƕ���*/
		if ((tPktInf.len_flg[0]=='0')&&(lTagLen!=tPktInf.data_len))
		{
			printf("[%s][%s][%ld][%d]fixed length error\n", tPktInf.cmt, tPktInf.tag, lTagLen, __LINE__);
			EXIT_PROCESS(-102);
		}
		/*���Tag���ǿ�ѡ*/
		if ((lTagLen==0)&&(tPktInf.tag_opt[0]=='0'))
			continue;
		
		if(checkTag( sTagContent, tPktInf.tag_type[0], lTagLen)) 
		{
			printf("[%s][%s][%d]\n", tPktInf.cmt, tPktInf.tag, __LINE__);
			EXIT_PROCESS(-103);
		}
		memcpy(curPos, sTag, 5);
		curPos=&curPos[5];
		lPktLen+=5;
		if (lTagLen>0) memcpy(curPos, sTagContent, lTagLen);
		curPos=&curPos[lTagLen];
		lPktLen+=lTagLen;
	}

	if(nCloseCmtCursor()!=0)
	{
		printf("Cannot Close Cursor CMTConvert_CUR!\n");
		return -5;
	}
	if(nFreeCmtCursor()!=0)
	{
		printf("Cannot Free Cursor CMTConvert_CUR!\n");
		return -6;
	}

	if(nRet!=0) return nRet;

	memcpy(curPos, "}", 1);
	curPos=&curPos[1];
	lPktLen+=1;


	
	/*������ͷ1*/
	memcpy(outBuf,    "{1:", 3);						 /*ҵ������*/	
	memcpy(outBuf+11, tCnsSwtBuf->tCnapsGen.sTrnType, 1);/*ҵ������*/
	memcpy(outBuf+12, tCnsSwtBuf->tCnapsGen.sTrnStat, 3);/*ҵ��״̬*/	
	memcpy(outBuf+15, tCnsSwtBuf->tCnapsGen.sPktID, 8);/*���ı�ʶ��*/	
	memcpy(outBuf+23, tCnsSwtBuf->tCnapsGen.sPktNo, 20);/*���ı�ʶ��*/		
	memcpy(outBuf+57, tCnsSwtBuf->tCnapsGen.sCmtNo, 3);/*CNAPS���״���*/	
	memcpy(outBuf+60, tCnsSwtBuf->tCnapsGen.sWrkdate, 8);/*��������*/	
	memset(sPktDat, 0, 15);
	CommonGetCurrentTime(sPktDat);/*��������*/
	memcpy(outBuf+43, sPktDat, 14);
	
	sprintf(sPktLen, "%06d", lPktLen);/*���ĳ���*/		
	memcpy(outBuf+3, sPktLen, 6);
	memcpy(outBuf+68, "}", 1);	

	/*������ͷ2*/
	memcpy(outBuf+CNS_PKTHEAD_LEN,    "{2:", 3);	 
	memcpy(outBuf+CNS_PKTHEAD_LEN+3, tCnsSwtBuf->tCnapsGen.sCmtNo, 3);/*CNAPS���״���*/	
	memcpy(outBuf+CNS_PKTHEAD_LEN+6, &cLevel, 1);/*CNAPS���״���*/	
	memcpy(outBuf+CNS_PKTHEAD_LEN2-1, "}", 1);	

	printf("\n------------CnsInToOut2 End--------------\n");

	return 0;
}/*end of CnsInToOut2*/


char *findTag(char * tag, char * InBuf, char* sTagContent)
{

	char *oldAdd, *newAdd;
	char  sTmp[11];
	char* temp1;		
	/*int pos;*/
	temp1 = sTagContent;
	
	
/*	oldAdd = (char *)strstr(InBuf, tag);*/
	oldAdd = searchTag(InBuf, tag);

		
	if(oldAdd == NULL)
	{
		return 0;
	}
	
	newAdd = (char *)strstr(oldAdd+5, ":");


	if(newAdd == NULL)
	{
		newAdd = (char *)strstr(oldAdd+5, "}");
		if(newAdd == NULL)
		{	
			return 0;
		}
	}	
	
	memcpy(temp1, oldAdd+5, newAdd - oldAdd-5 );
	memcpy(sTmp, newAdd, 10);
	sTmp[10]=0;
	printf("newAdd=%s\n", sTmp);
	
	
	/*return newAdd;*/
	if (memcmp(InBuf, tag, 5)==0)
		return newAdd;
	else
		return InBuf;

}/*end of findTag*/

char *searchTag(char * InBuf, char * tag)
{
	char *firstp, *nextp; 
	
	firstp = (char *)strstr(InBuf, ":");
	if (firstp == NULL)
	{
		return 0;
	}
	while (firstp != NULL)
	{
		nextp = (char *)strstr(firstp+1, ":");
		if (memcmp(tag, firstp, 4) == 0)
		{
			return firstp;
		}
		else
		{
			firstp = (char *)strstr(nextp+1, ":");
		}
	}
/*	if (firstp == NULL)
	{*/
		return 0;
/*	}*/
}/*end of searchTag*/

int checkTag(char * tTagContent, char tag_type, int len)
{
	/*char  sContent[MAX_TAGCNT_LEN];*/
	int i;
	switch(tag_type)
	{
	
		case 'n':
				for(i=0; i<len; i++)
				{
					if((tTagContent[i]!=' ')&&(tTagContent[i]<'0')&&((tTagContent[i]>'9')))
					{
						return -2;
					}
				}
			
		break;
		case 'x':
				for(i=0; i<len; i++)
				{
					if(tTagContent[i]==':')
					{
						return -2;
					}
					/*if(   (tTagContent[i]!=' ')&&(tTagContent[i]<'0')&&(tTagContent[i]>'9')&& \
						  (tTagContent[i]!=10)&&(tTagContent[i]!=13)&&(tTagContent[i]<'a')&&(tTagContent[i]>'z') \
						&&(tTagContent[i]<'A')&&(tTagContent[i]>'Z')&&(tTagContent[i]!='.')&&(tTagContent[i]!=',') \
						&&(tTagContent[i]!='-')&&( tTagContent[i]!='(')&&(tTagContent[i]!=')')&&(tTagContent[i]!=39) \
						&&(tTagContent[i]!='/')&&(tTagContent[i]!='=')&& \
						(tTagContent[i]!='+')&&(tTagContent[i]!=':')&&(tTagContent[i]!='?')&&(tTagContent[i]!='!') \
						&&(tTagContent[i]!='"')&&(tTagContent[i]!='%')&&(tTagContent[i]!='&')&&(tTagContent[i]!='*') \
						&&(tTagContent[i]!='<')&&(tTagContent[i]!='>')&&(tTagContent[i]!=';')&&(tTagContent[i]!='@') \
						&&(tTagContent[i]!='#'))
					{
						return -2;
					}*/
				}
			
		break;		
		case 'g':
				
				for(i=0; i<len; i++)
				{
					if(tTagContent[i]==':')
					{
						return -2;
					}
				}
		break;
		case 'G':
				for(i=0; i<len; i++)
				{
					if(tTagContent[i]==':')
					{
						return -2;
					}
					/*if((tTagContent[i]!=' ')&&(tTagContent[i]<'0')&&((tTagContent[i]>'9'))&&
						(tTagContent[i]!=10)&&(tTagContent[i]!=13)&&(tTagContent[i]<'a')&&(tTagContent[i]>'z')
						&&(tTagContent[i]<'A')&&(tTagContent[i]>'Z')&&(tTagContent[i]!='.')&&(tTagContent[i]!=',')
						&&(tTagContent[i]!='-')&&( tTagContent[i]!='(')&&(tTagContent[i]!=')')&&(tTagContent[i]!=39)
						&&(tTagContent[i]!='/')&&(tTagContent[i]!='=')&&
						(tTagContent[i]!='+')&&(tTagContent[i]!=':')&&(tTagContent[i]!='?')&&(tTagContent[i]!='!')
						&&(tTagContent[i]!='"')&&(tTagContent[i]!='%')&&(tTagContent[i]!='&')&&
						(tTagContent[i]!='*')&&(tTagContent[i]!='<')&&(tTagContent[i]!='>')&&(tTagContent[i]!=';')
						&&(tTagContent[i]!='@')&&(tTagContent[i]!='#')&&(tTagContent[i]<0x80)) 
					{
						return -2;
					}*/
				}
				
		break;			
		
		default:
		break;
	
	}
	return 0;
} /*end of checkTag*/


short nGetBswfNext(char cGetFld, short *pnFldIndex, short nMtIndex,
                        struct wd_bswiftfld_area *pdbBlock,
                        struct wd_bswiftfld_area *pdbSubBlock,
                        struct wd_bswiftfld_area *pdbTag)
{
	static struct wd_bswiftfld_area   dbTag;
	short     nFldIndex;

	memset(&dbTag, 0, sizeof(struct wd_bswiftfld_area));

	memcpy(&nFldIndex, pnFldIndex, sizeof(nFldIndex));
	dbTag.mt_index=nMtIndex;
	dbTag.fld_index=nFldIndex;

	
	switch(cGetFld)
	{
		case 'b':
			while(nGetBswfNextFld(&dbTag)==1)
			{
				if ((dbTag.fld_type[0]!='b')
					&&(dbTag.fld_opt[0]=='0'))
					{
					nFldIndex++;
					dbTag.mt_index=nMtIndex;
					dbTag.fld_index=nFldIndex;
					continue;
					}
				
				if (dbTag.fld_type[0]=='b')
				{
					memset(pdbBlock, 0, sizeof(struct wd_bswiftfld_area));
					memset(pdbSubBlock, 0, sizeof(struct wd_bswiftfld_area));
					memset(pdbTag, 0, sizeof(struct wd_bswiftfld_area));
			
					memcpy(pdbBlock, &dbTag, sizeof(struct wd_bswiftfld_area));
					nFldIndex=dbTag.fld_index+1;
					memcpy(pnFldIndex, &nFldIndex, sizeof(nFldIndex));
					return 1;
				}
				else return 0;
			}
			return 0;
		case 's':
			if ((pdbBlock->fld_attr[0]!='0')
					&&(pdbBlock->fld_attr[0]!='1')
					&&(pdbBlock->fld_attr[0]!='2'))
				return 0;
			if (pdbBlock->fld_attr[0]=='0')
				return 0;
			if (pdbBlock->fld_attr[1]!='1')
				return 0;
			if (pdbBlock->fld_attr[0]=='1')
				pdbBlock->fld_attr[2]='0';
	
			while(nGetBswfNextFld(&dbTag)==1)
			{
				/*if ((dbTag.fld_type[0]!='s')
						&&(dbTag.fld_opt[0]=='0'))*/
				if (((dbTag.fld_type[0]!='s')
						&&(dbTag.fld_opt[0]=='0'))
						||((dbTag.fld_type[0]=='t')
						&&(pdbBlock->fld_attr[0]=='2')))
					{
					nFldIndex++;
					dbTag.mt_index=nMtIndex;
					dbTag.fld_index=nFldIndex;
					continue;
					}
				if (dbTag.fld_index-pdbBlock->fld_index > pdbBlock->sub_tag)
					return 0;

				if (dbTag.fld_type[0]=='s')
				{
					memset(pdbSubBlock, 0, sizeof(struct wd_bswiftfld_area));
			
					memcpy(pdbSubBlock, &dbTag, sizeof(struct wd_bswiftfld_area));
					nFldIndex=dbTag.fld_index+1;
					memcpy(pnFldIndex, &nFldIndex, sizeof(nFldIndex));
					return 1;
				}
				else return 0;
			}
			return 0;
		case 't':
			if ((pdbBlock->fld_attr[0]!='0')
					&&(pdbBlock->fld_attr[0]!='1')
					&&(pdbBlock->fld_attr[0]!='2'))
				return 0;
			if (pdbBlock->fld_attr[0]=='0')
				return 0;
			if (pdbBlock->fld_attr[2]!='1')
				return 0;
			if (pdbBlock->fld_attr[0]=='1')
				pdbBlock->fld_attr[1]='0';
	
			while(nGetBswfNextFld(&dbTag)==1)
			{
				if (((dbTag.fld_type[0]!='t')
						&&(dbTag.fld_opt[0]=='0'))
						||((dbTag.fld_type[0]=='s')
						&&(pdbBlock->fld_attr[0]=='2')))
					{
					nFldIndex++;
					dbTag.mt_index=nMtIndex;
					dbTag.fld_index=nFldIndex;
					continue;
					}
				if (dbTag.fld_index-pdbBlock->fld_index > pdbBlock->sub_tag)
					return 0;
				
				if (dbTag.fld_type[0]=='t')
				{
					memset(pdbTag, 0, sizeof(struct wd_bswiftfld_area));
					memcpy(pdbTag, &dbTag, sizeof(struct wd_bswiftfld_area));
					nFldIndex=dbTag.fld_index+1;
					memcpy(pnFldIndex, &nFldIndex, sizeof(nFldIndex));
					return 1;
				}
				else return 0;
			}
			return 0;
	
		default:
			return 0;
			
	}

}/*end of nGetBswfNext*/


short nDeclareMtCursor(short nMtIndex, char *sFldTeam)
{
	extern DBPROCESS *dbproc;
	char             sSqlTmp[300],sMtIndex[MT_BIT+1];

	strcpy(sSqlTmp,"declare MtConvert_CUR cursor for ");
	strcat(sSqlTmp,"select fld_index,mt,fld_name,fld_name_len, ");
	strcat(sSqlTmp,      " fld_type,fld_attr,sub_tag,fld_opt,fld_flg,len_flg, ");
	strcat(sSqlTmp,      " fld_data_pos,data_len,fld_team from BSWIFTFLD ");
	strcat(sSqlTmp,      " where mt_index=");
	sprintf(sMtIndex, "%d", nMtIndex);
	strcat(sSqlTmp,sMtIndex);
	strcat(sSqlTmp,      " and (fld_team='0' or fld_team='");
	strcat(sSqlTmp, sFldTeam);
	strcat(sSqlTmp,      "') order by fld_index ");
	
	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Declare MtConvert_CUR Successful!\n");
	return 0;
}/*end of nDeclareMtCursor*/

short nOpenMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "open MtConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Open MtConvert_CUR Successful!\n");
	return 0;
}/*end of nOpenMtCursor*/


short nGetBswfNextFld(struct wd_bswiftfld_area *pdbtFld)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j,nFldIndex;

	nFldIndex=pdbtFld->fld_index;
	memset(pdbtFld, 0, sizeof(struct wd_bswiftfld_area));
	/*pdbtFld->fld_index=0;*/
	while (nFldIndex!=pdbtFld->fld_index)
	{
		memset(pdbtFld, 0, sizeof(struct wd_bswiftfld_area));
		dbcmd(dbproc, "fetch MtConvert_CUR ");
		dbsqlexec(dbproc);
		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS)
			return 0;
		if (ret != SUCCEED)
			return 0;
	
		/* Bind program variables. */
		dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->fld_index);
		dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->mt);
		dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_name);
		dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_name_len);
		dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_type);
		dbbind(dbproc, 6, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_attr);
		dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->sub_tag);
		dbbind(dbproc, 8, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_opt);
		dbbind(dbproc, 9, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_flg);
		dbbind(dbproc, 10,NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->len_flg);
		dbbind(dbproc, 11,SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->fld_data_pos);
		dbbind(dbproc, 12,SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->data_len);
		dbbind(dbproc, 13,NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_team);
	
		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;
	
		if (j < 1)
			return 0;
		if ((pdbtFld->fld_name_len[0]>='0')&&(pdbtFld->fld_name_len[0]<='9'))
			pdbtFld->fld_name[pdbtFld->fld_name_len[0]-'0']='\0';
	}
	if (nFldIndex==pdbtFld->fld_index)
		return 1;
	
return 0;
}/*end of nGetBswfNextFld*/

short nGetBswfFld(struct wd_bswiftfld_area *pdbtFld)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;
	char             sSqlTmp[300],sMtIndex[MT_BIT+1];

	strcat(sSqlTmp,"select fld_index,mt,fld_name,fld_name_len, ");
	strcat(sSqlTmp,      " fld_type,fld_attr,sub_tag,fld_opt,fld_flg,len_flg, ");
	strcat(sSqlTmp,      " fld_data_pos,data_len,fld_team from BSWIFTFLD ");
	strcat(sSqlTmp,      " where mt_index=");
	sprintf(sMtIndex, "%d", pdbtFld->mt_index);
	strcat(sSqlTmp,sMtIndex);
	strcat(sSqlTmp,      " and fld_name_len='");
	strcat(sSqlTmp,pdbtFld->fld_name_len);
	strcat(sSqlTmp,      "' and fld_name='");
	strcat(sSqlTmp,pdbtFld->fld_name);
	strcat(sSqlTmp,      "'");

	memset(pdbtFld, 0, sizeof(struct wd_bswiftfld_area));

	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	ret = dbresults(dbproc);
	if (ret == NO_MORE_RESULTS)
		return 0;
	if (ret != SUCCEED)
		return 0;
	
	/* Bind program variables. */
	dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->fld_index);
	dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->mt);
	dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_name);
	dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_name_len);
	dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_type);
	dbbind(dbproc, 6, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_attr);
	dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->sub_tag);
	dbbind(dbproc, 8, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_opt);
	dbbind(dbproc, 9, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_flg);
	dbbind(dbproc, 10,NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->len_flg);
	dbbind(dbproc, 11,SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->fld_data_pos);
	dbbind(dbproc, 12,SMALLBIND,     (DBINT)0, (BYTE *)&pdbtFld->data_len);
	dbbind(dbproc, 13,NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtFld->fld_team);
	
	j = 0;
	while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;

	if (j < 1)
		return 0;
	if ((pdbtFld->fld_name_len[0]>='0')&&(pdbtFld->fld_name_len[0]<='9'))
		pdbtFld->fld_name[pdbtFld->fld_name_len[0]-'0']='\0';
return 1;
}/*end of nGetBswfFld*/

short nCloseMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "close MtConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Close MtConvert_CUR Successful!\n");
	return 0;
}/*end of nCloseMtCursor*/

short nFreeMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "deallocate cursor MtConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}

	printf("Deallocate MtConvert_CUR Successful!\n");
	return 0;
}/*end of nFreeMtCursor*/




short nDeclareCmtCursor(short nCmtIndex)
{
	extern DBPROCESS *dbproc;
	char             sSqlTmp[300],sMtIndex[CMT_BIT+1];

	strcpy(sSqlTmp,"declare CMTConvert_CUR cursor for ");
	strcat(sSqlTmp,"select tag_index, tag, tag_type, ");
	strcat(sSqlTmp,      " tag_opt, tag_flg, len_flg, ");
	strcat(sSqlTmp,      " tag_data_pos, data_len from BCNAPSFLD ");
	strcat(sSqlTmp,      " where cmt_index=");
	sprintf(sMtIndex, "%d", nCmtIndex);
	strcat(sSqlTmp,sMtIndex);
	strcat(sSqlTmp,      " order by tag_index ");
	

	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Declare CMTConvert_CUR Successful!\n");
	return 0;
}/*end of nDeclareCmtCursor*/



short nOpenCmtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "open CMTConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Open CMTConvert_CUR Successful!\n");
	return 0;
}/*end of nOpenCmtCursor*/


short nGetBcnsNextTag(struct wd_bcnapsfld_area *pdbtTag)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;
	/*,nFldIndex*/

	/*nFldIndex=pdbtTag->tag_index;*/
	memset(pdbtTag, 0, sizeof(struct wd_bcnapsfld_area));
	/*pdbtTag->fld_index=0;*/
	/*while (nFldIndex!=pdbtTag->tag_index)
	{*/
		memset(pdbtTag, 0, sizeof(struct wd_bcnapsfld_area));
		dbcmd(dbproc, "fetch CMTConvert_CUR ");
		dbsqlexec(dbproc);
		ret = dbresults(dbproc);
		if (ret == NO_MORE_RESULTS)
			return 0;
		if (ret != SUCCEED)
			return 0;
	
		/* Bind program variables. */
		dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->tag_index);
		dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag);
		dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_type);
		dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_opt);
		dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_flg);
		dbbind(dbproc, 6, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->len_flg);
		dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->tag_data_pos);
		dbbind(dbproc, 8, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->data_len);
	
		j = 0;
		while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;
	
		if (j < 1)
			return 0;
/*printf("[%d][%s]\n", pdbtTag->tag_index,pdbtTag->tag);*/
	/*}	
	if (nFldIndex==pdbtTag->tag_index)*/
		return 1;
	
/*return 0;*/
}/*end of nGetBcnsNextTag*/

short nGetBcnsTag(struct wd_bcnapsfld_area *pdbtTag)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;
	char             sSqlTmp[300],sMtIndex[CMT_BIT+1];

	strcat(sSqlTmp,"select tag_index, tag, tag_type, ");
	strcat(sSqlTmp,      " tag_opt, tag_flg, len_flg, ");
	strcat(sSqlTmp,      " tag_data_pos, data_len from BCNAPSFLD ");
	strcat(sSqlTmp,      " where cmt_index=");
	sprintf(sMtIndex, "%d", pdbtTag->cmt_index);
	strcat(sSqlTmp,sMtIndex);
	strcat(sSqlTmp,      " and tag='");
	strcat(sSqlTmp,pdbtTag->tag);
	strcat(sSqlTmp,      "'");

	memset(pdbtTag, 0, sizeof(struct wd_bcnapsfld_area));
	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	ret = dbresults(dbproc);
	if (ret == NO_MORE_RESULTS)
		return 0;
	if (ret != SUCCEED)
		return 0;
	
	/* Bind program variables. */
	dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->tag_index);
	dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag);
	dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_type);
	dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_opt);
	dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->tag_flg);
	dbbind(dbproc, 6, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pdbtTag->len_flg);
	dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->tag_data_pos);
	dbbind(dbproc, 8, SMALLBIND,     (DBINT)0, (BYTE *)&pdbtTag->data_len);

	j = 0;
	while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;
	
	if (j < 1)
		return 0;
return 1;
}/*end of nGetBcnsTag*/


short nCloseCmtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "close CMTConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Close CMTConvert_CUR Successful!\n");
	return 0;
}/*end of nCloseCmtCursor*/

short nFreeCmtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "deallocate cursor CMTConvert_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}

	printf("Deallocate CMTConvert_CUR Successful!\n");
	return 0;
}/*end of nFreeCmtCursor*/



void vTita2Tota( T_CnsSwtTitaDef  *pSwtNormalReq, T_CnsSwtTotaDef  *pSwtInBuf)
{
	/* TITA to TOTA */
	memcpy(&pSwtInBuf->tIPCHeader, &pSwtNormalReq->tIPCHeader, sizeof(pSwtInBuf->tIPCHeader));
	memcpy(&pSwtInBuf->tTotaPkt.tCnapsGen, &pSwtNormalReq->tTitaPkt.tCnapsGen, 
			sizeof(pSwtInBuf->tTotaPkt.tCnapsGen));
	memcpy(pSwtInBuf->tTotaPkt.sRsv, pSwtNormalReq->tTitaPkt.sRsv, 
			sizeof(pSwtInBuf->tTotaPkt.sRsv));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.header, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.header,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.header));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.clsno, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.clsno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.clsno));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.termid, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.termid,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.termid));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.kinbr, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.kinbr,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.kinbr));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.trmseq, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.trmseq,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.trmseq));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.ejfno, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.ejfno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.ejfno));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.taskid, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.taskid,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.taskid));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.txno, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.txno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.txno));

	memcpy(pSwtInBuf->tTotaPkt.tTotaLabel.tlrno, 
			pSwtNormalReq->tTitaPkt.tTitaLabel.tlrno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.tlrno));

	pSwtInBuf->tTotaPkt.tTotaLabel.tmtype =
			pSwtNormalReq->tTitaPkt.tTitaLabel.tmtype;


	return;
}/*end of vTita2Tota*/



void vTota2Tita( T_CnsSwtTotaDef  *pSwtInBuf, T_CnsSwtTitaDef  *pSwtNormalReq )
{
	/* TITA to TOTA */
	memcpy(&pSwtNormalReq->tIPCHeader, &pSwtInBuf->tIPCHeader, sizeof(pSwtInBuf->tIPCHeader));
	memcpy(&pSwtNormalReq->tTitaPkt.tCnapsGen, 
			&pSwtInBuf->tTotaPkt.tCnapsGen,
			sizeof(pSwtInBuf->tTotaPkt.tCnapsGen));
	memcpy(pSwtNormalReq->tTitaPkt.sRsv, 
			pSwtInBuf->tTotaPkt.sRsv,
			sizeof(pSwtInBuf->tTotaPkt.sRsv));

	memcpy(pSwtNormalReq->tTitaPkt.tTitaLabel.header,
			pSwtInBuf->tTotaPkt.tTotaLabel.header, 
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.header));

	memcpy( pSwtNormalReq->tTitaPkt.tTitaLabel.clsno,
			pSwtInBuf->tTotaPkt.tTotaLabel.clsno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.clsno));

	memcpy( pSwtNormalReq->tTitaPkt.tTitaLabel.termid,
			pSwtInBuf->tTotaPkt.tTotaLabel.termid,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.termid));

	memcpy( pSwtNormalReq->tTitaPkt.tTitaLabel.kinbr,
			pSwtInBuf->tTotaPkt.tTotaLabel.kinbr,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.kinbr));

	memcpy(pSwtNormalReq->tTitaPkt.tTitaLabel.trmseq,
			pSwtInBuf->tTotaPkt.tTotaLabel.trmseq, 
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.trmseq));

	memcpy(pSwtNormalReq->tTitaPkt.tTitaLabel.ejfno,
			pSwtInBuf->tTotaPkt.tTotaLabel.ejfno, 
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.ejfno));

	memcpy(pSwtNormalReq->tTitaPkt.tTitaLabel.taskid,
			pSwtInBuf->tTotaPkt.tTotaLabel.taskid, 
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.taskid));

	memcpy( pSwtNormalReq->tTitaPkt.tTitaLabel.txno,
			pSwtInBuf->tTotaPkt.tTotaLabel.txno,
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.txno));

	memcpy(pSwtNormalReq->tTitaPkt.tTitaLabel.tlrno,
			pSwtInBuf->tTotaPkt.tTotaLabel.tlrno, 
			sizeof(pSwtInBuf->tTotaPkt.tTotaLabel.tlrno));

	pSwtNormalReq->tTitaPkt.tTitaLabel.tmtype =
			pSwtInBuf->tTotaPkt.tTotaLabel.tmtype;


	return;
}/*end of vTota2Tita*/

void vMtMsgToPacket(char *sMtText,MT_PACKET *pOutPacket, short nDataLen)
{
	char    sLen[PACKET_LEN_BIT+1];

	memset( pOutPacket, 0, sizeof(MT_PACKET));

	if (sMtText[0] == '{') /* added by Laura, for some MT103, no length */
	{
		{
		char 	sPattern[10];
		sprintf(sPattern, "%0%ds", PACKET_LEN_BIT);
		sprintf(sLen, sPattern, nDataLen);
		}
		memcpy( pOutPacket->sPacketLen, sLen, PACKET_LEN_BIT);
		pOutPacket->packet_len=nDataLen;
	
		memcpy( pOutPacket->sPacket, sMtText, pOutPacket->packet_len);
	}
	else
	{
		memset( sLen, '\0', sizeof(sLen));
		memcpy( sLen, sMtText, PACKET_LEN_BIT);
		memcpy( pOutPacket->sPacketLen, sMtText, PACKET_LEN_BIT);
		pOutPacket->packet_len=atol(sLen);
		/* added by Laura, if length is zeros, use input nDataLen */
		if (pOutPacket->packet_len == 0)
			pOutPacket->packet_len = nDataLen-PACKET_LEN_BIT-PACKET_MSG_ACK;
		/* added */
	
		if(memcmp(&sMtText[PACKET_LEN_BIT], "MSGACK", strlen("MSGACK"))==0)
		{
			memcpy( pOutPacket->sMsgAck, &sMtText[PACKET_LEN_BIT], PACKET_MSG_ACK);
			memcpy( pOutPacket->sPacket, &sMtText[PACKET_LEN_BIT+PACKET_MSG_ACK], pOutPacket->packet_len);
		}
		else
		{
			memcpy( pOutPacket->sPacket, &sMtText[PACKET_LEN_BIT], pOutPacket->packet_len);
		}
	}
}/*end of vMtMsgToPacket*/

void vHostOut2PayTxn(T_HostSwtOutDef *pHostSwtDef, struct wd_bpaytxnlog_area *pTxnLog)
{
	int i,j;
	char szTmp[30],szAmtTmp[30];

	memcpy(pTxnLog->p_cls_ssn, pHostSwtDef->tIPCHeader.sClsSsn, CR_CLSSSN_LEN);
	memcpy(pTxnLog->p_refno_eft, pHostSwtDef->tHostGen.sRefSSN, sizeof(pHostSwtDef->tHostGen.sRefSSN));
	memcpy(pTxnLog->p_sender, pHostSwtDef->tHostGen.sLTIdr, sizeof(pHostSwtDef->tHostGen.sLTIdr));
	memcpy(pTxnLog->p_mt_type, pHostSwtDef->tHostGen.sMsgType, sizeof(pHostSwtDef->tHostGen.sMsgType));
	memcpy(pTxnLog->p_mt_localtime, pHostSwtDef->tHostGen.sTimeIcn, sizeof(pHostSwtDef->tHostGen.sTimeIcn));
	memcpy(pTxnLog->p_value_date, "20", 2);
	memcpy(pTxnLog->p_value_date+2, pHostSwtDef->tHostGen.sValueDate, 6);
	/*
	memcpy(pTxnLog->p_curr_cd, pHostSwtDef->tHostGen.sStlCur, sizeof(pHostSwtDef->tHostGen.sStlCur));
	*/
	memcpy(pTxnLog->p_curr_cd, CURRENCY_CODE_RMB, sizeof(pHostSwtDef->tHostGen.sStlCur));
	
	memcpy(szTmp, pHostSwtDef->tHostGen.sStlAmt, sizeof(pHostSwtDef->tHostGen.sStlAmt));
	memset(szAmtTmp,0,sizeof(szAmtTmp));
	j = 0;
	for(i=0;i<strlen(szTmp);i++)
	{
		if (szTmp[i]==',')
		{
			continue;
		}
		szAmtTmp[j] = szTmp[i];
		j++;
	}
	sprintf(pTxnLog->p_amount,"%015s",szAmtTmp);
	CommonGetCurrentTime(pTxnLog->rec_updt_time);
}/*end of vHostOut2PayTxn*/

void vHostIn2PayTxn(T_HostSwtInDef *pHostSwtDef, struct wd_bpaytxnlog_area *pTxnLog)
{
	int i,j;
	char szTmp[30],szAmtTmp[30];

	memcpy(pTxnLog->p_cls_ssn, pHostSwtDef->tIPCHeader.sClsSsn, CR_CLSSSN_LEN);
	memcpy(pTxnLog->p_refno_eft, pHostSwtDef->tHostGen.sRefSSN, sizeof(pHostSwtDef->tHostGen.sRefSSN));
	memcpy(pTxnLog->p_sender, pHostSwtDef->tHostGen.sLTIdr, sizeof(pHostSwtDef->tHostGen.sLTIdr));
	memcpy(pTxnLog->p_mt_type, pHostSwtDef->tHostGen.sMsgType, sizeof(pHostSwtDef->tHostGen.sMsgType));
	memcpy(pTxnLog->p_mt_localtime, pHostSwtDef->tHostGen.sTimeIcn, sizeof(pHostSwtDef->tHostGen.sTimeIcn));
	memcpy(pTxnLog->p_value_date, "20", 2);
	memcpy(pTxnLog->p_value_date+2, pHostSwtDef->tHostGen.sValueDate, 6);
	/*
	memcpy(pTxnLog->p_curr_cd, pHostSwtDef->tHostGen.sStlCur, sizeof(pHostSwtDef->tHostGen.sStlCur));
	*/
	memcpy(pTxnLog->p_curr_cd, CURRENCY_CODE_RMB, sizeof(pHostSwtDef->tHostGen.sStlCur));
	
	memcpy(szTmp, pHostSwtDef->tHostGen.sStlAmt, sizeof(pHostSwtDef->tHostGen.sStlAmt));
	memset(szAmtTmp,0,sizeof(szAmtTmp));
	j = 0;
	for(i=0;i<strlen(szTmp);i++)
	{
		if (szTmp[i]==',')
		{
			continue;
		}
		szAmtTmp[j] = szTmp[i];
		j++;
	}
	/* added by Laura, 2004/03/08 */
	if (szTmp[strlen(szTmp)-2] == ',')
	{
		strcat(szAmtTmp, "0");
	}
	sprintf(pTxnLog->p_amount,"%015s",szAmtTmp);
	CommonGetCurrentTime(pTxnLog->rec_updt_time);
}/*end of vHostIn2PayTxn*/

void vMtAmount2Cnaps(char *sAmount)
{
	char   sTmp[31];
	short  i,j,k;
	k=strlen(sAmount);
	i=0;
	j=1;
	sTmp[0]='0';
	while( i<=k)
	{
		if(sAmount[i]!=',')
		{
			sTmp[j]=sAmount[i];
			j++;
		}
		i++;
	}
	sTmp[j]=0;
	if(j==i)
		strcpy(sAmount, sTmp);
	else
		strcpy(&sAmount[1], sTmp);
}

void vCnaps15Amount2Mt(char *sAmount)
{
	char   sTmp[31];
	short  i;
	i=strlen(sAmount);
	sTmp[i-3]=',';
	sTmp[i]='\0';
	memcpy(sTmp, &sAmount[1], i-3);
	memcpy(&sTmp[i-2], &sAmount[i-2], 2);
	strcpy(sAmount, sTmp);
}

long nAddBlockData(char *sBlockName, char *sBlockData, char *sPacket)
{
	strcat(sPacket, "{");
	strcat(sPacket, sBlockName);
	strcat(sPacket, ":");
	strcat(sPacket, sBlockData);
	strcat(sPacket, "}");
	return(strlen(sBlockName)+3);
}
long nAddTagData(char *sTagName, char *sTagData, char *sPacket)
{
	strcat(sPacket, "\x0d\x0a:");
	strcat(sPacket, sTagName);
	strcat(sPacket, ":");
	strcat(sPacket, sTagData);
	return(strlen(sTagName)+4);
}

long nAddBlock4Data(char *sBlockName, char *sBlockData, char *sPacket)
{
	strcat(sPacket, "{");
	strcat(sPacket, sBlockName);
	strcat(sPacket, ":");
	strcat(sPacket, sBlockData);
	strcat(sPacket, "\x0d\x0a-}");
	return(strlen(sBlockName)+6);
}


void DBC2SBC(unsigned char *inDBC,unsigned char *outSBC)
{
	int i,j,iLen;
	
	i=0;
	j=0;
	iLen = strlen((char *)inDBC);
	for(;;)
	{
		if(i >= iLen)
			break;
		if(inDBC[i] < 128)
		{
			outSBC[j] = 0xA3;
			j++;
			outSBC[j] = 0x80 + inDBC[i];
			j++;
			i++;
		}else
		{
			if (inDBC[i+1] < 128)
			{
				i++;
				continue;
			}
			outSBC[j] = inDBC[i];
			i++;
			j++;
			outSBC[j] = inDBC[i];
			i++;
			j++;
		}
	}
}

int nProcessCMT417File(char *sFileName)
{
	FILE		*fp;
	char		sBuffer[3000];
	int			nMsgType;
	char		sTemp0[3000];
	char		sBankIssno[8+1];
	char		sWorkDate[8+1];
	int			nRet;
	struct wd_bsysctl_area  wd_bsysctl;

	/* find current work date */
	memset(sWorkDate, 0, sizeof(sWorkDate));
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) == 0)
	{
		memcpy(sWorkDate, wd_bsysctl.work_date, sizeof(sWorkDate)-1);
	}
	else
	{
		printf("\n[��ѯϵͳ������Ϣ��¼��������¼δ�ҵ���]\n");
		return -999;
	}

	fp = fopen(sFileName, "r");
	if (fp == NULL)
	{
		printf("Open file error! [%s]\n", sFileName);
		return -1;
	}

	/* 1st Line */
	memset(sBuffer, 0, sizeof(sBuffer));
	if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
	{
		printf("File empty (1)! [%s]\n", sFileName);
		fclose(fp);
		return -2;
	}	

printf("1st Line(File Type): [%s]\n", sBuffer);

	if ((memcmp(sBuffer+8, "104", 3) != 0) &&
		(memcmp(sBuffer+8, "105", 3) != 0))
	{
		printf("Message type error! [$s]\n", sFileName);
		fclose(fp);
		return -3;
	}	

	if (strlen(sBuffer) <= 16)
	{
		printf("File data error! [$s]\n", sFileName);
		fclose(fp);
		return -4;
	}	
	
	if (memcmp(sBuffer+8, "104", 3) == 0)
	{ 
		nMsgType = 104;
	}
	
	if (memcmp(sBuffer+8, "105", 3) == 0)
	{
		nMsgType = 105;
	}

	/* 2nd Line */	
	memset(sBuffer, 0, sizeof(sBuffer));
	if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
	{
		printf("File empty (2)! [%s]\n", sFileName);
		fclose(fp);
		return -12;
	}	
printf("2nd Line(Length of header): [%s]\n", sBuffer);

	/* 3rd Line */	
	memset(sBuffer, 0, sizeof(sBuffer));
	if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
	{
		printf("File empty (3)! [%s]\n", sFileName);
		fclose(fp);
		return -22;
	}	
printf("3rd Line(Length of body): [%s]\n", sBuffer);

	/* 4th Line */	
	memset(sBuffer, 0, sizeof(sBuffer));
	if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
	{
		printf("File empty (4)! [%s]\n", sFileName);
		fclose(fp);
		return -32;
	}	
printf("4th Line(Batch number): [%s]\n", sBuffer);

	memcpy(sBankIssno, sBuffer+8, 8);
	sBankIssno[8] = 0;
	printf("INFO Bank Issno [%s]\n", sBankIssno);

	switch (nMsgType)
	{
		case 104: /* CNAPS�к����� */

			/* from line 5 - details */
			while(1)
			{
				memset(sBuffer, 0, sizeof(sBuffer));
				if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
					break;

				if (sBuffer[0] == '}')
				{
					break;
				}

				memset(sTemp0, 0, sizeof(sTemp0));
				strcpy(sTemp0, sBuffer);

				nRet = nProcessCMT417FileCnapsString(sTemp0, sWorkDate, sBankIssno);
				if (nRet == 1) break;
				if (nRet == 2) continue;

			} /* end of while */

			break;
		
		case 105: /* EIS�к����� */

			/* from line 5 - details */
			while(1)
			{
				memset(sBuffer, 0, sizeof(sBuffer));
				if (fgets(sBuffer, sizeof(sBuffer), fp) == NULL)
					break;

				if (sBuffer[0] == '}')
				{
					break;
				}

				memset(sTemp0, 0, sizeof(sTemp0));
				strcpy(sTemp0, sBuffer);

				nRet = nProcessCMT417FileEisString(sTemp0, sWorkDate, sBankIssno);
				if (nRet == 1) break;
				if (nRet == 2) continue;

			} /* end of while */

			break;
	} /* end of switch */

	fclose(fp);
	return 0;
}


int nProcessCMT417FileCnapsString(char *sTemp0, char *sWorkDate, char *sBankIssno)
{
	char		sEbankcode[6+1];
	char		*ptr0=NULL, *last0=NULL;
	char		cBankType;
	struct wd_bcnapsbank_area			wd_bcnapsbank;
	struct wd_bcnapsbanktmp_area		wd_bcnapsbanktmp;
	struct wd_beisbank_area				wd_beisbank;
	struct wd_beisbanktmp_area			wd_beisbanktmp;

	/* �������� */
	ptr0 = strtok_r(sTemp0, "|", &last0);
	if (ptr0 == NULL || *ptr0 == '\n') return 2;
	cBankType = ptr0[0];
	
	printf("INFO Bank Code Maintenance Type [%c]\n", 
		cBankType);
	
	if ((cBankType != '1') && (cBankType != '2') && (cBankType != '3'))
	{
		return 1;
	}
	
	switch (cBankType)
	{
		case '1': /* update - ��� */
			memset(&wd_bcnapsbanktmp, 0, sizeof(wd_bcnapsbanktmp));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.bank_code, ptr0);
			printf("CMT417: INFO BCNAPSBANKTMP bank_code [%s]\n", 
				wd_bcnapsbanktmp.bank_code);
	
			/* ��Ч���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.alt_effdate, ptr0);
			printf("CMT417: INFO BCNAPSBANKTMP alt_effdate [%s]\n", 
				wd_bcnapsbanktmp.alt_effdate);
	
			/* ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.category, ptr0);
	
			/* �б���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.cls_code, ptr0);
	
			/* ����ֱ�Ӳ������к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.dre_code, ptr0);
	
			/* ���ڽڵ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.node_code, ptr0);
	
			/* �����ϼ������� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.supr_list, ptr0);
	
			/* �������д��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.pbc_code, ptr0);
	
			/* ���ڳ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.city_code, ptr0);
	
			/* ������ȫ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.long_name, ptr0);
			printf("CMT417: INFO BCNAPSBANKTMP long_name [%s]\n", 
				wd_bcnapsbanktmp.long_name);
	
			/* �����߼�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.short_name, ptr0);
	
			/* ��ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.address, ptr0);
	
			/* �ʱ� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.postcode, ptr0);
	
			/* �绰/��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.telephone, ptr0);
	
			/* �����ʼ���ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.email, ptr0);
	
			/* ��ע */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbanktmp.remark, ptr0);
	
			strcpy(wd_bcnapsbanktmp.alt_issno, sBankIssno);
			CommonGetCurrentTimeDB(wd_bcnapsbanktmp.alt_date);
	
			printf("CMT417: INFO BCNAPSBANKTMP alt_issno [%s]\n", 
				wd_bcnapsbanktmp.alt_issno);
			printf("CMT417: INFO BCNAPSBANKTMP alt_date [%s]\n", 
				wd_bcnapsbanktmp.alt_date);
	
			if (DbsBCNAPSBANKTMP(DBS_INSERT, &wd_bcnapsbanktmp) != 0)
			{
				printf("CMT417: INSERT into BCNAPSBANKTMP error!!!\n"); 
			}
	
			/* �������Ч */
			if (memcmp(wd_bcnapsbanktmp.alt_effdate, sWorkDate, 8)
				<= 0)
			{
				memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
				memcpy(wd_bcnapsbank.bank_code, wd_bcnapsbanktmp.bank_code, 12);
				if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank) != 0)
				{
					printf("CMT417: [%s] not found in BCNAPSBANK!", 
						wd_bcnapsbanktmp.bank_code);
					return 2;
				}

				wd_bcnapsbank.alt_type[0] = '1'; /* update */
				memcpy(wd_bcnapsbank.category, wd_bcnapsbanktmp.category, 
					sizeof(wd_bcnapsbanktmp.category)-1);
				memcpy(wd_bcnapsbank.cls_code, wd_bcnapsbanktmp.cls_code, 
					sizeof(wd_bcnapsbanktmp.cls_code)-1);
				memcpy(wd_bcnapsbank.dre_code, wd_bcnapsbanktmp.dre_code, 
					sizeof(wd_bcnapsbanktmp.dre_code)-1);
				memcpy(wd_bcnapsbank.node_code, wd_bcnapsbanktmp.node_code, 
					sizeof(wd_bcnapsbanktmp.node_code)-1);
				memcpy(wd_bcnapsbank.supr_list, wd_bcnapsbanktmp.supr_list, 
					sizeof(wd_bcnapsbanktmp.supr_list)-1);
				memcpy(wd_bcnapsbank.pbc_code, wd_bcnapsbanktmp.pbc_code, 
					sizeof(wd_bcnapsbanktmp.pbc_code)-1);
				memcpy(wd_bcnapsbank.city_code, wd_bcnapsbanktmp.city_code, 
					sizeof(wd_bcnapsbanktmp.city_code)-1);
				memcpy(wd_bcnapsbank.long_name, wd_bcnapsbanktmp.long_name, 
					sizeof(wd_bcnapsbanktmp.long_name)-1);
				memcpy(wd_bcnapsbank.short_name, wd_bcnapsbanktmp.short_name, 
					sizeof(wd_bcnapsbanktmp.short_name)-1);
				memcpy(wd_bcnapsbank.address, wd_bcnapsbanktmp.address, 
					sizeof(wd_bcnapsbanktmp.address)-1);
				memcpy(wd_bcnapsbank.postcode, wd_bcnapsbanktmp.postcode, 
					sizeof(wd_bcnapsbanktmp.postcode)-1);
				memcpy(wd_bcnapsbank.telephone, wd_bcnapsbanktmp.telephone, 
					sizeof(wd_bcnapsbanktmp.telephone)-1);
				memcpy(wd_bcnapsbank.email, wd_bcnapsbanktmp.email, 
					sizeof(wd_bcnapsbanktmp.email)-1);
				memcpy(wd_bcnapsbank.alt_date, wd_bcnapsbanktmp.alt_date, 
					sizeof(wd_bcnapsbanktmp.alt_date)-1);
				memcpy(wd_bcnapsbank.alt_issno, wd_bcnapsbanktmp.alt_issno, 
					sizeof(wd_bcnapsbanktmp.alt_issno)-1);
				memcpy(wd_bcnapsbank.remark, wd_bcnapsbanktmp.remark, 
					sizeof(wd_bcnapsbanktmp.remark)-1);
				CommonGetCurrentTimeDB(wd_bcnapsbank.rec_updt_time);
		
				if (DbsBCNAPSBANK(DBS_IUPD, &wd_bcnapsbank) != 0)
				{
					printf("CMT417: [%s] BCNAPSBANK update error!", 
						wd_bcnapsbanktmp.bank_code);
					return 2;
				}

				DbsBCNAPSBANKTMP(DBS_IDEL, &wd_bcnapsbanktmp);

				CnapsBankCodeSend2EFT(sWorkDate, 1, &wd_bcnapsbank);
			}

			break;

		case '2': /* add - ���� */
			memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.bank_code, ptr0);
			printf("CMT417: INFO BCNAPSBANK bank_code [%s]\n", 
				wd_bcnapsbank.bank_code);
	
			/* ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.category, ptr0);
	
			/* ԭ���Ƿ�Ϊ�������� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			/* ignore */
	
			/* �������к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			memset(sEbankcode, 0, sizeof(sEbankcode));
			strcpy(sEbankcode, ptr0);
			RightTrim(sEbankcode);
			printf("CMT417: INFO BCNAPSBANK eis_bank_code [%s]\n", 
				sEbankcode);
	
			/* �б���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.cls_code, ptr0);
	
			/* ����ֱ�Ӳ������к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.dre_code, ptr0);
	
			/* ���ڽڵ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.node_code, ptr0);
	
			/* �����ϼ������� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.supr_list, ptr0);
	
			/* �������д��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.pbc_code, ptr0);
	
			/* ���ڳ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.city_code, ptr0);
	
			/* ������ȫ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.long_name, ptr0);
			printf("CMT417: INFO BCNAPSBANK long_name [%s]\n", 
				wd_bcnapsbank.long_name);
	
			/* �����߼�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.short_name, ptr0);
	
			/* ��ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.address, ptr0);
	
			/* �ʱ� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.postcode, ptr0);
	
			/* �绰/��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.telephone, ptr0);
	
			/* �����ʼ���ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.email, ptr0);
	
			/* ��Ч���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.eff_date, ptr0);
			printf("CMT417: INFO BCNAPSBANK eff_date [%s]\n", 
				wd_bcnapsbank.eff_date);
	
			/* ʧЧ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.inv_date, ptr0);
			printf("CMT417: INFO BCNAPSBANK inv_date [%s]\n", 
				wd_bcnapsbank.inv_date);
	
			/* ��ע */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.remark, ptr0);
	
			if (memcmp(wd_bcnapsbank.eff_date, sWorkDate, 8) <= 0)
			{
				/* ����Ч */
				wd_bcnapsbank.status[0] = '1';
			}
			else
			{
				wd_bcnapsbank.status[0] = '0';
			}

			strcpy(wd_bcnapsbank.alt_issno, sBankIssno);
			wd_bcnapsbank.alt_type[0] = '2';
			CommonGetCurrentTimeDB(wd_bcnapsbank.alt_date);
	
			printf("CMT417: INFO BCNAPSBANK status [%s]\n", 
				wd_bcnapsbank.status);
			printf("CMT417: INFO BCNAPSBANK alt_issno [%s]\n", 
				wd_bcnapsbank.alt_issno);
			printf("CMT417: INFO BCNAPSBANK alt_date [%s]\n", 
				wd_bcnapsbank.alt_date);
	
			if (DbsBCNAPSBANK(DBS_INSERT, &wd_bcnapsbank) != 0)
			{
				printf("CMT417: INSERT into BCNAPSBANK error!!!\n"); 
				return 2;
			}
	
			/* �������Ч */
			if (memcmp(wd_bcnapsbank.eff_date, sWorkDate, 8) <= 0)
			{
				CnapsBankCodeSend2EFT(sWorkDate, 2, &wd_bcnapsbank);
			}

			/* �ǵ�������ͨ���� */
			if (strlen(sEbankcode) == 6)
			{
				if (memcmp(wd_bcnapsbank.eff_date, sWorkDate, 8) <= 0)
				{
					memset(&wd_beisbank, 0, sizeof(wd_beisbank));
					memcpy(wd_beisbank.bank_code, sEbankcode, 6);
					if (DbsBEISBANK(DBS_FIND, &wd_beisbank) != 0)
					{
						printf("CMT417: [%s] not found in BEISBANK!", 
							wd_beisbank.bank_code);
						return 2;
					}

					wd_beisbank.alt_type[0] = '1'; 
					memcpy(wd_beisbank.eis_site_code, 
						wd_bcnapsbank.city_code, 4);
					wd_beisbank.cnaps_flag[0] = 'N'; 
					memcpy(wd_beisbank.cbnk_code, 
						wd_bcnapsbank.bank_code, 12);
					CommonGetCurrentTimeDB(wd_beisbank.alt_date);
					strcpy(wd_beisbank.alt_issno, sBankIssno);

					if (DbsBEISBANK(DBS_IUPD, &wd_beisbank) != 0)
					{
						printf("CMT417: UPDATE BEISBANK error!!!\n"); 
						return 2;
					}

					EisBankCodeSend2EFT(sWorkDate, 3, &wd_beisbank);
				}
				else
				{
					memset(&wd_beisbanktmp, 0, sizeof(wd_beisbanktmp));

					memcpy(wd_beisbanktmp.bank_code, sEbankcode, 6);
					wd_beisbanktmp.alt_type[0] = '4'; 
					memcpy(wd_beisbanktmp.alt_effdate, 
						wd_bcnapsbank.eff_date, 8);

					memcpy(wd_beisbanktmp.eis_site_code, 
						wd_bcnapsbank.city_code, 4);
					wd_beisbanktmp.cnaps_flag[0] = 'N'; 
					memcpy(wd_beisbanktmp.cbnk_code, 
						wd_bcnapsbank.bank_code, 12);
					CommonGetCurrentTimeDB(wd_beisbanktmp.alt_date);
					strcpy(wd_beisbanktmp.alt_issno, sBankIssno);

					if (DbsBEISBANKTMP(DBS_INSERT, &wd_beisbanktmp) != 0)
					{
						printf("CMT417: INSERT into BEISBANKTMP error!!!\n"); 
					}
				}
			}
	
			break;
	
		case '3': /* close - ע�� */
			memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.bank_code, ptr0);
			printf("CMT417: INFO BCNAPSBANK bank_code [%s]\n", 
				wd_bcnapsbank.bank_code);
	
			/* find original bank code record */
			if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank) != 0)
			{
				printf("CMT417: FIND from BCNAPSBANK error!!!\n"); 
				return 2;
			}
	
			/* ʧЧ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_bcnapsbank.inv_date, ptr0);
			printf("CMT417: INFO BCNAPSBANK inv_date [%s]\n", 
				wd_bcnapsbank.inv_date);
	
			/* ��ʧЧ */
			if (memcmp(wd_bcnapsbank.inv_date, sWorkDate, 8) <= 0)
			{
				wd_bcnapsbank.status[0] = '2';
			}
			strcpy(wd_bcnapsbank.alt_issno, sBankIssno);
			wd_bcnapsbank.alt_type[0] = '3';
			CommonGetCurrentTimeDB(wd_bcnapsbank.alt_date);
	
			printf("CMT417: INFO BCNAPSBANK status [%s]\n", 
				wd_bcnapsbank.status);
			printf("CMT417: INFO BCNAPSBANK alt_issno [%s]\n", 
				wd_bcnapsbank.alt_issno);
			printf("CMT417: INFO BCNAPSBANK alt_date [%s]\n", 
				wd_bcnapsbank.alt_date);
	
			if (DbsBCNAPSBANK(DBS_IUPD, &wd_bcnapsbank) != 0)
			{
				printf("CMT417: UPDATE into BCNAPSBANK error!!!\n"); 
				return 2;
			}
	
			/* �����ʧЧ */
			if (memcmp(wd_bcnapsbank.inv_date, sWorkDate, 8) <= 0)
			{
				CnapsBankCodeSend2EFT(sWorkDate, 3, &wd_bcnapsbank);
			}

			break;

		default:
			printf("CMT417: Invalid Maintenance Type\n"); 
			break;
	}

	return 0;
}

int nProcessCMT417FileEisString(char *sTemp0, char *sWorkDate, char *sBankIssno)
{
	char		*ptr0=NULL, *last0=NULL;
	char		cBankType;
	struct wd_beisbank_area				wd_beisbank;
	struct wd_beisbank_area				wd_beisbank0;
	struct wd_beisbanktmp_area			wd_beisbanktmp;

	/* �������� */
	ptr0 = strtok_r(sTemp0, "|", &last0);
	if (ptr0 == NULL || *ptr0 == '\n') return 2;
	cBankType = ptr0[0];
	
	printf("INFO Bank Code Maintenance Type [%c]\n", 
		cBankType);
	
	if ((cBankType != '1') && (cBankType != '2') && (cBankType != '3'))
	{
		return 1;
	}
	
	switch (cBankType)
	{
		case '1': /* update - ��� */
			memset(&wd_beisbanktmp, 0, sizeof(wd_beisbanktmp));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.bank_code, ptr0);
			printf("CMT417: INFO BEISBANKTMP bank_code [%s]\n", 
				wd_beisbanktmp.bank_code);
	
			/* ��Ч���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.alt_effdate, ptr0);
			printf("CMT417: INFO BEISBANKTMP alt_effdate [%s]\n", 
				wd_beisbanktmp.alt_effdate);
	
			/* ϵͳ��־ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.cnaps_flag, ptr0);
			printf("CMT417: INFO BEISBANKTMP cnaps_flag [%s]\n", 
				wd_beisbanktmp.cnaps_flag);
	
			/* ֧��ϵͳ�к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.cbnk_code, ptr0);
			printf("CMT417: INFO BEISBANKTMP cbnk_code [%s]\n", 
				wd_beisbanktmp.cbnk_code);
	
			/* EISСվ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.eis_site_code, ptr0);
			printf("CMT417: INFO BEISBANKTMP eis_site_code [%s]\n", 
				wd_beisbanktmp.eis_site_code);
	
			/* �б���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.cls_code, ptr0);
	
			/* ���ڳ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.city_code, ptr0);
	
			/* ������ȫ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.long_name, ptr0);
			printf("CMT417: INFO BEISBANKTMP long_name [%s]\n", 
				wd_beisbanktmp.long_name);
	
			/* �����߼�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.short_name, ptr0);
	
			/* ��ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.address, ptr0);
	
			/* �ʱ� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.postcode, ptr0);
	
			/* �绰/��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.telephone, ptr0);
	
			/* �����ʼ���ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.email, ptr0);
	
			/* ��ע */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbanktmp.remark, ptr0);
	
			strcpy(wd_beisbanktmp.alt_issno, sBankIssno);
			wd_beisbanktmp.alt_type[0] = '1';
			CommonGetCurrentTimeDB(wd_beisbanktmp.alt_date);
	
			printf("CMT417: INFO BEISBANKTMP alt_issno [%s]\n", 
				wd_beisbanktmp.alt_issno);
			printf("CMT417: INFO BEISBANKTMP alt_date [%s]\n", 
				wd_beisbanktmp.alt_date);
	
			if (DbsBEISBANKTMP(DBS_INSERT, &wd_beisbanktmp) != 0)
			{
				printf("CMT417: INSERT into BEISBANKTMP error!!!\n"); 
			}
	
			/* �������Ч */
			if (memcmp(wd_beisbanktmp.alt_effdate, sWorkDate, 8)
				<= 0)
			{
				memset(&wd_beisbank, 0, sizeof(wd_beisbank));
				memcpy(wd_beisbank.bank_code, wd_beisbanktmp.bank_code, 6);
				if (DbsBEISBANK(DBS_FIND, &wd_beisbank) != 0)
				{
					printf("CMT417: [%s] not found in BEISBANK!", 
						wd_beisbanktmp.bank_code);
					return 2;
				}

				wd_beisbank.alt_type[0] = '1'; /* update */
				memcpy(wd_beisbank.eis_site_code, wd_beisbanktmp.eis_site_code, 
					sizeof(wd_beisbanktmp.eis_site_code)-1);
				wd_beisbank.cnaps_flag[0] = wd_beisbanktmp.cnaps_flag[0]; 
				memcpy(wd_beisbank.cbnk_code, wd_beisbanktmp.cbnk_code, 
					sizeof(wd_beisbanktmp.cbnk_code)-1);
				memcpy(wd_beisbank.cls_code, wd_beisbanktmp.cls_code, 
					sizeof(wd_beisbanktmp.cls_code)-1);
				memcpy(wd_beisbank.city_code, wd_beisbanktmp.city_code, 
					sizeof(wd_beisbanktmp.city_code)-1);
				memcpy(wd_beisbank.long_name, wd_beisbanktmp.long_name, 
					sizeof(wd_beisbanktmp.long_name)-1);
				memcpy(wd_beisbank.short_name, wd_beisbanktmp.short_name, 
					sizeof(wd_beisbanktmp.short_name)-1);
				memcpy(wd_beisbank.address, wd_beisbanktmp.address, 
					sizeof(wd_beisbanktmp.address)-1);
				memcpy(wd_beisbank.postcode, wd_beisbanktmp.postcode, 
					sizeof(wd_beisbanktmp.postcode)-1);
				memcpy(wd_beisbank.telephone, wd_beisbanktmp.telephone, 
					sizeof(wd_beisbanktmp.telephone)-1);
				memcpy(wd_beisbank.email, wd_beisbanktmp.email, 
					sizeof(wd_beisbanktmp.email)-1);
				memcpy(wd_beisbank.remark, wd_beisbanktmp.remark, 
					sizeof(wd_beisbanktmp.remark)-1);
				memcpy(wd_beisbank.alt_date, wd_beisbanktmp.alt_date, 
					sizeof(wd_beisbanktmp.alt_date)-1);
				memcpy(wd_beisbank.alt_issno, wd_beisbanktmp.alt_issno, 
					sizeof(wd_beisbanktmp.alt_issno)-1);
				CommonGetCurrentTimeDB(wd_beisbank.rec_updt_time);
		
				if (DbsBEISBANK(DBS_IUPD, &wd_beisbank) != 0)
				{
					printf("CMT417: [%s] BEISBANK update error!", 
						wd_beisbanktmp.bank_code);
					return 2;
				}

				DbsBEISBANKTMP(DBS_IDEL, &wd_beisbanktmp);

				if (wd_beisbank.cnaps_flag[0] == 'E')
				{
					EisBankCodeSend2EFT(sWorkDate, 1, &wd_beisbank);
				}
				else
				{
					EisBankCodeSend2EFT(sWorkDate, 3, &wd_beisbank);
				}
			}

			break;

		case '2': /* add - ���� */
			memset(&wd_beisbank, 0, sizeof(wd_beisbank));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.bank_code, ptr0);
			printf("CMT417: INFO BEISBANK bank_code [%s]\n", 
				wd_beisbank.bank_code);
	
			/* ϵͳ��־ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.cnaps_flag, ptr0);
			printf("CMT417: INFO BEISBANK cnaps_flag [%s]\n", 
				wd_beisbank.cnaps_flag);
	
			/* ֧��ϵͳ�к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.cbnk_code, ptr0);
			printf("CMT417: INFO BEISBANK cbnk_code [%s]\n", 
				wd_beisbank.cbnk_code);
	
			/* EISСվ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.eis_site_code, ptr0);
			printf("CMT417: INFO BEISBANK eis_site_code [%s]\n", 
				wd_beisbank.eis_site_code);
	
			/* �б���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.cls_code, ptr0);
	
			/* ���ڳ��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.city_code, ptr0);
	
			/* ������ȫ�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.long_name, ptr0);
			printf("CMT417: INFO BEISBANK long_name [%s]\n", 
				wd_beisbank.long_name);
	
			/* �����߼�� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.short_name, ptr0);
	
			/* ��ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.address, ptr0);
	
			/* �ʱ� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.postcode, ptr0);
	
			/* �绰/��� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.telephone, ptr0);
	
			/* �����ʼ���ַ */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.email, ptr0);
	
			/* ��Ч���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.eff_date, ptr0);
			printf("CMT417: INFO BEISBANK eff_date [%s]\n", 
				wd_beisbank.eff_date);
	
			/* ʧЧ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.inv_date, ptr0);
			printf("CMT417: INFO BEISBANK inv_date [%s]\n", 
				wd_beisbank.inv_date);
	
			/* ��ע */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.remark, ptr0);
	
			if (memcmp(wd_beisbank.eff_date, sWorkDate, 8) <= 0)
			{
				/* ����Ч */
				wd_beisbank.status[0] = '1';
			}
			else
			{
				wd_beisbank.status[0] = '0';
			}

			strcpy(wd_beisbank.alt_issno, sBankIssno);
			wd_beisbank.alt_type[0] = '2';
			CommonGetCurrentTimeDB(wd_beisbank.alt_date);
	
			printf("CMT417: INFO BEISBANK status [%s]\n", 
				wd_beisbank.status);
			printf("CMT417: INFO BEISBANK alt_issno [%s]\n", 
				wd_beisbank.alt_issno);
			printf("CMT417: INFO BEISBANK alt_date [%s]\n", 
				wd_beisbank.alt_date);
	
			if (DbsBEISBANK(DBS_INSERT, &wd_beisbank) != 0)
			{
				printf("CMT417: INSERT into BEISBANK error!!!\n"); 
				return 2;
			}
	
			/* �������Ч */
			if (memcmp(wd_beisbank.eff_date, sWorkDate, 8) <= 0)
			{
				if (wd_beisbank.cnaps_flag[0] == 'E')
				{
					EisBankCodeSend2EFT(sWorkDate, 2, &wd_beisbank);
				}
			}
	
			break;
	
		case '3': /* close - ע�� */
			memset(&wd_beisbank, 0, sizeof(wd_beisbank));
			/* �к� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.bank_code, ptr0);
			printf("CMT417: INFO BEISBANK bank_code [%s]\n", 
				wd_beisbank.bank_code);
	
			/* find original bank code record */
			if (DbsBEISBANK(DBS_FIND, &wd_beisbank) != 0)
			{
				printf("CMT417: FIND from BEISBANK error!!!\n"); 
				return 2;
			}
	
			/* ʧЧ���� */
			ptr0 = strtok_r(NULL, "|", &last0);
			if (ptr0 == NULL || *ptr0 == '\n') return 2;
			strcpy(wd_beisbank.inv_date, ptr0);
			printf("CMT417: INFO BEISBANK inv_date [%s]\n", 
				wd_beisbank.inv_date);
	
			/* ��ʧЧ */
			if (memcmp(wd_beisbank.inv_date, sWorkDate, 8) <= 0)
			{
				wd_beisbank.status[0] = '2';
			}
			strcpy(wd_beisbank.alt_issno, sBankIssno);
			wd_beisbank.alt_type[0] = '3';
			CommonGetCurrentTimeDB(wd_beisbank.alt_date);
	
			printf("CMT417: INFO BEISBANK status [%s]\n", 
				wd_beisbank.status);
			printf("CMT417: INFO BEISBANK alt_issno [%s]\n", 
				wd_beisbank.alt_issno);
			printf("CMT417: INFO BEISBANK alt_date [%s]\n", 
				wd_beisbank.alt_date);
	
			if (DbsBEISBANK(DBS_IUPD, &wd_beisbank) != 0)
			{
				printf("CMT417: UPDATE into BEISBANK error!!!\n"); 
				return 2;
			}
	
			/* �����ʧЧ */
			if (memcmp(wd_beisbank.inv_date, sWorkDate, 8) <= 0)
			{
				EisBankCodeSend2EFT(sWorkDate, 3, &wd_beisbank);
			}

			break;

		default:
			printf("CMT417: Invalid Maintenance Type\n"); 
			break;
	}

	return 0;
}

void CnapsBankCodeSend2EFT(char *sWorkDate, int type, 
struct wd_bcnapsbank_area *pwd_bcnapsbank)
{
	char sDataBuf[200];
	int  nRet;

	memset(sDataBuf, 0, sizeof(sDataBuf));
	strcpy(sDataBuf, "00000168");
	strcat(sDataBuf, "BANKCODE");
	strcat(sDataBuf, "{");
	strcat(sDataBuf, "C");
	switch (type)
	{
		case 1: strcat(sDataBuf, "M");
				break;
		case 2: strcat(sDataBuf, "A");
				break;
		case 3: strcat(sDataBuf, "D");
				break;
		default: strcat(sDataBuf, "M");
				break;
	}
	memcpy(sDataBuf+19, pwd_bcnapsbank->bank_code, 12);
	memcpy(sDataBuf+31, pwd_bcnapsbank->city_code, 4);

	/* long_name */
	memset(sDataBuf+35, ' ', 30);
	if(strlen(pwd_bcnapsbank->long_name) >= 30)
	{
		memcpy(sDataBuf+35, pwd_bcnapsbank->long_name, 30);
	}
	else
	{
		memcpy(sDataBuf+35, pwd_bcnapsbank->long_name, 
			strlen(pwd_bcnapsbank->long_name));
	}
	memcpy(sDataBuf+65, "     ", 5);
	memset(sDataBuf+70, ' ', 30);
	if(strlen(pwd_bcnapsbank->long_name) > 30)
	{
		memcpy(sDataBuf+70, pwd_bcnapsbank->long_name+30, 
			strlen(pwd_bcnapsbank->long_name)-30);
	}
	memcpy(sDataBuf+100, "     ", 5);

	/* address */
	memset(sDataBuf+105, ' ', 30);
	if(strlen(pwd_bcnapsbank->address) >= 30)
	{
		memcpy(sDataBuf+105, pwd_bcnapsbank->address, 30);
	}
	else
	{
		memcpy(sDataBuf+105, pwd_bcnapsbank->address, 
			strlen(pwd_bcnapsbank->address));
	}
	memcpy(sDataBuf+135, "     ", 5);
	memset(sDataBuf+140, ' ', 30);
	if(strlen(pwd_bcnapsbank->address) > 30)
	{
		memcpy(sDataBuf+140, pwd_bcnapsbank->address+30, 
			strlen(pwd_bcnapsbank->address)-30);
	}
	memcpy(sDataBuf+170, "     ", 5);

	memcpy(sDataBuf+175, "}", 1);

	WriteLogFileToEFT(sWorkDate, sDataBuf);

	sleep(1);
	nRet = nCommonMsqSend(strlen(sDataBuf), sDataBuf, 
		CI_MANAGER, CI_HSTCOMM_B);
	if (nRet != 0)
	{
		printf("CnapsBankCodeSend2EFT: MSQ HSTCOMM_B SEND error!");
	}
	
	return;
}

void EisBankCodeSend2EFT(char *sWorkDate, int type, 
struct wd_beisbank_area *pwd_beisbank)
{
	char sDataBuf[200];
	int  nRet;

	memset(sDataBuf, 0, sizeof(sDataBuf));
	strcpy(sDataBuf, "00000168");
	strcat(sDataBuf, "BANKCODE");
	strcat(sDataBuf, "{");
	strcat(sDataBuf, "E");
	switch (type)
	{
		case 1: strcat(sDataBuf, "M");
				break;
		case 2: strcat(sDataBuf, "A");
				break;
		case 3: strcat(sDataBuf, "D");
				break;
		default: strcat(sDataBuf, "M");
				break;
	}
	memcpy(sDataBuf+19, pwd_beisbank->bank_code, 6);
	memcpy(sDataBuf+25, "      ", 6);
	memcpy(sDataBuf+31, pwd_beisbank->eis_site_code, 4);

	/* long_name */
	memset(sDataBuf+35, ' ', 30);
	if(strlen(pwd_beisbank->long_name) >= 30)
	{
		memcpy(sDataBuf+35, pwd_beisbank->long_name, 30);
	}
	else
	{
		memcpy(sDataBuf+35, pwd_beisbank->long_name, 
			strlen(pwd_beisbank->long_name));
	}
	memcpy(sDataBuf+65, "     ", 5);
	memset(sDataBuf+70, ' ', 30);
	if(strlen(pwd_beisbank->long_name) > 30)
	{
		memcpy(sDataBuf+70, pwd_beisbank->long_name+30, 
			strlen(pwd_beisbank->long_name)-30);
	}
	memcpy(sDataBuf+100, "     ", 5);

	/* address */
	memset(sDataBuf+105, ' ', 30);
	if(strlen(pwd_beisbank->address) >= 30)
	{
		memcpy(sDataBuf+105, pwd_beisbank->address, 30);
	}
	else
	{
		memcpy(sDataBuf+105, pwd_beisbank->address, 
			strlen(pwd_beisbank->address));
	}
	memcpy(sDataBuf+135, "     ", 5);
	memset(sDataBuf+140, ' ', 30);
	if(strlen(pwd_beisbank->address) > 30)
	{
		memcpy(sDataBuf+140, pwd_beisbank->address+30, 
			strlen(pwd_beisbank->address)-30);
	}
	memcpy(sDataBuf+170, "     ", 5);

	memcpy(sDataBuf+175, "}", 1);

	WriteLogFileToEFT(sWorkDate, sDataBuf);

	sleep(1);
	nRet = nCommonMsqSend(strlen(sDataBuf), sDataBuf, 
		CI_MANAGER, CI_HSTCOMM_B);
	if (nRet != 0)
	{
		printf("EisBankCodeSend2EFT: MSQ HSTCOMM_B SEND error!");
	}
	
	return;
}

void WriteLogFileToEFT(char *sWorkDate, char *sDataBuf)
{
	char sFileName[1024];
	char sTime[20];
	FILE *fpe;

	memset(sFileName, 0, sizeof(sFileName));
	sprintf(sFileName, "%s/iodata/eft/bankcode/BANKCODE-%8.8s", 
		getenv("APPL"), sWorkDate);

	fpe = fopen(sFileName, "a+");
	if (fpe != NULL)
	{
		memset(sTime, 0, sizeof(sTime));
		CommonGetCurrentTime(sTime);
		fprintf(fpe, "TIME === [%s]\n", sTime);
		fprintf(fpe, "%s\n", sDataBuf);
	}

	fclose(fpe);
	return;
}


