/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: DebugString.c                                               */
/* DESCRIPTIONS: The common routines for debug, including                    */
/*               DebugString -- Display the message buffer like unix "hd"    */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

/*
#include "cplusplus.h"
*/

/*****************************************************************************/
/* FUNC:   void DebugString (char *psBuf, int iLength, int iLine);           */
/* INPUT:  psBuf       -- the buffer to display                              */
/*         iLength     -- display the first iLength bytes of psBuf           */
/*         iLine       -- the line number of source code                     */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Display the message buffer like unix "hd".                        */
/*****************************************************************************/
#include  "stdio.h"
#include  <string.h>
#include  <stdlib.h>

void DebugString( char *psBuf, int iLength, int iLine)
{
   int i,j=0;
   char s[100], temp[5];
   char	ptr[30];
	 memset(ptr,'\0',sizeof(ptr));
 	 sprintf(ptr,"%s",getenv("HT_DEBUG_STRING_MODE"));
 	 /*strcpy(ptr,"ON");*/
	 if ( ptr[0] == '\0' )
	 {
	 	printf("environmental variable HT_DEBUG_STRING_MODE not set\n");
	 	return;
	 }
	 else
	 {
	 	if ( strcmp(ptr, "OFF") == 0 )	 		
	 		return;
	 }

   printf( "Debug Information from Line: %04d\n", iLine);

   for (i=0; i<iLength; i++)
   {
      if (j==0)
      {
         memset( s, ' ', 84);
         sprintf(temp,   " %03d:",i );
         memcpy( s, temp, 5);
         sprintf(temp,   ":%03d",i+15 );
         memcpy( &s[72], temp, 4);
      }
      sprintf( temp, "%02X ", (unsigned char)psBuf[i]);
      memcpy( &s[j*3+5+(j>7)], temp, 3);
      if ( isprint( psBuf[i]))
      {
         s[j+55+(j>7)]=psBuf[i];
      }
      else
      {
         s[j+55+(j>7)]='.';
      }
      j++;
      if ( j==16)
      {
         s[76]=0;
         printf( "%s\n", s);
         j=0;
      }
   }
   if ( j)
   {
      s[76]=0;
      printf( "%s\n", s);
   }
}
