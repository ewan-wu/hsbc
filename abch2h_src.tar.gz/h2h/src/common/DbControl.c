#include <sys/time.h>
#include <sys/timeb.h>
#include <time.h>

#include <sybfront.h>
#include <sybdb.h>

#include "htlog.h"
#include "public.h"
#include "glb_def.h"
#include "msglog.h"
#include "ipc.h"
#include "wd_incl.h"
#include "sysdef.h"
#include "common.h"
#include "swttoc.h"

extern DBPROCESS *dbproc;

extern short    LoadTxnnoMap();
extern short    LoadSrvMsq();
/*extern short    ErrReport(long lMsgSource, long lErrorCode, long lErrorSubCode,
                         long lSeverity, char *sDescription);*/
extern int 	HtLog(	char *logfile, int level, 
						char *file, int line, char *fmt, ...);
extern short    HtDebugString(    char *logfile,
                        char *psBuf, int iLength,
                        char *iFile, int iLine );
extern short    nCommonMsqAllInit(long lSrvId);
extern long     DbConnect();
extern long     DbBeginTxn();
extern long     DbCommitTxn();
extern long     DbRollbackTxn();
extern void     CommonGetCurrentTime(char *sCurrentTime);

/*extern short    DbsBCNAPSMSGLOG( int ifunc , struct wd_bcnapsmsglog_area	*LtpWdBCNAPSMSGLOG );
extern short    DbsBSWIFTMSGLOG( int ifunc , struct wd_bswiftmsglog_area	*LtpWdBCNAPSMSGLOG );
extern short    DbsBPAYTXNLOG(   int ifunc , struct wd_bpaytxnlog_area	        *LtpWdBPAYTXNLOG );*/
extern short    nDeclareCmtCursor(short);
extern short    nOpenCmtCursor();
extern short    nCloseCmtCursor();
extern short    nFreeCmtCursor();

extern short    nGetBcnsNextTag(struct wd_bcnapsfld_area *pdbtTag);
extern short    nGetBswfFld(struct wd_bswiftfld_area *pdbtFld);
extern short    nGetBcnsTag(struct wd_bcnapsfld_area *pdbtTag);
extern int      MbStrCpy( char * Src, char * Desc, int iLen );
extern void     DeleteTailSpace(char *pString,ULONG lTail);

short    nDeclareCmtMtCursor(short nCmtIndex,short nMtIndex);
short    nOpenCmtMtCursor();
short    nCloseCmtMtCursor();
short    nFreeCmtMtCursor();
/*short    nGetNextRule(struct wd_bvmsgrule_area *pRule);*/

int nNewSwfMsgSeqWithoutToctl(char *sSwfMsgSeq);

/****************************************************************************/
/*    PROGRAM NAME:  nInitMsgQue										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:                                                               */
/****************************************************************************/
short nInitMsgQue(short nSwitchType, char *logfile)
{
	long 	lReturn  =  0;

	lReturn=DbConnect();
	if ( lReturn!= 0)
	{
		/*ErrReport(nSwitchType,
			EI_DATABASE,
			lReturn,
			CI_SEVERITY_SYSERROR,
			ES_DB_OPEN);*/
		HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"nInitMsgQue:DbConnect Error!\n");
		return -1;
	}

	/*****************************************/
    	/* Load the server information in SRVMSQ */
	/*****************************************/
	if (LoadSrvMsq()!=0)
	{
        /*	ErrReport(nSwitchType, 
                	  EI_DATABASE, 
                  	  0, 
                  	  CI_SEVERITY_SYSERROR,
                  	 ES_DB_SELECT);*/
        	HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
				"nInitMsgQue:Load server information from SRVMSQ Error!\n");
			return -1;
	}
	printf("nInitMsgQue:Load server information from SRVMSQ success!\n");

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"nInitMsgQue:Load server information from SRVMSQ success!\n");


	/*****************************************/
	/* Load the Txnno information in gTXNNOMAP */
	/*****************************************/
	if (LoadTxnnoMap() != 0)
	{
        /*	ErrReport(nSwitchType, 
                	  EI_DATABASE, 
                  	  0, 
                  	  CI_SEVERITY_SYSERROR,
                  	 ES_DB_SELECT);*/
        	 HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
			"nInitMsgQue:Load Txnno information from TXNNOMAP Error!\n");	
			return -1;
	}
	printf("nInitMsgQue:Load Txnno information from TXNNOMAP success!\n");

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
    		"nInitMsgQue:Load Txnno information from TXNNOMAP success!\n");


	/*****************************/
	/* Initial the message queue */
	/*****************************/
	lReturn = nCommonMsqAllInit(nSwitchType);
	if (lReturn != 0) 
	{
		/*ErrReport(nSwitchType, 
			EI_MESSAGEQUEUE, 
			lReturn, 
			CI_SEVERITY_SYSERROR,
			ES_MSGQ_CONNECT);*/
		HtLog(  logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
					"nInitMsgQue:Connect MSGQ Error!\n");

		return -1;
	}
	printf("Connect MSGQ success!\n");

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"nInitMsgQue:Connect MSGQ success!\n");

	return 0;
} 


/****************************************************************************/
/*    PROGRAM NAME:  nInsertCnapsMsgLog										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/
short nInsertCnapsMsgLog(char *pMsgText, struct wd_bcnapsmsglog_area *ptCnapsMsg, char cDirection, char *logfile)
{
	char  sTmp[30];
	long  nLen;
	short nRet;
	
	if ((memcmp(pMsgText, "{1:", 3 )!=0)
		||(pMsgText[CNS_PKTHEAD_LEN-1]!='}'))
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"Invalid Packet");
	    	return -1;
	}

	/* just a insert action, no need transaction, Laura
	nRet=DbBeginTxn();		
	if (0 != nRet)
	{
		printf("DbBeginTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbBeginTxn error!\n");
		return -4;
	}		
	*/

	/*****************************************/
	/* init tCnapsmsg						 */
	/*****************************************/
	DbsBCNAPSMSGLOG(DBS_INI, ptCnapsMsg);
		
	memcpy(ptCnapsMsg->cmt_seqno, pMsgText+15, 8);
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"ptCnapsMsg->cmt_seqno[%s]\n",ptCnapsMsg->cmt_seqno);
	ptCnapsMsg->cmt_io[0] = cDirection;

	/*****************************************/
	/* Find the cnapsmsg in CNAPSMSG		 */
	/*****************************************/
	nRet =  DbsBCNAPSMSGLOG(DBS_FIND, ptCnapsMsg);
	if (0 == nRet)
	{
		printf("find repeat cnapsmsg from CNAPSMSG!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"find repeat cnapsmsg from CNAPSMSG!\n");
		return -2;
	}		

	memset(sTmp, 0, sizeof(sTmp));
	memcpy(sTmp, pMsgText+57, 3);
	ptCnapsMsg->cmt_type = atoi(sTmp);
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"ptCnapsMsg->cmt_type[%d]\n",ptCnapsMsg->cmt_type);



	CommonGetCurrentTime(ptCnapsMsg->rec_updt_time);

	memcpy(ptCnapsMsg->cmt_localtime, pMsgText+43,14);

	memcpy(ptCnapsMsg->cmt_work_date, pMsgText+60,8);

	
	ptCnapsMsg->cmt_trn_type[0] = pMsgText[11];
	
	if (memcmp(pMsgText+CNS_PKTHEAD_LEN, "{2:", 3 )==0)
		ptCnapsMsg->cmt_priority[0] = pMsgText[CNS_PKTHEAD_LEN+6];
	else
		ptCnapsMsg->cmt_priority[0] = '0';

	memcpy(ptCnapsMsg->cmt_sender, pMsgText+23,12);
	memcpy(ptCnapsMsg->cmt_refno, pMsgText+35,8);
	memcpy(ptCnapsMsg->cmt_status, pMsgText+12,3);
	
	memset(sTmp, 0, sizeof(sTmp));	
	memcpy(sTmp, pMsgText+3, 6);
	ptCnapsMsg->cmt_text_len = atoi(sTmp);
	
	if(ptCnapsMsg->cmt_text_len>sizeof(ptCnapsMsg->cmt_text)-1)
	{
		nLen=sizeof(ptCnapsMsg->cmt_text)-1;
	}
	else
	{
		nLen=ptCnapsMsg->cmt_text_len;		
	}
	
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"ptCnapsMsg->cmt_text_len[%d],nLen[%d]\n",ptCnapsMsg->cmt_text_len,nLen);


	memcpy(ptCnapsMsg->cmt_text, pMsgText, nLen);
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"ptCnapsMsg->cmt_text[%s]\n",ptCnapsMsg->cmt_text);
/*	HtDebugString(logfile, (char* )ptCnapsMsg, sizeof(struct wd_bcnapsmsglog_area), 
			__FILE__, __LINE__);
*/

	/*****************************************/
	/*Insert the Cnaspmsg to CNAPSMSG		 */
	/*****************************************/
	
	if (strlen(pMsgText) > 1000) /* ?? */
	{
		nRet=0;
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Length of message over 1000 -- nRet[%d]!\n",nRet);
	}
	else
	{
		nRet=DbsBCNAPSMSGLOG(DBS_INSERT, ptCnapsMsg);
	}
	if (0 != nRet)
	{
		/*ErrReport(CI_CNAPSBDG, 
			EI_DATABASE,
			0, 
			CI_SEVERITY_SYSERROR,
			ES_DB_INSERT);*/
		printf("insert cnapsmsg error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"insert cnapsmsg error nRet[%d]!\n",nRet);
		/* just a insert action, no need transaction, Laura
		DbRollbackTxn();
		*/
		return -3;
	}
	/* just a insert action, no need transaction, Laura
	nRet=DbCommitTxn( );
	if (0 != nRet)
	{
		printf("DbCommitTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbCommitTxn error!\n");
		return -5;
	}		
	*/

return 0;	
}

/****************************************************************************/
/*    PROGRAM NAME:  nInsertHostMsgLog										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/
short nInsertHostMsgLog(MT_PACKET *pPacket,T_HostSwtOutDef *pHostSwtDef, struct wd_bswiftmsglog_area *pHostMsg, char cDirection, char *logfile)
{
	char  sTmp[30];
	long  nLen;
	short nRet;
	char sMsgSeq[6+1];
	
	if (memcmp(pPacket->sPacket, "{1:", 3 )!=0)
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"Invalid Packet");
	    	return -1;
	}

	/* 2003/12/24 */
	if((memcmp(pPacket->sMsgAck, "MSGACK", strlen("MSGACK"))==0) ||
		(memcmp(pHostSwtDef->tHostGen.sMsgType, "ACK", 3)==0))
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"MSGACK - Do not insert into BSWIFTMSGLOG");
	    	return 0;
	}
	/* 2003/12/24 */

	/* just a insert action, no need transaction, Laura
	nRet=DbBeginTxn();		
	if (0 != nRet)
	{
		printf("DbBeginTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbBeginTxn error!\n");
		return -4;
	}		
	**/

	/*****************************************/
	/* init pHostMsg                         */
	/*****************************************/
	DbsBSWIFTMSGLOG(DBS_INI, pHostMsg);
		
	/* 2003/12/24
	memcpy(pHostMsg->mt_seqno, pHostSwtDef->tHostGen.sSeqSSN, sizeof(pHostSwtDef->tHostGen.sSeqSSN));
	*/
	if (nNewSwfMsgSeqWithoutToctl(sMsgSeq) != 0)
	{
		memcpy(pHostMsg->mt_seqno, pHostSwtDef->tHostGen.sSeqSSN, 
			sizeof(pHostSwtDef->tHostGen.sSeqSSN));
	}
	else
	{
		memcpy(pHostMsg->mt_seqno, sMsgSeq, sizeof(pHostMsg->mt_seqno) - 1);
	}
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_seqno[%s]\n",pHostMsg->mt_seqno);
	pHostMsg->mt_io[0] = cDirection;

	/*****************************************/
	/* Find the hostmsg in SWIFTMSG		 */
	/*****************************************/
	nRet =  DbsBSWIFTMSGLOG(DBS_FIND, pHostMsg);
	if (0 == nRet)
	{
		printf("find repeat cnapsmsg from SWIFTMSGLOG!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"find repeat cnapsmsg from SWIFTMSGLOG!\n");
		return -2;
	}

	memcpy(pHostMsg->mt_type, pHostSwtDef->tHostGen.sMsgType, sizeof(pHostSwtDef->tHostGen.sMsgType));
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
	    		"pHostMsg->mt_type[%s]\n",pHostMsg->mt_type);


	CommonGetCurrentTime(pHostMsg->rec_updt_time);

	memset(sTmp, 0, sizeof(sTmp));
	memcpy(sTmp, pHostSwtDef->tHostGen.sTimeIcn, sizeof(pHostSwtDef->tHostGen.sTimeIcn));
	if (strlen(sTmp)==0)
		memcpy(sTmp, pHostSwtDef->tHostGen.sOutDate2, sizeof(pHostSwtDef->tHostGen.sOutDate2));
	if (strlen(sTmp)==0)
		memcpy(sTmp, pHostSwtDef->tHostGen.sDateBlk, sizeof(pHostSwtDef->tHostGen.sDateBlk));

	if (strlen(sTmp)>0)
	{
		memcpy(pHostMsg->mt_localtime, sTmp,6);
	}
	else
	{
		memcpy(pHostMsg->mt_localtime, &pHostMsg->rec_updt_time[2], 6);
	}

	memcpy(pHostMsg->mt_sender_lt, pHostSwtDef->tHostGen.sLTIdr, sizeof(pHostSwtDef->tHostGen.sLTIdr));
	pHostMsg->mt_priority[0]=pHostSwtDef->tHostGen.cMsgPrty;
	if(memcmp(pHostSwtDef->tHostGen.sMsgType, "007", 3)==0)
		pHostMsg->mt_status[0]='9';
	else
		pHostMsg->mt_status[0]='0';
	memcpy(pHostMsg->mt_refno, pHostSwtDef->tHostGen.sRefSSN, sizeof(pHostSwtDef->tHostGen.sRefSSN));
	pHostMsg->mt_text_len=(int)pPacket->packet_len;
	
	if(pHostMsg->mt_text_len>sizeof(pHostMsg->mt_text)-1)
	{
		nLen=sizeof(pHostMsg->mt_text)-1;
	}
	else
	{
		nLen=(long)pHostMsg->mt_text_len;		
	}
	
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_text_len[%d],nLen[%d]\n",pHostMsg->mt_text_len,nLen);

	if(memcmp(pPacket->sMsgAck, "MSGACK", strlen("MSGACK"))==0)
		pHostMsg->memo[0]='1';
	else
		pHostMsg->memo[0]='0';
	memcpy(pHostMsg->mt_text, pPacket->sPacket, nLen);
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_text[%s]\n",pHostMsg->mt_text);

	/*****************************************/
	/*Insert the Hostmsg to SWIFTMSG		 */
	/*****************************************/
	nRet=DbsBSWIFTMSGLOG(DBS_INSERT, pHostMsg);
	if (0 != nRet)
	{
		/*ErrReport(CI_HOSTBDG+CI_, 
			EI_DATABASE,
			0, 
			CI_SEVERITY_SYSERROR,
			ES_DB_INSERT);*/
		printf("insert SWIFTMSGLOG error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"insert SWIFTMSGLOG error nRet[%d]!\n",nRet);
		/* just a insert action, no need transaction, Laura
		DbRollbackTxn();
		*/
		return -3;
	}
	/* just a insert action, no need transaction, Laura
	nRet=DbCommitTxn( );
	if (0 != nRet)
	{
		printf("DbCommitTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbCommitTxn error!\n");
		return -5;
	}		
	*/

return 0;	
}

short nInsertHostMsgLogIn(MT_PACKET *pPacket,T_HostSwtInDef *pHostSwtDef, struct wd_bswiftmsglog_area *pHostMsg, char cDirection, char *logfile)
{
	char  sTmp[30];
	long  nLen;
	short nRet;
	
	if (memcmp(pPacket->sPacket, "{1:", 3 )!=0)
	{
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"Invalid Packet");
	    	return -1;
	}

	/* just a insert action, no need transaction, Laura
	nRet=DbBeginTxn();		
	if (0 != nRet)
	{
		printf("DbBeginTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbBeginTxn error!\n");
		return -4;
	}		
	**/

	/*****************************************/
	/* init pHostMsg                         */
	/*****************************************/
	DbsBSWIFTMSGLOG(DBS_INI, pHostMsg);
		
	memcpy(pHostMsg->mt_seqno, pHostSwtDef->tHostGen.sSeqSSN, sizeof(pHostSwtDef->tHostGen.sSeqSSN));
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_seqno[%s]\n",pHostMsg->mt_seqno);
	pHostMsg->mt_io[0] = cDirection;

	/*****************************************/
	/* Find the hostmsg in SWIFTMSG		 */
	/*****************************************/
	nRet =  DbsBSWIFTMSGLOG(DBS_FIND, pHostMsg);
	if (0 == nRet)
	{
		printf("find repeat cnapsmsg from SWIFTMSGLOG!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"find repeat cnapsmsg from SWIFTMSGLOG!\n");
		return -2;
	}

	memcpy(pHostMsg->mt_type, pHostSwtDef->tHostGen.sMsgType, sizeof(pHostSwtDef->tHostGen.sMsgType));
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
	    		"pHostMsg->mt_type[%s]\n",pHostMsg->mt_type);


	CommonGetCurrentTime(pHostMsg->rec_updt_time);

	memset(sTmp, 0, sizeof(sTmp));
	memcpy(sTmp, pHostSwtDef->tHostGen.sTimeIcn, sizeof(pHostSwtDef->tHostGen.sTimeIcn));
	/* no sOutDate2 in T_HostSwtInDef buffer 
	if (strlen(sTmp)==0)
		memcpy(sTmp, pHostSwtDef->tHostGen.sOutDate2, sizeof(pHostSwtDef->tHostGen.sOutDate2));
	*/
	if (strlen(sTmp)==0)
		memcpy(sTmp, pHostSwtDef->tHostGen.sDateBlk, sizeof(pHostSwtDef->tHostGen.sDateBlk));

	if (strlen(sTmp)>0)
	{
		memcpy(pHostMsg->mt_localtime, sTmp,6);
	}
	else
	{
		memcpy(pHostMsg->mt_localtime, &pHostMsg->rec_updt_time[2], 6);
	}

	memcpy(pHostMsg->mt_sender_lt, pHostSwtDef->tHostGen.sLTIdr, sizeof(pHostSwtDef->tHostGen.sLTIdr));
	pHostMsg->mt_priority[0]=pHostSwtDef->tHostGen.cMsgPrty;
	if(memcmp(pHostSwtDef->tHostGen.sMsgType, "007", 3)==0)
		pHostMsg->mt_status[0]='9';
	else
		pHostMsg->mt_status[0]='0';
	memcpy(pHostMsg->mt_refno, pHostSwtDef->tHostGen.sRefSSN, sizeof(pHostSwtDef->tHostGen.sRefSSN));
	pHostMsg->mt_text_len=(int)pPacket->packet_len;
	
	if(pHostMsg->mt_text_len>sizeof(pHostMsg->mt_text)-1)
	{
		nLen=sizeof(pHostMsg->mt_text)-1;
	}
	else
	{
		nLen=(long)pHostMsg->mt_text_len;		
	}
	
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_text_len[%d],nLen[%d]\n",pHostMsg->mt_text_len,nLen);

	if(memcmp(pPacket->sMsgAck, "MSGACK", strlen("MSGACK"))==0)
		pHostMsg->memo[0]='1';
	else
		pHostMsg->memo[0]='0';
	memcpy(pHostMsg->mt_text, pPacket->sPacket, nLen);
	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	    		"pHostMsg->mt_text[%s]\n",pHostMsg->mt_text);

	/*****************************************/
	/*Insert the Hostmsg to SWIFTMSG		 */
	/*****************************************/
	nRet=DbsBSWIFTMSGLOG(DBS_INSERT, pHostMsg);
	if (0 != nRet)
	{
		/*ErrReport(CI_HOSTBDG+CI_, 
			EI_DATABASE,
			0, 
			CI_SEVERITY_SYSERROR,
			ES_DB_INSERT);*/
		printf("insert SWIFTMSGLOG error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"insert SWIFTMSGLOG error nRet[%d]!\n",nRet);
		/* just a insert action, no need transaction, Laura
		DbRollbackTxn();
		*/
		return -3;
	}
	/* just a insert action, no need transaction, Laura
	nRet=DbCommitTxn( );
	if (0 != nRet)
	{
		printf("DbCommitTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbCommitTxn error!\n");
		return -5;
	}		
	*/

return 0;	
}

/*****************************************************************************/
/* FUNC:   int nPickoutCmtInfo(char *pCmtNo, void *ptTitaIPC, void *pOutBuf );*/
/* INPUT:  pCmtNo       -- the string of CMT type                            */
/*         pTitaIPC     -- the pointer of a TitaIPC                          */
/*         pOutBuf      -- the pointer of CMT Buffer                         */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Pick out the CMT message data information from a Tita structer    */
/*****************************************************************************/
/* added by li_jiaxi 2003-08-15  */

int nPickoutCmtInfo(char *pCmtNo, T_CnsSwtTitaDef  *ptTitaIPC, void *pOutBuf, char *logfile)
{
	struct wd_bcnapsfld_area tPktInf;
	char                      sCmtNo[4];
	int                       tag_pos,tita_pos,data_len;
	char                     *psOutBuf,*pTitaIPC;
	short                     nCmtIndex,nRet;

	
	tag_pos=7+2+15;
	tita_pos=0;

	HtDebugString(logfile, pCmtNo, 3, __FILE__, __LINE__);

/*DebugString(ptTitaIPC, sizeof(T_CnsSwtTitaDef), __LINE__);*/

	memcpy(sCmtNo, pCmtNo, 3);
	sCmtNo[3]=0;
	nCmtIndex=atoi(sCmtNo);

	psOutBuf=(char *)pOutBuf;
	pTitaIPC=(char *)ptTitaIPC;
	if(nDeclareCmtCursor(nCmtIndex)!=0)
	{
		printf("Cannot Declare Cursor CMTConvert_CUR!\n");
		return -3;
	}

	if(nOpenCmtCursor()!=0)
	{
		printf("Cannot Open Cursor CMTConvert_CUR!\n");
		return -4;
	}

	nRet=0;

	while (nGetBcnsNextTag(&tPktInf)==1)
	{

	/*DebugString( psOutBuf, tag_pos, __LINE__);*/
		/*���Tag���Ƕ���*/
		if(tPktInf.len_flg[0]=='1')
		{	/*(ԭ)���ҷ���3λ�����15λ*/
			if ((memcmp(tPktInf.tag, "32A", 3)==0) 
				||(memcmp(tPktInf.tag, "CND", 3)==0)) 
			{
				tita_pos=tPktInf.tag_data_pos + sizeof(T_IPCHeader);
				data_len =3;
		/*printf("tag_pos[%d]tita_pos[%d]\n",  tag_pos, tita_pos);*/
				memcpy(psOutBuf+tag_pos, &pTitaIPC[tita_pos], data_len);
				tag_pos = tag_pos + data_len;
				psOutBuf[tag_pos]=0;
				tag_pos++;
				
				data_len =15;
		/*printf("tag_pos[%d]tita_pos[%d]\n",  tag_pos, tita_pos);*/
				/* modified by Laura, 2004/03/08
				memcpy(psOutBuf+tag_pos, &pTitaIPC[tita_pos+3], data_len);
				*/
				{
				char sTmpAmt[16];
				memset(sTmpAmt, 0, sizeof(sTmpAmt));
				memcpy(sTmpAmt, &pTitaIPC[tita_pos+3], data_len);
				DeleteTailSpace(sTmpAmt, data_len);
				if (strlen(sTmpAmt) >= data_len)
				{
					memcpy(psOutBuf+tag_pos, &pTitaIPC[tita_pos+3], data_len);
				}
				else
				{
					memset(psOutBuf+tag_pos, '0', data_len - strlen(sTmpAmt));
					memcpy(psOutBuf+tag_pos+data_len-strlen(sTmpAmt), 
						&pTitaIPC[tita_pos+3], strlen(sTmpAmt));
				}
				}
				tag_pos = tag_pos + data_len;
				psOutBuf[tag_pos]=0;
				tag_pos++;

			}
			else 
			{
				tita_pos=tPktInf.tag_data_pos + sizeof(T_IPCHeader);
				data_len =tPktInf.data_len;
		/*printf("tag_pos[%d]tita_pos[%d]\n",  tag_pos, tita_pos);
		DebugString( &pTitaIPC[tita_pos], data_len, __LINE__);*/
				memcpy(psOutBuf+tag_pos, &pTitaIPC[tita_pos], data_len);
				tag_pos = tag_pos + data_len;
				psOutBuf[tag_pos]=0;
				tag_pos++;
			}
		
		} else {
			/*/////////���Ƕ���*/
			HtLog(logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
       			        "Only fixed length tag supported!\n");
			nRet=-1;
			break;
		}


	}
	   					
	if(nCloseCmtCursor()!=0)
	{
		printf("Cannot Close Cursor CMTConvert_CUR!\n");
		return -5;
	}
	if(nFreeCmtCursor()!=0)
	{
		printf("Cannot Free Cursor CMTConvert_CUR!\n");
		return -6;
	}

/*	HtDebugString(logfile, (char *)tpIPCTita->tIPCHeader.sClsSsn, 6, __FILE__, __LINE__);
	HtDebugString(logfile, (char *)tpIPCTita->tTitaPkt.tCnapsGen.sWrkdate, 8, __FILE__, __LINE__);
	*/
	DebugString( psOutBuf, tag_pos, __LINE__);
	return nRet;
}

/****************************************************************************/
/*    PROGRAM NAME:  nInsertTxnLog										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/
short nInsertTxnLog(struct wd_bpaytxnlog_area *pTxnLog, char *logfile)
{
	short nRet;

	/* just a insert action, no need transaction, Laura
	nRet=DbBeginTxn();		
	if (0 != nRet)
	{
		printf("DbBeginTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbBeginTxn error!\n");
		return -4;
	}		
	*/
	nRet =  DbsBPAYTXNLOG(DBS_FIND, pTxnLog);
	if (0 == nRet)
	{
		printf("find repeat paytxnmsg!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"find repeat paytxnmsg!\n");
		return -2;
	}		
	nRet=DbsBPAYTXNLOG(DBS_INSERT, pTxnLog);
	if (0 != nRet)
	{
		printf("insert paytxnmsg error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"insert paytxnmsg error nRet[%d]!\n",nRet);
		/* just a insert action, no need transaction, Laura
		DbRollbackTxn();
		*/
		return -3;
	}
	/* just a insert action, no need transaction, Laura
	nRet=DbCommitTxn( );
	if (0 != nRet)
	{
		printf("DbCommitTxn error!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"DbCommitTxn error!\n");
		return -5;
	}		
	*/

return 0;	
}


/****************************************************************************/
/*    PROGRAM NAME:  nGetCnapsDeptNo										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/

short nGetCnapsDeptNo(struct wd_bdeptctl_area *pDept)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;
	char             sSqlTmp[300];

	strcat(sSqlTmp,"select dept_id,dept_id_eft,dept_name,work_flag,work_type,rec_updt_time from BDEPTCTL ");
	strcat(sSqlTmp,      " where dept_id_eft='");
	strcat(sSqlTmp,pDept->dept_id_eft);
	strcat(sSqlTmp,      "'");

	memset(pDept, 0, sizeof(struct wd_bdeptctl_area));

	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	ret = dbresults(dbproc);
	if (ret == NO_MORE_RESULTS)
		return 0;
	if (ret != SUCCEED)
		return 0;
	
	/* Bind program variables. */
	dbbind(dbproc, 1, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->dept_id);
	dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->dept_id_eft);
	dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->dept_name);
	dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->work_flag);
	dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->work_type);
	dbbind(dbproc, 6, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pDept->rec_updt_time);
	
	j = 0;
	while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;

	if (j < 1)
		return 0;
return 1;
}/*end of nGetCnapsDeptNo*/


/****************************************************************************/
/*    PROGRAM NAME:  nGetCnapsPayType										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/

short nGetCnapsPayType(struct wd_bptypmap_area *pType)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;
	char             sSqlTmp[300];

	strcat(sSqlTmp,"select pay_type,pay_type_eft,rec_updt_time from BTYPMAP ");
	strcat(sSqlTmp,      " where pay_type_eft='");
	strcat(sSqlTmp,pType->pay_type_eft);
	strcat(sSqlTmp,      "'");

	memset(pType, 0, sizeof(struct wd_bptypmap_area));

	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	ret = dbresults(dbproc);
	if (ret == NO_MORE_RESULTS)
		return 0;
	if (ret != SUCCEED)
		return 0;
	
	/* Bind program variables. */
	dbbind(dbproc, 1, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pType->pay_type);
	dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pType->pay_type_eft);
	dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pType->rec_updt_time);
	
	j = 0;
	while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;

	if (j < 1)
		return 0;
return 1;
}/*end of nGetCnapsPayType*/

/****************************************************************************/
/*    PROGRAM NAME:  nConvertCnapsEftTag										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/

/*short   nConvertCnapsEftTag(short nCmtIndex, short nMtIndex,
                                T_CnsSwtTitaDef  *pSwtTita,
				T_HostSwtOutDef  *pHostSwf,
				char *sDirect,
                                char *logfile)
{
	char      *szTo,*szFrom;
	struct wd_bvmsgrule_area  tRule;

	if(memcmp(sDirect, "CNAPS2EFT", strlen("CNAPS2EFT"))==0)
	{
		szTo=(char *)&pHostSwf->tHostGen;
		szFrom=(char *)&pSwtTita->tTitaPkt;
	}
	else 
	if(memcmp(sDirect, "EFT2CNAPS", strlen("EFT2CNAPS"))==0)
	{
		szTo=(char *)&pSwtTita->tTitaPkt;
		szFrom=(char *)&pHostSwf->tHostGen;
	}
	else
		return -1;

	if(nDeclareCmtMtCursor(nCmtIndex, nMtIndex)!=0)
	{
		printf("Cannot Declare Cursor CMTMTConvert_CUR!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Cannot Declare Cursor CMTMTConvert_CUR!\n");
		return -2;
	}

	if(nOpenCmtMtCursor()!=0)
	{
		printf("Cannot Open Cursor CMTMTConvert_CUR!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Cannot Open Cursor CMTMTConvert_CUR!\n");
		return -3;
	}

	while (nGetNextRule(&tRule)==1)
	{
		switch(tRule.rule_type[0])
		{
		case '0':/\*copy fixed length*\/
			if(memcmp(sDirect, "CNAPS2EFT", strlen("CNAPS2EFT"))==0)
			{
				memcpy(&szTo[tRule.fld_data_pos+tRule.fld_start_pos],
					&szFrom[tRule.tag_data_pos+tRule.tag_start_pos], tRule.copy_len);
			}
			else
			{
				memcpy(&szTo[tRule.tag_data_pos+tRule.tag_start_pos],
					&szFrom[tRule.fld_data_pos+tRule.fld_start_pos], tRule.copy_len);
			}
			break;
		case '1':
			break;
		case '2':
			break;
		default:
			printf("Invalid Rule Type!\n");
			HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
				"Invalid Rule Type!\n");
			return -6;
		}
		
	}


	if(nCloseCmtMtCursor()!=0)
	{
		printf("Cannot Close Cursor CMTMTConvert_CUR!\n");
		return -4;
	}
	if(nFreeCmtMtCursor()!=0)
	{
		printf("Cannot Free Cursor CMTMTConvert_CUR!\n");
		return -5;
	}

}*//*end of nConvertCnapsEftTag*/

/****************************************************************************/
/*    PROGRAM NAME:  nConvertEftRef2CnapsRef										*/
/*    DESCRIPTIONS:                                                         */
/*    AUTHOR:  Garhee                                                             */
/****************************************************************************/
short  nConvertEftRef2CnapsRef(char *sEftRef, char *sCnapsRef,char *logfile)
{
	char sTmp[9];
	struct wd_bdeptctl_area	   tDeptCtl;
	struct wd_bptypmap_area	   tTypeCtl;

	if (strlen(sEftRef)!=16)
	{
		printf("Invalid Eft Reference Number!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Invalid Eft Reference Number!\n");
		return -1;
	}

	memset(&tDeptCtl, 0, sizeof(tDeptCtl));
	memset(&tTypeCtl, 0, sizeof(tTypeCtl));
	memset(&sTmp, 0, sizeof(sTmp));

	memcpy(tDeptCtl.dept_id_eft, sEftRef, 2);
	if (nGetCnapsDeptNo(&tDeptCtl)!=1 )
	{
		printf("Can not find department info from BDEPTCTL!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Can not find department info from BDEPTCTL!\n");
		return -2;
	}
	sTmp[0]=tDeptCtl.dept_id[0];

	memcpy(tTypeCtl.pay_type_eft, &sEftRef[2], 2);
	if (nGetCnapsPayType(&tTypeCtl)!=1 )
	{
		printf("Can not find payment type info from BDEPTCTL!\n");
		HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Can not find payment type info from BDEPTCTL!\n");
		return -3;
	}
	sTmp[1]=tTypeCtl.pay_type[0];

	memcpy(&sTmp[2], &sEftRef[4], 2);
	memcpy(&sTmp[4], &sEftRef[12], 4);
	strcpy(sCnapsRef, sTmp);
	return 0;
}/*end of nConvertEftRef2CnapsRef*/





short nDeclareCmtMtCursor(short nCmtIndex,short nMtIndex)
{
	extern DBPROCESS *dbproc;
	char             sSqlTmp[400],sIndex[MT_BIT+1];

	strcpy(sSqlTmp,"declare CMTMTCnvrt_CUR cursor for ");
	strcat(sSqlTmp,"select mt_index, fld_index, mt, fld_name, fld_name_len, ");
	strcat(sSqlTmp,      " fld_data_pos, fld_data_len, fld_team, ");
	strcat(sSqlTmp,      " fld_start_pos, cmt_index, tag_index,cmt, tag, ");
	strcat(sSqlTmp,      " tag_data_pos, tag_data_len, tag_start_pos, ");
	strcat(sSqlTmp,      " copy_len, rule_type");/*, rsv1, rsv2, rsv3, rsv4 */
	strcat(sSqlTmp,      " where cmt_index=");
	sprintf(sIndex, "%d", nCmtIndex);
	strcat(sSqlTmp,sIndex);
	strcat(sSqlTmp,      " and mt_index=");
	sprintf(sIndex, "%d", nCmtIndex);
	strcat(sSqlTmp,sIndex);
	

	dbcmd(dbproc, sSqlTmp);
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Declare CMTMTCnvrt_CUR Successful!\n");
	return 0;
}/*end of nDeclareCmtCursor*/



short nOpenCmtMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "open CMTMTCnvrt_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Open CMTMTCnvrt_CUR Successful!\n");
	return 0;
}/*end of nOpenCmtCursor*/


/*short nGetNextRule(struct wd_bvmsgrule_area *pRule)
{
	RETCODE           ret;
	extern DBPROCESS *dbproc;
	long              j;

	memset(pRule, 0, sizeof(struct wd_bvmsgrule_area));
	dbcmd(dbproc, "fetch CMTMTCnvrt_CUR ");
	dbsqlexec(dbproc);
	ret = dbresults(dbproc);
	if (ret == NO_MORE_RESULTS)
		return 0;
	if (ret != SUCCEED)
		return 0;

	/\* Bind program variables. *\/ 
	dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->mt_index);
	dbbind(dbproc, 2, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->fld_index);
	dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->mt);
	dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->fld_name);
	dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->fld_name_len);
	dbbind(dbproc, 6, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->fld_data_pos);
	dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->fld_data_len);
	dbbind(dbproc, 8, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->fld_team);
	dbbind(dbproc, 9, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->fld_start_pos);
	dbbind(dbproc,10, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->cmt_index);
	dbbind(dbproc,11, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->tag_index);
	dbbind(dbproc,12, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->cmt);
	dbbind(dbproc,13, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->tag);
	dbbind(dbproc,14, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->tag_data_pos);
	dbbind(dbproc,15, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->tag_data_len);
	dbbind(dbproc,16, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->tag_start_pos);
	dbbind(dbproc,17, SMALLBIND,     (DBINT)0, (BYTE *)&pRule->copy_len);
	dbbind(dbproc,18, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->rule_type);
	/\*dbbind(dbproc,19, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->rsv1);
	dbbind(dbproc,20, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->rsv2);
	dbbind(dbproc,21, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->rsv3);
	dbbind(dbproc,22, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)pRule->rsv4);*\/

	j = 0;
	while (dbnextrow(dbproc) != NO_MORE_ROWS) j++;
	
	if (j < 1)
		return 0;
return 1;
}*//*end of nGetBcnsNextTag*/


short nCloseCmtMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "close CMTMTCnvrt_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}
	printf("Close CMTMTCnvrt_CUR Successful!\n");
	return 0;
}/*end of nCloseCmtCursor*/

short nFreeCmtMtCursor()
{
	extern DBPROCESS *dbproc;

	dbcmd(dbproc, "deallocate cursor CMTMTCnvrt_CUR ");
	dbsqlexec(dbproc);
	if (dbresults(dbproc) != SUCCEED)
	{
		return -1;
	}

	printf("Deallocate CMTMTCnvrt_CUR Successful!\n");
	return 0;
}/*end of nFreeCmtCursor*/





long nGetTitaCnapsTag(T_TitaPktDef *pCnapsPkt, char *psCmtNo, char *psTagName, long nStartPos, long nLen, char *psData)
{
	struct wd_bcnapsfld_area   tPktInf;
	extern DBPROCESS           *dbproc;
	RETCODE                    result_code;
	long                       nRet,nLenTmp;
	char                       *psTitaPacket;
	char                       sPacket[MAX_PACKET_LEN];

	psTitaPacket=(char *)&pCnapsPkt->tCnapsGen;
	memset(&tPktInf,  '\0', sizeof(tPktInf));

	dbcmd(dbproc,"select tag_index, tag_type, ");
	dbcmd(dbproc,      " tag_opt, tag_flg, len_flg, ");
	dbcmd(dbproc,      " tag_data_pos, data_len from BCNAPSFLD ");
	dbcmd(dbproc,      " where tag='");
	dbcmd(dbproc,psTagName);
	dbcmd(dbproc,      "' and cmt_index=");
	dbcmd(dbproc,psCmtNo);
	
	dbsqlexec(dbproc);
	nRet=-1;

	while ((result_code = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (result_code == SUCCEED)
		{
			/* Bind program variables. */
			dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.tag_index);
			dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_type);
			dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_opt);
			dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_flg);
			dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.len_flg);
			dbbind(dbproc, 6, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.tag_data_pos);
			dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.data_len);

			/* Now find the rows. */

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				if ((DBCURCMD(dbproc) == 2)
					&& (DBCURROW(dbproc) > 10))
					continue;
				nRet=0;
				break;
			}
		}
	}

	/*Get Tag Data*/
	if (nRet==0)
	{
		if (nLen>tPktInf.data_len)
			memset(sPacket,   '\0',    nLen+1);
		else
			memset(sPacket,   '\0',    tPktInf.data_len+1);
		memcpy(sPacket,   &psTitaPacket[tPktInf.tag_data_pos+nStartPos-1], tPktInf.data_len-nStartPos);
		DeleteTailSpace(sPacket, tPktInf.data_len);
		nLenTmp=strlen(sPacket);
		if (nLenTmp<=nLen)
		{
			nRet=nLenTmp;
			strcpy(psData, sPacket);
		}
		else
		{
			nRet=MbStrCpy( psData, sPacket, nLen );
		}
	}

return nRet;
}/*end of nGetTitaCnapsTag*/

long nGetTotaCnapsTag(T_CnsTotaPktDef *pCnapsPkt, char *psCmtNo, char *psTagName, long nStartPos, long nLen, char *psData)
{
	struct wd_bcnapsfld_area   tPktInf;
	extern DBPROCESS           *dbproc;
	RETCODE                    result_code;
	long                       nRet,nLenTmp;
	char                       *psTitaPacket;
	char                       sPacket[MAX_PACKET_LEN];

	psTitaPacket=(char *)&pCnapsPkt->tCnapsGen;
	memset(&tPktInf,  '\0', sizeof(tPktInf));

	dbcmd(dbproc,"select tag_index, tag_type, ");
	dbcmd(dbproc,      " tag_opt, tag_flg, len_flg, ");
	dbcmd(dbproc,      " tag_data_pos, data_len from BCNAPSFLD ");
	dbcmd(dbproc,      " where tag='");
	dbcmd(dbproc,psTagName);
	dbcmd(dbproc,      "' and cmt_index=");
	dbcmd(dbproc,psCmtNo);
	
	dbsqlexec(dbproc);
	nRet=-1;

	while ((result_code = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (result_code == SUCCEED)
		{
			/* Bind program variables. */
			dbbind(dbproc, 1, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.tag_index);
			dbbind(dbproc, 2, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_type);
			dbbind(dbproc, 3, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_opt);
			dbbind(dbproc, 4, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.tag_flg);
			dbbind(dbproc, 5, NTBSTRINGBIND, (DBINT)0, (BYTE DBFAR *)tPktInf.len_flg);
			dbbind(dbproc, 6, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.tag_data_pos);
			dbbind(dbproc, 7, SMALLBIND,     (DBINT)0, (BYTE *)&tPktInf.data_len);

			/* Now find the rows. */

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				if ((DBCURCMD(dbproc) == 2)
					&& (DBCURROW(dbproc) > 10))
					continue;
				nRet=0;
				break;
			}
		}
	}

	/*Get Tag Data*/
	if (nRet==0)
	{
		if (nLen>tPktInf.data_len)
			memset(sPacket,   '\0',    nLen+1);
		else
			memset(sPacket,   '\0',    tPktInf.data_len+1);
		memcpy(sPacket,   &psTitaPacket[tPktInf.tag_data_pos-DELTA_TITA_TOTA+nStartPos-1], tPktInf.data_len-nStartPos);
		DeleteTailSpace(sPacket, tPktInf.data_len);
		nLenTmp=strlen(sPacket);
		if (nLenTmp<=nLen)
		{
			nRet=nLenTmp;
			strcpy(psData, sPacket);
		}
		else
		{
			nRet=MbStrCpy( psData, sPacket, nLen );
		}
	}

return nRet;
}/*end of nGetTotaCnapsTag*/


int nGetSettleBankCodeCNAPS(char *sInBankCode, char *sSettleBankCode, char *sNodeCode)
{
	struct wd_bcnapsbank_area wd_bcnapsbank;
	struct wd_bcnapsbank_area wd_bcnapsbank_dre;

	memset(&wd_bcnapsbank, 0, sizeof(wd_bcnapsbank));
	memcpy(wd_bcnapsbank.bank_code, sInBankCode, 
		sizeof(wd_bcnapsbank.bank_code) - 1);
	if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank) != 0)
	{
		return -1;
	}

	memcpy(sSettleBankCode, wd_bcnapsbank.dre_code, 
		sizeof(wd_bcnapsbank.dre_code) - 1);
	sSettleBankCode[sizeof(wd_bcnapsbank.dre_code) - 1] = 0; 

	memset(&wd_bcnapsbank_dre, 0, sizeof(wd_bcnapsbank_dre));
	memcpy(wd_bcnapsbank_dre.bank_code, wd_bcnapsbank.dre_code, 
		sizeof(wd_bcnapsbank_dre.bank_code) - 1);
	if (DbsBCNAPSBANK(DBS_FIND, &wd_bcnapsbank_dre) != 0)
	{
		memcpy(sNodeCode, wd_bcnapsbank_dre.bank_code+3, 4);
		sNodeCode[4] = 0; 
	}
	else
	{
		memcpy(sNodeCode, wd_bcnapsbank_dre.node_code, 4);
		sNodeCode[4] = 0; 
	}

	return 0;
}

int nGetSettleBankCodeEIS(char *sInBankCode, char *sSettleBankCode, char *sSiteCode)
{
	RETCODE	ret;
	int		i;
	char	sCnapsFlag[1+1];
	char	sBankCode[6+1];
	char	sBankCodeCnaps[12+1];
	char	sBankCodeCnapsClear[12+1];
	char	sNodeCode[5+1];
	char	sCityCodeTmp[4+1];
	char	sEisSiteCode[5+1];

	memset(sEisSiteCode, 0, sizeof(sEisSiteCode));
	memset(sCityCodeTmp, 0, sizeof(sCityCodeTmp));
	memset(sBankCodeCnaps, 0, sizeof(sBankCodeCnaps));
	memset(sBankCodeCnapsClear, 0, sizeof(sBankCodeCnapsClear));
	memset(sNodeCode, 0, sizeof(sNodeCode));
	memset(sCnapsFlag, 0, sizeof(sCnapsFlag));

	memset(sBankCode, 0, sizeof(sBankCode));
	memcpy(sBankCode, sInBankCode, 6);

	dbfcmd(dbproc, "select cnaps_flag, cbnk_code, city_code, eis_site_code ");
	dbfcmd(dbproc, "from BEISBANK ");
	dbfcmd(dbproc, "where bank_code = '%s' ", sBankCode);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sCnapsFlag);
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE DBFAR *)sBankCodeCnaps);
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, (BYTE DBFAR *)sCityCodeTmp);
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, (BYTE DBFAR *)sEisSiteCode);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			/* judge cnaps flag */
			if (sCnapsFlag[0] == 'E')
			{
				/* clearing bank cnaps code - EIS Center Code */
				strcpy(sSettleBankCode, CURRENT_EIS_CENTER_CODE);
			}
			else
			{
				/* clearing bank cnaps code */
				if (nGetSettleBankCodeCNAPS(sBankCodeCnaps, 
						sBankCodeCnapsClear, sNodeCode) != 0)
				{
					memcpy(sSettleBankCode, sBankCodeCnaps, 12); 
					sSettleBankCode[12] = 0;
				}
				else
				{
					memcpy(sSettleBankCode, sBankCodeCnapsClear, 12); 
					sSettleBankCode[12] = 0;
				}
			}
			memcpy(sSiteCode, sEisSiteCode, 4);
			sSiteCode[4] = 0;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

/* return 1-CNAPS/2-EIS */
int nJudgeBankCodeCnapsOrEis(char *sInBankCode)
{
	if ((sInBankCode[6] > '9') || (sInBankCode[6] < '0'))
	{
		return 2;
	}
	else
	{
		return 1;
	}
}


void vTransferRefnoFromMtToCnaps(char *sInRefno, char *sOutRefno)
{
	struct wd_bptypmap_area wd_bptypmap;
	long lPid;
	short nReturn;
	SwtToSEQReqDef tSwtTocSeq;

if (sInRefno[9] == 'G')
{
	/* 1-digit is always '7' for GIRO payment */
	sOutRefno[0] = '7';

	lPid = getpid();

	/* 7-digits is the sequence number */
	tSwtTocSeq.MsgType=CI_TOCTL_SEQ;
	tSwtTocSeq.nMsgCode=lPid;
	tSwtTocSeq.nSwitchPID=lPid;
	tSwtTocSeq.nReplyCode=0;
	tSwtTocSeq.nSeqLen=0;
	memset(tSwtTocSeq.sSeqStr, '0', sizeof(tSwtTocSeq.sSeqStr));
	memcpy(tSwtTocSeq.sSeqType, SEQCTL_RCD_ID_GIROPSEQ, 
		strlen(SEQCTL_RCD_ID_GIROPSEQ));
			
	nReturn = SwtSnd2ToSEQ (&tSwtTocSeq);
	if ((nReturn!=0) || (tSwtTocSeq.nReplyCode!=0))
	{
		memcpy(sOutRefno+1, "0000000", 7);
	}
	else
	{
		memcpy(sOutRefno+1, tSwtTocSeq.sSeqStr, 7);
	}
}
else
{
	/* department code */
	sOutRefno[0] = sInRefno[0];

	/* payment type */
	memset(&wd_bptypmap, 0, sizeof(wd_bptypmap));
	memcpy(wd_bptypmap.pay_type_eft, sInRefno+2, 2);

	if (DbsBPTYPMAP(DBS_FIND, &wd_bptypmap) != 0)
	{
		sOutRefno[1] = '0';
	}
	else
	{
		sOutRefno[1] = wd_bptypmap.pay_type[0];
	}
	
	/* date DD + sequence code */
	memcpy(sOutRefno+2, sInRefno+10, 6);
}
	sOutRefno[8] = 0;
	printf("sOutRefno [%s]\n", sOutRefno);
	return;
}

void vTransferRefnoFromCnapsToMt(char *sInRefno, char *sOutRefno)
{
	RETCODE ret;
	int		i;
	char	sPayTypeEFT[2+1];
	char	sTemp1[4+1];
	char	sTemp2[4+1];
	struct wd_bsysctl_area wd_bsysctl;

if (sInRefno[0] == '7')
{
	memcpy(sOutRefno, "----------------", 16);
}
else
{
	/* department code */
	sOutRefno[0] = sInRefno[0];
	sOutRefno[1] = '0';

	/* payment type */
	memset(sPayTypeEFT, 0, sizeof(sPayTypeEFT));
	sOutRefno[2] = ' ';
	sOutRefno[3] = ' ';

	dbfcmd(dbproc, "select pay_type_eft ");
	dbfcmd(dbproc, "from BPTYPMAP ");
	dbfcmd(dbproc, "where pay_type = '%c' ", sInRefno[1]);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sPayTypeEFT);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) break;

			/* output */
			sOutRefno[2] = sPayTypeEFT[0];
			sOutRefno[3] = sPayTypeEFT[1];
		}
		else
		{
			break;
		}
	}

	/* YYYYMM */
	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));
	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, sizeof(wd_bsysctl.rcd_id)-1);
	if (DbsBSYSCTL(DBS_FIND, &wd_bsysctl) != 0)
	{
		/* YYYYMM */
		memcpy(sOutRefno+4, "000000", 6);
	}
	else
	{
		if (memcmp(wd_bsysctl.work_date+6, sInRefno+2, 2) < 0)
		{
			if ((wd_bsysctl.work_date[5] == '0') &&
				(wd_bsysctl.work_date[6] == '1'))
			{
				/* YYYY */
				memcpy(sTemp1, wd_bsysctl.work_date, 4);
				sTemp1[4] = 0;
				sprintf(sTemp2, "%04d", atoi(sTemp1)-1);
				memcpy(sOutRefno+4, sTemp2, 4);
				/* MM */
				memcpy(sOutRefno+8, "12", 2);
			}
			else
			{
				/* YYYY */
				memcpy(sOutRefno+4, wd_bsysctl.work_date, 4);
				/* MM */
				memcpy(sTemp1, wd_bsysctl.work_date+4, 2);
				sTemp1[2] = 0;
				sprintf(sTemp2, "%02d", atoi(sTemp1)-1);
				memcpy(sOutRefno+8, sTemp2, 2);
			}
		}
		else
		{
			/* YYYYMM */
			memcpy(sOutRefno+4, wd_bsysctl.work_date, 6);
		}
	}

	/* date DD + sequence code */
	memcpy(sOutRefno+10, sInRefno+2, 6);
}
	sOutRefno[16] = 0;
	printf("sOutRefno [%s]\n", sOutRefno);
	return;
}

void vGetCnapsResponseCodeDesc(char *sRspCode, char *sRspCodeDesc)
{
	struct wd_bcnapspsc_area wd_bcnapspsc;

	memset(&wd_bcnapspsc, 0, sizeof(wd_bcnapspsc));
	memcpy(wd_bcnapspsc.proc_code, sRspCode, 
		sizeof(wd_bcnapspsc.proc_code) - 1);

	if (DbsBCNAPSPSC(DBS_FIND, &wd_bcnapspsc) != 0)
	{
		strcpy(sRspCodeDesc, "Description not found!");
	}
	else
	{
		strcpy(sRspCodeDesc, wd_bcnapspsc.proc_cd_desc);
	}

	return;
}

int nFindOriginalPaytxnlogByRefno(char *sSender, char *sRefno, char *sValueDate, 
char *sWorkDate, char *sClsSsn)
{
	RETCODE	ret;
	int		i;

	char	sInSender[12+1];
	char	sInRefno[8+1];
	char	sInValueDate[8+1];
	char	sOutClsSsn[6+1];
	char	sOutWorkDate[8+1];

	memset(sInSender, 0, sizeof(sInSender));
	memset(sInRefno, 0, sizeof(sInRefno));
	memset(sInValueDate, 0, sizeof(sInValueDate));

	memcpy(sInSender, sSender, sizeof(sInSender) - 1);
	memcpy(sInRefno, sRefno, sizeof(sInRefno) - 1);
	memcpy(sInValueDate, sValueDate, sizeof(sInValueDate) - 1);

	memset(sOutClsSsn, 0, sizeof(sOutClsSsn));
	memset(sOutWorkDate, 0, sizeof(sOutWorkDate));
	
	dbfcmd(dbproc, "select p_cls_ssn, p_work_date ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_refno = '%s' ", sInRefno);
	dbfcmd(dbproc, "and p_sender = '%s' ", sInSender);
	dbfcmd(dbproc, "and p_value_date = '%s' ", sInValueDate);

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutClsSsn);
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutWorkDate);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			memcpy(sClsSsn, sOutClsSsn, sizeof(sOutClsSsn) - 1);
			sClsSsn[sizeof(sOutClsSsn) - 1] = 0;
			memcpy(sWorkDate, sOutWorkDate, sizeof(sOutWorkDate) - 1);
			sWorkDate[sizeof(sOutWorkDate) - 1] = 0;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindOriginalPaytxnlogByRefnoWorkDate(char *sSender, char *sRefno, 
char *sWorkDate, char *sClsSsn)
{
	RETCODE	ret;
	int		i;

	char	sInSender[12+1];
	char	sInRefno[8+1];
	char	sInWorkDate[8+1];
	char	sOutClsSsn[6+1];
	char	sOutWorkDate[8+1];

	memset(sInSender, 0, sizeof(sInSender));
	memset(sInRefno, 0, sizeof(sInRefno));
	memset(sInWorkDate, 0, sizeof(sInWorkDate));

	memcpy(sInSender, sSender, sizeof(sInSender) - 1);
	memcpy(sInRefno, sRefno, sizeof(sInRefno) - 1);
	memcpy(sInWorkDate, sWorkDate, sizeof(sInWorkDate) - 1);

	memset(sOutClsSsn, 0, sizeof(sOutClsSsn));
	memset(sOutWorkDate, 0, sizeof(sOutWorkDate));
	
	dbfcmd(dbproc, "select p_cls_ssn, p_work_date ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_refno = '%s' ", sInRefno);
	dbfcmd(dbproc, "and p_sender = '%s' ", sInSender);
	dbfcmd(dbproc, "and p_work_date = '%s' ", sInWorkDate);

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutClsSsn);
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutWorkDate);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			memcpy(sClsSsn, sOutClsSsn, sizeof(sOutClsSsn) - 1);
			sClsSsn[sizeof(sOutClsSsn) - 1] = 0;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindOriginalPaytxnlogByRefnoEFT(char *sRefnoEFT, char *sValueDate, 
char *sWorkDate, char *sClsSsn)
{
	RETCODE	ret;
	int		i;

	char	sInRefnoEFT[16+1];
	char	sInValueDate[8+1];
	char	sOutClsSsn[6+1];
	char	sOutWorkDate[8+1];

	memset(sInRefnoEFT, 0, sizeof(sInRefnoEFT));
	memset(sInValueDate, 0, sizeof(sInValueDate));

	memcpy(sInRefnoEFT, sRefnoEFT, sizeof(sInRefnoEFT) - 1);
	memcpy(sInValueDate, sValueDate, sizeof(sInValueDate) - 1);

	memset(sOutClsSsn, 0, sizeof(sOutClsSsn));
	memset(sOutWorkDate, 0, sizeof(sOutWorkDate));
	
	dbfcmd(dbproc, "select p_cls_ssn, p_work_date ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_refno_eft = '%s' ", sInRefnoEFT);
	dbfcmd(dbproc, "and p_value_date = '%s' ", sInValueDate);

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutClsSsn);
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutWorkDate);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			memcpy(sClsSsn, sOutClsSsn, sizeof(sOutClsSsn) - 1);
			sClsSsn[sizeof(sOutClsSsn) - 1] = 0;
			memcpy(sWorkDate, sOutWorkDate, sizeof(sOutWorkDate) - 1);
			sWorkDate[sizeof(sOutWorkDate) - 1] = 0;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindOriginalPaytxnlogByPktID(char *sPktID, char *sWorkDate, char *sClsSsn)
{
	RETCODE	ret;
	int		i;

	char	sInPktID[8+1];
	char	sOutClsSsn[6+1];
	char	sOutWorkDate[8+1];

	memset(sInPktID, 0, sizeof(sInPktID));
	memcpy(sInPktID, sPktID, sizeof(sInPktID) - 1);

	memset(sOutClsSsn, 0, sizeof(sOutClsSsn));
	memset(sOutWorkDate, 0, sizeof(sOutWorkDate));
	
	dbfcmd(dbproc, "select p_cls_ssn, p_work_date ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where substring(p_data_2, 1, 8) = '%s' ", sInPktID);

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutClsSsn);
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, (BYTE DBFAR *)sOutWorkDate);

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			memcpy(sClsSsn, sOutClsSsn, sizeof(sOutClsSsn) - 1);
			sClsSsn[sizeof(sOutClsSsn) - 1] = 0;
			memcpy(sWorkDate, sOutWorkDate, sizeof(sOutWorkDate) - 1);
			sWorkDate[sizeof(sOutWorkDate) - 1] = 0;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nUpdateOriginalPaytxnlogStatusByClsSsn(char *sClsSsn, char *sWorkDate, 
char *sStatus, char *sProcessCode)
{
	RETCODE	ret;
	int		i;

	char	sInClsSsn[6+1];
	char	sInWorkDate[8+1];
	char	sInStatus[1+1];
	char	sInProcessCode[8+1];

	memset(sInClsSsn, 0, sizeof(sInClsSsn));
	memset(sInWorkDate, 0, sizeof(sInWorkDate));
	memset(sInStatus, 0, sizeof(sInStatus));
	memset(sInProcessCode, 0, sizeof(sInProcessCode));

	memcpy(sInClsSsn, sClsSsn, sizeof(sInClsSsn) - 1);
	memcpy(sInWorkDate, sWorkDate, sizeof(sInWorkDate) - 1);
	memcpy(sInStatus, sStatus, sizeof(sInStatus) - 1);
	memcpy(sInProcessCode, sProcessCode, sizeof(sInProcessCode) - 1);

	dbfcmd(dbproc, "update BPAYTXNLOG set ");
	dbfcmd(dbproc, "p_status = '%s', ", sInStatus);
	dbfcmd(dbproc, "p_data_1 = '%s' ", sInProcessCode);
	dbfcmd(dbproc, "where p_work_date = '%s' ", sInWorkDate);
	dbfcmd(dbproc, "and p_cls_ssn = '%s' ", sInClsSsn);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			return 0;
		}
		else
		{
			return -1;
		}
	}
	return -1;
}

int nFindNo910ByPktId(struct wd_btblcmtno910_area * pcmtno910)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from Btblcmtno910 ");
	dbfcmd(dbproc, "where cmt0bc = '%s' ", pcmtno910->cmt0bc);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->ref_no));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->cmtno));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->cnaps_date));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->cmt0bc));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->type));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->recdate));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->terminal_id));
			dbbind(dbproc, 8, INTBIND, (DBINT)0, 
				(BYTE *)&(pcmtno910->srv_id));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->tita_header));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->tota_header));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->gen_fld));
			dbbind(dbproc, 12, INTBIND, (DBINT)0, 
				(BYTE *)&(pcmtno910->packet_len));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->rsv1));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->rsv2));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->rsv3));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->rsv4));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmtno910->rsv5));

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT105ByCMT0BC(struct wd_btblcmt105_area * pcmt105)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from Btblcmt105 ");
	dbfcmd(dbproc, "where cmt0bc = '%s' and type='0'", pcmt105->cmt0bc);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt32a1));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt32a2));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt011));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt52a));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt012));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt58a));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmtcf3));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmtcf4));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmtcef));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt0bc));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt010));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt0b9));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmt72a));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->cmtc42));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->c42desc));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->rsv1));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->rsv2));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->rsv3));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->rsv4));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt105->rsv5));

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT108ByCMT0BC(struct wd_btblcmt108_area * pcmt108)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from Btblcmt108 ");
	dbfcmd(dbproc, "where cmt0bc = '%s' and type='0'", pcmt108->cmt0bc);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt52a));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt011));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt58a));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt012));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt32a1));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt32a2));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt051));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt02b));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt005));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmtcq1));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmtcr1));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmtcq2));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmtcr2));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt0bc));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt010));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt0b9));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmt72a));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->cmtc42));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->c42desc));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->rsv1));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->rsv2));
			dbbind(dbproc, 26, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->rsv3));
			dbbind(dbproc, 27, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->rsv4));
			dbbind(dbproc, 28, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt108->rsv5));

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT109ByCMT0BC(struct wd_btblcmt109_area * pcmt109)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from Btblcmt109 ");
	dbfcmd(dbproc, "where cmt0bc = '%s' and type='0'", pcmt109->cmt0bc);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt32a1));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt32a2));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt011));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg1));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg2));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg3));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt012));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg4));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg5));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg6));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt0bc));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt010));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt0b9));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg7));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtc42));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->c42desc));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv1));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv2));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv3));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv4));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}
int nFindCMT100ByCMT0BC(struct wd_btblcmt100_area * pcmt100)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from Btblcmt100 ");
	dbfcmd(dbproc, "where cmt0bc = '%s' and type = '0'", pcmt100->cmt0bc);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt32a1));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt32a2));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt011));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt52a));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmtcc4));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt50c));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt50a));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt50b));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt012));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt58a));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmtcc5));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt59c));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt59a));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt59b));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmtcef));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt0bc));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt010));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt0b9));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmt72a));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->cmtc42));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->c42desc));
			dbbind(dbproc, 26, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->rsv1));
			dbbind(dbproc, 27, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->rsv2));
			dbbind(dbproc, 28, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->rsv3));
			dbbind(dbproc, 29, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->rsv4));
			dbbind(dbproc, 30, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt100->rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindTxnLogByDateRefnoSenderSettle(struct wd_bpaytxnlog_area * ppaytxnlog)
{
	RETCODE	ret;
	int		i;

	dbfcmd(dbproc, "select * ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_status = '1' and p_refno = '%s' and p_sender='%s' and p_work_date='%s'", 
		ppaytxnlog->p_refno,ppaytxnlog->p_sender,ppaytxnlog->p_work_date);
	
	/*HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
	   		"nFindTxnLogByDateRefnoSender's sql : %s,%s,%s\n",
	   		ppaytxnlog->p_refno,ppaytxnlog->p_sender,ppaytxnlog->p_o_work_date);
	*/    		
	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_refno));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_refno_eft));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_sender));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_work_date));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_io_flag));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cr_flag));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cr_appno));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cr_status));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_proc_cd));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_status));
			dbbind(dbproc, 12, INTBIND, (DBINT)0, 
				(BYTE *)&(ppaytxnlog->p_cmt_type));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cmt_localtime));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cmt_io));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_mt_type));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_mt_localtime));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_mt_io));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_value_date));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_curr_cd));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_amount));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_sender_clr));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_receiver));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_receiver_clr));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payer_bnk));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payer_act));
			dbbind(dbproc, 26, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payer_name));
			dbbind(dbproc, 27, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payer_addr));
			dbbind(dbproc, 28, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payee_bnk));
			dbbind(dbproc, 29, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payee_act));
			dbbind(dbproc, 30, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payee_name));
			dbbind(dbproc, 31, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_payee_addr));
			dbbind(dbproc, 32, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_pay_type));
			dbbind(dbproc, 33, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_bill_date));
			dbbind(dbproc, 34, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_bill_no));
			dbbind(dbproc, 35, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_bill_type));
			dbbind(dbproc, 36, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_bill_enc));
			dbbind(dbproc, 37, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_amount_a1));
			dbbind(dbproc, 38, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_amount_a2));
			dbbind(dbproc, 39, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_lend_rate));
			dbbind(dbproc, 40, INTBIND, (DBINT)0, 
				(BYTE *)&(ppaytxnlog->p_lend_term));
			dbbind(dbproc, 41, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_refno));
			dbbind(dbproc, 42, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_sender));
			dbbind(dbproc, 43, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_work_date));
			dbbind(dbproc, 44, INTBIND, (DBINT)0, 
				(BYTE *)&(ppaytxnlog->p_o_cmt_type));
			dbbind(dbproc, 45, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_cmt_localtime));
			dbbind(dbproc, 46, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_cmt_io));
			dbbind(dbproc, 47, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_mt_type));
			dbbind(dbproc, 48, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_mt_localtime));
			dbbind(dbproc, 49, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_o_mt_io));
			dbbind(dbproc, 50, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cntr_cd_s));
			dbbind(dbproc, 51, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_cntr_cd_r));
			dbbind(dbproc, 52, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_text));
			dbbind(dbproc, 53, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_memo));
			dbbind(dbproc, 54, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_data_1));
			dbbind(dbproc, 55, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->p_data_2));
			dbbind(dbproc, 56, CHARBIND, (DBINT)0, 
				(BYTE *)(ppaytxnlog->rec_updt_time));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT301ByCj901c056(struct wd_btblcmt301_area * pcmt301)
{
	RETCODE	ret;
	int		i;
	char    sSql[1024];
	struct wd_btblcmt301_area wd_btblcmt301;  /* 2004/01/12 */
	
	memset(&wd_btblcmt301, 0, sizeof(wd_btblcmt301));
	memset(sSql,0,sizeof(sSql));
	sprintf(sSql,"select * from Btblcmt301 where cmtcj9 = '%s' and "
		"cmt01c = '%s' and cmt056 = '%s'",pcmt301->cmtcj9,pcmt301->cmt01c,
		pcmt301->cmt056);
	dbfcmd(dbproc, sSql);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtcj9));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt01c));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt011));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt056));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt01d));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt012));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt051));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtcc1));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtcc2));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtce2));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt005));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtcnd1));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtcnd2));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt010));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt0b9));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmt053));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.cmtc42));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.c42desc));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.rsv1));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.rsv2));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.rsv3));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.rsv4));
			dbbind(dbproc, 26, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_btblcmt301.rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			memcpy(pcmt301, &wd_btblcmt301, sizeof(wd_btblcmt301));
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT311C47046(struct wd_btblcmt311_area * pcmt311)
{
	RETCODE	ret;
	int		i;
	char    sSql[1024];
	
	memset(sSql,0,sizeof(sSql));
	sprintf(sSql,"select * from Btblcmt311 where cmt046 = '%s' and "
		"cmtc47 = '%s'",pcmt311->cmt046,pcmt311->cmtc47);
	dbfcmd(dbproc, sSql);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmtc47));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmt051));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmtcc1));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmtce2));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmt046));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmt72a));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->cmtc42));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->c42desc));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->rsv1));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->rsv2));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->rsv3));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->rsv4));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt311->rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT31330A52AC47(struct wd_btblcmt313_area * pcmt313)
{
	RETCODE	ret;
	int		i;
	char    sSql[1024];
	
	memset(sSql,0,sizeof(sSql));
	sprintf(sSql,"select * from Btblcmt313 where cmt30a = '%s' and "
		"cmt52a = '%s' and cmtc47='%s' ",pcmt313->cmt30a,pcmt313->cmt52a,
		pcmt313->cmtc47);
	dbfcmd(dbproc, sSql);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt52a));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt011));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt010));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmtc47));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt58a));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt012));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt0b9));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt051));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmtce2));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt005));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmtcnd1));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmtcnd2));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmt72a));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->cmtc42));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->c42desc));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->rsv1));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->rsv2));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->rsv3));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->rsv4));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt313->rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindCMT109By30ACG10BC(struct wd_btblcmt109_area * pcmt109)
{
	RETCODE	ret;
	int		i;
	char    sSql[1024];
	
	memset(sSql,0,sizeof(sSql));
	sprintf(sSql,"select * from Btblcmt109 where cmt30a = '%s' and "
		"cmtcg1 = '%s' and cmt0bc='%s' ",pcmt109->cmt30a,pcmt109->cmtcg1,
		pcmt109->cmt0bc);
	dbfcmd(dbproc, sSql);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cls_ssn));
			dbbind(dbproc, 2, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->type));
			dbbind(dbproc, 3, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->recdate));
			dbbind(dbproc, 4, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt30a));
			dbbind(dbproc, 5, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt32a1));
			dbbind(dbproc, 6, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt32a2));
			dbbind(dbproc, 7, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt011));
			dbbind(dbproc, 8, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg1));
			dbbind(dbproc, 9, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg2));
			dbbind(dbproc, 10, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg3));
			dbbind(dbproc, 11, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt012));
			dbbind(dbproc, 12, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg4));
			dbbind(dbproc, 13, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg5));
			dbbind(dbproc, 14, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg6));
			dbbind(dbproc, 15, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt0bc));
			dbbind(dbproc, 16, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt010));
			dbbind(dbproc, 17, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmt0b9));
			dbbind(dbproc, 18, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtcg7));
			dbbind(dbproc, 19, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->cmtc42));
			dbbind(dbproc, 20, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->c42desc));
			dbbind(dbproc, 21, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv1));
			dbbind(dbproc, 22, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv2));
			dbbind(dbproc, 23, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv3));
			dbbind(dbproc, 24, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv4));
			dbbind(dbproc, 25, CHARBIND, (DBINT)0, 
				(BYTE *)(pcmt109->rsv5));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nNewSwfMsgSeqWithoutToctl(char *sSwfMsgSeq)
{
	struct wd_bseqctl_area wd_bseqctl;
    int iSEQ;
    int iLen;
    char sSEQ[12+1];
    char sPat[10];

	memset(&wd_bseqctl, 0, sizeof(wd_bseqctl));
	memcpy(wd_bseqctl.rcd_id, SEQCTL_RCD_ID_SWIFTMSG, 
		sizeof(wd_bseqctl.rcd_id) - 1);

	if(DbsBSEQCTL(DBS_LOCK, &wd_bseqctl) != 0)
	{
		return -1;
	}

    iSEQ = wd_bseqctl.sn_next_apply;
    iLen = wd_bseqctl.sn_len;
    sprintf(sPat, "%%0%dd", wd_bseqctl.sn_len);
    sprintf(sSEQ, sPat, wd_bseqctl.sn_next_apply);
    if (iSEQ == wd_bseqctl.sn_max)
    	wd_bseqctl.sn_next_apply = wd_bseqctl.sn_min;
    else
        wd_bseqctl.sn_next_apply = wd_bseqctl.sn_next_apply + 1;
    CommonGetCurrentTimeDB(wd_bseqctl.rec_updt_time);

	if(DbsBSEQCTL(DBS_UPDATE, &wd_bseqctl) != 0)
	{
		DbsBSEQCTL(DBS_CLOSE, &wd_bseqctl);
		return -2;
	}

	if(DbsBSEQCTL(DBS_CLOSE, &wd_bseqctl) != 0)
	{
		return -3;
	}

	memcpy(sSwfMsgSeq, sSEQ, iLen);
	return 0;
}

short nKeepAccountTemplate(char *sAccount, char cType, char *sName, char *sBank, char *sRemarks1, char *sRemarks2)
{
	struct wd_bacctmpl_area wd_bacctmpl;
	char sAccountTemp[60];

	if (strlen(sAccount) >= sizeof(wd_bacctmpl.actno))
		return -1;

	/* delete old record, whether it is existed or not */
	memset(&wd_bacctmpl, 0, sizeof(wd_bacctmpl));
	memset(sAccountTemp, 0, sizeof(sAccountTemp));
	memset(sAccountTemp, ' ', sizeof(wd_bacctmpl.actno)-1);
	memcpy(sAccountTemp, sAccount, strlen(sAccount));
	memcpy(wd_bacctmpl.actno, sAccountTemp, strlen(sAccountTemp));
	wd_bacctmpl.type[0] = cType;
	DbsBACCTMPL(DBS_IDEL, &wd_bacctmpl);

	/* insert new record */
	memset(&wd_bacctmpl, 0, sizeof(wd_bacctmpl));
	memcpy(wd_bacctmpl.actno, sAccount, sizeof(wd_bacctmpl.actno)-1);
	wd_bacctmpl.type[0] = cType;
	memcpy(wd_bacctmpl.name, sName, sizeof(wd_bacctmpl.name)-1);
	memcpy(wd_bacctmpl.bankno, sBank, sizeof(wd_bacctmpl.bankno)-1);
	memcpy(wd_bacctmpl.remarks1, sRemarks1, sizeof(wd_bacctmpl.remarks1)-1);
	memcpy(wd_bacctmpl.remarks2, sRemarks2, sizeof(wd_bacctmpl.remarks2)-1);
	CommonGetCurrentTimeDB(wd_bacctmpl.rec_updt_time);
	DbsBACCTMPL(DBS_INSERT, &wd_bacctmpl);

	return 0;
}

int nUpdateOriginalPaytxnlogQueueCancel(char *sSender, char *sRefno, 
char *sWorkDate)
{
	RETCODE	ret;

	char	sInSender[12+1];
	char	sInRefno[8+1];
	char	sInWorkDate[8+1];

	memset(sInSender, 0, sizeof(sInSender));
	memset(sInRefno, 0, sizeof(sInRefno));
	memset(sInWorkDate, 0, sizeof(sInWorkDate));
	memcpy(sInSender, sSender, sizeof(sInSender) - 1);
	memcpy(sInRefno, sRefno, sizeof(sInRefno) - 1);
	memcpy(sInWorkDate, sWorkDate, sizeof(sInWorkDate) - 1);

	dbfcmd(dbproc, "update BPAYTXNLOG ");
	dbfcmd(dbproc, "set p_status = '%c' ", BPAYTXNLOG_STATUS_QUEUECAN);
	dbfcmd(dbproc, "where p_refno = '%s' ", sInRefno);
	dbfcmd(dbproc, "and p_sender = '%s' ", sInSender);
	dbfcmd(dbproc, "and p_work_date = '%s' ", sInWorkDate);
	dbfcmd(dbproc, "and p_status = '%c' ", BPAYTXNLOG_STATUS_QUEUE);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			return 0;
		}
		else
		{
			return -1;
		}
	}
	return -1;
}

int nUpdateOriginalPaytxnlogErrorByMBFE(char *sRefno, char *sWorkDate)
{
	RETCODE	ret;

	char	sInRefno[8+1];
	char	sInWorkDate[8+1];

	memset(sInRefno, 0, sizeof(sInRefno));
	memset(sInWorkDate, 0, sizeof(sInWorkDate));
	memcpy(sInRefno, sRefno, sizeof(sInRefno) - 1);
	memcpy(sInWorkDate, sWorkDate, sizeof(sInWorkDate) - 1);

	dbfcmd(dbproc, "update BPAYTXNLOG ");
	dbfcmd(dbproc, "set p_status = '%c' ", BPAYTXNLOG_STATUS_ERROR);
	dbfcmd(dbproc, "where p_refno = '%s' ", sInRefno);
	dbfcmd(dbproc, "and p_io_flag = '%c' ", BPAYTXNLOG_IO_FLAG_OUTGOING);
	dbfcmd(dbproc, "and p_work_date = '%s' ", sInWorkDate);
	dbfcmd(dbproc, "and p_status = '%c' ", BPAYTXNLOG_STATUS_UNSETTLE);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			return 0;
		}
		else
		{
			return -1;
		}
	}
	return -1;
}

int nFindOriginalPaytxnlogByRefnoEFT_2_Total(char *sRefnoEFT, char *sValueDate, 
int *pnTotal)
{
	RETCODE	ret;
	int		i;

	char	sInRefnoEFT[16+1];
	char	sInValueDate[8+1];
	int		nCount;

	memset(sInRefnoEFT, 0, sizeof(sInRefnoEFT));
	memset(sInValueDate, 0, sizeof(sInValueDate));
	nCount = 0;

	memcpy(sInRefnoEFT, sRefnoEFT, sizeof(sInRefnoEFT) - 1);
	memcpy(sInValueDate, sValueDate, sizeof(sInValueDate) - 1);

	dbfcmd(dbproc, "select count(*) ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_refno_eft = '%s' ", sInRefnoEFT);
	dbfcmd(dbproc, "and p_value_date = '%s' ", sInValueDate);

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, INTBIND, (DBINT)0, (BYTE *)&(nCount));

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			*pnTotal = nCount;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

int nFindOriginalPaytxnlogByRefnoEFT_2_Success(char *sRefnoEFT, char *sValueDate, int *pnSuccess)
{
	RETCODE	ret;
	int		i;

	char	sInRefnoEFT[16+1];
	char	sInValueDate[8+1];
	int		nCount;

	memset(sInRefnoEFT, 0, sizeof(sInRefnoEFT));
	memset(sInValueDate, 0, sizeof(sInValueDate));
	nCount = 0;

	memcpy(sInRefnoEFT, sRefnoEFT, sizeof(sInRefnoEFT) - 1);
	memcpy(sInValueDate, sValueDate, sizeof(sInValueDate) - 1);

	dbfcmd(dbproc, "select count(*) ");
	dbfcmd(dbproc, "from BPAYTXNLOG ");
	dbfcmd(dbproc, "where p_refno_eft = '%s' ", sInRefnoEFT);
	dbfcmd(dbproc, "and p_value_date = '%s' ", sInValueDate);
	dbfcmd(dbproc, "and p_status = '1' ");

	dbsqlexec(dbproc);
	i = 0;
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, INTBIND, (DBINT)0, (BYTE *)&(nCount));

			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;

			*pnSuccess = nCount;
			return 0;
		}
		else
		{
			break;
		}
	}
	return -1;
}

