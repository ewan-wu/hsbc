/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: HexZeroOpr.c                                                */
/* DESCRIPTIONS: The common routines for string encode/decode                */
/* DESCRIPTIONS: The common routines for 16 TO 8 and 8 TO 16                 */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-02-26  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/
/*
#include "cplusplus.h"
*/

void HexZeroEncode(short nInBufLen, unsigned char *sInBuf, 
			  short *nOutBufLen, unsigned char *sOutBuf)
{
	short i,j;

	i = 0; j = 0;
	while (i < nInBufLen)
	{
		if (sInBuf[i] == (unsigned char)0x00)
		{
			sOutBuf[j] = 0xa1;
			j++;
			sOutBuf[j] = 0x01;
		}
		else if (sInBuf[i] == (unsigned char)0xa1)
		{
			sOutBuf[j] = 0xa1;
			j++;
			sOutBuf[j] = 0x02;
		}
		else
			sOutBuf[j] = sInBuf[i];
		i ++; j ++;
	}
	*nOutBufLen = j;
}

void HexZeroDecode(short nInBufLen, unsigned char *sInBuf, 
			  short *nOutBufLen, unsigned char *sOutBuf)
{
	short i,j;

	i = 0; j = 0;
	while (i < nInBufLen)
	{
		if ( (sInBuf[i] == (unsigned char)0xa1) &&
			 (sInBuf[i+1] == (unsigned char)0x01) )
		{
			i ++;
			sOutBuf[j] = 0x00;
		}
		else if ( (sInBuf[i] == (unsigned char)0xa1) &&
				  (sInBuf[i+1] == (unsigned char)0x02) )
		{
			i ++;
			sOutBuf[j] = 0xa1;
		}
		else
			sOutBuf[j] = sInBuf[i];
		i ++; j ++;
	}
	*nOutBufLen = j;
}

/*void Transfer8To16( char * MsgIn , char * MsgOut )
{
	int i = 0;
	for ( i=0;i<8;i++)
	{
		sprintf( &MsgOut[i*2] , "%02X" , (unsigned char)MsgIn[i] );
	}
	return;
}
*/
/*void Transfer16To8( char *MsgIn , char *MsgOut )
{
	int i, j;
	int nFirst, nSecond;
	for (i=0,j=0;i<8,j<16;i++,j++)
	{
		if ((nFirst  = MsgIn[j]   - '0' ) > 9 )
			nFirst  -= 7;
		if ((nSecond = MsgIn[++j] - '0' ) > 9 )
			nSecond -= 7;
		MsgOut[i] = (unsigned char )( nFirst*16 + nSecond );
	}
	return;
}
*/
