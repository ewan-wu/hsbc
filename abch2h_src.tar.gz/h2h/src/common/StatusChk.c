/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: StatusChk.pc                                                */
/* DESCRIPTIONS: The common routines for status checking and set,            */
/*               including                                                   */
/*               ChkSysStatus         -- check status in table BSYSCTL       */
/*               SetSysStatus         -- set status in table BSYSCTL         */
/*               GetCurHstStlmDate    -- get current host settlement date    */
/*               GetLstHstStlmDate    -- get last host settlement date       */
/*               SetHstStlmDate       -- set host settlement date            */
/*               ChkLineStatus        -- check line status in table BLINECTL */
/*               SetLineStatus        -- set line status in table BLINECTL   */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2003-09-18  Jin, Laura     SYBASE Version                                 */
/*****************************************************************************/

#include <stdio.h>
#include <sybfront.h>
#include <sybdb.h>

#include <stdlib.h>
#include "sysdef.h"
#include "status.h"
#include "wd_incl.h"
#include "cplusplus.h"

extern DBPROCESS *dbproc;

extern int GetProfileString(char * pszSection, char * pszEntry, 
                     char * pszDestination, int cbReturnBuf, char * pszFileName);

/*****************************************************************************/
/* FUNC:   short ChkSysStatus (short nChkType, short *pnStatus);             */
/* INPUT:  nChkType       -- check conditions                                */
/* OUTPUT: pnStatus       -- check return status                             */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Check status in table BSYSCTL.                                    */
/*****************************************************************************/
short ChkSysStatus(short nChkType, short *pnStatus)
{
	RETCODE ret;
	int i;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));

	if (-1 == GetProfileString(	"GENERAL",
								"SYS_RECORD_ID",
								wd_bsysctl.rcd_id,
								sizeof(wd_bsysctl.rcd_id),
								getenv("TOPCFG")))
	{
    	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
			sizeof(wd_bsysctl.rcd_id) - 1);
	}
	wd_bsysctl.rcd_id[sizeof(wd_bsysctl.rcd_id) - 1] = 0;

	i = 0;
	ret = SUCCEED;
    switch (nChkType)
    {
        case CHK_STATUS:
			dbfcmd(dbproc, "select sys_status from BSYSCTL ");
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
						(BYTE *)(wd_bsysctl.sys_status));
					while (dbnextrow(dbproc) != NO_MORE_ROWS)
					{
						i++;
					}
					if (i < 1) return -1;
    				*pnStatus = atoi(wd_bsysctl.sys_status);
					return 0;
				}
			}
			return -1;
            
        case CHK_HST_STATUS:
			dbfcmd(dbproc, "select eft_status from BSYSCTL ");
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
						(BYTE *)(wd_bsysctl.eft_status));
					while (dbnextrow(dbproc) != NO_MORE_ROWS)
					{
						i++;
					}
					if (i < 1) return -1;
    				*pnStatus = atoi(wd_bsysctl.eft_status);
					return 0;
				}
			}
			return -1;
            
        case CHK_CNAPS_STATUS:
			dbfcmd(dbproc, "select cnaps_status from BSYSCTL ");
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
						(BYTE *)(wd_bsysctl.cnaps_status));
					while (dbnextrow(dbproc) != NO_MORE_ROWS)
					{
						i++;
					}
					if (i < 1) return -1;
    				*pnStatus = atoi(wd_bsysctl.cnaps_status);
					return 0;
				}
			}
			return -1;
            
        case CHK_CNAPS_SIGN:
			dbfcmd(dbproc, "select cnaps_sign from BSYSCTL ");
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
						(BYTE *)(wd_bsysctl.cnaps_sign));
					while (dbnextrow(dbproc) != NO_MORE_ROWS)
					{
						i++;
					}
					if (i < 1) return -1;
    				*pnStatus = atoi(wd_bsysctl.cnaps_sign);
					return 0;
				}
			}
			return -1;
            
        default: return -1;
    }
	/*
    return 0;
	*/
}

/*****************************************************************************/
/* FUNC:   short SetSysStatus (short nSetType, short nStatus);               */
/* INPUT:  nSetType       -- set conditions                                  */
/*         nStatus        -- set status                                      */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Set status in table BSYSCTL.                                      */
/*****************************************************************************/
short SetSysStatus(short nSetType, short nStatus)
{
	RETCODE ret;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));

	if (-1 == GetProfileString(	"GENERAL",
								"SYS_RECORD_ID",
								wd_bsysctl.rcd_id,
								sizeof(wd_bsysctl.rcd_id),
								getenv("TOPCFG")))
	{
    	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
			sizeof(wd_bsysctl.rcd_id) - 1);
	}
	wd_bsysctl.rcd_id[sizeof(wd_bsysctl.rcd_id) - 1] = 0;

    switch (nSetType)
    {
        case SET_STATUS:
			wd_bsysctl.sys_status[0] = nStatus + '0';
			wd_bsysctl.sys_status[1] = 0;

			dbfcmd(dbproc, "update BSYSCTL set ");
			dbfcmd(dbproc, "sys_status = '%s' ", wd_bsysctl.sys_status);
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					return 0;
				}
			}
			return -1;

        case SET_HST_STATUS:
			wd_bsysctl.eft_status[0] = nStatus + '0';
			wd_bsysctl.eft_status[1] = 0;

			dbfcmd(dbproc, "update BSYSCTL set ");
			dbfcmd(dbproc, "eft_status = '%s' ", wd_bsysctl.eft_status);
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					return 0;
				}
			}
			return -1;

        case SET_CNAPS_STATUS:
			sprintf(wd_bsysctl.cnaps_status, "%2d", nStatus);

			dbfcmd(dbproc, "update BSYSCTL set ");
			dbfcmd(dbproc, "cnaps_status = '%s' ", wd_bsysctl.cnaps_status);
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					return 0;
				}
			}
			return -1;

        case SET_CNAPS_SIGN:
			wd_bsysctl.cnaps_sign[0] = nStatus + '0';
			wd_bsysctl.cnaps_sign[1] = 0;

			dbfcmd(dbproc, "update BSYSCTL set ");
			dbfcmd(dbproc, "cnaps_sign = '%s' ", wd_bsysctl.cnaps_sign);
			dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
			dbsqlexec(dbproc);

			while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
			{
				if (ret == SUCCEED)
				{
					return 0;
				}
			}
			return -1;

        default: return -1;
    }
	/*
    return 0;
	*/
}

/*****************************************************************************/
/* FUNC:   short GetCurHstStlmDate (char *psCurHstStlmDate);                 */
/* INPUT:  <none>                                                            */
/* OUTPUT: psCurHstStlmDate  -- return the current host settlement date      */
/* RETURN: 0                 -- success                                      */
/*         -1                -- failure                                      */
/* DESC:   Get current host settlement date from table BSYSCTL.              */
/*****************************************************************************/
short GetCurHstStlmDate(char *psCurHstStlmDate)
{
	RETCODE ret;
	int i ;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));

	if (-1 == GetProfileString(	"GENERAL",
								"SYS_RECORD_ID",
								wd_bsysctl.rcd_id,
								sizeof(wd_bsysctl.rcd_id),
								getenv("TOPCFG")))
	{
    	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
			sizeof(wd_bsysctl.rcd_id) - 1);
	}
	wd_bsysctl.rcd_id[sizeof(wd_bsysctl.rcd_id) - 1] = 0;

	i = 0;
	ret = SUCCEED;
	dbfcmd(dbproc, "select work_date from BSYSCTL ");
	dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
	dbsqlexec(dbproc);

	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_bsysctl.work_date));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
    		memcpy(&psCurHstStlmDate[0], wd_bsysctl.work_date, 
           		sizeof(wd_bsysctl.work_date) - 1);
			return 0;
		}
	}
	return -1;
}

/*****************************************************************************/
/* FUNC:   short GetLstHstStlmDate (char *psLstHstStlmDate);                 */
/* INPUT:  <none>                                                            */
/* OUTPUT: psLstHstStlmDate  -- return the last host settlement date         */
/* RETURN: 0                 -- success                                      */
/*         -1                -- failure                                      */
/* DESC:   Get last host settlement date from table BSYSCTL.                 */
/*****************************************************************************/
short GetLstHstStlmDate(char *psLstHstStlmDate)
{
	RETCODE ret;
	int i;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));

	if (-1 == GetProfileString(	"GENERAL",
								"SYS_RECORD_ID",
								wd_bsysctl.rcd_id,
								sizeof(wd_bsysctl.rcd_id),
								getenv("TOPCFG")))
	{
    	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
			sizeof(wd_bsysctl.rcd_id) - 1);
	}
	wd_bsysctl.rcd_id[sizeof(wd_bsysctl.rcd_id) - 1] = 0;

	i = 0;
	ret = SUCCEED;
	dbfcmd(dbproc, "select last_work_date from BSYSCTL ");
	dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
	dbsqlexec(dbproc);

	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_bsysctl.last_work_date));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
 		  	memcpy(&psLstHstStlmDate[0], wd_bsysctl.last_work_date, 
       		    sizeof(wd_bsysctl.last_work_date) - 1);
			return 0;
		}
	}
	return -1;
}

/*****************************************************************************/
/* FUNC:   short SetHstStlmDate (char *psHstStlmDate);                       */
/* INPUT:  psHstStlmDate     -- the current host settlement date             */
/* OUTPUT: <none>                                                            */
/* RETURN: 0                 -- success                                      */
/*         -1                -- failure                                      */
/* DESC:   Set the current host date of BSYSCTL, and                         */
/*         move the original to the last host date of BSYSCTL.               */
/*****************************************************************************/
short SetHstStlmDate(char *psHstStlmDate)
{
	RETCODE ret;
	struct wd_bsysctl_area wd_bsysctl;

	memset(&wd_bsysctl, 0, sizeof(wd_bsysctl));

	if (-1 == GetProfileString(	"GENERAL",
								"SYS_RECORD_ID",
								wd_bsysctl.rcd_id,
								sizeof(wd_bsysctl.rcd_id),
								getenv("TOPCFG")))
	{
    	memcpy(wd_bsysctl.rcd_id, SYS_RECORD_ID, 
			sizeof(wd_bsysctl.rcd_id) - 1);
	}
	wd_bsysctl.rcd_id[sizeof(wd_bsysctl.rcd_id) - 1] = 0;

	/* change last date */
	dbfcmd(dbproc, "update BSYSCTL set ");
	dbfcmd(dbproc, "last_work_date = work_date ");
	dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
	dbsqlexec(dbproc);

	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret != SUCCEED)
		{
			return -1;
		}
	}

	/* set current date */
	memcpy(wd_bsysctl.work_date, psHstStlmDate, 
		sizeof(wd_bsysctl.work_date) - 1);
	dbfcmd(dbproc, "update BSYSCTL set ");
	dbfcmd(dbproc, "work_date = '%s' ", wd_bsysctl.work_date);
	dbfcmd(dbproc, "where rcd_id = '%s' ", wd_bsysctl.rcd_id);
	dbsqlexec(dbproc);

	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret != SUCCEED)
		{
			return -1;
		}
	}
	return 0;
}

/*****************************************************************************/
/* FUNC:   short ChkLineStatus (long nLineCode, short *pnStatus);           */
/* INPUT:  nLineCode      -- the line_code of the checked line               */
/* OUTPUT: pnStatus       -- check return status                             */
/*                           0: status off                                   */
/*                           1: status on                                    */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Check line status in table BLINECTL.                              */
/*****************************************************************************/
short ChkLineStatus(long nLineCode, short *pnStatus)
{
	RETCODE ret;
	int i;
	struct wd_blinectl_area wd_blinectl;

	memset(&wd_blinectl, 0, sizeof(wd_blinectl));
    wd_blinectl.line_code = (int)nLineCode;

	i = 0;
	ret = SUCCEED;
	dbfcmd(dbproc, "select line_status from BLINECTL ");
	dbfcmd(dbproc, "where line_code = %d ", wd_blinectl.line_code);

	dbsqlexec(dbproc);
	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			dbbind(dbproc, 1, CHARBIND, (DBINT)0, 
				(BYTE *)(wd_blinectl.line_status));
			while (dbnextrow(dbproc) != NO_MORE_ROWS)
			{
				i++;
			}
			if (i < 1) return -1;
    		*pnStatus = atoi(wd_blinectl.line_status);
			return 0;
		}
	}
	return -1;
}

/*****************************************************************************/
/* FUNC:   short SetLineStatus (long nLineCode, short nStatus);             */
/* INPUT:  nLineCode      -- the line_code of the set line                   */
/*         nStatus        -- set status                                      */
/*                           0: status off                                   */
/*                           1: status on                                    */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Set line status in table BLINECTL.                                */
/*****************************************************************************/
short SetLineStatus(long nLineCode, short nStatus)
{
	RETCODE ret;
	struct wd_blinectl_area wd_blinectl;

	memset(&wd_blinectl, 0, sizeof(wd_blinectl));
    wd_blinectl.line_code = (int)nLineCode;
	wd_blinectl.line_status[0] = nStatus + '0';
	wd_blinectl.line_status[1] = 0;

	dbfcmd(dbproc, "update BLINECTL set ");
	dbfcmd(dbproc, "line_status = '%s' ", wd_blinectl.line_status);
	dbfcmd(dbproc, "where line_code = %d ", wd_blinectl.line_code);
	dbsqlexec(dbproc);

	while ((ret = dbresults(dbproc)) != NO_MORE_RESULTS)
	{
		if (ret == SUCCEED)
		{
			return 0;
		}
	}
	return -1;
}


