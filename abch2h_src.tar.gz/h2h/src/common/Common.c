/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: Common.c                                                    */
/* DESCRIPTIONS: The common routines, including                              */
/*               CommonGetCurrentTime -- Get the system time by format       */
/*                                       (YYYYMMDDHHMMSS)                    */
/*               CommonGetCurrentDate -- Get the system date by format       */
/*                                       (YYYYMMDD)                          */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <sys/timeb.h>

#include "glb_def.h"

#define MAX_BUF     36

static struct timeb inittime, starttime, endtime;

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentDate (char *sCurrentDate);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentDate   -- the string of current date                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system date with the format (YYYYMMDD).                   */
/*****************************************************************************/
void  CommonGetCurrentDate(char *sCurrentDate)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
/*
   _tzset();
*/
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentDate, "%4d%02d%02d", tmCurrentTime->tm_year + 1900, 
           tmCurrentTime->tm_mon + 1, tmCurrentTime->tm_mday);
}

/*****************************************************************************/
/* FUNC:   void CommonGetCurrentTime (char *sCurrentTime);                   */
/* INPUT:  <none>                                                            */
/* OUTPUT: sCurrentTime   -- the string of current time                      */
/* RETURN: <none>                                                            */
/* DESC:   Get the system time with the format (YYYYMMDDhhmmss).             */
/*****************************************************************************/
void CommonGetCurrentTime(char *sCurrentTime)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d%02d%02d%02d%02d%02d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}

void CommonGetCurrentTimeDB(char *sCurrentTime)
{  
   time_t current;
   struct tm *tmCurrentTime;
   
   tzset();
   time(&current);
   tmCurrentTime = localtime(&current);
   sprintf(sCurrentTime, "%4d/%02d/%02d %02d:%02d:%02d", 
           tmCurrentTime->tm_year + 1900, tmCurrentTime->tm_mon + 1, 
           tmCurrentTime->tm_mday, tmCurrentTime->tm_hour,
           tmCurrentTime->tm_min, tmCurrentTime->tm_sec);
}


/* from Comm1.c */
char *GetSystemTime(void)
{
   time_t current;
   struct tm *tmCurrentTime;
   char stime[30];

   memset(stime, 0, sizeof(stime));

   time(&current);
   tmCurrentTime = localtime(&current);

   sprintf(stime, "%04d-%02d-%02d %02d:%02d:%02d",
                1900 + tmCurrentTime->tm_year,
                tmCurrentTime->tm_mon+1,
                tmCurrentTime->tm_mday,
                tmCurrentTime->tm_hour,
                tmCurrentTime->tm_min ,
                tmCurrentTime->tm_sec );

   return stime;


}

char *GetCurTime(void)
{
	long tt;
	time(&tt);
	return((char *)ctime(&tt));
}

int CommonInterval(const char *date1, const char *date2)
{
    char year[5], month[3], day[3];
    struct tm   time1, time2;
    time_t	time_1, time_2;

    memset(year, 0, sizeof(year));
    memset(month, 0, sizeof(month));
    memset(day, 0, sizeof(day));

    /* make up date 1 */
    memcpy(year, date1, 4);
    memcpy(month, date1 + 4, 2);
    memcpy(day, date1 + 6, 2);
    time1.tm_year  = atoi(year) - 1900;
    time1.tm_mon   = atoi(month) - 1;
    time1.tm_mday  = atoi(day);
    time1.tm_hour  = 0;
    time1.tm_min   = 0;
    time1.tm_sec   = 1;
    time1.tm_isdst = -1;

    if ((time_1 = mktime(&time1)) == -1)
    {
		/* date format error */
		return -1;
    }

    /* make up date 2 */
    memcpy(year, date2, 4);
    memcpy(month, date2 + 4, 2);
    memcpy(day, date2 + 6, 2);

    time2.tm_year  = atoi(year) - 1900;
    time2.tm_mon   = atoi(month) - 1;
    time2.tm_mday  = atoi(day);
    time2.tm_hour  = 0;
    time2.tm_min   = 0;
    time2.tm_sec   = 1;
    time2.tm_isdst = -1;

    if ((time_2 = mktime(&time2)) == -1)
    {
		/* date format error */
		return -1;
    }

    /* calculate interval */
    return abs((int)(difftime(time_1, time_2) / 24 / 60 / 60));
}

void SetTimeStart(char *sDesc)
{
	ftime(&inittime);
	memcpy(&starttime, &inittime, sizeof(inittime));
	printf("Time Begin [%s]\n",sDesc );
}

void GetTimeDiff(char *sDesc)
{
	ftime(&endtime);
	printf("Time Middle [%s], Diff in sec[%d] misec[%d]\n",sDesc,
		endtime.time - starttime.time, endtime.millitm - starttime.millitm);
	memcpy(&starttime, &endtime, sizeof(endtime));
}

void GetTimeTotal(char *sDesc)
{
	ftime(&endtime);
	printf("Time End [%s], Diff in sec[%d] misec[%d]\n",
		sDesc, endtime.time - inittime.time,
		endtime.millitm - inittime.millitm );
}

/******************************************************************************/
/*  Function     : apitoa()                                                   */
/*  Description  : convert integer data into string without '\0' terminated   */
/*  Arguments    : inum - input integer data                                  */
/*                 len - required length to convert                           */
/*                 obuf - string without 0x00 terminated                      */
/*  Return Value : void                                                       */
/******************************************************************************/
void apitoa(int inum, int len, char *obuf)
{
    char    temp[50];
    char    fmt[10];

    sprintf(fmt, "%%0%dld", len);
    sprintf(temp, fmt, inum);
    memcpy(obuf, temp, len);
}

/******************************************************************************/
/*  Function     : apatoi()                                                   */
/*  Description  : convert ascii buffer into integer value with input length  */
/*  Arguments    : ibuf - input ascii buffer                                  */
/*                 len - required length to convert                           */
/*  Return Value : integer value                                              */
/******************************************************************************/
int apatoi(char *ibuf, int len)
{
    char    temp[16];

    memset(temp, '\0', sizeof(temp));
    memcpy(temp, ibuf, len);
    return(atoi(temp));
}

/******************************************************************************/
/*  Function     : str2dbl()                                                  */
/*  Description  : convert ascii buffer into double value with input length   */
/*                 and precision                                              */
/*  Arguments    : ibuf - input ascii buffer                                  */
/*                 ibuflen - require length to convert                        */
/*                 idot - dot position                                        */
/*                 obuf - pointer to double value                             */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int str2dbl(char *ibuf, short ibuflen, short idot, double *obuf)
{
    char    lstrbuf[MAX_BUF];
    short   i;

    if(strlen(ibuf) < ibuflen)
        return SYS_FAIL;

    if(strlen(ibuf) < idot)
        return SYS_FAIL;

    if(ibuflen < idot)
        return SYS_FAIL;

    for(i = 0; i < ibuflen+1; i ++)
    {
        if(i == (ibuflen - idot))
            lstrbuf[i] = '.';
        else
            lstrbuf[i] = *ibuf++;
    }

    lstrbuf[i] = '\0';

    *obuf = atof(lstrbuf);

    return SYS_OK;
}

/******************************************************************************/
/*  Function     : dbl2str()                                                  */
/*  Description  : convert double data to string without '\0' terminated      */
/*  Arguments    : idbl - pointer to double data                              */
/*                 idot - dot position                                        */
/*                 ilen - required length to convert                          */
/*                 isign - set to 1 if '+/-' sign needed                      */
/*                 obuf - output buffer                                       */
/*  Return Value : SYS_OK - success                                           */
/*                 SYS_FAIL - fail                                            */
/******************************************************************************/
int dbl2str(double *idbl, short idot, short ilen, short isign, char *obuf)
{
    char    lstrbuf[ MAX_BUF ];
    char    lstrtmp[ MAX_BUF ];
    char    Lstr[ MAX_BUF ];
    char    fmt[10];
    char    *p1;
    double  ldbl;

    /*********** check input data ****************/
    if( idot > ilen )
        return SYS_FAIL;
    /*********** truncate ************************/
    ldbl=*idbl;
    dbltrunc( &ldbl,idot );

    sprintf(fmt,"%%+#0%d.%df",ilen+2,idot);
    sprintf(lstrbuf,fmt,ldbl);
    strcpy(lstrtmp,&lstrbuf[1]);

    if ( isign != 0 )
    {
        strcpy(Lstr,lstrtmp);
        p1=strtok(Lstr,".");
        if ( strlen(p1) > ( ilen - idot - 1 ) )
            memcpy(&lstrbuf[1],&lstrtmp[strlen(p1)-ilen+idot+1],
                ilen-idot);
        else
            strcpy(&lstrbuf[1],p1);
        p1=strtok(NULL,".");
        memcpy(&lstrbuf[ilen-idot],p1,idot);
        if ( *idbl >= 0 )
        {
            /*
            lstrbuf[0]='+';
            */
            lstrbuf[0]=lstrtmp[0];
        }
        else
            lstrbuf[0]='-';
    }
    else
    {
        strcpy(Lstr,lstrtmp);
        p1=strtok(Lstr,".");
        if ( strlen(p1) > ( ilen - idot ) )
            memcpy(lstrbuf,&lstrtmp[strlen(p1)-ilen+idot],
                ilen-idot);
        else
            strcpy(lstrbuf,p1);

        p1=strtok(NULL,".");
        memcpy(&lstrbuf[ilen-idot],p1,idot);
    }
    memcpy(obuf,lstrbuf,ilen);
    return SYS_OK;
}

int dbltrunc(double *ival, int itnclen)
{
    char lstrbuf[ MAX_BUF ];
    char lfmt[ MAX_BUF ];
    int lofset,len;
    double  temp;

    sprintf(lfmt,"%%.%df",itnclen+1);
    sprintf(lstrbuf,lfmt,*ival);
    len=strlen(lstrbuf);
    for(lofset=0; ( lofset < len) && ( lstrbuf[lofset] != '.') ; lofset++);
    if ( itnclen >= 0 )
        memset(&lstrbuf[lofset+itnclen+1],0x00,
            MAX_BUF - (lofset+itnclen+2 ));
    else
    {
        memset(&lstrbuf[lofset+itnclen],'0', itnclen * -1 );
        memset(&lstrbuf[lofset],0x00, MAX_BUF -lofset+1 );
    }
    temp=atof(lstrbuf);
    *ival=temp;
    return SYS_OK;
}


int nStringDelete(char *sBuf, int len, char c1, char c2)
{
	int i, j;
	char sStr[10240];

	if (len <= 0) return 0;

	j = 0;
	memset(sStr, 0, sizeof(sStr));

	for (i=0; i<len; i++)
	{
		if (c1 != '\0')
		{
			if (sBuf[i] == c1)
				continue;
		}
		if (c2 != '\0')
		{
			if (sBuf[i] == c2)
				continue;
		}
		sStr[j] = sBuf[i];
		j++;
	}
	
	memset(sBuf, 0, len);
	if (j == 0)
	{
		return 0;
	}
	else
	{
		memcpy(sBuf, sStr, j);
		return j;
	}
}

int nCHExpatPatch(unsigned char *sBuf, int len)
{
	int i, j;
	unsigned char sStr[10240];

	if (len <= 0) return 0;

	j = 0;
	memset(sStr, 0, sizeof(sStr));

	for (i=0; i<len; i++)
	{
		if ((sBuf[i] != 0xC2) && (sBuf[i] != 0xC3))
		{
			sStr[j] = sBuf[i];
		}
		else
		{
			if (sBuf[i] == 0xC2)
			{
				sStr[j] = sBuf[i+1];
			}
			else /* 0xC3 */
			{
				sStr[j] = sBuf[i+1] + 0x40;
			}
			i++;
		}
		j++;
	}

	memset(sBuf, 0, len);
	if (j == 0)
	{
		return 0;
	}
	else
	{
		memcpy(sBuf, sStr, j);
		return j;
	}
}

/* replace all "c1" with "c2" */
void vStringReplace(char *sBuf, int len, char c1, char c2)
{
	int i;

	if (len <= 0) return;

	for (i=0; i<len; i++)
	{
		if (sBuf[i] == c1)
			sBuf[i] = c2;
	}
	return;
}

