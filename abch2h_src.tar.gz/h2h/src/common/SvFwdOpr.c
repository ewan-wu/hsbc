/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: SvFwdOpr.c                                                  */
/* DESCRIPTIONS: The common routines for SAF table maintain, including       */
/*               SvFwdInst      -- insert a record into table FWDMSG(SAF)    */
/*               SvFwdUpdt      -- update a record in table FWDMSG(SAF)      */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2003-09-28  Jin, Laura     SYBASE Version for DB                          */
/*****************************************************************************/

#include <stdio.h>
/*
#include "cplusplus.h"
*/

#include "wd_incl.h"
#include "forward.h"
#include "glb_def.h"

extern void HexZeroEncode(short nInBufLen, unsigned char *sInBuf, 
			  short *nOutBufLen, unsigned char *sOutBuf);
extern void CommonGetCurrentTimeDB(char *sCurrentTime);
extern short DbsBFWDMSG( int ifunc , struct wd_bfwdmsg_area	*LtpWdBFWDMSG );

/*****************************************************************************/
/* FUNC:   short SvFwdInst (FwdMsgInfDef *ptFwdMsgInf);                        */
/* INPUT:  tFwdMsgInf     -- the FWDMSG information to be inserted           */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Insert a record into SAF table FWDMSG.                            */
/*****************************************************************************/
short SvFwdInst(FwdMsgInfDef *ptFwdMsgInf)
{
	unsigned char sTmpMsg[MAX_FWD_MSG_LEN+256];
	short nTmpMsgLen;
	struct wd_bfwdmsg_area wd_bfwdmsg;

	memset(&wd_bfwdmsg, 0, sizeof(wd_bfwdmsg));

	/* msg_work_date, msg_cls_ssn, msg_refno, msg_sender */
	memcpy(wd_bfwdmsg.msg_work_date, ptFwdMsgInf->sSysWorkDate, 
		sizeof(wd_bfwdmsg.msg_work_date) - 1);
	memcpy(wd_bfwdmsg.msg_cls_ssn, ptFwdMsgInf->sSysClsSsn, 
		sizeof(wd_bfwdmsg.msg_cls_ssn) - 1);
	memcpy(wd_bfwdmsg.msg_refno, ptFwdMsgInf->sRefno, 
		sizeof(wd_bfwdmsg.msg_refno) - 1);
	memcpy(wd_bfwdmsg.msg_sender, ptFwdMsgInf->sSender, 
		sizeof(wd_bfwdmsg.msg_sender) - 1);

	/* msg_type, msg_target, msg_txn_no */
	memcpy(wd_bfwdmsg.msg_type, ptFwdMsgInf->sMsgType, 
		sizeof(wd_bfwdmsg.msg_type) - 1);
	wd_bfwdmsg.msg_target[0] = ptFwdMsgInf->cFwdTarget;
	wd_bfwdmsg.msg_txn_no = ptFwdMsgInf->nTxnNumber;

	/* msg_localtime, rec_updt_time, memo */
	CommonGetCurrentTimeDB(wd_bfwdmsg.msg_localtime);
	CommonGetCurrentTimeDB(wd_bfwdmsg.rec_updt_time);
	memcpy(wd_bfwdmsg.memo, ptFwdMsgInf->sMemo, 
		sizeof(wd_bfwdmsg.memo) - 1);

	/* msg_snd_cnt */
	if (ptFwdMsgInf->nFwdTimes > 0)
	{
		wd_bfwdmsg.msg_snd_cnt = ptFwdMsgInf->nFwdTimes;
	}
	else
	{
		if (ptFwdMsgInf->nFwdTimes == 0)
		{
			wd_bfwdmsg.msg_snd_cnt = DEFAULT_FWD_TIMES;
		}
		else
		{
			wd_bfwdmsg.msg_snd_cnt = 0;
			CommonGetCurrentTimeDB(wd_bfwdmsg.msg_snd_time);
		}
	}

	/* msg_text_len, msg_text */
    if (ptFwdMsgInf->nTxnMsgLen > MAX_FWD_MSG_LEN)
	{
    	ptFwdMsgInf->nTxnMsgLen = MAX_FWD_MSG_LEN;
	}

	HexZeroEncode ( ptFwdMsgInf->nTxnMsgLen, 
					(unsigned char *)ptFwdMsgInf->sTxnMsg,
					&nTmpMsgLen,
					sTmpMsg);

    if (nTmpMsgLen > MAX_FWD_MSG_LEN)
    	nTmpMsgLen = MAX_FWD_MSG_LEN;

	wd_bfwdmsg.msg_text_len = nTmpMsgLen;
	memcpy(wd_bfwdmsg.msg_text, sTmpMsg, nTmpMsgLen);

	/* insert */
	if (DbsBFWDMSG(DBS_INSERT, &wd_bfwdmsg) != 0)
	{
		return -1;
	}

	return 0;
}

/*****************************************************************************/
/* FUNC:   short SvFwdUpdt (char *sSysSeqNum,                                */
/*                          short nFwdTarget,                                */
/*                          short nFwdTimes,                                 */
/*                          short nTxnMsgLen,                                */
/*                          char *sTxnMsg);                                  */
/* INPUT:  sSysSeqNum     -- the cls_ssn field in table FWDMSG           */
/*         nFwdTarget     -- the forwarding target                           */
/*         nFwdTimes      -- the new forwarding times (if nFwdTimes > 0)     */
/*                           stop forwarding          (if nFwdTimes == 0)    */
/*                           do not change the original forwarding times     */
/*                                                    (if nFwdTimes < 0)     */
/*         nTxnMsgLen     -- the length of new forwarding message            */
/*                                                    (if nTxnMsgLen > 0)    */
/*                           do not change the original forwarding message   */
/*                                                    (if nTxnMsgLen <= 0)   */
/*         sTxnMsg        -- the forwarding message body                     */
/* OUTPUT: <none>                                                            */
/* RETURN: 0              -- success                                         */
/*         -1             -- failure                                         */
/* DESC:   Update a record in SAF table FWDMSG.                              */
/*****************************************************************************/
short SvFwdUpdt(char *sSysWorkDate, char *sSysClsSsn,
				short nFwdTimes, short nTxnMsgLen, char *sTxnMsg)
{
	unsigned char sTmpMsg[MAX_FWD_MSG_LEN+256];
	short nTmpMsgLen;
	struct wd_bfwdmsg_area wd_bfwdmsg;

    if ( (nFwdTimes < 0) && (nTxnMsgLen <= 0) )
        return 0;

	memset(&wd_bfwdmsg, 0, sizeof(wd_bfwdmsg));

    /* fetch the original record */
	memcpy(wd_bfwdmsg.msg_work_date, sSysWorkDate, 
		sizeof(wd_bfwdmsg.msg_work_date) - 1);
	memcpy(wd_bfwdmsg.msg_cls_ssn, sSysClsSsn, 
		sizeof(wd_bfwdmsg.msg_cls_ssn) - 1);

	/* DBS_LOCK */
	if (DbsBFWDMSG(DBS_LOCK, &wd_bfwdmsg) != 0)
	{
		return -1;
	}

    /* prepare updated fields */
    if (nFwdTimes >= 0)
        wd_bfwdmsg.msg_snd_cnt = nFwdTimes;
    if (nTxnMsgLen > 0)
    {
    	if (nTxnMsgLen > MAX_FWD_MSG_LEN)
    		nTxnMsgLen = MAX_FWD_MSG_LEN;
		
		HexZeroEncode ( nTxnMsgLen, 
						(unsigned char *)sTxnMsg,
						&nTmpMsgLen,
						sTmpMsg
						);
				
		if (nTmpMsgLen > MAX_FWD_MSG_LEN)
    		nTmpMsgLen = MAX_FWD_MSG_LEN;
		
		wd_bfwdmsg.msg_text_len = nTmpMsgLen;
		memset(wd_bfwdmsg.msg_text, 0, sizeof(wd_bfwdmsg.msg_text));
		memcpy(wd_bfwdmsg.msg_text, sTmpMsg, nTmpMsgLen);
    }

	if (DbsBFWDMSG(DBS_UPDATE, &wd_bfwdmsg) != 0)
	{
		DbsBFWDMSG(DBS_CLOSE, &wd_bfwdmsg);
		return -1;
	}

	DbsBFWDMSG(DBS_CLOSE, &wd_bfwdmsg);
    return 0;
}

short SvFwdReset(char *sSysWorkDate, char *sSysClsSsn, short nFwdTimes)

{
	return SvFwdUpdt(sSysWorkDate, sSysClsSsn, nFwdTimes, 0, NULL);
}

/*
short SvFwdResetP(long lPktID, short nFwdTimes)
{
	sqlca.sqlcode = 0;
	H_FWDMSG_PKT_ID = lPktID;
	H_FWDMSG_SAF_STAT = nFwdTimes;

	EXEC SQL UPDATE fwdmsg
		SET  saf_stat = :H_FWDMSG_SAF_STAT
		WHERE pkt_id = :H_FWDMSG_PKT_ID;

	return sqlca.sqlcode;
}
*/
