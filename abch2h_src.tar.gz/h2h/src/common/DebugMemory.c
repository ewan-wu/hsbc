/*****************************************************************************/
/*             TOPLINK -- Shanghai Huateng Software System Inc.              */
/*****************************************************************************/
/* PROGRAM NAME: DebugMemory.c                                               */
/* DESCRIPTIONS: The common routines for debug, including                    */
/*               DebugMemory -- Get the memory informaition                  */
/*****************************************************************************/
/*                             MODIFICATION LOG                              */
/* DATE        PROGRAMMER     DESCRIPTION                                    */
/* 2000-01-16  Jin, Laura     Initial Version Creation                       */
/*****************************************************************************/

#include <malloc.h>
/*
#include "cplusplus.h"
*/

/*****************************************************************************/
/* FUNC:   void DebugMemory (char *psDesc);                                  */
/* INPUT:  psDesc      -- a description for the memory information           */
/* OUTPUT: <none>                                                            */
/* RETURN: <none>                                                            */
/* DESC:   Get the memory information.                                       */
/*****************************************************************************/
void DebugMemory( char *psDesc)
{
	struct mallinfo info;
	info = mallinfo();
	printf("%s ----> %d\n", psDesc, info.uordblks);
	/*added 20140417*/
	printf("%s ----> arena:%d\n", psDesc, info.arena);
	printf("%s ----> ordblks:%d\n", psDesc, info.ordblks);
	printf("%s ----> smblks:%d\n", psDesc, info.smblks);
	printf("%s ----> hblks:%d\n", psDesc, info.hblks);
	printf("%s ----> usmblks:%d\n", psDesc, info.usmblks);
	printf("%s ----> fsmblks:%d\n", psDesc, info.fsmblks);
	printf("%s ----> fordblks:%d\n", psDesc, info.fordblks);
	printf("%s ----> keepcost:%d\n", psDesc, info.keepcost);
	/*added 20140417*/
}

