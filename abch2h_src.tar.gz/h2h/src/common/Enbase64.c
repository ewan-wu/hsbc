/************************************************************
*
* Base64 Encoding Source Code
*
* Shanghai Huateng Software Systems Co., Ltd.
*
* All Rights Reserved 
*
* 1998. 11.27
*
* By Alan Wen
*
*************************************************************/
#include <stdio.h>
#include <string.h>

int EncodeBase64(unsigned char*, long, unsigned char*, long*);
int ToBase64(unsigned char*, unsigned char*, int);
int DecodeBase64(unsigned char*, long, unsigned char*, long*);
int FromBase64(unsigned char*, unsigned char*, int*);

unsigned char BASE64_CODE[]={"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"};

/* 
 * EncodeBase64
 * Param: unsigned char* psInData -- IN / Pointer to Original Data buf
 *        long lInDataLen -- IN / Length of Original Data
 *        unsigned char* psOutData -- IN / Pointer to Output Data buf
 *        long* plOutDataLen -- IN / Length of Output Data buf 
 *                              OUT / Length of Base64 Code
 *
 * Return: 0 -- On Successful
 *         -1 -- *plOutDataLen too small
 */
int EncodeBase64(unsigned char* psInData, long lInDataLen, unsigned char* psOutData, long* plOutDataLen)
{
	int i;

	if (*plOutDataLen < lInDataLen/3*4)
	{
		/*
		printf("Base64 Encode overflow! (output buf not enough)\n\n");
		*/
		return -1;
	}
	
	for (i = 0; i < lInDataLen; i += 3)
		ToBase64(&psInData[i], &psOutData[i/3*4], lInDataLen-i-3 >= 0 ? 3 : lInDataLen%3);
	*plOutDataLen = i/3*4;
	
	return 0;
}

/*
 * ToBase64 (Internal used by EncodeBase64)
 * Param: unsigned char psInData[3] -- IN / Pointer to 3 or less chars of Original Data
 *        unsigned char psOutData[4] -- IN / Pointer to 4 char of Encoded Base64 Data
 *        int iLen -- IN / Length of the Original Data, should only be 1, 2, or 3
 *
 * Return: 0 -- On sucess
 *         -1 -- On any error
 */
int ToBase64(unsigned char psInData[3], unsigned char psOutData[4], int iLen)
{
	psOutData[0] = BASE64_CODE[psInData[0] >> 2];
	if (iLen == 1)
	{
		psOutData[1] = BASE64_CODE[psInData[0] << 4 & 0x30];
		psOutData[2] = '=';
		psOutData[3] = '=';
		return 0;
	}
	psOutData[1] = BASE64_CODE[psInData[0] << 4 & 0x30 | psInData[1] >> 4];
	if (iLen == 2)
	{
		psOutData[2] = BASE64_CODE[psInData[1] << 2 & 0x3C];
		psOutData[3] = '=';
		return 0;
	}
	psOutData[2] = BASE64_CODE[psInData[1] << 2 & 0x3C | psInData[2] >> 6];
	psOutData[3] = BASE64_CODE[psInData[2] & 0x3F];

	return 0;
}

/*
 * FromBase64 (Internal used by EncodeBase64)
 * Param: unsigned char szInput[4] -- IN / Original Data
 *        unsigned char szOutput[3] -- IN / Output Data
 *        int* pLen -- OUT / Length of the output data
 *
 * Return: 0 -- On sucess
 *         -1 -- On any error
 */
int FromBase64(unsigned char szInput[4], unsigned char szOutput[3], int* pLen)
{
	unsigned char szBuf[4];
	int i;

	for (i = 0; i < 4; i++)
	{
		if (szInput[i] == '=') 
			szBuf[i] = '\0';
		else
			szBuf[i] = (unsigned char*)strchr((char*)BASE64_CODE, szInput[i]) - BASE64_CODE;
	}

	szOutput[0] = (szBuf[0] << 2) | ((szBuf[1] & 0x30) >> 4);
	szOutput[1] = (szBuf[1] & 0x0f) << 4 | ((szBuf[2] & 0x3c) >> 2);
	szOutput[2] = (szBuf[2] << 6) | (szBuf[3] & 0x3f);

	*pLen = 3;
	if (szInput[2] == '=') (*pLen)--;
	if (szInput[3] == '=') (*pLen)--;
	
	return 0;
}

/* 
 * DecodeBase64
 * Param: unsigned char* szInput -- IN / Pointer to Original Data buf
 *        long lLen -- IN / Length of Original Data
 *        unsigned char* szOutput -- OUT / Output Data goes here
 *        long* plLen -- IN / Length of Output Data buf 
 *                       OUT / Length of Base64 Code
 *
 * Return: 0 -- On Successful
 *         -1 -- On Any Error
 */
int DecodeBase64(unsigned char* szInput, long lLen, unsigned char* szOutput, long* plLen)
{
	int i, iLen;
	unsigned char szBuf[4];
	
	if (*plLen < lLen/4*3)
	{
		/*
		printf("Base64 Decode overflow! (output buf not enough)\n\n");
		*/
		return -1;
	}

	szBuf[3] = '\0';
	szOutput[0] = '\0';

	*plLen = 0;

	for (i = 0; i < lLen; i += 4)
	{
		FromBase64(szInput + i, szBuf, &iLen); 
		memcpy(szOutput + (*plLen), szBuf, iLen);
	
		*plLen += iLen;
	}
	return 0;
}

/*
 * Calling Samples
 */
/*
void main(void)
{
	unsigned char buf[100];
	long Len;
	unsigned char outbuf[150];
	long outLen = 150;
	
	printf("Input the Original Data:");
	scanf("%s", buf);
	EncodeBase64(buf, strlen(buf), outbuf, &outLen);
	printf("After Encode is %s\n", outbuf);
	memset(buf, 0, 100);
	Len = 100;
	DecodeBase64(outbuf, outLen, buf, &Len);
	printf("After Decode is %s\n", buf);
}
*/
