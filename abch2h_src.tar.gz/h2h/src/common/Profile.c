#include "stdio.h"
/*
#include "cplusplus.h"
*/

#define PF_FALSE     0

typedef char * PSTR;

/*extern int GetProfileString(PSTR pszSection, PSTR pszEntry, 
                     PSTR pszDestination, int cbReturnBuf, PSTR pszFileName);
*/

void ClearBlank(char * line)
{
	int i = 0, j, k;
	char buf[256];

	while (line[i] != 0)
	{
		if (line[i] == ';' || line[i] == '\n')
		{
			line[i] = 0;
			/*
			for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); line[j--] = 0);
			*/
			if ( i != 0 )
         	{
            	for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); )
            	{
               		line[j] = 0;
               		if ( j == 0 ) break;
               		j--;
            	}
         	}
			break;
		}	
		i++;
	}
 
	i = 0;
	memset(buf, 0, 256);

	while ((line[i] != '=') && (i < strlen(line))) i++;
	if (i == strlen(line)) return;

	for (j = i - 1; (line[j] == ' ') || (line[j] == '\t'); j--);
	for (k = i + 1; (line[k] == ' ') || (line[k] == '\t'); k++);

	memcpy(buf, line, j + 1);
	buf[j + 1] = '=';
 	strcat(buf + j + 2, line + k);
 
	strcpy(line, buf);
}

int IsSection(char * line)
{
	return line[0] == '[';
}

int IsThisSection(char * line, char * pszSection)
{
	return !memcmp(line + 1, pszSection, strlen(pszSection));
}

int IsThisEntry(char * line, char * pszEntry)
{
	return (!memcmp(line, pszEntry, strlen(pszEntry)) &&
           line[strlen(pszEntry)] == '=') ;
} 

int CutContent(char * line, char * pszDestination, int cbReturnBuf)
{
	int i = 0;

	while (line[i++] != '=');

	strncpy(pszDestination, line + i, cbReturnBuf);

	return 0;
} 

int GetProfileString(PSTR pszSection, PSTR pszEntry, 
                     PSTR pszDestination, int cbReturnBuf, PSTR pszFileName)
{
	FILE * fp;
	char line[256];
	int cbNum = -1;
	int InThisSection = PF_FALSE;
	
	fp = fopen(pszFileName, "r");
	if (fp == NULL) 
	{
		printf("INI file not found!\n");
		return -1;
		/***
		exit(-1);
		***/
	}

	while (NULL !=	fgets(line, 256, fp))
	{
		ClearBlank(line);

		if (IsSection(line))
		{
			InThisSection = IsThisSection(line, pszSection);
			continue;
		}

		if (InThisSection == PF_FALSE) continue;

		if (IsThisEntry(line, pszEntry))
		{
			cbNum = CutContent(line, pszDestination, cbReturnBuf);
			break;
		}
	}

	fclose(fp);

	if (cbNum == -1)
	{
		printf ("Read INI file fail!\n");
		return -1;
		/***
		exit(-1);
		***/
	}

	return cbNum;

}

int GetProfileInt(PSTR pszSection, PSTR pszEntry, PSTR pszFileName)
{
	char buf[256];

	if (GetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
		return (int)atol(buf);
}

long GetProfileLong(PSTR pszSection, PSTR pszEntry, PSTR pszFileName)
{
	char buf[256];

	if (GetProfileString(pszSection, pszEntry, buf, 256, pszFileName) < 0)
		return -1;
	else
		return atol(buf);
}

