#ifndef _BRIDGE_H
#define _BRIDGE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
/*
#include "convert.h"
*/
#include "msgque.h"
#include "msglog.h"
#include "common.h"
#include "status.h"
#include "glb_def.h"
#include "wd_incl.h"
/*
#include "device.h"
#include "txnlen.h"
*/
#include "ipc.h"

#define _LOG
#define _DEBUG

#define STELLER_MAX_CMT_LEN              2000
#define TXNO_FE_CMT_MAX                  4300
#define TXNO_FE_CMT_MIN                  4200

short   InitBridge();
void    vBdgProcess(long,void*); 

#endif
