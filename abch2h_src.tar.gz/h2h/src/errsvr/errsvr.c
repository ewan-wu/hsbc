/*********************************************************************
*	Copyright 2000, Shanghai Huateng Software System Inc.        	 *
*	All rights Reserved.                                         	 *
*                                                                    *
*	This is UNPUBLISHED PROPRIETARY SOURCE CODE of Shanghai      	 *
*	Huateng Software System Inc.; the contents of this file may  	 *
*	not be disclosed to third parties, copied or duplicated in   	 *
*	any form, in whole or in part, without the prior written     	 *
*	permission of Shanghai Huateng Software System Inc.          	 *
*                                                                    *
*********************************************************************/

/*********************************************************************
*	Name	: errsvr.c                                               *
*	Desc	: sytem message report server                            *
*	Author:                                                          *
*	Date	:                                                        *
*	Function: 1. Accept system message from various servers          *
*             2. Send signal to umsctl server                        *
*	Location: $(TOPDIR)/src/errsvr                                   *
*                                                                    *
* 	Modify By:                                                       *
* 	Name    Date			What                                     * 
* 	----	----------	----------------------------------           *
* 	Xutonghui 2003/07/15   initial Version                           *
**********************************************************************/
#include "htlog.h"
#include "errsvr.h"

void vErrProcess(struct wd_bsyslog_area *, pid_t);
void vLineErrorApp(struct wd_bsyslog_area *);

char  sTime[14];
char  logfile[128];

void main(int argc, char **argv)
{
 	int   	len;
 	long  	lReturn;
 	short 	nDataLen,nRet;
	long 	lMsgSource;
 	pid_t 	UmsctlPid;

 	struct
 	{
    	long mtype;
    	struct wd_bsyslog_area buf;
 	} msgerr_buf;

    setbuf(stdout,NULL);    
    setbuf(stderr, NULL);

    if ( argc != 2 )
    {
        fprintf(stdout, "Usage: errsvr < logfile >\n");
        exit(0);
    }

    nRet = GetLogName(argv[1], logfile);
    if (nRet != 0 )
    {
        ErrReport(CI_ERRSVR,
                  EI_PROCESS,
                  0,
                  CI_SEVERITY_SYSERROR,
                  ES_PROCESS_EXIT);

        fprintf(stderr, "GetLogName error !\n");
    }

    lReturn = DbConnect();
    if (lReturn != 0)
    {
#ifdef _LOG
        printf("OPEN EBBANK DATABASE ERROR lReturn = %d..., EXIT 2\n", lReturn);
#endif

		HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        	"OPEN EBBANK DATABASE ERROR lReturn = %d..., EXIT 2\n", lReturn);

        exit(2);
    }
	HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        	"OPEN DATABASE Ok !\n");

	/*****************************/
   	/* Initial the message queue */
	/*****************************/
	nRet = nCommonMsqAllInit(CI_ERRSVR);
	if (nRet != 0) 
   	{
       	ErrReport(CI_ERRSVR, 
                  	EI_MESSAGEQUEUE, 
                  	0, 
                  	CI_SEVERITY_SYSERROR,
                  	ES_MSGQ_ERR_CONNECT);
        printf("Msqini error !\n");
    }

#ifdef _LOG
	printf("Init:Connect ERRSRV MSGQ success!\n");
#endif

	HtLog(	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__, 
			"Connect ERRSRV MSGQ success!\n");

  	UmsctlPid = (pid_t) 0;

  	while(1)
   	{
		nRet = nCommonMsqRecv (&nDataLen, (char*)&msgerr_buf, 
								&lMsgSource, CI_ERRSVR);
   		
        if (nRet == -1)
        {
           		continue;
        }
		/***
       	if ((msgerr_buf.buf.msg_code == EI_INIT)&&
        	(msgerr_buf.buf.msg_src == CI_UMSCOMM))
        {
           		UmsctlPid = msgerr_buf.buf.msg_subcode;
       	   		CommonGetCurrentTime( sTime );

#ifdef _LOG
	        	printf("receive UMSCTL pid = %d at %s\n", UmsctlPid, sTime);
#endif

				HtLog( logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
	        		"receive UMSCTL pid = %d at %s\n", UmsctlPid, sTime);
        }
		***/

       	vErrProcess( &msgerr_buf.buf, UmsctlPid);
   
   } /* while (1) */
}
    
void vLineErrorApp(struct wd_bsyslog_area *errorbuf)
{
	short line_status;
	long line_code;
	short ret;

#ifdef _LOG
  	printf("Enter into update line status\n");
  	printf("msg_src= %d, errsubcode= %d\n",
		  	errorbuf->msg_src,errorbuf->msg_subcode);
#endif

	HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
  			"Enter into update line status\n");

	HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
  			"msg_src= %d, errsubcode= %d\n",
		  	errorbuf->msg_src,errorbuf->msg_subcode);

	line_code = errorbuf->msg_src;

	line_status = 0;  /*LINE_STATUS_FAIL*/
   	ret = 0;
/* !!!!! NOT COMPLETED
   	ret = SetLineStatus(line_code,line_status);
*/
	if (ret == 0) 
		DbCommitTxn();
   	if ( ret <  0)
   	{
		CommonGetCurrentTime( sTime );

#ifdef _LOG
        printf("line_code=[%d], line_status=[%d]\n", line_code, line_status);
        printf("update the table linestat error %d at %s\n", ret, sTime);
#endif

		HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"line_code=[%d], line_status=[%d]\n", line_code, line_status);

		HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"update the table linestat error %d at %s\n", ret, sTime);

        ErrReport(CI_ERRSVR,
				  EI_DATABASE,
				  ret,
				  CI_SEVERITY_SYSERROR,
                  ES_DB_UPDATE);
   	}

}
                                    
void vErrProcess (struct wd_bsyslog_area *errorbuf, pid_t UmsctlPid)
{                        
  	short ret;

  	CommonGetCurrentTime( sTime );

#ifdef _LOG
  	/*printf("ERRSVR recv a msg at %s\n", sTime);*/
#endif

	HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
  			"ERRSVR recv a msg at %s\n", sTime);
    
	memset ( errorbuf->rec_updt_time,'\0',sizeof(errorbuf->rec_updt_time));
	memcpy ( errorbuf->rec_updt_time,sTime,sizeof(errorbuf->rec_updt_time)-1);

	HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
       		"updt_time %s\n", errorbuf->rec_updt_time );

	/* set time in SYBASE DB format */
	CommonGetCurrentTimeDB(errorbuf->rec_updt_time);
	CommonGetCurrentTimeDB(errorbuf->sys_log_time);

	ret = DbsBSYSLOG(DBS_INSERT , errorbuf);

  	if ( ret != 0 )    
  	{ 
		CommonGetCurrentTime( sTime );

#ifdef _LOG
        printf("insert the table errlog error %d at %s\n", ret, sTime);
#endif

		HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
        		"insert the table errlog error %d at %s\n", ret, sTime);
    }

	if (ret == 0) 
		DbCommitTxn();

	/***
  	if (errorbuf->msg_src == CI_FECOMM || 
		errorbuf->msg_src == CI_FECOMMSCT || 
		errorbuf->msg_src == CI_CONCOMM || 
		errorbuf->msg_src == CI_CONCOMMSCT || 
		errorbuf->msg_src == CI_HSTCOMM || 
		errorbuf->msg_src == CI_HSTCOMMSCT || 
		errorbuf->msg_src == CI_GBASECOMM || 
		errorbuf->msg_src == CI_CNAPSCOMM1 || 		
		errorbuf->msg_src == CI_CNAPSCOMM2 )
	***/
  	if (errorbuf->msg_src == CI_TLRCOMM || 
		errorbuf->msg_src == CI_TLRBDG  || 
		errorbuf->msg_src == CI_MANAGER || 
		errorbuf->msg_src == CI_BDGMNG  || 
		errorbuf->msg_src == CI_TOCTL_SEQ  || 
		errorbuf->msg_src == CI_BASWT   || 
		errorbuf->msg_src == CI_BACMDSND || 
		errorbuf->msg_src == CI_BACOMMSND || 
		errorbuf->msg_src == CI_BACOMMRCV || 
		errorbuf->msg_src == CI_FILESCAN )
		{
			if ((errorbuf->msg_subcode == S_INI)
				||(errorbuf->msg_subcode == S_RESTART))
			{
   				ret = 0;
				if (ret == 0)
					DbCommitTxn();
			}

			if 	(errorbuf->msg_subcode == S_END)
	    		vLineErrorApp(errorbuf);
		}

	if (UmsctlPid != 0)
	{
     	if (kill(UmsctlPid, SIGUSR1) == -1)
       		perror("kill");
      	else
		{
#ifdef _LOG
       		printf("Errsvr send signal to umsctl %d\n", UmsctlPid);
#endif
			HtLog( 	logfile, HT_LOG_MODE_COMPLEX, __FILE__,__LINE__,
          			"Errsvr send signal to umsctl %d\n", UmsctlPid);
		}
	}

}
