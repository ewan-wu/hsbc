#ifndef _ERRSVR_H
#define _ERRSVR_H

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>
#include <string.h>
#include <memory.h>

#include "common.h"
#include "msglog.h"
#include "msgque.h"
#include "wd_incl.h"
#include "glb_def.h"

#define LINE_CODE_L  5 
#define LINE_STATUS_L 2

#define  S_INI      5150
#define  S_RESTART  6150
#define  S_END      7150 /* added by Laura */

#define NORMAL 1
#define FAIL 0

#define _LOG

#endif /* _ERRSVR_H */


